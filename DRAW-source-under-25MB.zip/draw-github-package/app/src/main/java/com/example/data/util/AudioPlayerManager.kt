package com.example.data.util

import android.content.Context
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.net.Uri
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

private const val TAG = "AudioPlayerManager"

/**
 * Singleton Audio Player Manager for smooth audio playback across posts and stories.
 * Enforces single active playback, smooth volume fade-in and fade-out cross-fades,
 * and graceful pause/stop.
 */
object AudioPlayerManager {
    private var mediaPlayer: MediaPlayer? = null
    private val scope = CoroutineScope(Dispatchers.Main)
    private var fadeJob: Job? = null

    private val _currentAudioUrl = MutableStateFlow<String?>(null)
    val currentAudioUrl: StateFlow<String?> = _currentAudioUrl.asStateFlow()

    private val _isPlaying = MutableStateFlow(false)
    val isPlaying: StateFlow<Boolean> = _isPlaying.asStateFlow()

    private val _isMuted = MutableStateFlow(false)
    val isMuted: StateFlow<Boolean> = _isMuted.asStateFlow()

    private val _currentTrackTitle = MutableStateFlow<String>("")
    val currentTrackTitle: StateFlow<String> = _currentTrackTitle.asStateFlow()

    /**
     * Plays audio from remote URL or local URI with smooth fade-in.
     * If another track is currently playing, smoothly fades it out first.
     */
    fun play(context: Context, audioUrlOrUri: String, title: String = "") {
        if (audioUrlOrUri.isBlank()) return
        if (_isMuted.value) return

        // If same audio is already playing, do nothing
        if (_currentAudioUrl.value == audioUrlOrUri && _isPlaying.value) {
            return
        }

        fadeJob?.cancel()
        fadeJob = scope.launch {
            // Fade out current track if playing
            fadeOutCurrent(durationMs = 250L)

            try {
                releasePlayer()
                val player = MediaPlayer().apply {
                    setAudioAttributes(
                        AudioAttributes.Builder()
                            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                            .setUsage(AudioAttributes.USAGE_MEDIA)
                            .build()
                    )
                    if (audioUrlOrUri.startsWith("http://") || audioUrlOrUri.startsWith("https://")) {
                        setDataSource(audioUrlOrUri)
                    } else {
                        setDataSource(context, Uri.parse(audioUrlOrUri))
                    }
                    isLooping = true
                    setVolume(0.0f, 0.0f)
                }

                withContext(Dispatchers.IO) {
                    player.prepare()
                }

                player.start()
                mediaPlayer = player
                _currentAudioUrl.value = audioUrlOrUri
                _currentTrackTitle.value = title
                _isPlaying.value = true

                // Smooth fade-in
                fadeInCurrent(targetVolume = 1.0f, durationMs = 300L)
            } catch (e: Exception) {
                Log.e(TAG, "Failed to play audio: ${e.message}")
                releasePlayer()
                _isPlaying.value = false
                _currentAudioUrl.value = null
            }
        }
    }

    /**
     * Smoothly fades out and stops the current audio.
     */
    fun stop(fade: Boolean = true) {
        fadeJob?.cancel()
        if (fade && mediaPlayer?.isPlaying == true) {
            fadeJob = scope.launch {
                fadeOutCurrent(durationMs = 250L)
                releasePlayer()
                _isPlaying.value = false
                _currentAudioUrl.value = null
                _currentTrackTitle.value = ""
            }
        } else {
            releasePlayer()
            _isPlaying.value = false
            _currentAudioUrl.value = null
            _currentTrackTitle.value = ""
        }
    }

    fun toggleMute() {
        val newMuted = !_isMuted.value
        _isMuted.value = newMuted
        if (newMuted) {
            stop(fade = true)
        }
    }

    private suspend fun fadeOutCurrent(durationMs: Long) {
        val player = mediaPlayer ?: return
        if (!player.isPlaying) return
        val steps = 10
        val stepDelay = durationMs / steps
        for (i in steps downTo 0) {
            val vol = (i / steps.toFloat()).coerceIn(0f, 1f)
            try {
                player.setVolume(vol, vol)
            } catch (_: Exception) {}
            delay(stepDelay)
        }
        try {
            player.pause()
        } catch (_: Exception) {}
    }

    private suspend fun fadeInCurrent(targetVolume: Float, durationMs: Long) {
        val player = mediaPlayer ?: return
        val steps = 10
        val stepDelay = durationMs / steps
        for (i in 0..steps) {
            val vol = (i / steps.toFloat() * targetVolume).coerceIn(0f, 1f)
            try {
                player.setVolume(vol, vol)
            } catch (_: Exception) {}
            delay(stepDelay)
        }
    }

    private fun releasePlayer() {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (_: Exception) {}
        mediaPlayer = null
    }
}
