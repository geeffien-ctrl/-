package com.example.data.network

import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private const val TAG = "GooglePlacesService"

data class GooglePlaceModel(
    val placeId: String,
    val displayName: String,
    val formattedAddress: String,
    val latitude: Double,
    val longitude: Double,
    val primaryType: String,
    val photoReferences: List<String> = emptyList(),
    val attributions: List<String> = emptyList()
)

/**
 * Official Google Places API (New) Client Implementation.
 *
 * NOTE ON MAP ENGINE COMPLIANCE:
 * Google Maps Platform Terms of Service (Sec. 3.2.3 Restrictions Against Showing Places on Alternative Maps)
 * explicitly prohibits displaying Google Places results / photos on top of non-Google map tiles
 * (e.g., OpenFreeMap, OpenStreetMap, or MapLibre).
 *
 * This client provides the official Google Places architecture with Field Masks, place details,
 * and photo attribution builders ready for whenever the official Google Maps SDK is activated.
 */
class GooglePlacesApiService(private val apiKeyProvider: () -> String) {

  private val client = OkHttpClient.Builder()
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(20, TimeUnit.SECONDS)
      .build()

  /**
   * Search nearby places using Google Places API (New) Text Search with Field Masks.
   */
  suspend fun searchNearbyPlaces(
      query: String,
      lat: Double,
      lon: Double,
      radiusMeters: Double = 5000.0
  ): Result<List<GooglePlaceModel>> = withContext(Dispatchers.IO) {
    val apiKey = apiKeyProvider().trim()
    if (apiKey.isBlank()) {
      return@withContext Result.failure(
          IllegalStateException("Google Places API Key is not configured. Please supply a valid key via AI Studio Secrets.")
      )
    }

    try {
      val json = JSONObject().apply {
        put("textQuery", query)
        put("locationBias", JSONObject().apply {
          put("circle", JSONObject().apply {
            put("center", JSONObject().apply {
              put("latitude", lat)
              put("longitude", lon)
            })
            put("radius", radiusMeters)
          })
        })
        put("maxResultCount", 10)
      }

      val body = json.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
      val request = Request.Builder()
          .url("https://places.googleapis.com/v1/places:searchText")
          .header("Content-Type", "application/json")
          .header("X-Goog-Api-Key", apiKey)
          // Mandatory FieldMask to minimize billing and data consumption
          .header("X-Goog-FieldMask", "places.id,places.displayName,places.formattedAddress,places.location,places.primaryType,places.photos")
          .post(body)
          .build()

      val response = client.newCall(request).execute()
      val responseText = response.body?.string() ?: ""

      if (response.isSuccessful) {
        val root = JSONObject(responseText)
        val placesJson = root.optJSONArray("places") ?: JSONArray()
        val list = mutableListOf<GooglePlaceModel>()

        for (i in 0 until placesJson.length()) {
          val p = placesJson.getJSONObject(i)
          val id = p.optString("id")
          val name = p.optJSONObject("displayName")?.optString("text") ?: ""
          val address = p.optString("formattedAddress")
          val loc = p.optJSONObject("location")
          val pLat = loc?.optDouble("latitude") ?: 0.0
          val pLon = loc?.optDouble("longitude") ?: 0.0
          val primaryType = p.optString("primaryType")

          val photos = mutableListOf<String>()
          val attributions = mutableListOf<String>()
          val photosArr = p.optJSONArray("photos")
          if (photosArr != null) {
            for (j in 0 until photosArr.length()) {
              val photoObj = photosArr.getJSONObject(j)
              val photoName = photoObj.optString("name")
              if (photoName.isNotBlank()) {
                photos.add(photoName)
              }
              val authorsArr = photoObj.optJSONArray("authorAttributions")
              if (authorsArr != null) {
                for (k in 0 until authorsArr.length()) {
                  val author = authorsArr.getJSONObject(k).optString("displayName")
                  if (author.isNotBlank()) attributions.add(author)
                }
              }
            }
          }

          list.add(
              GooglePlaceModel(
                  placeId = id,
                  displayName = name,
                  formattedAddress = address,
                  latitude = pLat,
                  longitude = pLon,
                  primaryType = primaryType,
                  photoReferences = photos,
                  attributions = attributions
              )
          )
        }
        Result.success(list)
      } else {
        Log.e(TAG, "Google Places API error: ${response.code} - $responseText")
        Result.failure(Exception("Google Places error: HTTP ${response.code}"))
      }
    } catch (e: Exception) {
      Log.e(TAG, "Network exception calling Google Places", e)
      Result.failure(e)
    }
  }

  /**
   * Builds official Photo URI using photo reference resource name with attribution compliance.
   */
  fun getPhotoUrl(photoResourceName: String, maxWidthPx: Int = 800): String {
    val apiKey = apiKeyProvider().trim()
    if (apiKey.isBlank() || photoResourceName.isBlank()) return ""
    return "https://places.googleapis.com/v1/$photoResourceName/media?maxWidthPx=$maxWidthPx&key=$apiKey"
  }
}
