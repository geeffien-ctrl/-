package com.example.data.network

import com.example.data.model.NominatimResult
import com.example.data.model.OsrmResponse
import com.squareup.moshi.Moshi
import com.squareup.moshi.kotlin.reflect.KotlinJsonAdapterFactory
import okhttp3.Interceptor
import okhttp3.OkHttpClient
import okhttp3.logging.HttpLoggingInterceptor
import retrofit2.Retrofit
import retrofit2.converter.moshi.MoshiConverterFactory
import retrofit2.http.GET
import retrofit2.http.Path
import retrofit2.http.Query
import java.util.concurrent.TimeUnit

interface OsmApiService {
  @GET("https://nominatim.openstreetmap.org/search")
  suspend fun searchPlaces(
      @Query("q") query: String,
      @Query("format") format: String = "json",
      @Query("addressdetails") addressDetails: Int = 1,
      @Query("limit") limit: Int = 8,
      @Query("accept-language") language: String = "en,ar"
  ): List<NominatimResult>

  @GET("https://nominatim.openstreetmap.org/search")
  suspend fun searchPlacesNear(
      @Query("q") query: String,
      @Query("viewbox") viewbox: String,
      @Query("bounded") bounded: Int = 0,
      @Query("format") format: String = "json",
      @Query("addressdetails") addressDetails: Int = 1,
      @Query("limit") limit: Int = 12,
      @Query("accept-language") language: String = "ar,en"
  ): List<NominatimResult>

  @GET("https://nominatim.openstreetmap.org/reverse")
  suspend fun reverseGeocode(
      @Query("lat") lat: Double,
      @Query("lon") lon: Double,
      @Query("format") format: String = "json",
      @Query("addressdetails") addressDetails: Int = 1,
      @Query("accept-language") language: String = "en,ar"
  ): NominatimResult

  @GET("https://router.project-osrm.org/route/v1/driving/{coordinates}")
  suspend fun getRoute(
      @Path(value = "coordinates", encoded = true) coordinates: String, // lon1,lat1;lon2,lat2
      @Query("overview") overview: String = "full",
      @Query("geometries") geometries: String = "geojson",
      @Query("steps") steps: Boolean = true,
      @Query("alternatives") alternatives: String = "true"
  ): OsrmResponse
}

object OsmApiClient {
  private val userAgentInterceptor = Interceptor { chain ->
    val request =
        chain
            .request()
            .newBuilder()
            .header(
                "User-Agent",
                "DRAWNavigationApp/1.0 (Android; com.aistudio.draw.navapp)"
            )
            .build()
    chain.proceed(request)
  }

  private val loggingInterceptor =
      HttpLoggingInterceptor().apply {
        level = HttpLoggingInterceptor.Level.BASIC
      }

  private val okHttpClient =
      OkHttpClient.Builder()
          .addInterceptor(userAgentInterceptor)
          .addInterceptor(loggingInterceptor)
          .connectTimeout(15, TimeUnit.SECONDS)
          .readTimeout(15, TimeUnit.SECONDS)
          .build()

  private val moshi =
      Moshi.Builder()
          .addLast(KotlinJsonAdapterFactory())
          .build()

  val apiService: OsmApiService by lazy {
    Retrofit.Builder()
        .baseUrl("https://nominatim.openstreetmap.org/")
        .client(okHttpClient)
        .addConverterFactory(MoshiConverterFactory.create(moshi))
        .build()
        .create(OsmApiService::class.java)
  }
}
