package com.example.data.repository

import android.content.Context
import android.location.Location
import android.util.Log
import com.example.R
import com.example.data.DrawBrand
import com.example.data.model.AppUser
import com.example.data.model.LiveVehicle
import com.example.data.model.OrderStatus
import com.example.data.model.PlaceComment
import com.example.data.model.ServiceOrder
import com.example.data.model.TaxiColorPresets
import com.example.data.model.TaxiDriverStatus
import com.example.data.model.UserVehicleProfile
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject

private const val TAG = "VehiclesRepo"
private const val PREFS_NAME = "draw_user_vehicle"
private const val KEY_PROFILE = "saved_vehicle_profile_json"
private const val STALE_VEHICLE_TIMEOUT_MS = 120_000L // 2 minutes timeout

class VehiclesRepository(
    private val context: Context? = null
) {
    private val prefs = context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val _userProfileFlow = MutableStateFlow(loadSavedProfile())
    val userProfileFlow = _userProfileFlow.asStateFlow()

    private val db: FirebaseFirestore? by lazy {
        try {
            context?.let { ctx ->
                val dbId = ctx.getString(R.string.firestore_database_id)
                FirebaseFirestore.getInstance(dbId)
            } ?: FirebaseFirestore.getInstance()
        } catch (_: Exception) {
            try {
                FirebaseFirestore.getInstance()
            } catch (_: Exception) {
                null
            }
        }
    }

    fun getLocalProfile(): UserVehicleProfile = _userProfileFlow.value

    fun saveLocalProfile(profile: UserVehicleProfile) {
        _userProfileFlow.value = profile
        try {
            val json = JSONObject().apply {
                put("userId", profile.userId)
                put("vehicleModelId", profile.vehicleModelId)
                put("colorHex", profile.colorHex)
                put("customName", profile.customName)
                put("maker", profile.maker)
                put("model", profile.model)
                put("year", profile.year)
                put("usageType", profile.usageType)
                put("visibilityMode", profile.visibilityMode.id)
                put("isSharingLocation", profile.isSharingLocation)
                put("isAcceptingOrders", profile.isAcceptingOrders)
                put("lastUpdatedAt", profile.lastUpdatedAt)

                // Taxi Attributes
                put("isTaxiOwner", profile.isTaxiOwner)
                put("taxiDriverName", profile.taxiDriverName)
                put("taxiCarModel", profile.taxiCarModel)
                put("taxiFarePerKm", profile.taxiFarePerKm)
                put("taxiColorHex", profile.taxiColorHex)
                put("taxiStatus", profile.taxiStatus.id)
                put("totalLikes", profile.totalLikes)
                put("totalComments", profile.totalComments)
                put("totalCompletedTrips", profile.totalCompletedTrips)
            }
            prefs?.edit()?.putString(KEY_PROFILE, json.toString())?.apply()
        } catch (e: Exception) {
            Log.e(TAG, "Error saving local vehicle profile", e)
        }
    }

    private fun loadSavedProfile(): UserVehicleProfile {
        val raw = prefs?.getString(KEY_PROFILE, null) ?: return UserVehicleProfile()
        return try {
            val json = JSONObject(raw)
            val visModeStr = json.optString("visibilityMode", "")
            val visMode = if (visModeStr.isNotBlank()) {
                com.example.data.model.LocationVisibilityMode.fromId(visModeStr)
            } else if (json.optBoolean("isSharingLocation", false)) {
                com.example.data.model.LocationVisibilityMode.PUBLIC_TO_ALL
            } else {
                com.example.data.model.LocationVisibilityMode.HIDDEN_FROM_OTHERS
            }

            val taxiStatusStr = json.optString("taxiStatus", "available")

            UserVehicleProfile(
                userId = json.optString("userId"),
                vehicleModelId = "taxi_city",
                colorHex = json.optString("taxiColorHex", TaxiColorPresets.YELLOW.hex),
                customName = json.optString("customName"),
                maker = json.optString("maker"),
                model = json.optString("model"),
                year = json.optString("year"),
                usageType = "تاكسي",
                visibilityMode = visMode,
                isSharingLocation = json.optBoolean("isTaxiOwner", false) || visMode == com.example.data.model.LocationVisibilityMode.PUBLIC_TO_ALL,
                isAcceptingOrders = json.optBoolean("isAcceptingOrders", true),
                lastUpdatedAt = json.optLong("lastUpdatedAt", System.currentTimeMillis()),

                isTaxiOwner = json.optBoolean("isTaxiOwner", false),
                taxiDriverName = json.optString("taxiDriverName", ""),
                taxiCarModel = json.optString("taxiCarModel", ""),
                taxiFarePerKm = json.optDouble("taxiFarePerKm", 0.0),
                taxiColorHex = json.optString("taxiColorHex", TaxiColorPresets.YELLOW.hex),
                taxiStatus = TaxiDriverStatus.fromId(taxiStatusStr),
                totalLikes = json.optInt("totalLikes", 0),
                totalComments = json.optInt("totalComments", 0),
                totalCompletedTrips = json.optInt("totalCompletedTrips", 0)
            )
        } catch (e: Exception) {
            UserVehicleProfile()
        }
    }

    suspend fun syncProfileWithFirestore(profile: UserVehicleProfile): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            saveLocalProfile(profile)
            if (profile.userId.isBlank()) return@withContext Result.success(Unit)

            val firestore = db ?: return@withContext Result.success(Unit)
            val isPublic = profile.isTaxiOwner

            val docData = hashMapOf(
                "userId" to profile.userId,
                "vehicleModelId" to "taxi_city",
                "colorHex" to profile.taxiColorHex,
                "customName" to profile.effectiveDriverName,
                "maker" to profile.maker,
                "model" to profile.model,
                "year" to profile.year,
                "usageType" to "تاكسي",
                "visibilityMode" to (if (isPublic) "public" else "hidden"),
                "isSharingLocation" to isPublic,
                "isAcceptingOrders" to (isPublic && profile.taxiStatus == TaxiDriverStatus.AVAILABLE),
                "isTaxiOwner" to profile.isTaxiOwner,
                "taxiDriverName" to profile.effectiveDriverName,
                "taxiCarModel" to profile.effectiveMakeModel,
                "taxiFarePerKm" to profile.taxiFarePerKm,
                "taxiColorHex" to profile.taxiColorHex,
                "taxiStatus" to profile.taxiStatus.id,
                "totalLikes" to profile.totalLikes,
                "totalComments" to profile.totalComments,
                "totalCompletedTrips" to profile.totalCompletedTrips,
                "lastUpdatedAt" to System.currentTimeMillis()
            )
            firestore.collection("user_vehicles").document(profile.userId)
                .set(docData, SetOptions.merge())
                .await()

            // If user turned OFF taxi or hidden, delete from live_vehicles immediately
            if (!isPublic) {
                try {
                    firestore.collection("live_vehicles").document(profile.userId).delete().await()
                } catch (_: Exception) {}
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Failed syncing user vehicle profile to Firestore", e)
            Result.failure(e)
        }
    }

    suspend fun updateLiveVehicleLocation(
        profile: UserVehicleProfile,
        location: Location,
        heading: Float,
        driverName: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        // Taxi must be owned and active to be displayed on map
        if (!profile.isTaxiOwner || profile.userId.isBlank()) {
            return@withContext Result.success(Unit)
        }
        try {
            val firestore = db ?: return@withContext Result.success(Unit)
            val isAvail = profile.taxiStatus == TaxiDriverStatus.AVAILABLE

            val liveData = hashMapOf(
                "id" to profile.userId,
                "driverName" to profile.effectiveDriverName.ifBlank { driverName.ifBlank { "سائق DRAW" } },
                "vehicleModelId" to "taxi_city",
                "colorHex" to profile.taxiColorHex,
                "serviceType" to "تاكسي",
                "maker" to profile.maker,
                "model" to profile.model,
                "latitude" to location.latitude,
                "longitude" to location.longitude,
                "bearing" to heading,
                "speed" to (if (location.hasSpeed()) location.speed else 0f),
                "isSharingLocation" to true,
                "isAcceptingOrders" to isAvail,
                "isTaxiOwner" to true,
                "taxiCarModel" to profile.effectiveMakeModel,
                "taxiColorHex" to profile.taxiColorHex,
                "farePerKm" to profile.taxiFarePerKm,
                "taxiStatus" to profile.taxiStatus.id,
                "likesCount" to profile.totalLikes,
                "commentsCount" to profile.totalComments,
                "completedTripsCount" to profile.totalCompletedTrips,
                "lastUpdatedAt" to System.currentTimeMillis()
            )
            firestore.collection("live_vehicles").document(profile.userId)
                .set(liveData, SetOptions.merge())
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Error updating live vehicle location: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun stopSharingLiveLocation(userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (userId.isBlank()) return@withContext Result.success(Unit)
        try {
            val firestore = db ?: return@withContext Result.success(Unit)
            firestore.collection("live_vehicles").document(userId).delete().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.w(TAG, "Error stopping live location: ${e.message}")
            Result.failure(e)
        }
    }

    suspend fun fetchProfileFromFirestore(userId: String): UserVehicleProfile? = withContext(Dispatchers.IO) {
        if (userId.isBlank()) return@withContext null
        try {
            val firestore = db ?: return@withContext null
            val doc = firestore.collection("user_vehicles").document(userId).get().await()
            if (doc != null && doc.exists()) {
                val isTaxiOwner = doc.getBoolean("isTaxiOwner") ?: false
                val taxiColor = doc.getString("taxiColorHex") ?: doc.getString("colorHex") ?: TaxiColorPresets.YELLOW.hex
                val taxiStatusStr = doc.getString("taxiStatus") ?: "available"

                UserVehicleProfile(
                    userId = userId,
                    vehicleModelId = "taxi_city",
                    colorHex = taxiColor,
                    customName = doc.getString("customName") ?: "",
                    maker = doc.getString("maker") ?: "",
                    model = doc.getString("model") ?: "",
                    year = doc.getString("year") ?: "",
                    usageType = "تاكسي",
                    isSharingLocation = isTaxiOwner,
                    isAcceptingOrders = doc.getBoolean("isAcceptingOrders") ?: true,
                    lastUpdatedAt = doc.getLong("lastUpdatedAt") ?: System.currentTimeMillis(),
                    isTaxiOwner = isTaxiOwner,
                    taxiDriverName = doc.getString("taxiDriverName") ?: doc.getString("driverName") ?: "",
                    taxiCarModel = doc.getString("taxiCarModel") ?: doc.getString("makeModel") ?: "",
                    taxiFarePerKm = doc.getDouble("taxiFarePerKm") ?: 0.0,
                    taxiColorHex = taxiColor,
                    taxiStatus = TaxiDriverStatus.fromId(taxiStatusStr),
                    totalLikes = doc.getLong("totalLikes")?.toInt() ?: 0,
                    totalComments = doc.getLong("totalComments")?.toInt() ?: 0,
                    totalCompletedTrips = doc.getLong("totalCompletedTrips")?.toInt() ?: 0
                )
            } else null
        } catch (e: Exception) {
            Log.w(TAG, "Error fetching profile from Firestore", e)
            null
        }
    }

    suspend fun publishLiveLocation(
        profile: UserVehicleProfile,
        lat: Double,
        lng: Double,
        bearing: Double,
        speedKmh: Double
    ): Result<Unit> {
        val loc = Location("draw_gps").apply {
            latitude = lat
            longitude = lng
            this.bearing = bearing.toFloat()
            speed = (speedKmh / 3.6).toFloat()
        }
        return updateLiveVehicleLocation(profile, loc, bearing.toFloat(), profile.effectiveDriverName)
    }

    suspend fun createOrder(order: ServiceOrder): Result<ServiceOrder> = createServiceOrder(order)

    fun observeLiveVehicles(currentUserId: String = ""): Flow<List<LiveVehicle>> = callbackFlow {
        val firestore = db
        if (firestore == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }

        val listener = firestore.collection("live_vehicles")
            .whereEqualTo("isSharingLocation", true)
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Live vehicles snapshot warning: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val now = System.currentTimeMillis()
                    val vehicles = mutableListOf<LiveVehicle>()
                    for (doc in snapshot.documents) {
                        try {
                            val id = doc.getString("id") ?: doc.id
                            // Exclude current user's own taxi (rendered via local GPS)
                            if (id == currentUserId) continue

                            val lastUpdate = doc.getLong("lastUpdatedAt") ?: 0L
                            // Stale eviction: Discard vehicles not updated in past 2 minutes
                            if (now - lastUpdate > STALE_VEHICLE_TIMEOUT_MS) continue

                            val isTaxiOwner = doc.getBoolean("isTaxiOwner") ?: true
                            val taxiStatus = doc.getString("taxiStatus") ?: "available"
                            if (!isTaxiOwner || taxiStatus == "unavailable") continue

                            val taxiColor = doc.getString("taxiColorHex") ?: doc.getString("colorHex") ?: TaxiColorPresets.YELLOW.hex
                            val fare = doc.getDouble("farePerKm") ?: doc.getDouble("taxiFarePerKm") ?: 0.0

                            val v = LiveVehicle(
                                id = id,
                                driverName = doc.getString("driverName") ?: doc.getString("taxiDriverName") ?: "سائق تاكسي",
                                vehicleModelId = "taxi_city",
                                colorHex = taxiColor,
                                serviceType = "تاكسي",
                                maker = doc.getString("maker") ?: "",
                                model = doc.getString("model") ?: "",
                                latitude = doc.getDouble("latitude") ?: 0.0,
                                longitude = doc.getDouble("longitude") ?: 0.0,
                                bearing = doc.getDouble("bearing")?.toFloat() ?: 0f,
                                speed = doc.getDouble("speed")?.toFloat() ?: 0f,
                                isSharingLocation = true,
                                isAcceptingOrders = doc.getBoolean("isAcceptingOrders") ?: true,
                                lastUpdatedAt = lastUpdate,
                                isTaxiOwner = true,
                                taxiCarModel = doc.getString("taxiCarModel") ?: "",
                                taxiColorHex = taxiColor,
                                farePerKm = fare,
                                taxiStatus = taxiStatus,
                                likesCount = doc.getLong("likesCount")?.toInt() ?: 0,
                                commentsCount = doc.getLong("commentsCount")?.toInt() ?: 0,
                                completedTripsCount = doc.getLong("completedTripsCount")?.toInt() ?: 0
                            )
                            vehicles.add(v)
                        } catch (e: Exception) {
                            Log.e(TAG, "Error parsing live vehicle doc ${doc.id}", e)
                        }
                    }
                    trySend(vehicles)
                }
            }
        awaitClose { listener.remove() }
    }

    suspend fun createServiceOrder(order: ServiceOrder): Result<ServiceOrder> = withContext(Dispatchers.IO) {
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            val orderData = hashMapOf(
                "id" to order.id,
                "passengerUid" to order.passengerUid,
                "passengerName" to order.passengerName,
                "driverUid" to order.driverUid,
                "driverName" to order.driverName,
                "serviceType" to "تاكسي",
                "vehicleModelId" to "taxi_city",
                "pickupLat" to order.pickupLat,
                "pickupLng" to order.pickupLng,
                "pickupAddress" to order.pickupAddress,
                "dropoffLat" to order.dropoffLat,
                "dropoffLng" to order.dropoffLng,
                "dropoffAddress" to order.dropoffAddress,
                "status" to order.status.id,
                "driverLat" to order.driverLat,
                "driverLng" to order.driverLng,
                "estimatedDistanceMeters" to order.estimatedDistanceMeters,
                "notes" to order.notes,
                "farePerKm" to order.farePerKm,
                "estimatedFare" to order.estimatedFare,
                "finalFare" to order.finalFare,
                "taxiColorHex" to order.taxiColorHex,
                "taxiCarModel" to order.taxiCarModel,
                "createdAt" to order.createdAt,
                "updatedAt" to order.updatedAt
            )
            firestore.collection("service_orders").document(order.id)
                .set(orderData)
                .await()
            Result.success(order)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating service order", e)
            Result.failure(e)
        }
    }

    suspend fun updateOrderStatus(
        orderId: String,
        newStatus: OrderStatus,
        driverLat: Double? = null,
        driverLng: Double? = null
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            val updates = hashMapOf<String, Any>(
                "status" to newStatus.id,
                "updatedAt" to System.currentTimeMillis()
            )
            if (driverLat != null && driverLng != null) {
                updates["driverLat"] = driverLat
                updates["driverLng"] = driverLng
            }
            firestore.collection("service_orders").document(orderId)
                .update(updates)
                .await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating order status $orderId", e)
            Result.failure(e)
        }
    }

    suspend fun updateOrderPickupLocation(orderId: String, latitude: Double, longitude: Double): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            firestore.collection("service_orders").document(orderId).update(
                mapOf("pickupLat" to latitude, "pickupLng" to longitude, "updatedAt" to System.currentTimeMillis())
            ).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error updating pickup location $orderId", e)
            Result.failure(e)
        }
    }

    fun getTaxiCommentsFlow(driverId: String): Flow<List<PlaceComment>> = callbackFlow {
        val firestore = db
        if (firestore == null || driverId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val listener = firestore.collection("live_vehicles").document(driverId).collection("comments")
            .addSnapshotListener { snapshot, error ->
                if (error != null || snapshot == null) return@addSnapshotListener
                val comments = snapshot.documents.mapNotNull { doc ->
                    val text = doc.getString("text") ?: return@mapNotNull null
                    PlaceComment(doc.id, "taxi_$driverId", doc.getString("userId") ?: "", doc.getString("userName") ?: "مستخدم DRAW", DrawBrand.AVATAR_URI, text, doc.getLong("likesCount") ?: 0L, doc.getLong("createdAt") ?: System.currentTimeMillis())
                }.sortedBy { it.createdAt }
                trySend(comments)
            }
        awaitClose { listener.remove() }
    }

    suspend fun addTaxiComment(driverId: String, currentUser: AppUser, text: String): Result<Unit> = withContext(Dispatchers.IO) {
        if (currentUser.isAnonymous || currentUser.uid.isBlank()) return@withContext Result.failure(IllegalAccessException("Guest users cannot comment"))
        val value = text.trim()
        if (value.isBlank()) return@withContext Result.failure(IllegalArgumentException("التعليق فارغ"))
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            firestore.collection("live_vehicles").document(driverId).collection("comments").document()
                .set(mapOf("userId" to currentUser.uid, "userName" to (currentUser.displayName ?: "مستخدم DRAW"), "userPhotoUrl" to DrawBrand.AVATAR_URI, "text" to value, "likesCount" to 0L, "createdAt" to System.currentTimeMillis())).await()
            firestore.collection("live_vehicles").document(driverId).update("commentsCount", FieldValue.increment(1)).await()
            Result.success(Unit)
        } catch (e: Exception) { Log.e(TAG, "Error adding taxi comment", e); Result.failure(e) }
    }

    suspend fun deleteTaxiComment(driverId: String, commentId: String, userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            val ref = firestore.collection("live_vehicles").document(driverId).collection("comments").document(commentId)
            if (ref.get().await().getString("userId") != userId) return@withContext Result.failure(IllegalAccessException("لا يمكنك حذف تعليق مستخدم آخر"))
            ref.delete().await()
            firestore.collection("live_vehicles").document(driverId).update("commentsCount", FieldValue.increment(-1)).await()
            Result.success(Unit)
        } catch (e: Exception) { Log.e(TAG, "Error deleting taxi comment", e); Result.failure(e) }
    }

    suspend fun toggleTaxiCommentLike(driverId: String, commentId: String, userId: String, liked: Boolean): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            val comment = firestore.collection("live_vehicles").document(driverId).collection("comments").document(commentId)
            val like = comment.collection("likes").document(userId)
            if (liked) { like.set(mapOf("userId" to userId, "createdAt" to System.currentTimeMillis())).await(); comment.update("likesCount", FieldValue.increment(1)).await() }
            else { like.delete().await(); comment.update("likesCount", FieldValue.increment(-1)).await() }
            Result.success(Unit)
        } catch (e: Exception) { Log.e(TAG, "Error toggling taxi comment like", e); Result.failure(e) }
    }

    /**
     * Rate and review after completed trip:
     * Increments driver likes and comments count in Firestore.
     */
    suspend fun submitTripReview(
        orderId: String,
        driverId: String,
        liked: Boolean,
        comment: String?
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            val updates = hashMapOf<String, Any>(
                "passengerLiked" to liked,
                "updatedAt" to System.currentTimeMillis()
            )
            if (!comment.isNullOrBlank()) {
                updates["passengerComment"] = comment
            }
            firestore.collection("service_orders").document(orderId).update(updates).await()

            // Update driver's total stats
            val driverRef = firestore.collection("user_vehicles").document(driverId)
            val driverLiveRef = firestore.collection("live_vehicles").document(driverId)
            val incUpdates = hashMapOf<String, Any>(
                "totalCompletedTrips" to FieldValue.increment(1)
            )
            if (liked) {
                incUpdates["totalLikes"] = FieldValue.increment(1)
            }
            if (!comment.isNullOrBlank()) {
                incUpdates["totalComments"] = FieldValue.increment(1)
            }
            try { driverRef.update(incUpdates).await() } catch (_: Exception) {}
            try { driverLiveRef.update(incUpdates).await() } catch (_: Exception) {}

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error submitting trip review", e)
            Result.failure(e)
        }
    }

    suspend fun toggleDriverLike(driverId: String, userId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            val likeRef = firestore.collection("live_vehicles").document(driverId).collection("likes").document(userId)
            val liked = likeRef.get().await().exists()
            if (liked) {
                likeRef.delete().await()
                firestore.collection("live_vehicles").document(driverId).update("likesCount", FieldValue.increment(-1)).await()
            } else {
                likeRef.set(mapOf("userId" to userId, "createdAt" to System.currentTimeMillis())).await()
                firestore.collection("live_vehicles").document(driverId).update("likesCount", FieldValue.increment(1)).await()
            }
            Result.success(!liked)
        } catch (e: Exception) {
            Log.e(TAG, "Error toggling driver like", e)
            Result.failure(e)
        }
    }

    suspend fun addDriverComment(driverId: String, userId: String, userName: String, text: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            val ref = firestore.collection("live_vehicles").document(driverId).collection("comments").document()
            ref.set(mapOf("userId" to userId, "userName" to userName, "text" to text.trim(), "createdAt" to System.currentTimeMillis())).await()
            firestore.collection("live_vehicles").document(driverId).update("commentsCount", FieldValue.increment(1)).await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error adding driver comment", e)
            Result.failure(e)
        }
    }

    /**
     * Submit Report against driver or user for misconduct/fake profile.
     */
    suspend fun submitReport(
        orderId: String,
        targetUserId: String,
        reporterUid: String,
        reason: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val firestore = db ?: return@withContext Result.failure(Exception("Firestore not ready"))
            val reportDoc = hashMapOf(
                "orderId" to orderId,
                "targetUserId" to targetUserId,
                "reporterUid" to reporterUid,
                "reason" to reason,
                "timestamp" to System.currentTimeMillis()
            )
            firestore.collection("reports").add(reportDoc).await()
            try {
                firestore.collection("service_orders").document(orderId).update(
                    mapOf("isReported" to true, "reportedReason" to reason)
                ).await()
            } catch (_: Exception) {}
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error submitting report", e)
            Result.failure(e)
        }
    }

    fun observeOrdersForUser(userId: String): Flow<List<ServiceOrder>> = callbackFlow {
        if (userId.isBlank()) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val firestore = db
        if (firestore == null) {
            trySend(emptyList())
            close()
            return@callbackFlow
        }
        val listener = firestore.collection("service_orders")
            .addSnapshotListener { snapshot, error ->
                if (error != null) {
                    Log.w(TAG, "Service orders snapshot error: ${error.message}")
                    return@addSnapshotListener
                }
                if (snapshot != null) {
                    val list = mutableListOf<ServiceOrder>()
                    for (doc in snapshot.documents) {
                        val pUid = doc.getString("passengerUid") ?: ""
                        val dUid = doc.getString("driverUid") ?: ""
                        if (pUid == userId || dUid == userId) {
                            val statusId = doc.getString("status") ?: OrderStatus.WAITING_APPROVAL.id
                            val status = OrderStatus.values().firstOrNull { it.id == statusId } ?: OrderStatus.WAITING_APPROVAL
                            list.add(
                                ServiceOrder(
                                    id = doc.id,
                                    passengerUid = pUid,
                                    passengerName = doc.getString("passengerName") ?: "الراكب",
                                    driverUid = dUid,
                                    driverName = doc.getString("driverName") ?: "السائق",
                                    serviceType = "تاكسي",
                                    vehicleModelId = "taxi_city",
                                    pickupLat = doc.getDouble("pickupLat") ?: 0.0,
                                    pickupLng = doc.getDouble("pickupLng") ?: 0.0,
                                    pickupAddress = doc.getString("pickupAddress") ?: "",
                                    dropoffLat = doc.getDouble("dropoffLat"),
                                    dropoffLng = doc.getDouble("dropoffLng"),
                                    dropoffAddress = doc.getString("dropoffAddress"),
                                    status = status,
                                    driverLat = doc.getDouble("driverLat"),
                                    driverLng = doc.getDouble("driverLng"),
                                    estimatedDistanceMeters = doc.getDouble("estimatedDistanceMeters")?.toFloat() ?: 0f,
                                    notes = doc.getString("notes") ?: "",
                                    farePerKm = doc.getDouble("farePerKm") ?: 0.0,
                                    estimatedFare = doc.getDouble("estimatedFare") ?: 0.0,
                                    finalFare = doc.getDouble("finalFare") ?: 0.0,
                                    passengerLiked = doc.getBoolean("passengerLiked"),
                                    passengerComment = doc.getString("passengerComment"),
                                    taxiColorHex = doc.getString("taxiColorHex") ?: TaxiColorPresets.YELLOW.hex,
                                    taxiCarModel = doc.getString("taxiCarModel") ?: "",
                                    isReported = doc.getBoolean("isReported") ?: false,
                                    reportedReason = doc.getString("reportedReason"),
                                    createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                                    updatedAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
                                )
                            )
                        }
                    }
                    trySend(list)
                }
            }
        awaitClose { listener.remove() }
    }
}
