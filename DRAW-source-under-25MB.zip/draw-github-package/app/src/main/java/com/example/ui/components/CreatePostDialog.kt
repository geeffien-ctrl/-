package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.VideoLibrary
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.AudioTrack
import com.example.data.repository.AuthSessionManager
import com.example.data.repository.PostsRepository
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import kotlinx.coroutines.launch

@Composable
fun CreatePostDialog(
    onDismiss: () -> Unit,
    onPostCreated: () -> Unit
) {
    val context = LocalContext.current
    val postsRepository = remember { PostsRepository(context) }
    val scope = rememberCoroutineScope()
    val currentUser = remember { AuthSessionManager.getInstance(context).currentUser.value }

    var postType by remember { mutableStateOf("image") } // "image" or "video"
    val selectedImages = remember { mutableStateListOf<Uri>() }
    var selectedVideoUri by remember { mutableStateOf<Uri?>(null) }
    var selectedAudio by remember { mutableStateOf<AudioTrack?>(null) }
    var isAudioPickerOpen by remember { mutableStateOf(false) }
    var caption by remember { mutableStateOf("") }
    var isPublishing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 10)
    ) { uris ->
        if (uris.isNotEmpty()) {
            selectedImages.clear()
            selectedImages.addAll(uris)
        }
    }

    val videoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri ->
        if (uri != null) {
            selectedVideoUri = uri
            selectedAudio = null // Video uses its original audio
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val shape = RoundedCornerShape(26.dp)
        Surface(
            shape = shape,
            color = Color.White,
            shadowElevation = 16.dp,
            modifier = Modifier
                .fillMaxWidth(0.94f)
                .heightIn(max = 700.dp)
                .padding(vertical = 16.dp)
                .testTag("create_post_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "نشر محتوى جديد",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = DrawTextNearBlack
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE5E5EA))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF3A3A3C),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Post Type Segmented Switcher (صور / فيديو)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(44.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFF2F2F7))
                        .padding(3.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (postType == "image") Color.White else Color.Transparent)
                            .clickable {
                                postType = "image"
                                selectedVideoUri = null
                            }
                            .testTag("type_photos_segment"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "منشور صور",
                            fontSize = 13.5.sp,
                            fontWeight = if (postType == "image") FontWeight.Bold else FontWeight.Medium,
                            color = if (postType == "image") DrawRed else DrawTextSecondary
                        )
                    }
                    Box(
                        modifier = Modifier
                            .weight(1f)
                            .clip(RoundedCornerShape(12.dp))
                            .background(if (postType == "video") Color.White else Color.Transparent)
                            .clickable {
                                postType = "video"
                                selectedImages.clear()
                                selectedAudio = null
                            }
                            .testTag("type_video_segment"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "منشور فيديو (Reels)",
                            fontSize = 13.5.sp,
                            fontWeight = if (postType == "video") FontWeight.Bold else FontWeight.Medium,
                            color = if (postType == "video") DrawRed else DrawTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Media Picker Box
                if (postType == "image") {
                    if (selectedImages.isEmpty()) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0xFFF9F9FB))
                                .border(1.5.dp, Color(0x18000000), RoundedCornerShape(18.dp))
                                .clickable {
                                    photoPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                }
                                .testTag("pick_photos_box"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.AddPhotoAlternate,
                                    contentDescription = null,
                                    tint = DrawRed,
                                    modifier = Modifier.size(38.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "اختيار صورة أو عدة صور من المعرض",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DrawTextNearBlack
                                )
                                Text(
                                    text = "يمكنك اختيار حتى 10 صور في معرض واحد",
                                    fontSize = 12.sp,
                                    color = DrawTextSecondary
                                )
                            }
                        }
                    } else {
                        // Horizontal strip of selected photos
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .horizontalScroll(rememberScrollState()),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            selectedImages.forEachIndexed { idx, uri ->
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .border(1.dp, Color(0x20000000), RoundedCornerShape(14.dp))
                                ) {
                                    AsyncImage(
                                        model = uri,
                                        contentDescription = "Photo $idx",
                                        contentScale = ContentScale.Crop,
                                        modifier = Modifier.fillMaxSize()
                                    )
                                    IconButton(
                                        onClick = { selectedImages.removeAt(idx) },
                                        modifier = Modifier
                                            .align(Alignment.TopEnd)
                                            .padding(4.dp)
                                            .size(22.dp)
                                            .clip(CircleShape)
                                            .background(Color.Black.copy(alpha = 0.6f))
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.Close,
                                            contentDescription = "Remove",
                                            tint = Color.White,
                                            modifier = Modifier.size(14.dp)
                                        )
                                    }
                                }
                            }
                            if (selectedImages.size < 10) {
                                Box(
                                    modifier = Modifier
                                        .size(100.dp)
                                        .clip(RoundedCornerShape(14.dp))
                                        .background(Color(0xFFF2F2F7))
                                        .clickable {
                                            photoPickerLauncher.launch(
                                                PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                            )
                                        },
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.AddPhotoAlternate,
                                        contentDescription = "Add More",
                                        tint = DrawRed,
                                        modifier = Modifier.size(28.dp)
                                    )
                                }
                            }
                        }
                    }
                } else {
                    // Video Picker
                    if (selectedVideoUri == null) {
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(160.dp)
                                .clip(RoundedCornerShape(18.dp))
                                .background(Color(0xFFF9F9FB))
                                .border(1.5.dp, Color(0x18000000), RoundedCornerShape(18.dp))
                            .clickable {
                                videoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.VideoOnly)
                                )
                            }
                            .testTag("pick_video_box"),
                            contentAlignment = Alignment.Center
                        ) {
                            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                Icon(
                                    imageVector = Icons.Default.VideoLibrary,
                                    contentDescription = null,
                                    tint = DrawRed,
                                    modifier = Modifier.size(38.dp)
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "اختيار فيديو من المعرض",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DrawTextNearBlack
                                )
                                Text(
                                    text = "يحتفظ الفيديو بصوته الأصلي",
                                    fontSize = 12.sp,
                                    color = DrawTextSecondary
                                )
                            }
                        }
                    } else {
                        // Selected video preview container
                        Box(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(140.dp)
                                .clip(RoundedCornerShape(16.dp))
                                .background(Color(0xFF1C1C1E)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayCircle,
                                contentDescription = "Video Ready",
                                tint = Color.White,
                                modifier = Modifier.size(48.dp)
                            )
                            Text(
                                text = "تم اختيار الفيديو بنجاح",
                                color = Color.White,
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier
                                    .align(Alignment.BottomCenter)
                                    .padding(bottom = 12.dp)
                            )
                            IconButton(
                                onClick = { selectedVideoUri = null },
                                modifier = Modifier
                                    .align(Alignment.TopEnd)
                                    .padding(8.dp)
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(Color.Black.copy(alpha = 0.5f))
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "Remove",
                                    tint = Color.White,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Optional Audio Button for Image Posts
                if (postType == "image") {
                    Surface(
                        onClick = { isAudioPickerOpen = true },
                        shape = RoundedCornerShape(16.dp),
                        color = if (selectedAudio != null) Color(0xFFFFECEB) else Color(0xFFF2F2F7),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (selectedAudio != null) DrawRed else Color(0x14000000)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("post_sound_button")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp, vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = if (selectedAudio != null) Icons.Default.GraphicEq else Icons.Default.MusicNote,
                                contentDescription = "Sound",
                                tint = if (selectedAudio != null) DrawRed else DrawTextNearBlack,
                                modifier = Modifier.size(22.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = if (selectedAudio != null) selectedAudio!!.title else "الصوت (اختياري)",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = if (selectedAudio != null) DrawRed else DrawTextNearBlack
                                )
                                Text(
                                    text = if (selectedAudio != null) "مرفق بالمنشور" else "إضافة مسار صوتي من الجهاز",
                                    fontSize = 11.5.sp,
                                    color = DrawTextSecondary
                                )
                            }
                            if (selectedAudio != null) {
                                IconButton(
                                    onClick = { selectedAudio = null },
                                    modifier = Modifier.size(26.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "حذف الصوت",
                                        tint = DrawRed,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                    Spacer(modifier = Modifier.height(12.dp))
                }

                // Caption Input Field
                OutlinedTextField(
                    value = caption,
                    onValueChange = { caption = it },
                    placeholder = { Text("اكتب شرحاً أو وصفاً للمنشور...", fontSize = 13.5.sp) },
                    minLines = 3,
                    maxLines = 5,
                    shape = RoundedCornerShape(16.dp),
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = DrawRed,
                        unfocusedBorderColor = Color(0xFFE5E5EA),
                        focusedContainerColor = Color(0xFFF9F9FB),
                        unfocusedContainerColor = Color(0xFFF9F9FB)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("post_caption_input")
                )

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = errorMessage!!,
                        color = DrawRed,
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(18.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        enabled = !isPublishing,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("إلغاء", color = Color(0xFF8E8E93), fontWeight = FontWeight.SemiBold)
                    }

                    val canSubmit = (postType == "image" && selectedImages.isNotEmpty()) ||
                            (postType == "video" && selectedVideoUri != null)

                    Button(
                        onClick = {
                            if (currentUser == null) {
                                errorMessage = "يرجى تسجيل الدخول أولاً"
                                return@Button
                            }
                            if (!canSubmit) {
                                errorMessage = "يرجى اختيار وسائط للمنشور"
                                return@Button
                            }
                            isPublishing = true
                            errorMessage = null
                            scope.launch {
                                val res = postsRepository.createPost(
                                    currentUser = currentUser,
                                    caption = caption,
                                    type = postType,
                                    imageUris = selectedImages,
                                    videoUri = selectedVideoUri,
                                    audioTrack = selectedAudio,
                                    context = context
                                )
                                isPublishing = false
                                res.onSuccess {
                                    onPostCreated()
                                    onDismiss()
                                }.onFailure { e ->
                                    errorMessage = "فشل نشر المنشور: ${e.message}"
                                }
                            }
                        },
                        enabled = canSubmit && !isPublishing,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp)
                            .testTag("publish_post_submit_button")
                    ) {
                        if (isPublishing) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري النشر...", color = Color.White, fontWeight = FontWeight.Bold)
                        } else {
                            Text("نشر الآن", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                        }
                    }
                }
            }
        }
    }

    if (isAudioPickerOpen) {
        AudioPickerSheet(
            currentAudio = selectedAudio,
            onAudioSelected = { track ->
                selectedAudio = track
                isAudioPickerOpen = false
            },
            onDismiss = { isAudioPickerOpen = false }
        )
    }
}
