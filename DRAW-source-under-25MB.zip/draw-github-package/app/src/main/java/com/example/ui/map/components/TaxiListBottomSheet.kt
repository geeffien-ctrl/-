package com.example.ui.map.components

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LiveVehicle
import com.example.ui.theme.DrawGreen
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TaxiListBottomSheet(
    vehicles: List<LiveVehicle>,
    onVehicleSelected: (LiveVehicle) -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 26.dp, topEnd = 26.dp),
        modifier = modifier
    ) {
        Column(modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Column {
                    Text("التكاسي المتاحة", fontSize = 20.sp, fontWeight = FontWeight.Bold, color = DrawTextNearBlack)
                    Text("مرتبة من الأقرب إلى الأبعد", fontSize = 12.sp, color = DrawTextSecondary)
                }
                IconButton(onClick = onDismiss) {
                    Icon(Icons.Default.Close, contentDescription = "إغلاق", tint = DrawTextSecondary)
                }
            }
            Spacer(Modifier.height(8.dp))
            if (vehicles.isEmpty()) {
                Surface(
                    modifier = Modifier.fillMaxWidth().padding(vertical = 22.dp),
                    shape = RoundedCornerShape(16.dp),
                    color = Color(0xFFF8FAFC),
                    border = BorderStroke(1.dp, Color(0xFFE2E8F0))
                ) {
                    Text("لا توجد تكاسي متاحة حالياً", modifier = Modifier.padding(20.dp), color = DrawTextSecondary)
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = Modifier.fillMaxWidth()) {
                    items(vehicles, key = { it.effectiveUserId }) { vehicle ->
                        Surface(
                            modifier = Modifier.fillMaxWidth().clickable { onVehicleSelected(vehicle) },
                            shape = RoundedCornerShape(16.dp),
                            color = Color.White,
                            border = BorderStroke(1.dp, Color(0xFFE5E7EB)),
                            shadowElevation = 2.dp
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth().padding(14.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.LocalTaxi, contentDescription = null, tint = DrawGreen, modifier = Modifier.size(28.dp))
                                Spacer(Modifier.size(12.dp))
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(vehicle.driverName.ifBlank { "سائق تاكسي" }, fontSize = 15.sp, fontWeight = FontWeight.Bold, color = Color.Black)
                                    Text(vehicle.effectiveCarModel, fontSize = 12.5.sp, color = Color.Black)
                                    Text(
                                        if (vehicle.farePerKm > 0) "${vehicle.farePerKm.toInt()} لكل كم" else "السعر غير محدد من السائق",
                                        fontSize = 12.sp, color = if (vehicle.farePerKm > 0) DrawGreen else DrawTextSecondary, fontWeight = FontWeight.SemiBold
                                    )
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.NearMe, contentDescription = null, tint = DrawTextSecondary, modifier = Modifier.size(16.dp))
                                    Spacer(Modifier.size(3.dp))
                                    Text(formatTaxiDistance(vehicle.distanceToUserMeters), fontSize = 12.sp, color = DrawTextNearBlack, fontWeight = FontWeight.SemiBold)
                                }
                            }
                        }
                    }
                    item { Spacer(Modifier.height(12.dp)) }
                }
            }
        }
    }
}

private fun formatTaxiDistance(meters: Float): String = when {
    meters <= 0f -> "قريب منك"
    meters < 1000f -> "${meters.toInt()} م"
    else -> "%.1f كم".format(meters / 1000f)
}
