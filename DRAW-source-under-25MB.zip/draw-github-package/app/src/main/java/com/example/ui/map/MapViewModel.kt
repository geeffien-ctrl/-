package com.example.ui.map

import android.content.Context
import android.location.Location
import android.net.Uri
import android.util.Log
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.NominatimResult
import com.example.data.model.OsrmRoute
import com.example.data.model.PlaceComment
import com.example.data.model.PlaceRating
import com.example.data.model.PublicPlace
import com.example.data.model.SavedPlace
import com.example.data.model.UserNotification
import com.example.data.network.OpenRouterService
import com.example.data.repository.AiAssistantRepository
import com.example.data.repository.AiConversationRepository
import com.example.data.repository.AiConversationSession
import com.example.data.repository.AiPlaceSuggestion
import com.example.data.repository.DiscoveredPlaceCandidate
import com.example.data.repository.LocationRepository
import com.example.data.repository.NavigationRepository
import com.example.data.repository.NearbyPlacesSearchService
import com.example.data.repository.OrientationSensorRepository
import com.example.data.repository.PlaceInteractionsRepository
import com.example.data.repository.PublicPlacesRepository
import com.example.data.repository.SaveFavoriteResult
import com.example.data.util.ImageCompressUtil
import com.example.ui.map.components.PlaceIconItem
import com.example.ui.map.components.PlaceIconRegistry
import com.example.ui.map.navigation.NavigationVoiceSpeaker
import com.example.ui.map.navigation.RouteOption
import com.example.data.model.AppUser
import com.example.data.model.LiveVehicle
import com.example.data.model.OrderStatus
import com.example.data.model.RoadReport
import com.example.data.model.RoadReportType
import com.example.data.model.ServiceOrder
import com.example.data.model.TaxiDriverStatus
import com.example.data.model.UserVehicleProfile
import com.example.data.repository.AuthSessionManager
import com.example.data.repository.RoadReportsRepository
import com.example.data.repository.VehiclesRepository
import com.example.ui.map.components.RoadReportVerificationSession
import com.example.ui.map.components.VerificationPhase
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import java.util.UUID

private const val TAG = "MapViewModel"

data class AiAssistantMessageUi(
    val id: String = UUID.randomUUID().toString(),
    val sender: String, // "user" or "assistant"
    val text: String,
    val suggestedPlace: AiPlaceSuggestion? = null
)

/**
 * Proposal for an alternative route detour when a road hazard is detected on the driver's active path.
 */
data class HazardDetourProposal(
    val hazardReport: RoadReport,
    val hazardDistanceMeters: Float,
    val proposedAlternativeRoute: OsrmRoute,
    val currentRouteDistanceMeters: Double,
    val proposedRouteDistanceMeters: Double,
    val currentRouteDurationSec: Double,
    val proposedRouteDurationSec: Double,
    val distanceDiffMeters: Double,
    val durationDiffSeconds: Double,
    val timestamp: Long = System.currentTimeMillis()
)

data class MapUiState(
    val userLocation: Location? = null,
    val currentHeading: Float = 0.0f,
    val hasLocationPermission: Boolean = false,
    val searchQuery: String = "",
    val searchResults: List<NominatimResult> = emptyList(),
    val isSearching: Boolean = false,
    val selectedPlace: NominatimResult? = null,
    val currentRoute: OsrmRoute? = null,
    val routeOptions: List<RouteOption> = emptyList(),
    val selectedRouteIndex: Int = 0,
    val isCalculatingRoute: Boolean = false,
    val isNavigating: Boolean = false,
    val currentStepIndex: Int = 0,
    val hasArrived: Boolean = false,
    val arrivedDestinationName: String = "",
    val isVoiceGuidanceMuted: Boolean = false,
    val is3DMode: Boolean = false,
    val centerOnUserTrigger: Long = 0L,

    // Public community places from Firebase (Interactive Posts)
    val publicPlaces: List<PublicPlace> = emptyList(),
    val knownPlaces: List<PublicPlace> = emptyList(),
    val selectedPublicPlace: PublicPlace? = null,
    val isCurrentPlaceLiked: Boolean = false,
    val currentPlaceLikesCount: Long = 0L,
    val currentPlaceCommentsCount: Long = 0L,
    val isCommentsSheetOpen: Boolean = false,
    val placeComments: List<PlaceComment> = emptyList(),
    val userLikedCommentIds: Set<String> = emptySet(),
    val isSubmittingComment: Boolean = false,

    // Notifications Center
    val isNotificationsSheetOpen: Boolean = false,
    val userNotifications: List<UserNotification> = emptyList(),
    val unreadNotificationsCount: Int = 0,

    // Explore 60 Categories
    val isExploreSheetOpen: Boolean = false,
    val isSearchingNearby: Boolean = false,
    val discoveredCandidate: DiscoveredPlaceCandidate? = null,

    // Add place flow
    val isSavedPlacesSheetOpen: Boolean = false,
    val isAddCustomPlaceDialogOpen: Boolean = false,
    val customPlaceName: String = "",
    val customPlaceAddress: String = "",
    val customPlaceDescription: String = "",
    val customPlaceCategory: String = "food",
    val customPlaceIconId: String = "food_restaurant",
    val customPlaceLat: Double = 0.0,
    val customPlaceLng: Double = 0.0,
    val customPlaceImageUris: List<Uri> = emptyList(),
    val isPublishingPlace: Boolean = false,

    // Local / Account Favorites
    val savedFavorites: List<SavedPlace> = emptyList(),
    val isProfileMenuOpen: Boolean = false,
    val isSavingPlace: Boolean = false,
    val isGuestPublishRestricted: Boolean = false,
    val guestRestrictionMessage: String = "أنت تستخدم التطبيق كضيف، سجّل الدخول أو أنشئ حساباً حتى تتمكن من النشر والتفاعل",
    val errorMessage: String? = null,
    val statusMessage: String? = null,
    val isRefreshingAppData: Boolean = false,

    // DRAW Voice & AI Assistant
    val isAiAssistantOpen: Boolean = false,
    val isAiAssistantLoading: Boolean = false,
    val isVoiceListening: Boolean = false,
    val aiAssistantMessages: List<AiAssistantMessageUi> = emptyList(),
    val aiConversationSessions: List<AiConversationSession> = emptyList(),
    val currentAiConversationId: String = "",
    val isAiSpeaking: Boolean = false,
    val currentlySpeakingAiMessageId: String? = null,
    val isAiTtsAutoPlayEnabled: Boolean = true,

    // Road Reports (9 types + 1 clear action)
    val roadReports: List<RoadReport> = emptyList(),
    val isReportsSheetOpen: Boolean = false,
    val selectedRoadReport: RoadReport? = null,
    val verificationSession: RoadReportVerificationSession? = null,

    // Vehicles, Sharing & Services System
    val liveVehicles: List<LiveVehicle> = emptyList(),
    val userVehicleProfile: UserVehicleProfile? = null,
    val selectedDriverVehicle: LiveVehicle? = null,
    val isDriverProfileOpen: Boolean = false,
    val isTaxiListOpen: Boolean = false,
    val incomingOrder: ServiceOrder? = null,
    val activeOrder: ServiceOrder? = null,
    val isTaxiCommentsSheetOpen: Boolean = false,
    val taxiCommentsDriverId: String = "",
    val taxiComments: List<PlaceComment> = emptyList(),
    val taxiUserLikedCommentIds: Set<String> = emptySet(),

    // Hazard Detour & Alternative Route Proposal
    val activeHazardProposal: HazardDetourProposal? = null,
    val dismissedHazardIds: Set<String> = emptySet(),
    val detourProposalCount: Int = 0
) {
  val allMapPlaces: List<PublicPlace>
    get() {
      val result = publicPlaces.toMutableList()
      for (kp in knownPlaces) {
        val exists = result.any { it.id == kp.id || (Math.abs(it.latitude - kp.latitude) < 0.0003 && Math.abs(it.longitude - kp.longitude) < 0.0003) }
        if (!exists) {
          result.add(kp)
        }
      }
      return result
    }
}

class MapViewModel(
    private val locationRepository: LocationRepository,
    private val navigationRepository: NavigationRepository,
    private val publicPlacesRepository: PublicPlacesRepository = PublicPlacesRepository(),
    private val nearbyPlacesSearchService: NearbyPlacesSearchService = NearbyPlacesSearchService(publicPlacesRepository),
    private val aiAssistantRepository: AiAssistantRepository = AiAssistantRepository(),
    private val aiConversationRepository: AiConversationRepository? = null,
    private val openRouterService: OpenRouterService? = null,
    private val placeInteractionsRepository: PlaceInteractionsRepository = PlaceInteractionsRepository(),
    private val navigationVoiceSpeaker: NavigationVoiceSpeaker? = null,
    private val orientationSensorRepository: OrientationSensorRepository = OrientationSensorRepository(locationRepository.context),
    private val roadReportsRepository: RoadReportsRepository = RoadReportsRepository(locationRepository.context),
    private val vehiclesRepository: VehiclesRepository = VehiclesRepository(locationRepository.context),
    private val authSessionManager: AuthSessionManager = AuthSessionManager.getInstance(locationRepository.context)
) : ViewModel() {

  private val _uiState = MutableStateFlow(MapUiState())
  val uiState: StateFlow<MapUiState> = _uiState.asStateFlow()

  private var searchJob: Job? = null
  private var locationUpdatesJob: Job? = null
  private var headingJob: Job? = null
  private var viewportFetchJob: Job? = null
  private var placeLikeJob: Job? = null
  private var placeCommentsJob: Job? = null
  private var commentLikesJob: Job? = null
  private var notificationsJob: Job? = null
  private var roadReportsJob: Job? = null
  private var liveVehiclesJob: Job? = null
  private var ordersJob: Job? = null
  private var taxiCommentsJob: Job? = null
  private var ordersObservedUid: String? = null
  private var lastPickupSyncAt = 0L
  private var lastDriverRouteRefreshAt = 0L
  private val orderTimeoutJobs = mutableMapOf<String, Job>()
  private var lastRoutedPickup: Triple<String, Double, Double>? = null
  private var lastVehiclePublishTime = 0L
  private var lastKnownTaxiStatusWasActive = false

  init {
    performOneTimeMapContentClean()
    checkPermissionAndFetchLocation()
    observeSensorHeading()
    observePublicPlaces()
    observeVoiceSpeakerState()
    observeRoadReports()
    observeLiveVehiclesAndOrders()
  }

  private fun performOneTimeMapContentClean() {
    val prefs = locationRepository.context.getSharedPreferences("draw_map_cleanup_prefs", Context.MODE_PRIVATE)
    val hasCleaned = prefs.getBoolean("has_performed_map_cleanup_v7", false)
    if (!hasCleaned) {
      viewModelScope.launch {
        try {
          publicPlacesRepository.purgeAllPlacesFromFirestoreAndLocal()
          roadReportsRepository.purgeAllReportsFromFirestoreAndLocal()
          _uiState.update { it.copy(publicPlaces = emptyList(), roadReports = emptyList(), knownPlaces = emptyList()) }
          prefs.edit().putBoolean("has_performed_map_cleanup_v7", true).apply()
          Log.d(TAG, "Map user content cleaned successfully from Firestore and local cache (v7)")
        } catch (e: Exception) {
          Log.e(TAG, "Error performing map content clean", e)
        }
      }
    }
  }

  fun deleteRoadReport(reportId: String, currentUserId: String) {
    viewModelScope.launch {
      val result = roadReportsRepository.deleteReport(reportId, currentUserId)
      if (result.isSuccess) {
        _uiState.update {
          it.copy(
              selectedRoadReport = null,
              verificationSession = null,
              statusMessage = "تم حذف البلاغ بنجاح"
          )
        }
      } else {
        _uiState.update {
          it.copy(
              statusMessage = "فشل حذف البلاغ: ${result.exceptionOrNull()?.message ?: "خطأ غير معروف"}"
          )
        }
      }
    }
  }

  private fun observeVoiceSpeakerState() {
    if (navigationVoiceSpeaker != null) {
      viewModelScope.launch {
        navigationVoiceSpeaker.isSpeaking.collect { speaking ->
          _uiState.update { it.copy(isAiSpeaking = speaking) }
        }
      }
      viewModelScope.launch {
        navigationVoiceSpeaker.currentSpeakingUtteranceId.collect { id ->
          _uiState.update { it.copy(currentlySpeakingAiMessageId = id) }
        }
      }
    }
  }

  private fun observePublicPlaces() {
    viewModelScope.launch {
      try {
        publicPlacesRepository.getPublicPlacesFlow().collect { places ->
          _uiState.update { it.copy(publicPlaces = places) }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error observing public places", e)
      }
    }
  }

  fun checkPermissionAndFetchLocation(autoCenter: Boolean = false) {
    val hasPermission = locationRepository.hasLocationPermission()
    _uiState.update { it.copy(hasLocationPermission = hasPermission) }
    if (hasPermission) {
      viewModelScope.launch {
        val loc = locationRepository.getCurrentLocation()
        if (loc != null) {
          _uiState.update { it.copy(userLocation = loc) }
          if (autoCenter) {
            centerOnUser()
          }
        }
      }
      startContinuousLocationUpdates()
    }
  }

  private var lastLocationForBearing: Location? = null
  private var currentComputedBearing: Float = 0.0f
  private var currentSensorHeading: Float = 0.0f
  private var lastEmittedHeading: Float = 0.0f
  private var lastHeadingEmitTime: Long = 0L
  private var arrivalConfirmationCount: Int = 0
  private var offRouteCount: Int = 0
  private var lastRerouteTimeMs: Long = 0L
  private var minDistanceToDestReached: Float = Float.MAX_VALUE

  private fun observeSensorHeading() {
    headingJob?.cancel()
    headingJob = viewModelScope.launch {
      orientationSensorRepository.getHeadingUpdates().collect { heading ->
        currentSensorHeading = heading
        // During active navigation, if the user is stationary or moving slowly (< 1.0 m/s),
        // use device compass to rotate heading smoothly (throttled to protect event loop)
        if (_uiState.value.isNavigating) {
          val loc = _uiState.value.userLocation
          val isMoving = loc != null && loc.hasSpeed() && loc.speed >= 1.0f
          if (!isMoving) {
            val now = System.currentTimeMillis()
            val angleDiff = kotlin.math.abs(heading - lastEmittedHeading)
            if ((angleDiff >= 3.0f || now - lastHeadingEmitTime >= 400L) && now - lastHeadingEmitTime >= 150L) {
              lastEmittedHeading = heading
              lastHeadingEmitTime = now
              _uiState.update { it.copy(currentHeading = heading) }
            }
          }
        }
      }
    }
  }

  private fun startContinuousLocationUpdates() {
    locationUpdatesJob?.cancel()
    locationUpdatesJob = viewModelScope.launch {
      locationRepository.getLocationUpdates(1000L).collect { location ->
        val isMoving = location.hasSpeed() && location.speed >= 1.0f
        if (isMoving && location.hasBearing() && location.bearing != 0.0f) {
          currentComputedBearing = location.bearing
          lastLocationForBearing = location
        } else if (!isMoving && currentSensorHeading > 0.0f) {
          currentComputedBearing = currentSensorHeading
        } else {
          val last = lastLocationForBearing
          if (last != null) {
            val dist = location.distanceTo(last)
            if (dist >= 1.5f) {
              currentComputedBearing = last.bearingTo(location)
              lastLocationForBearing = location
            }
          } else {
            lastLocationForBearing = location
          }
        }
        location.bearing = currentComputedBearing
        val activeHeading = if (isMoving && location.hasBearing() && location.bearing != 0.0f) {
          location.bearing
        } else if (currentSensorHeading > 0.0f) {
          currentSensorHeading
        } else {
          currentComputedBearing
        }
        lastEmittedHeading = activeHeading
        _uiState.update {
          it.copy(
              userLocation = location,
              currentHeading = activeHeading
          )
        }
        refreshDriverPickupRoute(location)
        checkArrivalOnLocationChanged(location)
        checkOffRouteAndReroute(location)
        checkRouteHazardsAndProposeAlternative(location)
        processReportVerificationOnLocation(location)
        syncPassengerPickupLocation(location)
        publishUserVehicleLocation(location)
      }
    }
  }

  private fun checkArrivalOnLocationChanged(location: Location) {
    if (!_uiState.value.isNavigating) return
    val dest = _uiState.value.selectedPlace ?: return
    val results = FloatArray(1)
    Location.distanceBetween(
        location.latitude,
        location.longitude,
        dest.latitude,
        dest.longitude,
        results
    )
    val distance = results[0]
    val accuracy = if (location.hasAccuracy()) location.accuracy else 20.0f
    // Never trigger arrival on inaccurate GPS fix
    if (accuracy > 35.0f) return

    // If within 15 meters, or confirmed twice within 25 meters:
    if (distance <= 15.0f || (distance <= 25.0f && ++arrivalConfirmationCount >= 2)) {
      arrivalConfirmationCount = 0
      triggerArrival()
    } else if (distance > 35.0f) {
      arrivalConfirmationCount = 0
    }
  }

  fun triggerReroute(userLat: Double? = null, userLng: Double? = null) {
    val dest = _uiState.value.selectedPlace ?: return
    val loc = _uiState.value.userLocation ?: return
    val now = System.currentTimeMillis()
    if (now - lastRerouteTimeMs < 3500L) return
    lastRerouteTimeMs = now
    performAutoReroute(loc, dest)
  }

  private fun checkOffRouteAndReroute(location: Location) {
    if (!_uiState.value.isNavigating && _uiState.value.currentRoute == null) return
    val route = _uiState.value.currentRoute ?: return
    val dest = _uiState.value.selectedPlace ?: return
    val coords = route.geometry?.coordinates ?: return
    if (coords.size < 2) return

    // Disregard inaccurate fixes for off-route check
    if (location.hasAccuracy() && location.accuracy > 30.0f) return

    val now = System.currentTimeMillis()
    if (now - lastRerouteTimeMs < 3500L) return

    // Check distance to destination to detect reverse movement
    val distResults = FloatArray(1)
    Location.distanceBetween(
        location.latitude, location.longitude,
        dest.latitude, dest.longitude,
        distResults
    )
    val currentDistToDest = distResults[0]
    if (minDistanceToDestReached == Float.MAX_VALUE || currentDistToDest < minDistanceToDestReached) {
      minDistanceToDestReached = currentDistToDest
    } else if (currentDistToDest > minDistanceToDestReached + 25.0f) {
      // User moved backwards away from destination! Recalculate route immediately to extend path
      minDistanceToDestReached = currentDistToDest
      lastRerouteTimeMs = now
      performAutoReroute(location, dest)
      return
    }

    var minDistance = Float.MAX_VALUE
    for (i in 0 until coords.size - 1) {
      val c1 = coords[i]
      val c2 = coords[i + 1]
      val dist = distanceToSegmentMeters(
          location.latitude, location.longitude,
          c1[1], c1[0],
          c2[1], c2[0]
      )
      if (dist < minDistance) {
        minDistance = dist
      }
    }

    if (minDistance > 45.0f) {
      offRouteCount++
      if (offRouteCount >= 2) {
        offRouteCount = 0
        lastRerouteTimeMs = now
        performAutoReroute(location, dest)
      }
    } else {
      offRouteCount = 0
    }
  }

  private fun performAutoReroute(location: Location, destination: NominatimResult) {
    viewModelScope.launch {
      navigationVoiceSpeaker?.speakStepInstruction("جارٍ تحديث المسار")
      _uiState.update { it.copy(statusMessage = "جارٍ تحديث المسار وتمديده...") }
      val response = navigationRepository.getRoute(
          startLat = location.latitude,
          startLon = location.longitude,
          endLat = destination.latitude,
          endLon = destination.longitude
      )
      val rawRoutes = response?.routes ?: emptyList()
      if (rawRoutes.isNotEmpty()) {
        minDistanceToDestReached = Float.MAX_VALUE
        val sorted = rawRoutes.sortedBy { it.distance }.take(4)
        val colorConfigs = listOf(
            Triple("#007AFF", "المسار الأزرق", "أقصر مسار"),
            Triple("#E50914", "المسار الأحمر", "ثاني أقصر مسار"),
            Triple("#FF9500", "المسار البرتقالي", "ثالث أقصر مسار"),
            Triple("#FFCC00", "المسار الأصفر", "رابع أقصر مسار")
        )
        val options = sorted.mapIndexed { idx, r ->
          val (hex, name, rank) = colorConfigs[idx]
          RouteOption(idx, hex, name, rank, r)
        }
        val newRoute = options[0].route
        _uiState.update {
          it.copy(
              currentRoute = newRoute,
              routeOptions = options,
              selectedRouteIndex = 0,
              currentStepIndex = 0,
              statusMessage = "تم تحديث المسار بنجاح"
          )
        }
        navigationVoiceSpeaker?.speakRouteSelected(options[0])
        val firstStep = newRoute.legs.firstOrNull()?.steps?.firstOrNull()
        val instruction = firstStep?.maneuver?.instruction ?: firstStep?.name
        if (!instruction.isNullOrBlank()) {
          navigationVoiceSpeaker?.speakStepInstruction(instruction)
        }
      } else {
        _uiState.update { it.copy(statusMessage = null) }
      }
    }
  }

  private fun distanceToSegmentMeters(
      pLat: Double, pLon: Double,
      aLat: Double, aLon: Double,
      bLat: Double, bLon: Double
  ): Float {
    val latMetersPerDeg = 111320.0
    val lonMetersPerDeg = 111320.0 * kotlin.math.cos(Math.toRadians(pLat))

    val px = (pLon - aLon) * lonMetersPerDeg
    val py = (pLat - aLat) * latMetersPerDeg
    val bx = (bLon - aLon) * lonMetersPerDeg
    val by = (bLat - aLat) * latMetersPerDeg

    val segmentLenSq = bx * bx + by * by
    if (segmentLenSq == 0.0) {
      return kotlin.math.sqrt(px * px + py * py).toFloat()
    }

    val t = ((px * bx + py * by) / segmentLenSq).coerceIn(0.0, 1.0)
    val projX = bx * t
    val projY = by * t
    val dx = px - projX
    val dy = py - projY
    return kotlin.math.sqrt(dx * dx + dy * dy).toFloat()
  }

  private var lastHazardCheckTimeMs = 0L

  private fun checkRouteHazardsAndProposeAlternative(location: Location) {
    if (!_uiState.value.isNavigating && _uiState.value.currentRoute == null) return
    if (_uiState.value.activeHazardProposal != null) return // A proposal is already pending driver decision
    if (_uiState.value.detourProposalCount >= 3) return // Cap at 3 proposals to prevent annoying driver

    val now = System.currentTimeMillis()
    if (now - lastHazardCheckTimeMs < 4000L) return
    lastHazardCheckTimeMs = now

    val route = _uiState.value.currentRoute ?: return
    val coords = route.geometry?.coordinates ?: return
    if (coords.size < 2) return

    val reports = _uiState.value.roadReports.filter { !it.isCleared }
    if (reports.isEmpty()) return

    val dismissed = _uiState.value.dismissedHazardIds

    for (report in reports) {
      if (dismissed.contains(report.id)) continue

      val userDistResults = FloatArray(1)
      Location.distanceBetween(location.latitude, location.longitude, report.latitude, report.longitude, userDistResults)
      val distToUser = userDistResults[0]
      // Only alert for hazards ahead on journey (between 40m and 12,000m)
      if (distToUser < 40f || distToUser > 12000f) continue

      var minDistanceToPolyline = Float.MAX_VALUE
      for (i in 0 until coords.size - 1) {
        val c1 = coords[i]
        val c2 = coords[i + 1]
        val dist = distanceToSegmentMeters(
            report.latitude, report.longitude,
            c1[1], c1[0],
            c2[1], c2[0]
        )
        if (dist < minDistanceToPolyline) {
          minDistanceToPolyline = dist
        }
      }

      // If hazard is within 55m of active polyline
      if (minDistanceToPolyline <= 55f) {
        proposeDetourForHazard(report, distToUser, route, location)
        break
      }
    }
  }

  private fun proposeDetourForHazard(
      report: RoadReport,
      distToHazard: Float,
      currentRoute: OsrmRoute,
      userLoc: Location
  ) {
    // 1. Look for existing route options that avoid this hazard and do NOT pass through a ROAD_CLOSED
    val closedReports = _uiState.value.roadReports.filter { !it.isCleared && it.type == com.example.data.model.RoadReportType.ROAD_CLOSED }
    val candidateOption = _uiState.value.routeOptions.firstOrNull { opt ->
      opt.route != currentRoute && (opt.route.geometry?.coordinates?.none { c ->
        val distToThisHazard = distanceToSegmentMeters(report.latitude, report.longitude, c[1], c[0], c[1], c[0])
        val passesThroughClosedRoad = closedReports.any { cr ->
          distanceToSegmentMeters(cr.latitude, cr.longitude, c[1], c[0], c[1], c[0]) <= 60f
        }
        distToThisHazard <= 75f || passesThroughClosedRoad
      } ?: true)
    }

    if (candidateOption != null) {
      val alternative = candidateOption.route
      val curDist = currentRoute.distance
      val curDur = currentRoute.duration
      val altDist = alternative.distance
      val altDur = alternative.duration
      val proposal = HazardDetourProposal(
          hazardReport = report,
          hazardDistanceMeters = distToHazard,
          proposedAlternativeRoute = alternative,
          currentRouteDistanceMeters = curDist,
          proposedRouteDistanceMeters = altDist,
          currentRouteDurationSec = curDur,
          proposedRouteDurationSec = altDur,
          distanceDiffMeters = altDist - curDist,
          durationDiffSeconds = altDur - curDur
      )
      _uiState.update {
        it.copy(
            activeHazardProposal = proposal,
            detourProposalCount = it.detourProposalCount + 1
        )
      }
      navigationVoiceSpeaker?.speakStepInstruction("تنبيه: تم رصد ${report.type.titleArabic} على مسارك، يتوفر مسار بديل مقترح")
    } else {
      // 2. Request alternative route from navigation engine
      val dest = _uiState.value.selectedPlace ?: return
      viewModelScope.launch {
        val response = navigationRepository.getRoute(
            startLat = userLoc.latitude,
            startLon = userLoc.longitude,
            endLat = dest.latitude,
            endLon = dest.longitude
        )
        val validAlternative = response?.routes?.firstOrNull { r ->
          r != currentRoute && (r.geometry?.coordinates?.none { c ->
            val distToThisHazard = distanceToSegmentMeters(report.latitude, report.longitude, c[1], c[0], c[1], c[0])
            val passesThroughClosed = closedReports.any { cr ->
              distanceToSegmentMeters(cr.latitude, cr.longitude, c[1], c[0], c[1], c[0]) <= 60f
            }
            distToThisHazard <= 75f || passesThroughClosed
          } ?: true)
        }

        if (validAlternative != null && validAlternative.distance > 0) {
          val curDist = currentRoute.distance
          val curDur = currentRoute.duration
          val altDist = validAlternative.distance
          val altDur = validAlternative.duration
          val proposal = HazardDetourProposal(
              hazardReport = report,
              hazardDistanceMeters = distToHazard,
              proposedAlternativeRoute = validAlternative,
              currentRouteDistanceMeters = curDist,
              proposedRouteDistanceMeters = altDist,
              currentRouteDurationSec = curDur,
              proposedRouteDurationSec = altDur,
              distanceDiffMeters = altDist - curDist,
              durationDiffSeconds = altDur - curDur
          )
          _uiState.update {
            it.copy(
                activeHazardProposal = proposal,
                detourProposalCount = it.detourProposalCount + 1
            )
          }
          navigationVoiceSpeaker?.speakStepInstruction("تنبيه: تم رصد ${report.type.titleArabic} على مسارك، يتوفر مسار بديل مقترح")
        }
      }
    }
  }

  fun acceptDetourProposal() {
    val proposal = _uiState.value.activeHazardProposal ?: return
    val newRoute = proposal.proposedAlternativeRoute
    _uiState.update {
      it.copy(
          currentRoute = newRoute,
          activeHazardProposal = null,
          currentStepIndex = 0,
          statusMessage = "تم اعتماد المسار البديل وتجنب الخطر بنجاح"
      )
    }
    navigationVoiceSpeaker?.speakStepInstruction("تم اعتماد المسار البديل بنجاح")
  }

  fun dismissDetourProposal() {
    val proposal = _uiState.value.activeHazardProposal ?: return
    _uiState.update {
      it.copy(
          activeHazardProposal = null,
          dismissedHazardIds = it.dismissedHazardIds + proposal.hazardReport.id
      )
    }
  }

  fun onSearchQueryChanged(query: String) {
    _uiState.update { it.copy(searchQuery = query) }
    searchJob?.cancel()
    if (query.trim().length >= 2) {
      searchJob = viewModelScope.launch {
        delay(400)
        _uiState.update { it.copy(isSearching = true) }
        val results = navigationRepository.searchPlaces(query)
        _uiState.update {
          it.copy(
              searchResults = results,
              isSearching = false
          )
        }
      }
    } else {
      _uiState.update { it.copy(searchResults = emptyList(), isSearching = false) }
    }
  }

  fun selectPlace(place: NominatimResult, calculateRouteImmediately: Boolean = true) {
    _uiState.update {
      it.copy(
          selectedPlace = place,
          selectedPublicPlace = null,
          discoveredCandidate = null,
          searchResults = emptyList(),
          searchQuery = place.shortTitle
      )
    }
    if (calculateRouteImmediately) {
      calculateRouteToPlace(place)
    }
  }

  fun selectLocationFromCoordinates(lat: Double, lon: Double, title: String? = null) {
    // 1. Instantly place destination pin at exact tapped coordinates with zero lag
    val initialDisplay = title ?: String.format("%.5f, %.5f", lat, lon)
    val initialPlace = NominatimResult.fromCoordinates(
        lat = lat,
        lon = lon,
        title = initialDisplay,
        isDirectMapTap = true
    )
    _uiState.update {
      it.copy(
          selectedPlace = initialPlace,
          selectedPublicPlace = null,
          discoveredCandidate = null,
          searchQuery = initialPlace.shortTitle
      )
    }

    // 2. Reverse geocode asynchronously without snapping away from tapped coordinates
    viewModelScope.launch {
      val reverseResult = navigationRepository.reverseGeocode(lat, lon)
      val finalPlace = if (reverseResult != null) {
        val resolvedTitle = if (!title.isNullOrBlank()) title else reverseResult.displayName
        // CRITICAL: Keep exact tapped lat/lon so the pin never jumps to a neighborhood centroid
        reverseResult.copy(
            latStr = lat.toString(),
            lonStr = lon.toString(),
            name = if (!title.isNullOrBlank()) title else reverseResult.name,
            displayName = resolvedTitle,
            isDirectMapTap = true
        )
      } else {
        initialPlace
      }
      _uiState.update {
        it.copy(
            selectedPlace = finalPlace,
            searchQuery = finalPlace.shortTitle
        )
      }
    }
  }

  fun calculateRouteToPlace(place: NominatimResult) {
    val userLoc = _uiState.value.userLocation
    if (userLoc == null) {
      _uiState.update { it.copy(errorMessage = "يرجى تفعيل وتحديد موقعك الحالي لحساب المسار.") }
      return
    }

    viewModelScope.launch {
      _uiState.update { it.copy(isCalculatingRoute = true, errorMessage = null, hasArrived = false) }
      val response = navigationRepository.getRoute(
          startLat = userLoc.latitude,
          startLon = userLoc.longitude,
          endLat = place.latitude,
          endLon = place.longitude
      )
      val rawRoutes = response?.routes ?: emptyList()
      if (rawRoutes.isNotEmpty()) {
        // Order strictly by distance ascending:
        // 1. Blue (#007AFF) - Shortest
        // 2. Red (#E50914) - 2nd shortest
        // 3. Orange (#FF9500) - 3rd shortest
        // 4. Yellow (#FFCC00) - 4th shortest
        val sorted = rawRoutes.sortedBy { it.distance }.take(4)
        val colorConfigs = listOf(
            Triple("#007AFF", "المسار الأزرق", "أقصر مسار"),
            Triple("#E50914", "المسار الأحمر", "ثاني أقصر مسار"),
            Triple("#FF9500", "المسار البرتقالي", "ثالث أقصر مسار"),
            Triple("#FFCC00", "المسار الأصفر", "رابع أقصر مسار")
        )
        val options = sorted.mapIndexed { idx, r ->
          val (hex, name, rank) = colorConfigs[idx]
          RouteOption(
              index = idx,
              colorHex = hex,
              colorNameArabic = name,
              rankDescriptionArabic = rank,
              route = r
          )
        }
        _uiState.update {
          it.copy(
              routeOptions = options,
              selectedRouteIndex = if (options.size > 1) -1 else 0,
              currentRoute = options[0].route,
              isCalculatingRoute = false,
              isNavigating = false,
              currentStepIndex = 0,
              hasArrived = false
          )
        }
        navigationVoiceSpeaker?.speakRoutesDiscovered(options)
      } else {
        val errorMsg = when {
          response == null -> "تعذر الاتصال بخدمة المسارات. يرجى التحقق من اتصال الإنترنت."
          response.code == "NoRoute" -> "لا يوجد طريق بري متاح بين موقعك وهذه الوجهة."
          else -> "تعذر حساب مسار قيادة إلى هذه الوجهة المحددة."
        }
        _uiState.update {
          it.copy(
              isCalculatingRoute = false,
              errorMessage = errorMsg
          )
        }
      }
    }
  }

  fun selectRouteOption(index: Int) {
    val opt = _uiState.value.routeOptions.find { it.index == index } ?: return
    _uiState.update {
      it.copy(
          selectedRouteIndex = index,
          currentRoute = opt.route
      )
    }
    navigationVoiceSpeaker?.speakRouteSelected(opt)
  }

  fun startNavigation() {
    val currentIndex = if (_uiState.value.selectedRouteIndex >= 0) _uiState.value.selectedRouteIndex else 0
    val opt = _uiState.value.routeOptions.find { it.index == currentIndex }
        ?: _uiState.value.routeOptions.firstOrNull()
    val route = opt?.route ?: _uiState.value.currentRoute ?: return
    _uiState.update {
      it.copy(
          isNavigating = true,
          selectedRouteIndex = currentIndex,
          currentRoute = route,
          currentStepIndex = 0,
          hasArrived = false
      )
    }
    val userLoc = _uiState.value.userLocation
    val coords = route.geometry?.coordinates
    if (!coords.isNullOrEmpty() && coords.size > 1 && userLoc != null) {
      val nextCoord = coords[1]
      val nextLoc = Location("").apply {
        longitude = nextCoord[0]
        latitude = nextCoord[1]
      }
      currentComputedBearing = userLoc.bearingTo(nextLoc)
      val updatedLoc = Location(userLoc).apply {
        bearing = currentComputedBearing
      }
      _uiState.update { it.copy(userLocation = updatedLoc) }
    }
    if (opt != null) {
      navigationVoiceSpeaker?.speakRouteSelected(opt)
    }
    val firstStep = route.legs.firstOrNull()?.steps?.firstOrNull()
    val firstInstruction = firstStep?.maneuver?.instruction ?: firstStep?.name
    if (!firstInstruction.isNullOrBlank()) {
      navigationVoiceSpeaker?.speakStepInstruction(firstInstruction)
    }
  }

  fun stopNavigation() {
    navigationVoiceSpeaker?.stop()
    _uiState.update {
      it.copy(
          isNavigating = false,
          currentStepIndex = 0,
          activeHazardProposal = null,
          detourProposalCount = 0
      )
    }
  }

  fun triggerArrival() {
    navigationVoiceSpeaker?.stop()
    navigationVoiceSpeaker?.speakArrival()
    val destTitle = _uiState.value.selectedPublicPlace?.title
        ?: _uiState.value.discoveredCandidate?.title
        ?: _uiState.value.selectedPlace?.shortTitle
        ?: "وجهتك"

    _uiState.update {
      it.copy(
          isNavigating = false,
          hasArrived = true,
          arrivedDestinationName = destTitle,
          currentRoute = null,
          routeOptions = emptyList(),
          selectedRouteIndex = -1,
          selectedPlace = null,
          selectedPublicPlace = null,
          discoveredCandidate = null,
          currentStepIndex = 0,
          activeHazardProposal = null,
          detourProposalCount = 0
      )
    }
  }

  fun dismissArrival() {
    _uiState.update { it.copy(hasArrived = false) }
  }

  fun toggleVoiceGuidanceMute() {
    val nextMuted = !_uiState.value.isVoiceGuidanceMuted
    navigationVoiceSpeaker?.setMuted(nextMuted)
    _uiState.update { it.copy(isVoiceGuidanceMuted = nextMuted) }
  }

  fun nextNavigationStep() {
    val route = _uiState.value.currentRoute ?: return
    val steps = route.legs.firstOrNull()?.steps ?: emptyList()
    if (_uiState.value.currentStepIndex < steps.size - 1) {
      val nextIdx = _uiState.value.currentStepIndex + 1
      _uiState.update { it.copy(currentStepIndex = nextIdx) }
      val step = steps[nextIdx]
      val instruction = step.maneuver?.instruction ?: step.name
      if (!instruction.isNullOrBlank()) {
        navigationVoiceSpeaker?.speakStepInstruction(instruction)
      }
    } else {
      triggerArrival()
    }
  }

  fun clearSelection() {
    navigationVoiceSpeaker?.stop()
    _uiState.update {
      it.copy(
          selectedPlace = null,
          selectedPublicPlace = null,
          discoveredCandidate = null,
          currentRoute = null,
          routeOptions = emptyList(),
          selectedRouteIndex = -1,
          isNavigating = false,
          currentStepIndex = 0,
          hasArrived = false,
          searchQuery = "",
          searchResults = emptyList(),
          activeHazardProposal = null,
          detourProposalCount = 0
      )
    }
  }

  fun set3DMode(enabled: Boolean) {
    _uiState.update { it.copy(is3DMode = enabled) }
  }

  fun toggle3DMode() {
    _uiState.update { it.copy(is3DMode = !it.is3DMode) }
  }

  fun centerOnUser() {
    _uiState.update { it.copy(centerOnUserTrigger = System.currentTimeMillis()) }
  }

  fun requestCenterOnUser() = centerOnUser()

  fun onExploreCategorySelected(iconItem: PlaceIconItem) = onCategoryIconSelected(iconItem)

  fun toggleProfileMenu() {
    _uiState.update { it.copy(isProfileMenuOpen = !it.isProfileMenuOpen) }
  }

  // --- Viewport Camera Changes (Respecting OpenStreetMap Nominatim Rate Limits) ---

  fun onMapBoundsChanged(minLat: Double, maxLat: Double, minLng: Double, maxLng: Double) {
    viewportFetchJob?.cancel()
    // Intentionally avoid blasting automatic HTTP requests to Nominatim on every camera move.
    // Places are queried explicitly when the user taps an Explore category or searches,
    // protecting the application from IP rate-limiting (HTTP 429).
  }

  // --- Explore 60 Categories Flow ---

  fun openExploreSheet() {
    _uiState.update { it.copy(isExploreSheetOpen = true) }
  }

  fun closeExploreSheet() {
    _uiState.update { it.copy(isExploreSheetOpen = false) }
  }

  fun onCategoryIconSelected(iconItem: PlaceIconItem) {
    closeExploreSheet()
    val userLoc = _uiState.value.userLocation
    if (userLoc == null) {
      _uiState.update {
        it.copy(errorMessage = "يرجى تفعيل الموقع الحالي وتحديده أولاً لاستكشاف الأماكن القريبة.")
      }
      return
    }

    viewModelScope.launch {
      _uiState.update {
        it.copy(
            isSearchingNearby = true,
            statusMessage = "جاري البحث عن أقرب «${iconItem.nameArabic}»...",
            errorMessage = null
        )
      }

      val result = nearbyPlacesSearchService.findNearestPlaces(
          userLat = userLoc.latitude,
          userLon = userLoc.longitude,
          iconItem = iconItem,
          allCommunityPlaces = _uiState.value.publicPlaces,
          userSavedPlaces = _uiState.value.savedFavorites
      )

      result.fold(
          onSuccess = { candidates ->
            val topCandidate = candidates.firstOrNull()
            if (topCandidate != null) {
              val nominatimEquiv = NominatimResult.fromCoordinates(
                  lat = topCandidate.latitude,
                  lon = topCandidate.longitude,
                  title = topCandidate.title
              )
              _uiState.update {
                it.copy(
                    isSearchingNearby = false,
                    statusMessage = null,
                    discoveredCandidate = topCandidate,
                    selectedPlace = nominatimEquiv,
                    selectedPublicPlace = topCandidate.publicPlaceData
                )
              }
            } else {
              _uiState.update {
                it.copy(
                    isSearchingNearby = false,
                    statusMessage = null,
                    errorMessage = "لم يتم العثور على أماكن في فئة «${iconItem.nameArabic}» بالقرب منك."
                )
              }
            }
          },
          onFailure = { err ->
            _uiState.update {
              it.copy(
                  isSearchingNearby = false,
                  statusMessage = null,
                  errorMessage = err.message ?: "لم يتم العثور على أماكن في هذه الفئة بالقرب منك."
              )
            }
          }
      )
    }
  }

  fun dismissDiscoveredPlace() {
    _uiState.update {
      it.copy(
          discoveredCandidate = null,
          selectedPlace = null,
          selectedPublicPlace = null
      )
    }
  }

  fun flyToPlace(latitude: Double, longitude: Double, title: String = "") {
    val nominatimEquiv = NominatimResult.fromCoordinates(
        lat = latitude,
        lon = longitude,
        title = title.ifBlank { "موقع محدد" }
    ).copy(isDirectMapTap = false)
    _uiState.update {
      it.copy(
          isExploreSheetOpen = false,
          selectedPlace = nominatimEquiv,
          selectedPublicPlace = null,
          discoveredCandidate = null
      )
    }
  }

  // --- Public Community Place Details & Interactive Post ---

  fun selectPublicPlace(placeId: String, currentUserId: String = "") {
    val localPlace = _uiState.value.publicPlaces.find { it.id == placeId }
        ?: _uiState.value.knownPlaces.find { it.id == placeId }

    if (localPlace != null) {
      applySelectedPlace(localPlace, currentUserId)
    } else {
      viewModelScope.launch {
        try {
          val fetched = publicPlacesRepository.getPlaceById(placeId)
          if (fetched != null) {
            applySelectedPlace(fetched, currentUserId)
          }
        } catch (e: Exception) {
          Log.e(TAG, "Failed to load place by id $placeId", e)
        }
      }
    }
  }

  private fun applySelectedPlace(place: PublicPlace, currentUserId: String) {
    val nominatimEquiv = NominatimResult.fromCoordinates(
        lat = place.latitude,
        lon = place.longitude,
        title = "${place.title} - ${place.description}"
    )

    _uiState.update {
      it.copy(
          selectedPublicPlace = place,
          selectedPlace = nominatimEquiv,
          discoveredCandidate = null,
          isCurrentPlaceLiked = false,
          currentPlaceLikesCount = place.likesCount,
          currentPlaceCommentsCount = place.commentsCount
      )
    }

    placeLikeJob?.cancel()
    if (currentUserId.isNotBlank() && place.creatorId != "known_osm") {
      placeLikeJob = viewModelScope.launch {
        placeInteractionsRepository.isPlaceLikedFlow(place.id, currentUserId).collect { liked ->
          _uiState.update { it.copy(isCurrentPlaceLiked = liked) }
        }
      }
    }
  }

  fun dismissPublicPlace() {
    placeLikeJob?.cancel()
    _uiState.update {
      it.copy(
          selectedPublicPlace = null,
          selectedPlace = null,
          isCurrentPlaceLiked = false,
          currentPlaceLikesCount = 0L,
          currentPlaceCommentsCount = 0L
      )
    }
  }

  fun syncCurrentUser(currentUser: AppUser?) {
    notificationsJob?.cancel()
    if (currentUser != null && currentUser.uid.isNotBlank()) {
      startOrdersObservation(currentUser.uid)
      notificationsJob = viewModelScope.launch {
        placeInteractionsRepository.getNotificationsFlow(currentUser.uid).collect { list ->
          _uiState.update {
            it.copy(
                userNotifications = list,
                unreadNotificationsCount = list.count { notif -> !notif.read }
            )
          }
        }
      }
    } else {
      ordersJob?.cancel()
      ordersObservedUid = null
      _uiState.update {
        it.copy(
            userNotifications = emptyList(),
            unreadNotificationsCount = 0
        )
      }
    }
  }

  fun togglePlaceLike(currentUser: AppUser?) {
    if (currentUser == null || currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
      showGuestRestrictionDialog("لتتمكن من الإعجاب بالأماكن")
      return
    }
    val place = _uiState.value.selectedPublicPlace ?: return
    val currentlyLiked = _uiState.value.isCurrentPlaceLiked
    val currentCount = _uiState.value.currentPlaceLikesCount

    val nextLiked = !currentlyLiked
    val nextCount = (currentCount + if (nextLiked) 1L else -1L).coerceAtLeast(0L)
    _uiState.update {
      it.copy(
          isCurrentPlaceLiked = nextLiked,
          currentPlaceLikesCount = nextCount,
          selectedPublicPlace = place.copy(likesCount = nextCount)
      )
    }

    viewModelScope.launch {
      val result = placeInteractionsRepository.togglePlaceLike(
          placeId = place.id,
          placeTitle = place.title,
          placeCreatorId = place.creatorId,
          currentUser = currentUser
      )
      result.onFailure { e ->
        _uiState.update {
          it.copy(
              isCurrentPlaceLiked = currentlyLiked,
              currentPlaceLikesCount = currentCount,
              selectedPublicPlace = place.copy(likesCount = currentCount),
              errorMessage = "فشل تحديث الإعجاب: ${e.message}"
          )
        }
      }
    }
  }

  fun openCommentsSheet(placeId: String? = null, currentUserId: String = "") {
    val targetPlace = placeId?.let { pid -> _uiState.value.publicPlaces.find { it.id == pid } ?: _uiState.value.knownPlaces.find { it.id == pid } }
        ?: _uiState.value.selectedPublicPlace

    if (targetPlace != null) {
      startListeningToComments(targetPlace, currentUserId)
    } else if (!placeId.isNullOrBlank()) {
      viewModelScope.launch {
        try {
          val fetched = publicPlacesRepository.getPlaceById(placeId)
          if (fetched != null) {
            applySelectedPlace(fetched, currentUserId)
            startListeningToComments(fetched, currentUserId)
          }
        } catch (e: Exception) {
          Log.e(TAG, "Failed to load place for comments $placeId", e)
        }
      }
    }
  }

  private fun startListeningToComments(targetPlace: PublicPlace, currentUserId: String) {
    _uiState.update { it.copy(isCommentsSheetOpen = true) }

    placeCommentsJob?.cancel()
    placeCommentsJob = viewModelScope.launch {
      placeInteractionsRepository.getCommentsFlow(targetPlace.id).collect { comments ->
        val count = comments.size.toLong()
        _uiState.update {
          it.copy(
              placeComments = comments,
              currentPlaceCommentsCount = count,
              selectedPublicPlace = it.selectedPublicPlace?.copy(commentsCount = count)
          )
        }
      }
    }

    if (currentUserId.isNotBlank()) {
      commentLikesJob?.cancel()
      commentLikesJob = viewModelScope.launch {
        placeInteractionsRepository.getUserLikedCommentsFlow(targetPlace.id, currentUserId).collect { likedSet ->
          _uiState.update { it.copy(userLikedCommentIds = likedSet) }
        }
      }
    }
  }

  fun closeCommentsSheet() {
    _uiState.update { it.copy(isCommentsSheetOpen = false) }
    placeCommentsJob?.cancel()
    commentLikesJob?.cancel()
  }

  fun addComment(text: String, currentUser: AppUser?) {
    if (currentUser == null || currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
      showGuestRestrictionDialog("لتتمكن من كتابة تعليق")
      return
    }
    val place = _uiState.value.selectedPublicPlace ?: return
    viewModelScope.launch {
      _uiState.update { it.copy(isSubmittingComment = true) }
      val result = placeInteractionsRepository.addComment(
          placeId = place.id,
          placeTitle = place.title,
          placeCreatorId = place.creatorId,
          currentUser = currentUser,
          text = text
      )
      _uiState.update { it.copy(isSubmittingComment = false) }
      result.onFailure { err ->
        _uiState.update { it.copy(errorMessage = err.message ?: "فشل إرسال التعليق.") }
      }
    }
  }

  fun deleteComment(comment: PlaceComment, currentUserId: String) {
    val place = _uiState.value.selectedPublicPlace ?: return
    viewModelScope.launch {
      val result = placeInteractionsRepository.deleteComment(
          placeId = place.id,
          commentId = comment.id,
          userId = currentUserId
      )
      if (result.isSuccess) {
        _uiState.update {
          it.copy(
              statusMessage = "تم حذف التعليق بنجاح"
          )
        }
      } else {
        _uiState.update {
          it.copy(
              errorMessage = "فشل حذف التعليق: ${result.exceptionOrNull()?.message ?: "خطأ غير معروف"}"
          )
        }
      }
    }
  }

  fun toggleCommentLike(comment: PlaceComment, currentUser: AppUser?) {
    if (currentUser == null || currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
      showGuestRestrictionDialog("لتتمكن من الإعجاب بالتعليقات")
      return
    }
    val place = _uiState.value.selectedPublicPlace ?: return
    val commentId = comment.id
    val isLiked = _uiState.value.userLikedCommentIds.contains(commentId)

    val updatedSet = if (isLiked) {
      _uiState.value.userLikedCommentIds - commentId
    } else {
      _uiState.value.userLikedCommentIds + commentId
    }
    val updatedComments = _uiState.value.placeComments.map {
      if (it.id == commentId) {
        it.copy(likesCount = (it.likesCount + if (isLiked) -1L else 1L).coerceAtLeast(0L))
      } else it
    }
    _uiState.update {
      it.copy(
          userLikedCommentIds = updatedSet,
          placeComments = updatedComments
      )
    }

    viewModelScope.launch {
      val result = placeInteractionsRepository.toggleCommentLike(
          placeId = place.id,
          commentId = commentId,
          commentAuthorId = comment.userId,
          placeTitle = place.title,
          currentUser = currentUser
      )
      result.onFailure { e ->
        _uiState.update {
          it.copy(
              userLikedCommentIds = if (isLiked) it.userLikedCommentIds + commentId else it.userLikedCommentIds - commentId,
              errorMessage = "فشل تحديث الإعجاب: ${e.message}"
          )
        }
      }
    }
  }

  fun openNotificationsSheet() {
    _uiState.update { it.copy(isNotificationsSheetOpen = true) }
  }

  fun closeNotificationsSheet() {
    _uiState.update { it.copy(isNotificationsSheetOpen = false) }
  }

  fun onNotificationClicked(notification: UserNotification, currentUserId: String) {
    viewModelScope.launch {
      if (!notification.read && currentUserId.isNotBlank()) {
        placeInteractionsRepository.markNotificationAsRead(currentUserId, notification.id)
      }
    }
    _uiState.update { it.copy(isNotificationsSheetOpen = false) }
    selectPublicPlace(notification.placeId, currentUserId)
    if (notification.type == "PLACE_COMMENT" || notification.type == "COMMENT_LIKE") {
      openCommentsSheet(notification.placeId, currentUserId)
    }
  }

  fun markAllNotificationsAsRead(currentUserId: String) {
    if (currentUserId.isBlank()) return
    viewModelScope.launch {
      placeInteractionsRepository.markAllNotificationsAsRead(currentUserId)
    }
  }

  fun deletePublicPlace(placeId: String, currentUserId: String) {
    viewModelScope.launch {
      val result = publicPlacesRepository.deletePublicPlace(placeId, currentUserId)
      result.onSuccess {
        _uiState.update {
          it.copy(
              selectedPublicPlace = null,
              selectedPlace = null,
              statusMessage = "تم حذف المكان بنجاح."
          )
        }
      }.onFailure { err ->
        _uiState.update { it.copy(errorMessage = err.message ?: "تعذر حذف المكان.") }
      }
    }
  }

  // --- Add and Publish Place Flow (Mandatory 2-5 Photos) ---

  fun openAddCustomPlaceDialog(tappedLat: Double? = null, tappedLng: Double? = null) {
    val defaultName = _uiState.value.selectedPlace?.shortTitle ?: ""
    val defaultAddress = _uiState.value.selectedPlace?.displayName ?: ""
    val userLoc = _uiState.value.userLocation
    val lat = tappedLat ?: _uiState.value.selectedPlace?.latitude ?: userLoc?.latitude ?: 21.4225
    val lng = tappedLng ?: _uiState.value.selectedPlace?.longitude ?: userLoc?.longitude ?: 39.8262

    _uiState.update {
      it.copy(
          isAddCustomPlaceDialogOpen = true,
          customPlaceName = defaultName,
          customPlaceAddress = defaultAddress,
          customPlaceDescription = "",
          customPlaceCategory = "food",
          customPlaceIconId = "food_restaurant",
          customPlaceLat = lat,
          customPlaceLng = lng,
          customPlaceImageUris = emptyList(),
          isPublishingPlace = false
      )
    }
  }

  fun closeAddCustomPlaceDialog() {
    _uiState.update { it.copy(isAddCustomPlaceDialogOpen = false) }
  }

  fun onCustomPlaceNameChanged(name: String) {
    _uiState.update { it.copy(customPlaceName = name) }
  }

  fun onCustomPlaceAddressChanged(address: String) {
    _uiState.update { it.copy(customPlaceAddress = address) }
  }

  fun onCustomPlaceDescriptionChanged(desc: String) {
    _uiState.update { it.copy(customPlaceDescription = desc) }
  }

  fun onCustomPlaceCategoryChanged(category: String) {
    _uiState.update { it.copy(customPlaceCategory = category) }
  }

  fun onCustomPlaceIconChanged(iconId: String) {
    val iconItem = PlaceIconRegistry.getIconById(iconId)
    _uiState.update {
      it.copy(
          customPlaceIconId = iconId,
          customPlaceCategory = iconItem.categoryKey
      )
    }
  }

  fun onAddPlaceImagesPicked(uris: List<Uri>) {
    val current = _uiState.value.customPlaceImageUris.toMutableList()
    for (u in uris) {
      if (current.size < 5 && !current.contains(u)) {
        current.add(u)
      }
    }
    _uiState.update { it.copy(customPlaceImageUris = current) }
  }

  fun onAddPlaceImageRemoved(index: Int) {
    val current = _uiState.value.customPlaceImageUris.toMutableList()
    if (index in current.indices) {
      current.removeAt(index)
      _uiState.update { it.copy(customPlaceImageUris = current) }
    }
  }

  fun showGuestRestrictionDialog(actionDescription: String = "") {
    val message = if (actionDescription.isNotBlank()) {
      "أنت تستخدم التطبيق كضيف. يرجى تسجيل الدخول أو إنشاء حساب $actionDescription."
    } else {
      "أنت تستخدم التطبيق كضيف، سجّل الدخول أو أنشئ حساباً حتى تتمكن من النشر والتفاعل"
    }
    _uiState.update {
      it.copy(
          isGuestPublishRestricted = true,
          guestRestrictionMessage = message
      )
    }
  }

  fun closeGuestRestrictionDialog() {
    _uiState.update { it.copy(isGuestPublishRestricted = false) }
  }

  fun publishCommunityPlace(context: Context, currentUser: AppUser?) {
    if (currentUser == null || currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
      showGuestRestrictionDialog("لتتمكن من نشر الأماكن")
      return
    }

    val state = _uiState.value
    if (state.isPublishingPlace) return

    val title = state.customPlaceName.trim()
    val address = state.customPlaceAddress.trim().ifBlank { title }
    val desc = state.customPlaceDescription.trim()
    val uris = state.customPlaceImageUris

    if (title.length < 2) {
      _uiState.update { it.copy(errorMessage = "يرجى كتابة اسم صحيح للمكان (حرفين على الأقل).") }
      return
    }
    if (desc.length < 3) {
      _uiState.update { it.copy(errorMessage = "يرجى كتابة وصف واضح للمكان (3 أحرف على الأقل).") }
      return
    }
    viewModelScope.launch {
      _uiState.update { it.copy(isPublishingPlace = true) }

      val tempPlaceId = UUID.randomUUID().toString()
      val uploadedUrls = if (uris.isNotEmpty()) {
        publicPlacesRepository.uploadPlaceImages(context, uris, tempPlaceId)
      } else {
        emptyList()
      }

      val newPlace = PublicPlace(
          title = title,
          address = address,
          description = desc,
          category = state.customPlaceCategory,
          iconId = state.customPlaceIconId,
          latitude = state.customPlaceLat,
          longitude = state.customPlaceLng,
          images = uploadedUrls,
          creatorId = currentUser.uid,
          creatorName = currentUser.displayName ?: currentUser.email?.substringBefore("@") ?: "مستخدم DRAW",
          creatorPhotoUrl = currentUser.photoUrl?.toString() ?: ""
      )

      val result = publicPlacesRepository.createPublicPlace(newPlace)
      result.fold(
          onSuccess = { createdId ->
            _uiState.update {
              it.copy(
                  isPublishingPlace = false,
                  isAddCustomPlaceDialogOpen = false,
                  customPlaceImageUris = emptyList(),
                  customPlaceName = "",
                  customPlaceDescription = "",
                  statusMessage = "تم نشر المكان بنجاح على الخريطة وأصبح مرئياً لجميع المستخدمين!"
              )
            }
            selectPublicPlace(createdId, currentUser.uid)
          },
          onFailure = { err ->
            _uiState.update {
              it.copy(
                  isPublishingPlace = false,
                  errorMessage = "تعذر نشر المكان: ${err.message ?: "يرجى التأكد من الاتصال والمحاولة مجدداً."}"
              )
            }
          }
      )
    }
  }

  // --- Account Favorites Flow ---

  fun openSavedPlacesSheet() {
    _uiState.update { it.copy(isSavedPlacesSheetOpen = true) }
  }

  fun closeSavedPlacesSheet() {
    _uiState.update { it.copy(isSavedPlacesSheetOpen = false) }
  }

  fun loadFavorites(userId: String) {
    if (userId.isBlank()) return
    viewModelScope.launch {
      val favorites = navigationRepository.getFavorites(userId)
      _uiState.update { it.copy(savedFavorites = favorites) }
    }
  }

  fun saveCurrentPlaceToFavorites(userId: String) {
    val place = _uiState.value.selectedPlace ?: return
    if (userId.isBlank() || userId.startsWith("guest_")) {
      showGuestRestrictionDialog("لحفظ الأماكن في المفضلة")
      return
    }
    viewModelScope.launch {
      _uiState.update { it.copy(isSavingPlace = true) }
      val saved = SavedPlace(
          title = place.shortTitle,
          address = place.displayName,
          latitude = place.latitude,
          longitude = place.longitude,
          category = "favorite",
          iconId = "personal_favorite",
          placeRefId = place.osmId?.toString() ?: "",
          source = "osm"
      )
      val result = navigationRepository.saveFavorite(userId, saved)
      val msg = when (result) {
        is SaveFavoriteResult.Success -> "تم حفظ المكان في قائمتك الخاصة بنجاح!"
        is SaveFavoriteResult.AlreadySaved -> "المكان محفوظ مسبقاً في قائمتك الخاصة."
        is SaveFavoriteResult.Error -> "تعذر حفظ المكان: ${result.message}"
      }
      _uiState.update {
        it.copy(
            isSavingPlace = false,
            statusMessage = msg
        )
      }
      loadFavorites(userId)
    }
  }

  fun savePublicPlaceToFavorites(userId: String) {
    val place = _uiState.value.selectedPublicPlace ?: return
    if (userId.isBlank() || userId.startsWith("guest_")) {
      showGuestRestrictionDialog("لحفظ الأماكن في المفضلة")
      return
    }
    viewModelScope.launch {
      _uiState.update { it.copy(isSavingPlace = true) }
      val saved = SavedPlace(
          title = place.title,
          address = place.address.ifBlank { place.description },
          latitude = place.latitude,
          longitude = place.longitude,
          category = place.category,
          iconId = place.iconId,
          placeRefId = place.id,
          source = "draw",
          imageUrl = place.images.firstOrNull() ?: ""
      )
      val result = navigationRepository.saveFavorite(userId, saved)
      val msg = when (result) {
        is SaveFavoriteResult.Success -> "تم حفظ المكان في قائمتك الخاصة بنجاح!"
        is SaveFavoriteResult.AlreadySaved -> "المكان محفوظ مسبقاً في قائمتك الخاصة."
        is SaveFavoriteResult.Error -> "تعذر حفظ المكان: ${result.message}"
      }
      _uiState.update {
        it.copy(
            isSavingPlace = false,
            statusMessage = msg
        )
      }
      loadFavorites(userId)
    }
  }

  fun removeFavorite(userId: String, favoriteId: String) {
    viewModelScope.launch {
      navigationRepository.deleteFavorite(userId, favoriteId)
      if (userId.isNotBlank()) {
        loadFavorites(userId)
      }
      _uiState.update { it.copy(statusMessage = "تم حذف المكان من المفضلة.") }
    }
  }

  fun clearError() {
    _uiState.update { it.copy(errorMessage = null) }
  }

  fun clearStatus() {
    _uiState.update { it.copy(statusMessage = null) }
  }

  // --- DRAW Voice & AI Assistant Methods with Map Control Tools ---

  fun openAiAssistant() {
    _uiState.update { it.copy(isAiAssistantOpen = true) }
  }

  fun closeAiAssistant() {
    stopAiSpeech()
    _uiState.update { it.copy(isAiAssistantOpen = false, isVoiceListening = false) }
  }

  fun setVoiceListening(isListening: Boolean) {
    _uiState.update { it.copy(isVoiceListening = isListening) }
  }

  fun loadAiConversations(userId: String) {
    if (userId.isBlank() || aiConversationRepository == null) return
    viewModelScope.launch {
      val res = aiConversationRepository.getUserConversations(userId)
      res.onSuccess { sessions ->
        _uiState.update { it.copy(aiConversationSessions = sessions) }
      }
    }
  }

  fun selectAiConversation(userId: String, conversationId: String) {
    if (userId.isBlank() || aiConversationRepository == null) return
    stopAiSpeech()
    viewModelScope.launch {
      val res = aiConversationRepository.getConversationMessages(userId, conversationId)
      res.onSuccess { msgs ->
        val uiMsgs = msgs.map { m ->
          AiAssistantMessageUi(
              id = m.id,
              sender = if (m.role == "model" || m.role == "assistant") "assistant" else "user",
              text = m.content,
              suggestedPlace = m.suggestedPlaces.firstOrNull()
          )
        }
        _uiState.update {
          it.copy(
              currentAiConversationId = conversationId,
              aiAssistantMessages = uiMsgs
          )
        }
      }
    }
  }

  fun startNewAiConversation() {
    stopAiSpeech()
    _uiState.update {
      it.copy(
          currentAiConversationId = UUID.randomUUID().toString(),
          aiAssistantMessages = emptyList()
      )
    }
  }

  fun sendAiAssistantPrompt(prompt: String, currentUserId: String = "") {
    val cleanPrompt = prompt.trim()
    if (cleanPrompt.isBlank()) return

    val userMsg = AiAssistantMessageUi(
        sender = "user",
        text = cleanPrompt
    )

    _uiState.update {
      it.copy(
          isAiAssistantLoading = true,
          isVoiceListening = false,
          aiAssistantMessages = it.aiAssistantMessages + userMsg
      )
    }

    val norm = cleanPrompt
        .replace("أ", "ا")
        .replace("إ", "ا")
        .replace("آ", "ا")
        .replace("ة", "ه")
        .replace("ى", "ي")
        .trim()
        .lowercase()

    // 1. Map Tool: Center on User
    if (norm.contains("ارجع") || norm.contains("موقعي") || norm.contains("اين انا") || norm.contains("حدد موقعي") || norm.contains("عد للموقع")) {
      centerOnUser()
      val reply = "تمت إعادة تركيز الخريطة على موقعك الجغرافي الحالي بنجاح 📍"
      postAssistantResponse(userMsg, reply, null, currentUserId)
      return
    }

    // 2. Map Tool: Toggle 2D / 3D Perspective
    if (norm.contains("3d") || norm.contains("ثلاثي الابعاد")) {
      set3DMode(true)
      val reply = "تم تفعيل المنظور ثلاثي الأبعاد (3D) للخريطة 🏙️"
      postAssistantResponse(userMsg, reply, null, currentUserId)
      return
    } else if (norm.contains("2d") || norm.contains("ثنائي الابعاد")) {
      set3DMode(false)
      val reply = "تم التحويل إلى المنظور المسطح ثنائي الأبعاد (2D) 🗺️"
      postAssistantResponse(userMsg, reply, null, currentUserId)
      return
    } else if (norm.contains("بدل الخريطه") || norm.contains("بدل العرض") || norm.contains("غير المنظور")) {
      val new3D = !_uiState.value.is3DMode
      set3DMode(new3D)
      val reply = "تم تبديل عرض الخريطة إلى ${if (new3D) "ثلاثي الأبعاد (3D)" else "ثنائي الأبعاد (2D)"} 🔄"
      postAssistantResponse(userMsg, reply, null, currentUserId)
      return
    }

    // 3. Map Tool: Clear Route / Stop Navigation
    if (norm.contains("الغ المسار") || norm.contains("احذف المسار") || norm.contains("مسح المسار") || norm.contains("وقف الملاحه") || norm.contains("الغاء الملاحه") || norm.contains("وقف التوجيه")) {
      clearSelection()
      val reply = "تم إلغاء المسار ومسح خط التوجيه من الخريطة 🏁"
      postAssistantResponse(userMsg, reply, null, currentUserId)
      return
    }

    // 4. Map Tool: Nearest Landmark Queries
    if (norm.contains("اقرب مسجد") || norm.contains("اقرب جامع")) {
      findAndSuggestNearest("tour_mosque", "مسجد", userMsg, currentUserId)
      return
    } else if (norm.contains("اقرب مطعم") || norm.contains("اقرب وجبه") || norm.contains("مطاعم قريبه")) {
      findAndSuggestNearest("food_restaurant", "مطعم", userMsg, currentUserId)
      return
    } else if (norm.contains("اقرب محطه وقود") || norm.contains("اقرب بنزينه") || norm.contains("محطه وقود") || norm.contains("محطة بنزين")) {
      findAndSuggestNearest("trans_fuel", "محطة وقود", userMsg, currentUserId)
      return
    } else if (norm.contains("اقرب صيدليه") || norm.contains("اقرب علاج") || norm.contains("صيدليه قريبه")) {
      findAndSuggestNearest("health_pharmacy", "صيدلية", userMsg, currentUserId)
      return
    } else if (norm.contains("اقرب مستشفى") || norm.contains("اقرب مشفى") || norm.contains("طوارئ")) {
      findAndSuggestNearest("health_hospital", "مستشفى", userMsg, currentUserId)
      return
    } else if (norm.contains("اقرب فندق") || norm.contains("اقرب سكن")) {
      findAndSuggestNearest("personal_hotel", "فندق", userMsg, currentUserId)
      return
    } else if (norm.contains("اقرب مقهى") || norm.contains("اقرب كافيه") || norm.contains("قهوه")) {
      findAndSuggestNearest("food_cafe", "مقهى", userMsg, currentUserId)
      return
    }

    // 5. Conversational / Humor / General AI Query
    val userLoc = _uiState.value.userLocation?.let { it.latitude to it.longitude }
    val history = _uiState.value.aiAssistantMessages.takeLast(6).map {
      it.sender to it.text
    }

    viewModelScope.launch {
      val result = aiAssistantRepository.askAssistant(cleanPrompt, userLoc, history)
      result.fold(
          onSuccess = { responseText ->
            var suggestion: AiPlaceSuggestion? = null
            var cleanText = responseText

            val regex = Regex("""\[Place:\s*([^|]+)\|\s*Lat:\s*([0-9.-]+)\|\s*Lon:\s*([0-9.-]+)\]""")
            val match = regex.find(responseText)
            if (match != null) {
              val name = match.groupValues[1].trim()
              val lat = match.groupValues[2].toDoubleOrNull()
              val lon = match.groupValues[3].toDoubleOrNull()
              if (lat != null && lon != null) {
                suggestion = AiPlaceSuggestion(
                    name = name,
                    description = "موقع مقترح بواسطة مساعد DRAW الذكي",
                    latitude = lat,
                    longitude = lon
                )
              }
              cleanText = responseText.replace(regex, "").trim()
            }

            if (cleanText.isBlank() || cleanText.equals("null", ignoreCase = true) || cleanText.equals("none", ignoreCase = true)) {
              cleanText = "أهلاً بك! مساعد DRAW الملاحي معك 📍 كيف يمكنني مساعدتك في رحلتك وملاحتك اليوم؟"
            }

            postAssistantResponse(userMsg, cleanText, suggestion, currentUserId)
          },
          onFailure = { _ ->
            val fallbackMsg = "أهلاً بك! مساعد DRAW الملاحي معك 📍 يمكنك سؤالي عن أقرب الأماكن، الاستفسار عن حالة الطرق والازدحامات، أو طلب توجيه لأي وجهة في خريطتك وسأساعدك فوراً."
            postAssistantResponse(userMsg, fallbackMsg, null, currentUserId)
          }
      )
    }
  }

  private fun findAndSuggestNearest(
      iconId: String,
      categoryNameArabic: String,
      userMsg: AiAssistantMessageUi,
      userId: String
  ) {
    val userLoc = _uiState.value.userLocation
    if (userLoc == null) {
      val reply = "يرجى تفعيل أو تحديد موقعك الجغرافي للبحث عن أقرب $categoryNameArabic 📍"
      postAssistantResponse(userMsg, reply, null, userId)
      return
    }

    val iconItem = PlaceIconRegistry.getIconById(iconId)
    viewModelScope.launch {
      val result = nearbyPlacesSearchService.findNearestPlaces(
          userLat = userLoc.latitude,
          userLon = userLoc.longitude,
          iconItem = iconItem,
          allCommunityPlaces = _uiState.value.publicPlaces,
          userSavedPlaces = _uiState.value.savedFavorites
      )
      result.onSuccess { candidates ->
        val top = candidates.firstOrNull()
        if (top != null) {
          val distText = if (top.distanceMeters < 1000) {
            "${top.distanceMeters.toInt()} متر"
          } else {
            String.format("%.1f كم", top.distanceMeters / 1000f)
          }
          val suggestion = AiPlaceSuggestion(
              name = top.title,
              description = top.address,
              latitude = top.latitude,
              longitude = top.longitude
          )
          _uiState.update { it.copy(discoveredCandidate = top) }
          val reply = "وجدت لك أقرب $categoryNameArabic: «${top.title}» ويبعد عنك حوالي $distText. يمكنك بدء الملاحة إليه بضغطة واحدة!"
          postAssistantResponse(userMsg, reply, suggestion, userId)
        } else {
          val reply = "بحثت بالقرب من موقعك ولم أعثر على $categoryNameArabic مسجل حالياً. يمكنك تجربة كتابة الاسم في شريط البحث."
          postAssistantResponse(userMsg, reply, null, userId)
        }
      }.onFailure {
        val reply = "تعذر البحث عن أقرب $categoryNameArabic حالياً، يرجى التأكد من اتصالك بالإنترنت."
        postAssistantResponse(userMsg, reply, null, userId)
      }
    }
  }

  private fun postAssistantResponse(
      userMsg: AiAssistantMessageUi,
      responseText: String,
      suggestion: AiPlaceSuggestion?,
      userId: String
  ) {
    val assistantMsg = AiAssistantMessageUi(
        sender = "assistant",
        text = responseText,
        suggestedPlace = suggestion
    )
    _uiState.update {
      it.copy(
          isAiAssistantLoading = false,
          aiAssistantMessages = it.aiAssistantMessages + assistantMsg
      )
    }

    // Automatically speak AI answer via TTS if enabled
    if (_uiState.value.isAiTtsAutoPlayEnabled && !_uiState.value.isVoiceGuidanceMuted) {
      speakAiResponse(assistantMsg.id, responseText)
    }

    // Persist only for authenticated users (NEVER create dummy records for guests)
    if (userId.isNotBlank() && aiConversationRepository != null) {
      viewModelScope.launch {
        try {
          val convId = _uiState.value.currentAiConversationId.ifBlank { UUID.randomUUID().toString() }
          _uiState.update { it.copy(currentAiConversationId = convId) }
          val suggestionsList = if (suggestion != null) listOf(suggestion) else emptyList()
          val saveRes = aiConversationRepository.appendExchange(
              userId = userId,
              conversationId = convId,
              userMessageText = userMsg.text,
              modelResponseText = responseText,
              suggestedPlaces = suggestionsList
          )
          saveRes.onSuccess {
            loadAiConversations(userId)
          }
        } catch (e: Exception) {
          Log.w(TAG, "Failed to save AI conversation exchange", e)
        }
      }
    }
  }

  fun speakAiResponse(messageId: String, text: String) {
    navigationVoiceSpeaker?.speakAiResponse(text, utteranceId = messageId)
  }

  fun stopAiSpeech() {
    navigationVoiceSpeaker?.stop()
  }

  fun toggleAiSpeech(messageId: String, text: String) {
    if (_uiState.value.isAiSpeaking && _uiState.value.currentlySpeakingAiMessageId == messageId) {
      stopAiSpeech()
    } else {
      speakAiResponse(messageId, text)
    }
  }

  fun toggleAiTtsAutoPlay() {
    val newAutoPlay = !_uiState.value.isAiTtsAutoPlayEnabled
    if (!newAutoPlay) {
      stopAiSpeech()
    }
    _uiState.update { it.copy(isAiTtsAutoPlayEnabled = newAutoPlay) }
  }

  fun selectAiPlaceSuggestion(suggestion: AiPlaceSuggestion, startNavigationImmediately: Boolean) {
    closeAiAssistant()
    val lat = suggestion.latitude ?: return
    val lon = suggestion.longitude ?: return

    val nominatimResult = NominatimResult.fromCoordinates(
        lat = lat,
        lon = lon,
        title = suggestion.name
    )

    if (startNavigationImmediately) {
      calculateRouteToPlace(nominatimResult)
    } else {
      selectPlace(nominatimResult, calculateRouteImmediately = false)
    }
  }

  // --- Road Reports (9 Types + 1 Clear Hazard Action) ---

  private fun observeRoadReports() {
    roadReportsJob?.cancel()
    roadReportsJob = viewModelScope.launch {
      roadReportsRepository.getActiveReportsFlow().collect { reports ->
        _uiState.update { it.copy(roadReports = reports) }
      }
    }
  }

  fun openReportsSheet() {
    _uiState.update { it.copy(isReportsSheetOpen = true) }
  }

  fun closeReportsSheet() {
    _uiState.update { it.copy(isReportsSheetOpen = false) }
  }

  fun submitRoadReport(type: RoadReportType, description: String, currentUser: AppUser?) {
    val loc = _uiState.value.userLocation
    val lat = loc?.latitude ?: _uiState.value.selectedPlace?.latitude ?: 21.4225
    val lng = loc?.longitude ?: _uiState.value.selectedPlace?.longitude ?: 39.8262
    val userId = currentUser?.uid ?: "driver_${UUID.randomUUID().toString().take(6)}"
    val userName = currentUser?.displayName?.ifBlank { null } ?: "سائق في مجتمع DRAW"

    val newReport = RoadReport(
        id = UUID.randomUUID().toString(),
        type = type,
        description = description,
        latitude = lat,
        longitude = lng,
        creatorId = userId,
        creatorName = userName,
        createdAt = System.currentTimeMillis(),
        isCleared = false
    )

    viewModelScope.launch {
      _uiState.update { it.copy(isReportsSheetOpen = false) }
      val result = roadReportsRepository.createReport(newReport)
      if (result.isSuccess) {
        _uiState.update {
          it.copy(statusMessage = "تم نشر بلاغ '${type.titleArabic}' بنجاح على الخريطة")
        }
      } else {
        _uiState.update {
          it.copy(errorMessage = "تعذر نشر البلاغ، يرجى المحاولة مرة أخرى")
        }
      }
    }
  }

  fun selectRoadReport(reportId: String) {
    val report = _uiState.value.roadReports.firstOrNull { it.id == reportId } ?: return
    _uiState.update {
      it.copy(
          selectedRoadReport = report,
          verificationSession = null
      )
    }
  }

  fun closeReportDetails() {
    _uiState.update {
      it.copy(
          selectedRoadReport = null,
          verificationSession = null
      )
    }
  }

  fun startRoadReportResolution(report: RoadReport) {
    val userLoc = _uiState.value.userLocation
    val initialDist = if (userLoc != null) {
      val repLoc = Location("rep").apply {
        latitude = report.latitude
        longitude = report.longitude
      }
      userLoc.distanceTo(repLoc)
    } else {
      50.0f
    }

    val phase = if (initialDist <= 20.0f) VerificationPhase.AT_HAZARD else VerificationPhase.APPROACHING

    _uiState.update {
      it.copy(
          verificationSession = RoadReportVerificationSession(
              reportId = report.id,
              phase = phase,
              distanceToHazardMeters = initialDist,
              minDistanceToHazardReached = initialDist,
              distanceTraveledBeyondMeters = 0.0f,
              statusMessage = if (phase == VerificationPhase.AT_HAZARD) {
                "أنت عند موقع البلاغ! واصل التحرك 10 أمتار لتأكيد زوال الخطر..."
              } else {
                "يرجى الاقتراب من موقع البلاغ (متبقي ${initialDist.toInt()} م)"
              }
          )
      )
    }
  }

  fun cancelRoadReportResolution() {
    _uiState.update { it.copy(verificationSession = null) }
  }

  private fun processReportVerificationOnLocation(location: Location) {
    val session = _uiState.value.verificationSession ?: return
    val report = _uiState.value.selectedRoadReport ?: return
    if (session.reportId != report.id || session.phase == VerificationPhase.COMPLETED) return

    val accuracy = if (location.hasAccuracy()) location.accuracy else 20.0f
    // Rule: Check GPS accuracy and reject unreliable location readings (> 25m)
    if (accuracy > 25.0f) {
      _uiState.update {
        it.copy(
            verificationSession = session.copy(
                isGpsUnreliable = true,
                statusMessage = "⚠️ إشارة GPS غير دقيقة حالياً (${accuracy.toInt()}م) - بانتظار قراءة مؤكدة..."
            )
        )
      }
      return
    }

    val reportLoc = Location("hazard_pos").apply {
      latitude = report.latitude
      longitude = report.longitude
    }
    val distToHazard = location.distanceTo(reportLoc)

    when (session.phase) {
      VerificationPhase.IDLE, VerificationPhase.APPROACHING -> {
        val updatedMin = minOf(session.minDistanceToHazardReached, distToHazard)
        // User must approach and pass through the reported location (within 20m)
        if (distToHazard <= 20.0f) {
          _uiState.update {
            it.copy(
                verificationSession = session.copy(
                    phase = VerificationPhase.AT_HAZARD,
                    distanceToHazardMeters = distToHazard,
                    minDistanceToHazardReached = updatedMin,
                    distanceTraveledBeyondMeters = 0.0f,
                    isGpsUnreliable = false,
                    statusMessage = "تم الوصول إلى موقع البلاغ! يرجى مواصلة القيادة 10 أمتار لتأكيد زوال الخطر..."
                )
            )
          }
        } else {
          _uiState.update {
            it.copy(
                verificationSession = session.copy(
                    distanceToHazardMeters = distToHazard,
                    minDistanceToHazardReached = updatedMin,
                    isGpsUnreliable = false,
                    statusMessage = "يرجى الاقتراب من موقع البلاغ (متبقي ${distToHazard.toInt()} م)"
                )
            )
          }
        }
      }
      VerificationPhase.AT_HAZARD -> {
        // User has already reached the hazard area (within 20m).
        // Now require approximately 10 meters of verified travel beyond the report area.
        val beyondDist = distToHazard
        val required = session.requiredDistanceBeyondMeters

        if (beyondDist >= required) {
          // Verification successful! Mark report as cleared in Firestore and remove marker
          _uiState.update {
            it.copy(
                verificationSession = session.copy(
                    phase = VerificationPhase.COMPLETED,
                    distanceToHazardMeters = distToHazard,
                    distanceTraveledBeyondMeters = beyondDist,
                    isGpsUnreliable = false,
                    statusMessage = "نجح التحقق! تمت إزالة الخطر من الخريطة لجميع المستخدمين."
                )
            )
          }
          completeReportResolution(report, location)
        } else {
          _uiState.update {
            it.copy(
                verificationSession = session.copy(
                    distanceToHazardMeters = distToHazard,
                    distanceTraveledBeyondMeters = beyondDist,
                    isGpsUnreliable = false,
                    statusMessage = "جارٍ التحقق: تم قطع ${beyondDist.toInt()} / ${required.toInt()} م بعد موقع البلاغ"
                )
            )
          }
        }
      }
      VerificationPhase.COMPLETED, VerificationPhase.FAILED -> {
        // Terminal states
      }
    }
  }

  private fun completeReportResolution(report: RoadReport, location: Location) {
    viewModelScope.launch {
      val result = roadReportsRepository.resolveReport(
          reportId = report.id,
          userId = "verified_driver",
          userName = "سائق موثق عبر GPS",
          auditLocation = location
      )
      if (result.isSuccess) {
        delay(1200L)
        _uiState.update {
          it.copy(
              selectedRoadReport = null,
              verificationSession = null,
              statusMessage = "تم تأكيد زوال الخطر وإزالة البلاغ من الخريطة بنجاح"
          )
        }
      } else {
        _uiState.update {
          it.copy(
              verificationSession = it.verificationSession?.copy(
                  phase = VerificationPhase.FAILED,
                  statusMessage = "تعذر تحديث البلاغ في الخادم. يرجى المحاولة لاحقاً."
              )
          )
        }
      }
    }
  }

  // --- Vehicles, Sharing & Services System ---

  fun refreshVehicleProfile() {
    val local = vehiclesRepository.getLocalProfile()
    _uiState.update { it.copy(userVehicleProfile = local) }

    // If taxi mode is toggled OFF, immediately remove vehicle from live public tracking
    val user = authSessionManager.currentUser.value
    val uid = user?.uid ?: local.userId
    if (!local.isTaxiOwner && uid.isNotBlank()) {
      viewModelScope.launch {
        try {
          vehiclesRepository.stopSharingLiveLocation(uid)
        } catch (_: Exception) {}
      }
    }
  }

  fun refreshAppData() {
    if (_uiState.value.isRefreshingAppData) return
    _uiState.update { it.copy(isRefreshingAppData = true, statusMessage = "جارٍ تحديث البيانات والواجهة…") }
    viewModelScope.launch {
      try {
        checkPermissionAndFetchLocation(autoCenter = false)
        refreshVehicleProfile()
        val query = _uiState.value.searchQuery
        if (query.isNotBlank()) onSearchQueryChanged(query)
        _uiState.update { it.copy(isRefreshingAppData = false, statusMessage = "تم تحديث البيانات والواجهة من Firebase") }
      } catch (e: Exception) {
        Log.e(TAG, "Refresh failed", e)
        _uiState.update { it.copy(isRefreshingAppData = false, statusMessage = "تعذر تحديث البيانات، حاول مرة أخرى") }
      }
    }
  }

  private fun observeLiveVehiclesAndOrders() {
    refreshVehicleProfile()

    liveVehiclesJob?.cancel()
    liveVehiclesJob = viewModelScope.launch {
      try {
        vehiclesRepository.observeLiveVehicles().collect { vehicles ->
          val user = authSessionManager.currentUser.value
          val myUid = user?.uid ?: _uiState.value.userVehicleProfile?.userId
          val userLocation = _uiState.value.userLocation
          val withDistance = vehicles.filter { it.effectiveUserId != myUid }.map { vehicle ->
            val meters = if (userLocation != null && vehicle.latitude != 0.0 && vehicle.longitude != 0.0) {
              val result = FloatArray(1)
              Location.distanceBetween(userLocation.latitude, userLocation.longitude, vehicle.latitude, vehicle.longitude, result)
              result[0]
            } else 0f
            vehicle.copy(distanceToUserMeters = meters)
          }.sortedBy { it.distanceToUserMeters }
          _uiState.update { state ->
            state.copy(liveVehicles = withDistance)
          }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error observing live vehicles", e)
      }
    }

    val user = authSessionManager.currentUser.value
    if (user != null) {
      ordersJob?.cancel()
      ordersJob = viewModelScope.launch {
        try {
          vehiclesRepository.observeOrdersForUser(user.uid).collect { orders ->
            val incoming = orders.firstOrNull { it.effectiveDriverId == user.uid && it.status == OrderStatus.WAITING_APPROVAL }
            val active = orders.firstOrNull {
              it.status != OrderStatus.COMPLETED && it.status != OrderStatus.REJECTED && it.status != OrderStatus.CANCELLED
            } ?: orders.firstOrNull()

            _uiState.update { state ->
              state.copy(
                  incomingOrder = incoming,
                  activeOrder = active
              )
            }
          }
        } catch (e: Exception) {
          Log.e(TAG, "Error observing service orders", e)
        }
      }
    }
  }

  private fun startOrdersObservation(uid: String) {
    if (ordersObservedUid == uid && ordersJob?.isActive == true) return
    ordersObservedUid = uid
    ordersJob?.cancel()
    orderTimeoutJobs.values.forEach { it.cancel() }
    orderTimeoutJobs.clear()
    ordersJob = viewModelScope.launch {
      try {
        vehiclesRepository.observeOrdersForUser(uid).collect { orders ->
          val now = System.currentTimeMillis()
          val pendingOrders = orders.filter { it.effectiveDriverId == uid && it.status == OrderStatus.WAITING_APPROVAL }
          val pendingIds = pendingOrders.map { it.id }.toSet()
          orderTimeoutJobs.keys.toList().filterNot { it in pendingIds }.forEach { id ->
            orderTimeoutJobs.remove(id)?.cancel()
          }
          pendingOrders.forEach { pendingOrder ->
            if (pendingOrder.id !in orderTimeoutJobs) {
              val timeoutJob = viewModelScope.launch {
                val remaining = (60_000L - (System.currentTimeMillis() - pendingOrder.createdAt)).coerceAtLeast(0L)
                delay(remaining)
                vehiclesRepository.updateOrderStatus(pendingOrder.id, OrderStatus.REJECTED)
                orderTimeoutJobs.remove(pendingOrder.id)
              }
              orderTimeoutJobs[pendingOrder.id] = timeoutJob
            }
          }
          val incoming = pendingOrders.firstOrNull { now - it.createdAt < 60_000L }
          val rejectedForPassenger = orders.firstOrNull {
            it.effectiveCustomerId == uid && it.status == OrderStatus.REJECTED && now - it.updatedAt < 65_000L
          }
          val active = orders.firstOrNull {
            it.status != OrderStatus.COMPLETED && it.status != OrderStatus.REJECTED && it.status != OrderStatus.CANCELLED
          }
          _uiState.update { state ->
            state.copy(
                incomingOrder = incoming,
                activeOrder = active,
                statusMessage = when {
                  rejectedForPassenger != null -> "تعذر إكمال الطلب أو لم يرد السائق خلال دقيقة. دور على سائق آخر"
                  active?.effectiveCustomerId == uid && active.status == OrderStatus.ACCEPTED -> "انتظر ثواني في موقعك الحالي، السائق استلم الطلب"
                  else -> state.statusMessage
                }
            )
          }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error observing taxi orders for $uid", e)
      }
    }
  }

  private fun syncPassengerPickupLocation(location: Location) {
    val order = _uiState.value.activeOrder ?: return
    val user = authSessionManager.currentUser.value ?: return
    if (order.effectiveCustomerId != user.uid) return
    if (order.status == OrderStatus.REJECTED || order.status == OrderStatus.CANCELLED || order.status == OrderStatus.COMPLETED) return
    val now = System.currentTimeMillis()
    if (now - lastPickupSyncAt < 3000L) return
    lastPickupSyncAt = now
    viewModelScope.launch { vehiclesRepository.updateOrderPickupLocation(order.id, location.latitude, location.longitude) }
  }

  private fun refreshDriverPickupRoute(location: Location) {
    val order = _uiState.value.activeOrder ?: return
    val user = authSessionManager.currentUser.value ?: return
    if (order.effectiveDriverId != user.uid) return
    if (order.status != OrderStatus.ACCEPTED && order.status != OrderStatus.DRIVER_EN_ROUTE) return
    val now = System.currentTimeMillis()
    if (now - lastDriverRouteRefreshAt < 5000L) return
    if (order.effectivePickupLat == 0.0 || order.effectivePickupLng == 0.0) return
    lastDriverRouteRefreshAt = now
    viewModelScope.launch {
      try {
        val response = navigationRepository.getRoute(
            startLat = location.latitude,
            startLon = location.longitude,
            endLat = order.effectivePickupLat,
            endLon = order.effectivePickupLng
        )
        val route = response?.routes?.minByOrNull { it.distance } ?: return@launch
        _uiState.update {
          it.copy(
              routeOptions = listOf(RouteOption(0, "#007AFF", "المسار الأزرق", "مسار التوجه لموقع الراكب", route)),
              selectedRouteIndex = 0,
              currentRoute = route
          )
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error refreshing driver pickup route", e)
      }
    }
  }

  private fun publishUserVehicleLocation(location: Location) {
    val profile = _uiState.value.userVehicleProfile ?: return
    val user = authSessionManager.currentUser.value
    val uid = user?.uid ?: profile.userId.ifBlank { "driver_${location.latitude}_${location.longitude}".take(20) }

    // When "أنا صاحب تاكسي" is deactivated (false):
    // Never publish location, and if previously active, destroy the live tracking document immediately
    if (!profile.isTaxiOwner) {
      if (lastKnownTaxiStatusWasActive) {
        lastKnownTaxiStatusWasActive = false
        if (uid.isNotBlank()) {
          viewModelScope.launch {
            try {
              vehiclesRepository.stopSharingLiveLocation(uid)
            } catch (_: Exception) {}
          }
        }
      }
      return
    }

    lastKnownTaxiStatusWasActive = true
    val now = System.currentTimeMillis()
    if (now - lastVehiclePublishTime < 3000L) return
    lastVehiclePublishTime = now
    val speedKmh = if (location.hasSpeed()) (location.speed * 3.6).toDouble() else 0.0
    val bearing = location.bearing.toDouble()

    viewModelScope.launch {
      try {
        vehiclesRepository.publishLiveLocation(
            profile = profile.copy(userId = uid),
            lat = location.latitude,
            lng = location.longitude,
            bearing = bearing,
            speedKmh = speedKmh
        )
      } catch (e: Exception) {
        Log.e(TAG, "Error publishing vehicle location", e)
      }
    }
  }

  fun onVehicleClick(userId: String) {
    val vehicle = _uiState.value.liveVehicles.firstOrNull { it.effectiveUserId == userId }
    if (vehicle != null) {
      _uiState.update {
        it.copy(
            selectedDriverVehicle = vehicle,
            isDriverProfileOpen = true
        )
      }
    }
  }

  fun dismissDriverProfile() {
    _uiState.update {
      it.copy(
          selectedDriverVehicle = null,
          isDriverProfileOpen = false
      )
    }
  }

  fun toggleDriverLike(vehicle: LiveVehicle) {
    val user = authSessionManager.currentUser.value ?: return
    if (user.isAnonymous) return
    viewModelScope.launch {
      vehiclesRepository.toggleDriverLike(vehicle.effectiveUserId, user.uid)
      refreshAppData()
    }
  }

  fun addDriverComment(vehicle: LiveVehicle, text: String) {
    val user = authSessionManager.currentUser.value ?: return
    if (user.isAnonymous || text.isBlank()) return
    viewModelScope.launch {
      vehiclesRepository.addDriverComment(vehicle.effectiveUserId, user.uid, user.displayName ?: "مستخدم DRAW", text)
      refreshAppData()
    }
  }

  fun openTaxiComments(vehicle: LiveVehicle) {
    taxiCommentsJob?.cancel()
    _uiState.update { it.copy(isTaxiCommentsSheetOpen = true, taxiCommentsDriverId = vehicle.effectiveUserId, taxiComments = emptyList()) }
    taxiCommentsJob = viewModelScope.launch {
      vehiclesRepository.getTaxiCommentsFlow(vehicle.effectiveUserId).collect { comments ->
        _uiState.update { it.copy(taxiComments = comments) }
      }
    }
  }

  fun closeTaxiComments() {
    taxiCommentsJob?.cancel()
    _uiState.update { it.copy(isTaxiCommentsSheetOpen = false, taxiComments = emptyList(), taxiCommentsDriverId = "") }
  }

  fun addTaxiComment(driverId: String, text: String, currentUser: AppUser?) {
    val user = currentUser ?: return
    if (user.isAnonymous) return
    viewModelScope.launch { vehiclesRepository.addTaxiComment(driverId, user, text) }
  }

  fun deleteTaxiComment(driverId: String, comment: PlaceComment, currentUser: AppUser?) {
    val user = currentUser ?: return
    viewModelScope.launch { vehiclesRepository.deleteTaxiComment(driverId, comment.id, user.uid) }
  }

  fun toggleTaxiCommentLike(driverId: String, comment: PlaceComment, currentUser: AppUser?) {
    val user = currentUser ?: return
    if (user.isAnonymous) return
    val currentlyLiked = _uiState.value.taxiUserLikedCommentIds.contains(comment.id)
    _uiState.update { state ->
      state.copy(taxiUserLikedCommentIds = if (currentlyLiked) state.taxiUserLikedCommentIds - comment.id else state.taxiUserLikedCommentIds + comment.id)
    }
    viewModelScope.launch { vehiclesRepository.toggleTaxiCommentLike(driverId, comment.id, user.uid, !currentlyLiked) }
  }

  fun openTaxiList() {
    _uiState.update { it.copy(isTaxiListOpen = true) }
  }

  fun closeTaxiList() {
    _uiState.update { it.copy(isTaxiListOpen = false) }
  }

  fun toggleTaxiAvailability() {
    val profile = _uiState.value.userVehicleProfile ?: return
    if (!profile.isTaxiOwner) return
    val hasActiveOrder = _uiState.value.activeOrder?.let {
      it.status != OrderStatus.COMPLETED && it.status != OrderStatus.REJECTED && it.status != OrderStatus.CANCELLED
    } == true
    if (hasActiveOrder) return
    val nextAvailable = profile.taxiStatus != TaxiDriverStatus.AVAILABLE
    val updated = profile.copy(
        taxiStatus = if (nextAvailable) TaxiDriverStatus.AVAILABLE else TaxiDriverStatus.UNAVAILABLE,
        isAcceptingOrders = nextAvailable,
        isSharingLocation = true,
        lastUpdatedAt = System.currentTimeMillis()
    )
    vehiclesRepository.saveLocalProfile(updated)
    _uiState.update { it.copy(userVehicleProfile = updated) }
    viewModelScope.launch {
      val user = authSessionManager.currentUser.value
      if (user != null) vehiclesRepository.syncProfileWithFirestore(updated.copy(userId = user.uid))
    }
  }

  fun requestOrderFromDriver(vehicle: LiveVehicle) {
    if (!vehicle.effectiveIsAvailable) return
    val existingOrder = _uiState.value.activeOrder
    if (existingOrder != null && existingOrder.status != OrderStatus.COMPLETED && existingOrder.status != OrderStatus.REJECTED && existingOrder.status != OrderStatus.CANCELLED) return
    val user = authSessionManager.currentUser.value
    val customerId = user?.uid ?: UUID.randomUUID().toString()
    val customerName = user?.displayName?.ifBlank { null } ?: "راكب في مجتمع DRAW"
    val userLoc = _uiState.value.userLocation
    val pickupLat = userLoc?.latitude ?: vehicle.latitude
    val pickupLng = userLoc?.longitude ?: vehicle.longitude

    var distanceMeters = 0.0f
    if (userLoc != null && vehicle.latitude != 0.0 && vehicle.longitude != 0.0) {
      val res = FloatArray(1)
      Location.distanceBetween(
          userLoc.latitude, userLoc.longitude,
          vehicle.latitude, vehicle.longitude,
          res
      )
      distanceMeters = res[0]
    }
    val distanceKm = if (distanceMeters > 0) (distanceMeters / 1000.0) else 1.0
    val farePerKm = vehicle.farePerKm
    val estimatedFare = if (farePerKm > 0.0) distanceKm * farePerKm else 0.0

    val order = ServiceOrder(
        id = UUID.randomUUID().toString(),
        passengerUid = customerId,
        passengerName = customerName,
        driverUid = vehicle.effectiveUserId,
        driverName = vehicle.driverName,
        vehicleModelId = "taxi_city",
        serviceType = "تاكسي",
        pickupLat = pickupLat,
        pickupLng = pickupLng,
        status = OrderStatus.WAITING_APPROVAL,
        estimatedDistanceMeters = distanceMeters,
        farePerKm = farePerKm,
        estimatedFare = estimatedFare,
        taxiColorHex = vehicle.effectiveColorHex,
        taxiCarModel = vehicle.effectiveCarModel,
        createdAt = System.currentTimeMillis(),
        updatedAt = System.currentTimeMillis()
    )

    dismissDriverProfile()
    _uiState.update { it.copy(activeOrder = order) }

    viewModelScope.launch {
      try {
        val result = vehiclesRepository.createOrder(order)
        if (result.isSuccess) {
          _uiState.update { it.copy(statusMessage = "تم إرسال الطلب للسائق، ننتظر رده لمدة دقيقة") }
        } else {
          _uiState.update { it.copy(activeOrder = null, statusMessage = "تعذر إرسال الطلب للسائق، حاول مرة أخرى") }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error creating service order", e)
        _uiState.update { it.copy(activeOrder = null, statusMessage = "تعذر إرسال الطلب للسائق، حاول مرة أخرى") }
      }
    }
  }

  fun acceptIncomingOrder(order: ServiceOrder) {
    _uiState.update { it.copy(incomingOrder = null, activeOrder = order.copy(status = OrderStatus.ACCEPTED)) }
    viewModelScope.launch {
      try {
        vehiclesRepository.updateOrderStatus(order.id, OrderStatus.ACCEPTED)

        // Set driver's local profile taxi status to EN_ROUTE_TO_PICKUP and sync
        val profile = vehiclesRepository.getLocalProfile()
        if (profile.isTaxiOwner) {
          val updatedProfile = profile.copy(taxiStatus = TaxiDriverStatus.EN_ROUTE_TO_PICKUP)
          vehiclesRepository.saveLocalProfile(updatedProfile)
          val user = authSessionManager.currentUser.value
          if (user != null) {
            vehiclesRepository.syncProfileWithFirestore(updatedProfile.copy(userId = user.uid))
          }
        }

        // Calculate and draw route from driver position to pickup point
        val userLoc = _uiState.value.userLocation
        if (userLoc != null && order.pickupLat != 0.0 && order.pickupLng != 0.0) {
          val response = navigationRepository.getRoute(
              startLat = userLoc.latitude,
              startLon = userLoc.longitude,
              endLat = order.pickupLat,
              endLon = order.pickupLng
          )
          val routes = response?.routes ?: emptyList()
          if (routes.isNotEmpty()) {
            val shortest = routes.minByOrNull { it.distance } ?: routes[0]
            val option = RouteOption(
                index = 0,
                colorHex = "#007AFF",
                colorNameArabic = "المسار الأزرق",
                rankDescriptionArabic = "مسار التوجه لموقع الراكب",
                route = shortest
            )
            _uiState.update {
              it.copy(
                  routeOptions = listOf(option),
                  selectedRouteIndex = 0,
                  currentRoute = shortest,
                  isNavigating = false
              )
            }
          }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error accepting order", e)
      }
    }
  }

  fun rejectIncomingOrder(order: ServiceOrder) {
    _uiState.update { it.copy(incomingOrder = null) }
    viewModelScope.launch {
      try {
        vehiclesRepository.updateOrderStatus(order.id, OrderStatus.REJECTED)
      } catch (e: Exception) {
        Log.e(TAG, "Error rejecting order", e)
      }
    }
  }

  fun advanceOrderStatus(order: ServiceOrder, newStatus: OrderStatus) {
    _uiState.update { it.copy(activeOrder = order.copy(status = newStatus)) }
    viewModelScope.launch {
      try {
        vehiclesRepository.updateOrderStatus(order.id, newStatus)

        // Sync TaxiDriverStatus lifecycle
        val profile = vehiclesRepository.getLocalProfile()
        if (profile.isTaxiOwner) {
          val targetTaxiStatus = when (newStatus) {
            OrderStatus.IN_PROGRESS -> TaxiDriverStatus.IN_TRIP
            OrderStatus.COMPLETED, OrderStatus.CANCELLED, OrderStatus.REJECTED -> TaxiDriverStatus.AVAILABLE
            else -> profile.taxiStatus
          }
          if (targetTaxiStatus != profile.taxiStatus) {
            val updatedProfile = profile.copy(taxiStatus = targetTaxiStatus)
            vehiclesRepository.saveLocalProfile(updatedProfile)
            val user = authSessionManager.currentUser.value
            if (user != null) {
              vehiclesRepository.syncProfileWithFirestore(updatedProfile.copy(userId = user.uid))
            }
          }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error advancing order status", e)
      }
    }
  }

  fun cancelOrder(order: ServiceOrder) {
    _uiState.update { it.copy(activeOrder = order.copy(status = OrderStatus.CANCELLED)) }
    viewModelScope.launch {
      try {
        vehiclesRepository.updateOrderStatus(order.id, OrderStatus.CANCELLED)
        val profile = vehiclesRepository.getLocalProfile()
        if (profile.isTaxiOwner) {
          val updatedProfile = profile.copy(taxiStatus = TaxiDriverStatus.AVAILABLE)
          vehiclesRepository.saveLocalProfile(updatedProfile)
          val user = authSessionManager.currentUser.value
          if (user != null) {
            vehiclesRepository.syncProfileWithFirestore(updatedProfile.copy(userId = user.uid))
          }
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error cancelling order", e)
      }
    }
  }

  fun submitTripReview(order: ServiceOrder, liked: Boolean, comment: String?) {
    viewModelScope.launch {
      try {
        vehiclesRepository.submitTripReview(
            orderId = order.id,
            driverId = order.effectiveDriverId,
            liked = liked,
            comment = comment
        )
        _uiState.update { state ->
          val curr = state.activeOrder
          if (curr != null && curr.id == order.id) {
            state.copy(activeOrder = curr.copy(passengerLiked = liked, passengerComment = comment))
          } else state
        }
      } catch (e: Exception) {
        Log.e(TAG, "Error submitting trip review", e)
      }
    }
  }

  fun submitReportDriver(driverId: String, reason: String) {
    viewModelScope.launch {
      try {
        val orderId = _uiState.value.activeOrder?.id ?: ""
        val reporterUid = authSessionManager.currentUser.value?.uid ?: ""
        vehiclesRepository.submitReport(
            orderId = orderId,
            targetUserId = driverId,
            reporterUid = reporterUid,
            reason = reason
        )
      } catch (e: Exception) {
        Log.e(TAG, "Error reporting driver", e)
      }
    }
  }

  fun dismissActiveOrderCard() {
    _uiState.update { it.copy(activeOrder = null) }
  }

  override fun onCleared() {
    super.onCleared()
    navigationVoiceSpeaker?.shutdown()
  }
}
