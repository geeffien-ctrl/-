package com.example.data.repository

import android.content.Context
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlin.math.abs

/**
 * OrientationSensorRepository:
 * Captures real-time device orientation and compass heading using Android's hardware sensors
 * (Sensor.TYPE_ROTATION_VECTOR or fallback to Sensor.TYPE_ORIENTATION).
 * Emits smoothed azimuth in degrees [0, 360) where 0 = North, 90 = East, 180 = South, 270 = West.
 */
class OrientationSensorRepository(context: Context) {
  private val sensorManager =
      context.applicationContext.getSystemService(Context.SENSOR_SERVICE) as? SensorManager

  /**
   * Flow of filtered azimuth heading in degrees [0, 360).
   * Unregisters hardware listener automatically when not actively collected.
   */
  fun getHeadingUpdates(): Flow<Float> = callbackFlow {
    val manager = sensorManager
    if (manager == null) {
      close()
      return@callbackFlow
    }

    val rotationSensor = manager.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR)
        ?: manager.getDefaultSensor(Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR)
        ?: manager.getDefaultSensor(Sensor.TYPE_ORIENTATION)

    if (rotationSensor == null) {
      close()
      return@callbackFlow
    }

    val rotationMatrix = FloatArray(9)
    val orientationAngles = FloatArray(3)
    var lastEmittedHeading = -1f

    val listener = object : SensorEventListener {
      override fun onSensorChanged(event: SensorEvent) {
        val sensorType = event.sensor.type
        if (sensorType == Sensor.TYPE_ROTATION_VECTOR ||
            sensorType == Sensor.TYPE_GEOMAGNETIC_ROTATION_VECTOR) {
          try {
            SensorManager.getRotationMatrixFromVector(rotationMatrix, event.values)
            SensorManager.getOrientation(rotationMatrix, orientationAngles)
            var azimuth = Math.toDegrees(orientationAngles[0].toDouble()).toFloat()
            if (azimuth < 0f) azimuth += 360f
            emitSmoothed(azimuth)
          } catch (_: Exception) {}
        } else if (sensorType == Sensor.TYPE_ORIENTATION) {
          var azimuth = event.values[0]
          if (azimuth < 0f) azimuth += 360f
          emitSmoothed(azimuth)
        }
      }

      private fun emitSmoothed(newHeading: Float) {
        if (lastEmittedHeading < 0f) {
          lastEmittedHeading = newHeading
          trySend(newHeading)
          return
        }

        // Circular angular difference: finds the shortest arc
        var diff = (newHeading - lastEmittedHeading) % 360f
        if (diff < -180f) diff += 360f
        if (diff > 180f) diff -= 360f

        // Filter out micro-jitter under 0.8 degrees to save battery and eliminate hand tremors
        if (abs(diff) >= 0.8f) {
          // Low-pass filter for buttery smooth transition
          val smoothed = ((lastEmittedHeading + diff * 0.35f) % 360f + 360f) % 360f
          lastEmittedHeading = smoothed
          trySend(smoothed)
        }
      }

      override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}
    }

    manager.registerListener(
        listener,
        rotationSensor,
        SensorManager.SENSOR_DELAY_UI
    )

    awaitClose {
      manager.unregisterListener(listener)
    }
  }
}
