package com.example.ui.auth

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material.icons.outlined.PersonOutline
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import com.example.R
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.BalloonButton
import com.example.ui.components.BalloonTextField
import com.example.ui.components.DrawBrandHeader
import com.example.ui.components.ProviderSignInCard
import com.example.ui.theme.DrawBorderLight
import com.example.ui.theme.DrawLinkBlue
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawSurfaceLight
import com.example.ui.theme.DrawTextMuted
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import com.example.ui.theme.DrawWhite

/**
 * DRAW Phase 2: Login Screen
 *
 * Contains strictly the requested elements in order:
 * 1. Official DRAW logo (3D red-and-white design)
 * 2. Short, welcoming login heading
 * 3. Username-or-email input field
 * 4. Password input field with show/hide password control
 * 5. Blue "Forgot password?" link directly below password field
 * 6. Horizontal row with three clearly labeled sign-in options: Guest, Google, Apple
 * 7. Bottom registration prompt: "Don't have an account? Create account"
 */
@Composable
fun LoginScreen(
    uiState: AuthUiState,
    onUsernameOrEmailChange: (String) -> Unit,
    onPasswordChange: (String) -> Unit,
    onTogglePasswordVisibility: () -> Unit,
    onForgotPasswordClick: () -> Unit,
    onLoginSubmit: () -> Unit,
    onGuestSignIn: () -> Unit,
    onGoogleSignIn: () -> Unit,
    onAppleSignIn: () -> Unit,
    onCreateAccountClick: () -> Unit,
    modifier: Modifier = Modifier,
) {
  var isVisible by remember { mutableStateOf(false) }
  LaunchedEffect(Unit) { isVisible = true }

  val scrollState = rememberScrollState()

  Box(
      modifier =
          modifier
              .fillMaxSize()
              .background(DrawRed)
              .imePadding(),
  ) {
    // Top decorative curved background
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier =
            Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 24.dp),
    ) {
      Spacer(modifier = Modifier.height(16.dp))

      // Main White Card Surface
      AnimatedVisibility(
          visible = isVisible,
          enter =
              fadeIn(animationSpec = tween(500)) +
                  slideInVertically(
                      initialOffsetY = { 60 },
                      animationSpec = tween(500),
                  ),
      ) {
        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = DrawWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
            modifier =
                Modifier
                    .fillMaxWidth()
                    .widthIn(max = 480.dp)
                    .shadow(elevation = 16.dp, shape = RoundedCornerShape(32.dp), clip = false)
                    .testTag("login_card_surface"),
        ) {
          Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier =
                  Modifier
                      .fillMaxWidth()
                      .padding(horizontal = 24.dp, vertical = 32.dp),
          ) {
            // 1. Official DRAW Logo & 2. Welcoming Login Heading
            DrawBrandHeader(
                title = "Welcome Back",
                subtitle = "Sign in to continue your journey with DRAW",
                logoSize = 80.dp,
            )

            Spacer(modifier = Modifier.height(28.dp))

            // 3. Email Input Field (English placeholder: Enter your email)
            BalloonTextField(
                value = uiState.loginUsernameOrEmail,
                onValueChange = onUsernameOrEmailChange,
                label = "Email",
                placeholder = "Enter your email",
                leadingIcon = Icons.Outlined.Email,
                errorMessage = uiState.loginUsernameOrEmailError,
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next,
                    ),
                testTag = "login_username_or_email_input",
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Password Input Field (English placeholder: Enter your password)
            BalloonTextField(
                value = uiState.loginPassword,
                onValueChange = onPasswordChange,
                label = "Password",
                placeholder = "Enter your password",
                leadingIcon = Icons.Outlined.Lock,
                errorMessage = uiState.loginPasswordError,
                visualTransformation =
                    if (uiState.isLoginPasswordVisible) VisualTransformation.None
                    else PasswordVisualTransformation(),
                trailingIcon = {
                  IconButton(
                      onClick = onTogglePasswordVisibility,
                      modifier = Modifier.testTag("login_password_visibility_toggle"),
                  ) {
                    Icon(
                        imageVector =
                            if (uiState.isLoginPasswordVisible) Icons.Filled.VisibilityOff
                            else Icons.Filled.Visibility,
                        contentDescription =
                            if (uiState.isLoginPasswordVisible) "Hide password"
                            else "Show password",
                        tint = DrawTextSecondary,
                        modifier = Modifier.size(20.dp),
                    )
                  }
                },
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done,
                    ),
                keyboardActions = KeyboardActions(onDone = { onLoginSubmit() }),
                testTag = "login_password_input",
            )

            Spacer(modifier = Modifier.height(4.dp))

            // Primary Sign-In Action Button (Red background with clean pure white text)
            BalloonButton(
                text = "Sign In",
                onClick = onLoginSubmit,
                isLoading = uiState.isLoading,
                backgroundColor = DrawRed,
                contentColor = DrawWhite,
                testTag = "login_submit_button",
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Guest-only continuation
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            ) {
              Box(modifier = Modifier.weight(1f).height(1.dp).background(DrawBorderLight))
              Text(
                  text = "or continue as guest",
                  fontSize = 12.sp,
                  color = DrawTextMuted,
                  modifier = Modifier.padding(horizontal = 12.dp),
              )
              Box(modifier = Modifier.weight(1f).height(1.dp).background(DrawBorderLight))
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Guest sign-in only; Google and Apple quick registration are intentionally removed.
            Row(
                horizontalArrangement = Arrangement.spacedBy(10.dp),
                modifier =
                    Modifier
                        .fillMaxWidth()
                        .testTag("login_providers_row"),
            ) {
              ProviderSignInCard(
                  label = "الدخول كضيف",
                  icon = {
                    Icon(
                        imageVector = Icons.Filled.AccountCircle,
                        contentDescription = "Guest",
                        tint = Color(0xFF2563EB),
                        modifier = Modifier.size(28.dp),
                    )
                  },
                  onClick = onGuestSignIn,
                  modifier = Modifier.fillMaxWidth().height(64.dp),
                  testTag = "guest_sign_in_button",
              )
            }

            Spacer(modifier = Modifier.height(28.dp))

            // 7. Bottom Registration Prompt: "Don't have an account? Create account"
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth(),
            ) {
              Text(
                  text = "Don't have an account? ",
                  fontSize = 14.sp,
                  color = DrawTextSecondary,
              )
              Text(
                  text = "Create account",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = DrawLinkBlue,
                  modifier =
                      Modifier
                          .clickable(onClick = onCreateAccountClick)
                          .padding(vertical = 4.dp)
                          .testTag("create_account_link"),
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(16.dp))
    }
  }
}
