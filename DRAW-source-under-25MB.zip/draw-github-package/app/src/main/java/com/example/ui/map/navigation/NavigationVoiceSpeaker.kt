package com.example.ui.map.navigation

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import com.example.data.model.OsrmRoute
import java.util.Locale

import android.speech.tts.UtteranceProgressListener
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

private const val TAG = "NavigationVoiceSpeaker"

data class RouteOption(
    val index: Int,
    val colorHex: String,
    val colorNameArabic: String,
    val rankDescriptionArabic: String,
    val route: OsrmRoute
)

/**
 * Voice Navigation & AI Speaker for DRAW map guidance and assistant interactions.
 */
class NavigationVoiceSpeaker(context: Context) {
  private val appContext = context.applicationContext
  private var tts: TextToSpeech? = null
  private var isInitialized = false
  private var isMuted = false

  private val _isSpeaking = MutableStateFlow(false)
  val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

  private val _currentSpeakingUtteranceId = MutableStateFlow<String?>(null)
  val currentSpeakingUtteranceId: StateFlow<String?> = _currentSpeakingUtteranceId.asStateFlow()

  init {
    tts = TextToSpeech(appContext) { status ->
      if (status == TextToSpeech.SUCCESS) {
        val arLocale = Locale("ar")
        val result = tts?.setLanguage(arLocale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
          Log.w(TAG, "Arabic TTS language is not supported or missing data, falling back to default")
          tts?.language = Locale.getDefault()
        }
        tts?.setSpeechRate(0.95f)
        tts?.setPitch(1.0f)

        tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
          override fun onStart(utteranceId: String?) {
            _isSpeaking.value = true
            _currentSpeakingUtteranceId.value = utteranceId
          }

          override fun onDone(utteranceId: String?) {
            _isSpeaking.value = false
            _currentSpeakingUtteranceId.value = null
          }

          override fun onError(utteranceId: String?) {
            _isSpeaking.value = false
            _currentSpeakingUtteranceId.value = null
          }
        })

        isInitialized = true
      } else {
        Log.e(TAG, "TextToSpeech initialization failed with status $status")
      }
    }
  }

  fun setMuted(muted: Boolean) {
    isMuted = muted
    if (muted) {
      stop()
    }
  }

  fun isMuted(): Boolean = isMuted

  /**
   * Speaks an AI assistant conversational answer with speech synthesis.
   * Cleans emojis and markup for smooth Arabic pronunciation.
   */
  fun speakAiResponse(text: String, utteranceId: String = "AI_MSG_${System.currentTimeMillis()}") {
    if (isMuted || !isInitialized || text.isBlank()) return

    val cleanText = text
        .replace(Regex("""\[Place:[^\]]+\]"""), "")
        .replace(Regex("""[*#_`~>\[\]]"""), "")
        .replace(Regex("""[\uD83C-\uDBFF\uDC00-\uDFFF]+"""), "") // Remove emojis
        .trim()

    if (cleanText.isBlank()) return

    try {
      tts?.speak(cleanText, TextToSpeech.QUEUE_FLUSH, null, utteranceId)
    } catch (e: Exception) {
      Log.e(TAG, "Error speaking AI response", e)
      _isSpeaking.value = false
      _currentSpeakingUtteranceId.value = null
    }
  }

  private fun speak(text: String, queueMode: Int = TextToSpeech.QUEUE_FLUSH) {
    if (isMuted || !isInitialized || text.isBlank()) return
    try {
      tts?.speak(text, queueMode, null, "DRAW_NAV_${System.currentTimeMillis()}")
    } catch (e: Exception) {
      Log.e(TAG, "Error speaking navigation utterance: $text", e)
    }
  }

  fun speakRoutesDiscovered(routes: List<RouteOption>) {
    if (routes.isEmpty()) return
    val count = routes.size
    val sb = StringBuilder()
    if (count == 1) {
      val r = routes[0]
      sb.append("تم العثور على المسار الأنسب بمسافة ${r.route.formattedDistance} والوقت المتوقع ${r.route.formattedDuration}.")
    } else {
      sb.append("تم العثور على $count مسارات بديلة. ")
      routes.forEach { opt ->
        sb.append("${opt.colorNameArabic} هو ${opt.rankDescriptionArabic} بمسافة ${opt.route.formattedDistance}. ")
      }
      sb.append("المسار الأزرق محدد افتراضياً كأقصر مسار.")
    }
    speak(sb.toString())
  }

  fun speakRouteSelected(option: RouteOption) {
    val text = "بدأت اتباع ${option.colorNameArabic}، وهو ${option.rankDescriptionArabic}. المسافة ${option.route.formattedDistance}، والوقت ${option.route.formattedDuration}."
    speak(text)
  }

  fun speakStepInstruction(instruction: String) {
    if (instruction.isNotBlank()) {
      // Urgent turn or hazard: instantly interrupts any ongoing periodic speech
      stop()
      speak(instruction)
    }
  }

  fun speakCompanionTip(tip: String) {
    if (isMuted || !isInitialized || tip.isBlank() || _isSpeaking.value) return
    speak(tip, TextToSpeech.QUEUE_ADD)
  }

  fun speakArrival() {
    speak("نجحت المهمة! وصلت إلى وجهتك.")
  }

  fun stop() {
    try {
      tts?.stop()
    } catch (e: Exception) {
      Log.e(TAG, "Error stopping TTS", e)
    } finally {
      _isSpeaking.value = false
      _currentSpeakingUtteranceId.value = null
    }
  }

  fun shutdown() {
    try {
      tts?.stop()
      tts?.shutdown()
      tts = null
      isInitialized = false
    } catch (e: Exception) {
      Log.e(TAG, "Error shutting down TTS", e)
    } finally {
      _isSpeaking.value = false
      _currentSpeakingUtteranceId.value = null
    }
  }
}
