package com.example.ui.settings

import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Storage
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@Composable
fun AboutSubScreen(
    modifier: Modifier = Modifier,
) {
  val cardShape = RoundedCornerShape(22.dp)

  Column(
      modifier = modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
      verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // DRAW Hero Emblem & Version
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier.padding(top = 10.dp),
    ) {
      Box(
          modifier = Modifier
              .size(86.dp)
              .clip(CircleShape)
              .background(DrawRed)
              .shadow(8.dp, CircleShape),
          contentAlignment = Alignment.Center,
      ) {
        Image(
            painter = painterResource(id = R.drawable.ic_launcher_foreground),
            contentDescription = "DRAW Logo",
            modifier = Modifier.size(66.dp),
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
          text = "DRAW Navigation",
          fontSize = 22.sp,
          fontWeight = FontWeight.Bold,
          color = DrawTextNearBlack,
      )

      Text(
          text = "الإصدار 1.0.0 (النسخة الرسمية)",
          fontSize = 13.5.sp,
          color = DrawTextSecondary,
      )
    }

    // Technology Stack Info Card
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, cardShape, spotColor = Color(0x18000000))
            .border(0.8.dp, Color(0x14000000), cardShape),
        shape = cardShape,
        color = Color.White,
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Text(
            text = "التقنيات ومصادر البيانات",
            fontSize = 15.5.sp,
            fontWeight = FontWeight.Bold,
            color = DrawTextNearBlack,
        )

        Spacer(modifier = Modifier.height(14.dp))

        TechDetailRow(
            icon = Icons.Default.Map,
            title = "مزود الخرائط الفيكتورية",
            subtitle = "OpenFreeMap (نمط Positron الفاتح)",
            detail = "https://tiles.openfreemap.org/styles/positron",
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0x14000000), thickness = 0.8.dp)

        TechDetailRow(
            icon = Icons.Default.Code,
            title = "محرك عرض الخريطة",
            subtitle = "MapLibre GL JS v4",
            detail = "محرك رسومي متقدم ثلاثي وثنائي الأبعاد يدعم البلاطات الاتجاهية",
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0x14000000), thickness = 0.8.dp)

        TechDetailRow(
            icon = Icons.Default.Navigation,
            title = "نظام التوجيه والمسارات",
            subtitle = "OSRM & OpenStreetMap",
            detail = "حساب المسارات في الوقت الفعلي مع إرشادات المنعطفات",
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0x14000000), thickness = 0.8.dp)

        TechDetailRow(
            icon = Icons.Default.Storage,
            title = "الخادم السحابي وقواعد البيانات",
            subtitle = "Google Firebase & Cloud Firestore",
            detail = "حفظ الأماكن المفضلة وسجلات الحساب بصيغة آمنة ومشفرة",
        )
      }
    }

    // Rights & Open Source
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, cardShape, spotColor = Color(0x10000000))
            .border(0.8.dp, Color(0x12000000), cardShape),
        shape = cardShape,
        color = Color(0xFFFAFAFC),
    ) {
      Column(
          modifier = Modifier.padding(18.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
      ) {
        Text(
            text = "حقوق النشر ومساهمو البيانات",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = DrawTextNearBlack,
        )
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "بيانات الخرائط مقدمة بموجب ترخيص قاعدة البيانات المفتوحة (ODbL) من قِبل مساهمي OpenStreetMap وOpenFreeMap. جميع حقوق علامة DRAW محفوظة.",
            fontSize = 12.sp,
            color = DrawTextSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 17.sp,
        )
      }
    }
  }
}

@Composable
private fun TechDetailRow(
    icon: ImageVector,
    title: String,
    subtitle: String,
    detail: String,
) {
  Row(
      verticalAlignment = Alignment.Top,
      modifier = Modifier.fillMaxWidth(),
  ) {
    Box(
        modifier = Modifier
            .size(38.dp)
            .clip(CircleShape)
            .background(Color(0xFFFFECEB)),
        contentAlignment = Alignment.Center,
    ) {
      Icon(
          imageVector = icon,
          contentDescription = null,
          tint = DrawRed,
          modifier = Modifier.size(20.dp),
      )
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
          text = title,
          fontSize = 14.5.sp,
          fontWeight = FontWeight.SemiBold,
          color = DrawTextNearBlack,
      )
      Text(
          text = subtitle,
          fontSize = 12.5.sp,
          fontWeight = FontWeight.Medium,
          color = DrawDarkRed,
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
          text = detail,
          fontSize = 11.5.sp,
          color = DrawTextSecondary,
          lineHeight = 15.sp,
      )
    }
  }
}
