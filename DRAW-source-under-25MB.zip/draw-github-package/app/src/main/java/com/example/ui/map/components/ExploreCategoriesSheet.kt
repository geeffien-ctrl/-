package com.example.ui.map.components

import android.location.Location
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.LocationOn
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.PublicPlace
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * Modal bottom sheet presenting all 60 iOS-styled place categories,
 * and listing places in each category sorted accurately from nearest to farthest.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExploreCategoriesSheet(
    userLocation: Location? = null,
    publicPlaces: List<PublicPlace> = emptyList(),
    onPlaceSelected: (PublicPlace) -> Unit = {},
    onCategorySelected: (PlaceIconItem) -> Unit = {},
    onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = false)
  var selectedCategoryKey by remember { mutableStateOf("all") }
  var selectedIconItem by remember { mutableStateOf<PlaceIconItem?>(null) }

  ModalBottomSheet(
      onDismissRequest = onDismiss,
      sheetState = sheetState,
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      containerColor = Color(0xFDFDFDFF),
      dragHandle = {
        Box(
            modifier = Modifier
                .padding(top = 10.dp, bottom = 6.dp)
                .size(width = 38.dp, height = 4.dp)
                .clip(CircleShape)
                .background(Color(0xFFD1D1D6))
        )
      }
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 18.dp)
            .padding(bottom = 32.dp)
            .testTag("explore_categories_sheet")
    ) {
      if (selectedIconItem == null) {
        // --- VIEW 1: Categories & 60 Icons Grid ---
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFECEB)),
                contentAlignment = Alignment.Center
            ) {
              Icon(
                  imageVector = Icons.Default.Explore,
                  contentDescription = null,
                  tint = DrawRed,
                  modifier = Modifier.size(22.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                  text = "أقسام وأماكن الخريطة",
                  fontSize = 17.5.sp,
                  fontWeight = FontWeight.Bold,
                  color = DrawTextNearBlack
              )
              Text(
                  text = "اختر قسماً لعرض الأماكن من الأقرب إلى الأبعد",
                  fontSize = 12.sp,
                  color = DrawTextSecondary
              )
            }
          }

          IconButton(
              onClick = onDismiss,
              modifier = Modifier
                  .size(30.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFE5E5EA))
                  .testTag("close_explore_sheet")
          ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = Color(0xFF3A3A3C),
                modifier = Modifier.size(16.dp)
            )
          }
        }

        HorizontalDivider(color = Color(0x12000000), thickness = 0.8.dp)
        Spacer(modifier = Modifier.height(10.dp))

        // Category Filter Chips
        val scrollState = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(scrollState),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          PlaceIconRegistry.categories.forEach { cat ->
            val isSelected = selectedCategoryKey == cat.key
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isSelected) cat.color else Color(0xFFF2F2F7))
                .clickable { selectedCategoryKey = cat.key }
                .padding(horizontal = 12.dp, vertical = 7.dp)
                .testTag("explore_filter_${cat.key}")
            ) {
              Text(
                  text = cat.nameArabic,
                  fontSize = 12.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else Color(0xFF3C3C43)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // 60 Icons Grid
        val filteredIcons = PlaceIconRegistry.getIconsByCategory(selectedCategoryKey)
        LazyVerticalGrid(
            columns = GridCells.Fixed(4),
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 420.dp)
                .testTag("explore_icons_grid"),
            contentPadding = PaddingValues(bottom = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
          items(filteredIcons, key = { it.id }) { iconItem ->
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { selectedIconItem = iconItem }
                    .padding(vertical = 4.dp, horizontal = 2.dp)
                    .testTag("explore_icon_${iconItem.id}")
            ) {
              Box(
                  modifier = Modifier
                      .size(54.dp)
                      .shadow(elevation = 2.dp, shape = RoundedCornerShape(18.dp), spotColor = iconItem.primaryColor.copy(alpha = 0.35f))
                      .clip(RoundedCornerShape(18.dp))
                      .background(iconItem.softBgColor)
                      .border(width = 1.dp, color = iconItem.primaryColor.copy(alpha = 0.25f), shape = RoundedCornerShape(18.dp)),
                  contentAlignment = Alignment.Center
              ) {
                Icon(
                    imageVector = iconItem.iconVector,
                    contentDescription = iconItem.nameArabic,
                    tint = iconItem.primaryColor,
                    modifier = Modifier.size(28.dp)
                )
              }

              Spacer(modifier = Modifier.height(6.dp))

              Text(
                  text = iconItem.nameArabic,
                  fontSize = 11.5.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = DrawTextNearBlack,
                  textAlign = TextAlign.Center,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
              )

              Text(
                  text = iconItem.categoryArabic,
                  fontSize = 9.5.sp,
                  color = DrawTextSecondary,
                  textAlign = TextAlign.Center,
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
              )
            }
          }
        }
      } else {
        // --- VIEW 2: Places in Selected Category Sorted from Nearest to Farthest ---
        val currentIcon = selectedIconItem!!
        val matchingPlaces = remember(publicPlaces, currentIcon, userLocation) {
          val filtered = publicPlaces.filter { place ->
            place.iconId.equals(currentIcon.id, ignoreCase = true) ||
            place.category.equals(currentIcon.categoryKey, ignoreCase = true) ||
            place.title.contains(currentIcon.nameArabic)
          }

          val uLat = userLocation?.latitude ?: 33.3152
          val uLon = userLocation?.longitude ?: 44.3661

          // Calculate distance and sort ascending: Nearest -> Farthest
          filtered.map { place ->
            val dist = computeDistanceMeters(uLat, uLon, place.latitude, place.longitude)
            Pair(place, dist)
          }.sortedBy { it.second }
        }

        // Sub-Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
          ) {
            IconButton(
                onClick = { selectedIconItem = null },
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF2F2F7))
            ) {
              Icon(
                  imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                  contentDescription = "Back",
                  tint = DrawTextNearBlack,
                  modifier = Modifier.size(18.dp)
              )
            }
            Spacer(modifier = Modifier.width(10.dp))
            Column {
              Text(
                  text = "أماكن «${currentIcon.nameArabic}» القريبة",
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Bold,
                  color = DrawTextNearBlack
              )
              Text(
                  text = "مرتبة حسب المسافة من الأقرب إلى الأبعد",
                  fontSize = 11.5.sp,
                  color = DrawTextSecondary
              )
            }
          }

          IconButton(
              onClick = onDismiss,
              modifier = Modifier
                  .size(30.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFE5E5EA))
          ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = Color(0xFF3A3A3C),
                modifier = Modifier.size(16.dp)
            )
          }
        }

        HorizontalDivider(color = Color(0x12000000), thickness = 0.8.dp)
        Spacer(modifier = Modifier.height(10.dp))

        if (matchingPlaces.isNotEmpty()) {
          LazyColumn(
              modifier = Modifier
                  .fillMaxWidth()
                  .heightIn(max = 420.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp),
              contentPadding = PaddingValues(bottom = 14.dp)
          ) {
            items(matchingPlaces, key = { it.first.id }) { (place, dist) ->
              val isNearest = (place.id == matchingPlaces.first().first.id)

              Surface(
                  shape = RoundedCornerShape(16.dp),
                  color = if (isNearest) Color(0xFFF0FDF4) else Color(0xFFFAFAFA),
                  border = androidx.compose.foundation.BorderStroke(
                      width = if (isNearest) 1.5.dp else 1.dp,
                      color = if (isNearest) Color(0xFF22C55E) else Color(0x14000000)
                  ),
                  modifier = Modifier
                      .fillMaxWidth()
                      .clickable {
                        onPlaceSelected(place)
                        onDismiss()
                      }
                      .testTag("category_place_item_${place.id}")
              ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                  // Category colored icon
                  Box(
                      modifier = Modifier
                          .size(44.dp)
                          .clip(RoundedCornerShape(12.dp))
                          .background(currentIcon.softBgColor),
                      contentAlignment = Alignment.Center
                  ) {
                    Icon(
                        imageVector = currentIcon.iconVector,
                        contentDescription = null,
                        tint = currentIcon.primaryColor,
                        modifier = Modifier.size(24.dp)
                    )
                  }

                  Spacer(modifier = Modifier.width(12.dp))

                  Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Text(
                          text = place.title,
                          fontSize = 14.5.sp,
                          fontWeight = FontWeight.Bold,
                          color = DrawTextNearBlack,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis,
                          modifier = Modifier.weight(1f, fill = false)
                      )
                      if (isNearest) {
                        Spacer(modifier = Modifier.width(6.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFF22C55E)
                        ) {
                          Text(
                              text = "الأقرب إليك",
                              fontSize = 10.sp,
                              fontWeight = FontWeight.Bold,
                              color = Color.White,
                              modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                          )
                        }
                      }
                    }

                    Spacer(modifier = Modifier.height(2.dp))

                    // Distance badge
                    Row(verticalAlignment = Alignment.CenterVertically) {
                      Icon(
                          imageVector = Icons.Default.NearMe,
                          contentDescription = null,
                          tint = if (isNearest) Color(0xFF15803D) else Color(0xFF0284C7),
                          modifier = Modifier.size(13.dp)
                      )
                      Spacer(modifier = Modifier.width(4.dp))
                      Text(
                          text = "يبعد: ${formatDistance(dist)}",
                          fontSize = 12.sp,
                          fontWeight = FontWeight.SemiBold,
                          color = if (isNearest) Color(0xFF15803D) else Color(0xFF0284C7)
                      )
                    }

                    // Geographic Coordinates
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "الإحداثيات: %.4f , %.4f".format(place.latitude, place.longitude),
                        fontSize = 11.sp,
                        color = DrawTextSecondary
                    )
                  }

                  Spacer(modifier = Modifier.width(8.dp))

                  Icon(
                      imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                      contentDescription = "Go",
                      tint = Color(0xFF8E8E93),
                      modifier = Modifier.size(14.dp)
                  )
                }
              }
            }
          }
        } else {
          // No public places yet in this category - show prompt to search OpenStreetMap
          Column(
              modifier = Modifier
                  .fillMaxWidth()
                  .padding(vertical = 24.dp),
              horizontalAlignment = Alignment.CenterHorizontally
          ) {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFF3F4F6)),
                contentAlignment = Alignment.Center
            ) {
              Icon(
                  imageVector = currentIcon.iconVector,
                  contentDescription = null,
                  tint = currentIcon.primaryColor,
                  modifier = Modifier.size(28.dp)
              )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "لا توجد منشورات مسجلة بعد في «${currentIcon.nameArabic}»",
                fontSize = 14.5.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack,
                textAlign = TextAlign.Center
            )

            Text(
                text = "يمكنك البحث المباشر في الخريطة عن أقرب ${currentIcon.nameArabic} بمحيطك الجغرافي.",
                fontSize = 12.sp,
                color = DrawTextSecondary,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 24.dp, vertical = 6.dp)
            )

            Spacer(modifier = Modifier.height(14.dp))

            Button(
                onClick = {
                  onCategorySelected(currentIcon)
                  onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = DrawRed,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.height(44.dp)
            ) {
              Icon(imageVector = Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp))
              Spacer(modifier = Modifier.width(8.dp))
              Text("البحث المباشر في الخريطة", fontWeight = FontWeight.Bold)
            }
          }
        }
      }
    }
  }
}

private fun computeDistanceMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
  val results = FloatArray(1)
  Location.distanceBetween(lat1, lon1, lat2, lon2, results)
  return results[0]
}

private fun formatDistance(meters: Float): String {
  return if (meters < 1000f) {
    "${meters.toInt()} م"
  } else {
    "%.1f كم".format(meters / 1000f)
  }
}
