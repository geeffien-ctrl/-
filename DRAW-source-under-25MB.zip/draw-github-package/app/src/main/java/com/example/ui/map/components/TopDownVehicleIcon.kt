package com.example.ui.map.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.nativeCanvas
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.VehicleLibrary

/**
 * Top-Down Bird's-Eye View Vehicle Icon Component.
 * Pure 90-degree overhead direct top-down perspective.
 * 100% transparent background - no circles, no squares, no badge containers.
 * Implements all 20 Curated DRAW Vehicle Models.
 */
@Composable
fun TopDownVehicleIcon(
    modelId: String,
    modifier: Modifier = Modifier,
    size: Dp = 48.dp,
    customColorHex: String? = null
) {
    val model = VehicleLibrary.getModelById(modelId)
    val colorHex = customColorHex ?: model.defaultColorHex
    val mainColor = try {
        Color(android.graphics.Color.parseColor(colorHex))
    } catch (_: Exception) {
        Color(0xFF3B82F6)
    }

    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height

            // Normalized 40x80 design grid scaled to Canvas
            val sx = w / 40f
            val sy = h / 80f

            val normalizedId = model.id.lowercase()
            when {
                normalizedId == "coupe_2door" || normalizedId.contains("coupe") -> drawTopDownCoupe(mainColor, sx, sy)
                normalizedId == "sports_car" || normalizedId.contains("sport") -> drawTopDownSportsCar(mainColor, sx, sy)
                normalizedId == "taxi_cab" || normalizedId.contains("taxi") -> drawTopDownTaxi(mainColor, sx, sy)
                else -> drawTopDownTaxi(mainColor, sx, sy)
            }
        }
    }
}

// 1. Coupe 2-Door (سيارة ببابين)
private fun DrawScope.drawTopDownCoupe(color: Color, sx: Float, sy: Float) {
    val w = 29f
    val l = 68f
    val x = (40f - w) / 2f
    val y = (80f - l) / 2f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(11f * sx, 11f * sy))
    val wheelColor = Color(0xFF1F2937)
    drawRoundRect(wheelColor, Offset((x - 2.5f) * sx, (y + 11f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(wheelColor, Offset((x + w - 2f) * sx, (y + 11f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(wheelColor, Offset((x - 2.5f) * sx, (y + l - 21f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(wheelColor, Offset((x + w - 2f) * sx, (y + l - 21f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))

    drawRoundRect(color, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(11f * sx, 11f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(11f * sx, 11f * sy), style = Stroke(1.4f * sx))

    val glassColor = Color(0xFF1E293B)
    drawRoundRect(glassColor, Offset((x + 3.5f) * sx, (y + 20f) * sy), Size((w - 7f) * sx, 9f * sy), CornerRadius(2.5f * sx, 2.5f * sy))
    drawRoundRect(Color.White.copy(alpha = 0.2f), Offset((x + 5f) * sx, (y + 30f) * sy), Size((w - 10f) * sx, 18f * sy), CornerRadius(4f * sx, 4f * sy))
    drawRoundRect(glassColor, Offset((x + 4.5f) * sx, (y + 49f) * sy), Size((w - 9f) * sx, 8f * sy), CornerRadius(3f * sx, 3f * sy))

    drawRoundRect(Color(0xFFFEF08A), Offset((x + 3f) * sx, (y + 1.5f) * sy), Size(5f * sx, 3f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color(0xFFFEF08A), Offset((x + w - 8f) * sx, (y + 1.5f) * sy), Size(5f * sx, 3f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color(0xFFDC2626), Offset((x + 3f) * sx, (y + l - 3f) * sy), Size(6f * sx, 2f * sy), CornerRadius(1f * sx, 1f * sy))
    drawRoundRect(Color(0xFFDC2626), Offset((x + w - 9f) * sx, (y + l - 3f) * sy), Size(6f * sx, 2f * sy), CornerRadius(1f * sx, 1f * sy))
}

// 2. Sedan 4-Door (سيارة بأربعة أبواب)
private fun DrawScope.drawTopDownSedan4Door(color: Color, sx: Float, sy: Float) {
    val w = 30f
    val l = 70f
    val x = (40f - w) / 2f
    val y = (80f - l) / 2f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(10f * sx, 10f * sy))
    val wheelColor = Color(0xFF1F2937)
    drawRoundRect(wheelColor, Offset((x - 2.5f) * sx, (y + 12f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(wheelColor, Offset((x + w - 2f) * sx, (y + 12f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(wheelColor, Offset((x - 2.5f) * sx, (y + l - 22f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(wheelColor, Offset((x + w - 2f) * sx, (y + l - 22f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))

    drawRoundRect(color, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(10f * sx, 10f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(10f * sx, 10f * sy), style = Stroke(1.4f * sx))

    val glassColor = Color(0xFF1E293B)
    drawRoundRect(glassColor, Offset((x + 3.5f) * sx, (y + 16f) * sy), Size((w - 7f) * sx, 9f * sy), CornerRadius(2.5f * sx, 2.5f * sy))
    drawRoundRect(Color.White.copy(alpha = 0.2f), Offset((x + 4.5f) * sx, (y + 26f) * sy), Size((w - 9f) * sx, 24f * sy), CornerRadius(3f * sx, 3f * sy))
    drawLine(Color.White.copy(alpha = 0.6f), Offset((x + 4.5f) * sx, (y + 38f) * sy), Offset((x + w - 4.5f) * sx, (y + 38f) * sy), 1.2f * sx)
    drawRoundRect(glassColor, Offset((x + 4f) * sx, (y + 51f) * sy), Size((w - 8f) * sx, 7f * sy), CornerRadius(2.5f * sx, 2.5f * sy))

    drawRoundRect(Color(0xFFFEF08A), Offset((x + 3f) * sx, (y + 1.5f) * sy), Size(5f * sx, 3f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color(0xFFFEF08A), Offset((x + w - 8f) * sx, (y + 1.5f) * sy), Size(5f * sx, 3f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color(0xFFDC2626), Offset((x + 3.5f) * sx, (y + l - 3.5f) * sy), Size(5.5f * sx, 2.5f * sy), CornerRadius(1f * sx, 1f * sy))
    drawRoundRect(Color(0xFFDC2626), Offset((x + w - 9f) * sx, (y + l - 3.5f) * sy), Size(5.5f * sx, 2.5f * sy), CornerRadius(1f * sx, 1f * sy))
}

// 3. Sports Car (سيارة رياضية)
private fun DrawScope.drawTopDownSportsCar(color: Color, sx: Float, sy: Float) {
    val w = 31f
    val l = 71f
    val x = (40f - w) / 2f
    val y = (80f - l) / 2f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(10f * sx, 10f * sy))
    val wheelColor = Color(0xFF111827)
    drawRoundRect(wheelColor, Offset((x - 3f) * sx, (y + 11f) * sy), Size(5f * sx, 11f * sy), CornerRadius(2.5f * sx, 2.5f * sy))
    drawRoundRect(wheelColor, Offset((x + w - 2f) * sx, (y + 11f) * sy), Size(5f * sx, 11f * sy), CornerRadius(2.5f * sx, 2.5f * sy))
    drawRoundRect(wheelColor, Offset((x - 3.5f) * sx, (y + l - 22f) * sy), Size(5.5f * sx, 12f * sy), CornerRadius(2.5f * sx, 2.5f * sy))
    drawRoundRect(wheelColor, Offset((x + w - 2f) * sx, (y + l - 22f) * sy), Size(5.5f * sx, 12f * sy), CornerRadius(2.5f * sx, 2.5f * sy))

    drawRoundRect(color, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(10f * sx, 10f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(10f * sx, 10f * sy), style = Stroke(1.4f * sx))

    val glassColor = Color(0xFF0F172A)
    drawRoundRect(glassColor, Offset((x + 4f) * sx, (y + 18f) * sy), Size((w - 8f) * sx, 10f * sy), CornerRadius(2.5f * sx, 2.5f * sy))
    drawRoundRect(Color.White.copy(alpha = 0.2f), Offset((x + 5.5f) * sx, (y + 29f) * sy), Size((w - 11f) * sx, 16f * sy), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(glassColor, Offset((x + 5f) * sx, (y + 46f) * sy), Size((w - 10f) * sx, 8f * sy), CornerRadius(2.5f * sx, 2.5f * sy))

    // Rear Spoiler
    drawRoundRect(Color(0xFF111827), Offset((x + 1f) * sx, (y + l - 5f) * sy), Size((w - 2f) * sx, 4f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color.White, Offset((x + 1f) * sx, (y + l - 5f) * sy), Size((w - 2f) * sx, 4f * sy), CornerRadius(1.5f * sx, 1.5f * sy), style = Stroke(0.8f * sx))
}

// 4. City Taxi (سيارة أجرة تكسي)
private fun DrawScope.drawTopDownTaxi(color: Color, sx: Float, sy: Float) {
    val w = 30f
    val l = 70f
    val x = (40f - w) / 2f
    val y = (80f - l) / 2f

    // Soft drop shadow
    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(10f * sx, 10f * sy))

    // Tires
    val wheelColor = Color(0xFF1F2937)
    drawRoundRect(wheelColor, Offset((x - 2.5f) * sx, (y + 11f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(wheelColor, Offset((x + w - 2f) * sx, (y + 11f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(wheelColor, Offset((x - 2.5f) * sx, (y + l - 21f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(wheelColor, Offset((x + w - 2f) * sx, (y + l - 21f) * sy), Size(4.5f * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))

    // Main Taxi Body in selected color (Yellow, Red, or Ink Blue)
    drawRoundRect(color, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(10f * sx, 10f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(10f * sx, 10f * sy), style = Stroke(1.4f * sx))

    // Black hood & body side stripes (classic black accent)
    drawRoundRect(Color(0xFF111827), Offset((x + 6f) * sx, (y + 3f) * sy), Size(4f * sx, 14f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color(0xFF111827), Offset((x + w - 10f) * sx, (y + 3f) * sy), Size(4f * sx, 14f * sy), CornerRadius(1.5f * sx, 1.5f * sy))

    // Headlights (Warm amber / yellow)
    drawCircle(Color(0xFFFEF08A), 2.5f * sx, Offset((x + 4.5f) * sx, (y + 2.5f) * sy))
    drawCircle(Color(0xFFFEF08A), 2.5f * sx, Offset((x + w - 4.5f) * sx, (y + 2.5f) * sy))

    // Rear taillights (Red)
    drawRoundRect(Color(0xFFEF4444), Offset((x + 3f) * sx, (y + l - 3f) * sy), Size(5f * sx, 2.5f * sy), CornerRadius(1f * sx, 1f * sy))
    drawRoundRect(Color(0xFFEF4444), Offset((x + w - 8f) * sx, (y + l - 3f) * sy), Size(5f * sx, 2.5f * sy), CornerRadius(1f * sx, 1f * sy))

    // Front Windshield
    val glassColor = Color(0xFF1E293B)
    drawRoundRect(glassColor, Offset((x + 3.5f) * sx, (y + 19f) * sy), Size((w - 7f) * sx, 10f * sy), CornerRadius(2.5f * sx, 2.5f * sy))

    // Side windows
    drawRoundRect(glassColor, Offset((x + 2.5f) * sx, (y + 30f) * sy), Size(3.5f * sx, 18f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(glassColor, Offset((x + w - 6f) * sx, (y + 30f) * sy), Size(3.5f * sx, 18f * sy), CornerRadius(1.5f * sx, 1.5f * sy))

    // Rear Window
    drawRoundRect(glassColor, Offset((x + 3.5f) * sx, (y + 49f) * sy), Size((w - 7f) * sx, 8f * sy), CornerRadius(2.5f * sx, 2.5f * sy))

    // Taxi Roof Sign Dome (White / Warm Yellow with Black border)
    val domeX = (x + 6f) * sx
    val domeY = (y + 34f) * sy
    val domeW = 18f * sx
    val domeH = 8.5f * sy

    drawRoundRect(Color(0xFFFFF9C4), Offset(domeX, domeY), Size(domeW, domeH), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(Color(0xFF111827), Offset(domeX, domeY), Size(domeW, domeH), CornerRadius(3f * sx, 3f * sy), style = Stroke(1.3f * sx))

    // Black checker / trim accents under roof sign
    drawRect(Color(0xFF111827), Offset((x + 2f) * sx, (y + 36f) * sy), Size(3f * sx, 4f * sy))
    drawRect(Color(0xFF111827), Offset((x + w - 5f) * sx, (y + 36f) * sy), Size(3f * sx, 4f * sy))

    // Draw Arabic word «تكسي» on the roof sign
    try {
        val paint = android.graphics.Paint().apply {
            this.color = android.graphics.Color.BLACK
            this.textSize = 5.2f * sy
            this.isFakeBoldText = true
            this.textAlign = android.graphics.Paint.Align.CENTER
            this.isAntiAlias = true
        }
        val cx = domeX + domeW / 2f
        val cy = domeY + (domeH * 0.72f)
        drawContext.canvas.nativeCanvas.drawText("تكسي", cx, cy, paint)
    } catch (_: Exception) {}
}

// 5. Police Patrol Car (سيارة شرطة)
private fun DrawScope.drawTopDownPolice(sx: Float, sy: Float) {
    val policeDark = Color(0xFF1E293B)
    drawTopDownSedan4Door(policeDark, sx, sy)
    val w = 30f
    val x = (40f - w) / 2f
    val y = (80f - 70f) / 2f

    // White Roof
    drawRoundRect(Color.White, Offset((x + 4.5f) * sx, (y + 26f) * sy), Size((w - 9f) * sx, 24f * sy), CornerRadius(3f * sx, 3f * sy))
    // Red / Blue Police Lightbar
    drawRoundRect(Color(0xFF111827), Offset((x + 6f) * sx, (y + 34f) * sy), Size(18f * sx, 7f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(Color(0xFFEF4444), Offset((x + 7f) * sx, (y + 35f) * sy), Size(7f * sx, 5f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color(0xFF3B82F6), Offset((x + 16f) * sx, (y + 35f) * sy), Size(7f * sx, 5f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
}

// 6. Fire Truck (سيارة إطفاء)
private fun DrawScope.drawTopDownFireTruck(sx: Float, sy: Float) {
    val fireRed = Color(0xFFDC2626)
    val w = 34f
    val l = 76f
    val x = (40f - w) / 2f
    val y = (80f - l) / 2f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(6f * sx, 6f * sy))
    // Body
    drawRoundRect(fireRed, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(6f * sx, 6f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(6f * sx, 6f * sy), style = Stroke(1.4f * sx))

    // Cab windshield
    drawRoundRect(Color(0xFF1E293B), Offset((x + 3f) * sx, (y + 6f) * sy), Size((w - 6f) * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))

    // Roof emergency lights
    drawRoundRect(Color(0xFF38BDF8), Offset((x + 5f) * sx, (y + 18f) * sy), Size(6f * sx, 4f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color(0xFFEF4444), Offset((x + w - 11f) * sx, (y + 18f) * sy), Size(6f * sx, 4f * sy), CornerRadius(1.5f * sx, 1.5f * sy))

    // Roof rescue ladder (silver)
    drawRoundRect(Color(0xFFCBD5E1), Offset((x + 10f) * sx, (y + 26f) * sy), Size(14f * sx, 42f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(Color(0xFF475569), Offset((x + 10f) * sx, (y + 26f) * sy), Size(14f * sx, 42f * sy), CornerRadius(2f * sx, 2f * sy), style = Stroke(1.2f * sx))
    for (i in 0..5) {
        val ly = (y + 30f + i * 6f) * sy
        drawLine(Color(0xFF475569), Offset((x + 11f) * sx, ly), Offset((x + 23f) * sx, ly), 1.2f * sx)
    }
}

// 7. Ambulance (سيارة إسعاف)
private fun DrawScope.drawTopDownAmbulance(sx: Float, sy: Float) {
    val w = 33f
    val l = 74f
    val x = (40f - w) / 2f
    val y = (80f - l) / 2f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy))
    drawRoundRect(Color(0xFFDC2626), Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy), style = Stroke(1.5f * sx))

    // Windshield
    drawRoundRect(Color(0xFF1E293B), Offset((x + 3.5f) * sx, (y + 7f) * sy), Size((w - 7f) * sx, 9f * sy), CornerRadius(2f * sx, 2f * sy))

    // Red Cross on white roof
    val cx = 20f * sx
    val cy = (y + 38f) * sy
    drawRect(Color(0xFFDC2626), Offset(cx - 3.5f * sx, cy - 11f * sy), Size(7f * sx, 22f * sy))
    drawRect(Color(0xFFDC2626), Offset(cx - 11f * sx, cy - 3.5f * sy), Size(22f * sx, 7f * sy))

    // Dual emergency lightbars
    drawRoundRect(Color(0xFFEF4444), Offset((x + 5f) * sx, (y + 18f) * sy), Size(6f * sx, 4f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color(0xFF3B82F6), Offset((x + w - 11f) * sx, (y + 18f) * sy), Size(6f * sx, 4f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
}

// 8. Municipal Service (سيارة خدمات بلدية)
private fun DrawScope.drawTopDownMunicipal(color: Color, sx: Float, sy: Float) {
    val muniColor = Color(0xFFEA580C)
    val w = 33f
    val l = 74f
    val x = (40f - w) / 2f
    val y = (80f - l) / 2f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy))
    drawRoundRect(muniColor, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy), style = Stroke(1.4f * sx))

    drawRoundRect(Color(0xFF1E293B), Offset((x + 3.5f) * sx, (y + 7f) * sy), Size((w - 7f) * sx, 9f * sy), CornerRadius(2f * sx, 2f * sy))

    // Amber roof beacons
    drawCircle(Color(0xFFFBBF24), radius = 2.8f * sx, center = Offset((x + 7f) * sx, (y + 19f) * sy))
    drawCircle(Color(0xFFFBBF24), radius = 2.8f * sx, center = Offset((x + w - 7f) * sx, (y + 19f) * sy))

    // Rear utility equipment bed with yellow chevrons
    drawRoundRect(Color(0xFF1F2937), Offset((x + 3f) * sx, (y + 26f) * sy), Size((w - 6f) * sx, 42f * sy), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(Color(0xFFF59E0B), Offset((x + 7f) * sx, (y + 36f) * sy), Size((w - 14f) * sx, 20f * sy), CornerRadius(2f * sx, 2f * sy))
}

// 9. Government Service (سيارة خدمات حكومية)
private fun DrawScope.drawTopDownGovernment(color: Color, sx: Float, sy: Float) {
    val govColor = Color(0xFF334155)
    drawTopDownSedan4Door(govColor, sx, sy)
    val w = 30f
    val x = (40f - w) / 2f
    val y = (80f - 70f) / 2f

    // Chrome Official Roof Emblem Beacon
    drawCircle(Color(0xFFE2E8F0), radius = 3.2f * sx, center = Offset(20f * sx, (y + 38f) * sy))
    drawCircle(Color(0xFF3B82F6), radius = 1.8f * sx, center = Offset(20f * sx, (y + 38f) * sy))
}

// 10. Road Maintenance (سيارة صيانة طرق)
private fun DrawScope.drawTopDownRoadMaintenance(color: Color, sx: Float, sy: Float) {
    val maintYellow = Color(0xFFF59E0B)
    val w = 33f
    val l = 75f
    val x = (40f - w) / 2f
    val y = (80f - l) / 2f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(6f * sx, 6f * sy))
    drawRoundRect(maintYellow, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(6f * sx, 6f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(6f * sx, 6f * sy), style = Stroke(1.4f * sx))

    drawRoundRect(Color(0xFF1E293B), Offset((x + 3.5f) * sx, (y + 8f) * sy), Size((w - 7f) * sx, 9f * sy), CornerRadius(2f * sx, 2f * sy))

    // Arrow board / Hazard stripes on roof
    drawRoundRect(Color(0xFF111827), Offset((x + 4f) * sx, (y + 26f) * sy), Size((w - 8f) * sx, 42f * sy), CornerRadius(3f * sx, 3f * sy))
    val arrowPath = Path().apply {
        moveTo((x + 10f) * sx, (y + 55f) * sy)
        lineTo(20f * sx, (y + 38f) * sy)
        lineTo((x + w - 10f) * sx, (y + 55f) * sy)
    }
    drawPath(arrowPath, Color(0xFFFEF08A), style = Stroke(width = 3.5f * sx, cap = StrokeCap.Round, join = StrokeJoin.Round))
}

// 11. Mini Bus (باص صغير)
private fun DrawScope.drawTopDownMiniBus(color: Color, sx: Float, sy: Float) {
    val w = 34f
    val l = 72f
    val x = (40f - w) / 2f
    val y = (80f - l) / 2f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy))
    drawRoundRect(color, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy), style = Stroke(1.4f * sx))

    drawRoundRect(Color(0xFF1E293B), Offset((x + 3.5f) * sx, (y + 5f) * sy), Size((w - 7f) * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    drawRoundRect(Color(0xFFE2E8F0), Offset((x + 10f) * sx, (y + 28f) * sy), Size(14f * sx, 22f * sy), CornerRadius(3f * sx, 3f * sy))
}

// 12. City Bus (باص كبير - ممتلئ وعريض)
private fun DrawScope.drawTopDownBus(color: Color, sx: Float, sy: Float) {
    val w = 36f
    val l = 78f
    val x = (40f - w) / 2f
    val y = 1f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy))
    drawRoundRect(color, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(w * sx, l * sy), CornerRadius(7f * sx, 7f * sy), style = Stroke(1.5f * sx))

    drawRoundRect(Color(0xFF1E293B), Offset((x + 3f) * sx, (y + 4f) * sy), Size((w - 6f) * sx, 10f * sy), CornerRadius(2f * sx, 2f * sy))
    // Side panoramic windows
    drawRoundRect(Color(0xFFBFDBFE), Offset((x + 2.5f) * sx, (y + 17f) * sy), Size(4f * sx, 48f * sy), CornerRadius(1.5f * sx, 1.5f * sy))
    drawRoundRect(Color(0xFFBFDBFE), Offset((x + w - 6.5f) * sx, (y + 17f) * sy), Size(4f * sx, 48f * sy), CornerRadius(1.5f * sx, 1.5f * sy))

    // Dual Roof AC Vents
    drawRoundRect(Color(0xFFE2E8F0), Offset((x + 10f) * sx, (y + 20f) * sy), Size(16f * sx, 18f * sy), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(Color(0xFFE2E8F0), Offset((x + 10f) * sx, (y + 44f) * sy), Size(16f * sx, 18f * sy), CornerRadius(3f * sx, 3f * sy))
}

// 13. Water Tanker (صهريج مياه - تصميم محسّن ومكتمل)
private fun DrawScope.drawTopDownWaterTanker(color: Color, sx: Float, sy: Float) {
    val totalW = 35f
    val totalL = 78f
    val x = (40f - totalW) / 2f
    val y = 1f

    drawRoundRect(Color(0x33000000), Offset((x + 1f) * sx, (y + 3f) * sy), Size(totalW * sx, totalL * sy), CornerRadius(8f * sx, 8f * sy))

    // Front Cab
    drawRoundRect(color, Offset(x * sx, y * sy), Size(totalW * sx, 22f * sy), CornerRadius(5f * sx, 5f * sy))
    drawRoundRect(Color.White, Offset(x * sx, y * sy), Size(totalW * sx, 22f * sy), CornerRadius(5f * sx, 5f * sy), style = Stroke(1.4f * sx))
    drawRoundRect(Color(0xFF1E293B), Offset((x + 3.5f) * sx, (y + 5f) * sy), Size((totalW - 7f) * sx, 8f * sy), CornerRadius(2f * sx, 2f * sy))

    // Heavy Cylindrical Water Tank
    val tankW = totalW - 2f
    val tankL = 50f
    val tankX = x + 1f
    val tankY = y + 25f

    drawRoundRect(Color(0xFF0284C7), Offset(tankX * sx, tankY * sy), Size(tankW * sx, tankL * sy), CornerRadius(14f * sx, 14f * sy))
    drawRoundRect(Color.White, Offset(tankX * sx, tankY * sy), Size(tankW * sx, tankL * sy), CornerRadius(14f * sx, 14f * sy), style = Stroke(1.5f * sx))

    // 3 Reinforcement Ribs
    for (i in 0..2) {
        val by = (tankY + 12f + i * 13f) * sy
        drawLine(Color.White.copy(alpha = 0.6f), Offset((tankX + 2f) * sx, by), Offset((tankX + tankW - 2f) * sx, by), 1.5f * sx)
    }

    // Top Filling Dome Hatch
    drawCircle(Color(0xFFE0F2FE), radius = 4.5f * sx, center = Offset(20f * sx, (tankY + 25f) * sy))
    drawCircle(Color(0xFF0369A1), radius = 4.5f * sx, center = Offset(20f * sx, (tankY + 25f) * sy), style = Stroke(1.4f * sx))
    drawCircle(Color(0xFF38BDF8), radius = 2f * sx, center = Offset(20f * sx, (tankY + 25f) * sy))
}

// 14. Semi-Truck & Trailer (شاحنة برأس سحب ومقطورة منفصلة)
private fun DrawScope.drawTopDownSemiTrailer(color: Color, sx: Float, sy: Float) {
    val w = 34f
    val x = (40f - w) / 2f

    // 1. Tractor Unit (Front Cab)
    drawRoundRect(color, Offset(x * sx, 2f * sy), Size(w * sx, 20f * sy), CornerRadius(4f * sx, 4f * sy))
    drawRoundRect(Color.White, Offset(x * sx, 2f * sy), Size(w * sx, 20f * sy), CornerRadius(4f * sx, 4f * sy), style = Stroke(1.4f * sx))
    drawRoundRect(Color(0xFF1E293B), Offset((x + 3f) * sx, 5f * sy), Size((w - 6f) * sx, 7f * sy), CornerRadius(2f * sx, 2f * sy))

    // Fifth Wheel Coupling Pivot
    drawCircle(Color(0xFF111827), radius = 3.5f * sx, center = Offset(20f * sx, 24f * sy))
    drawCircle(Color(0xFF94A3B8), radius = 2f * sx, center = Offset(20f * sx, 24f * sy))

    // 2. Separate Semi-Trailer
    val trailerY = 27f * sy
    val trailerL = 50f * sy
    drawRoundRect(Color(0xFF475569), Offset(x * sx, trailerY), Size(w * sx, trailerL), CornerRadius(4f * sx, 4f * sy))
    drawRoundRect(Color.White, Offset(x * sx, trailerY), Size(w * sx, trailerL), CornerRadius(4f * sx, 4f * sy), style = Stroke(1.4f * sx))
    // Corrugated roof lines
    for (i in 0..5) {
        val ry = trailerY + (8f + i * 7f) * sy
        drawLine(Color.White.copy(alpha = 0.35f), Offset((x + 3f) * sx, ry), Offset((x + w - 3f) * sx, ry), 1.2f * sx)
    }
}

// 15. Dump Truck (شاحنة قلاب)
private fun DrawScope.drawTopDownDumpTruck(color: Color, sx: Float, sy: Float) {
    val w = 34f
    val x = (40f - w) / 2f

    // Cab
    drawRoundRect(color, Offset(x * sx, 2f * sy), Size(w * sx, 22f * sy), CornerRadius(4f * sx, 4f * sy))
    drawRoundRect(Color.White, Offset(x * sx, 2f * sy), Size(w * sx, 22f * sy), CornerRadius(4f * sx, 4f * sy), style = Stroke(1.4f * sx))
    drawRoundRect(Color(0xFF1E293B), Offset((x + 3f) * sx, 6f * sy), Size((w - 6f) * sx, 8f * sy), CornerRadius(2f * sx, 2f * sy))

    // Heavy Dump Bed
    val bedY = 27f * sy
    val bedL = 50f * sy
    drawRoundRect(Color(0xFFD97706), Offset(x * sx, bedY), Size(w * sx, bedL), CornerRadius(4f * sx, 4f * sy))
    drawRoundRect(Color.White, Offset(x * sx, bedY), Size(w * sx, bedL), CornerRadius(4f * sx, 4f * sy), style = Stroke(1.4f * sx))
    // Sand / Dirt payload
    drawRoundRect(Color(0xFFB45309), Offset((x + 4f) * sx, bedY + 4f * sy), Size((w - 8f) * sx, bedL - 8f * sy), CornerRadius(3f * sx, 3f * sy))
}

// 16. Cargo Truck (شاحنة نقل بضائع)
private fun DrawScope.drawTopDownCargoTruck(color: Color, sx: Float, sy: Float) {
    val w = 34f
    val x = (40f - w) / 2f

    // Cab
    drawRoundRect(color, Offset(x * sx, 2f * sy), Size(w * sx, 20f * sy), CornerRadius(4f * sx, 4f * sy))
    drawRoundRect(Color.White, Offset(x * sx, 2f * sy), Size(w * sx, 20f * sy), CornerRadius(4f * sx, 4f * sy), style = Stroke(1.4f * sx))
    drawRoundRect(Color(0xFF1E293B), Offset((x + 3f) * sx, 5f * sy), Size((w - 6f) * sx, 7f * sy), CornerRadius(2f * sx, 2f * sy))

    // Enclosed Box Container
    val boxY = 24f * sy
    val boxL = 53f * sy
    drawRoundRect(Color(0xFF2563EB), Offset(x * sx, boxY), Size(w * sx, boxL), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(Color.White, Offset(x * sx, boxY), Size(w * sx, boxL), CornerRadius(3f * sx, 3f * sy), style = Stroke(1.4f * sx))
}

// 17. Furniture Truck (شاحنة نقل أثاث)
private fun DrawScope.drawTopDownFurnitureTruck(color: Color, sx: Float, sy: Float) {
    val w = 34f
    val x = (40f - w) / 2f

    // Extended Luton Cab-Over Container
    val boxY = 2f * sy
    val boxL = 75f * sy
    drawRoundRect(Color(0xFF7C3AED), Offset(x * sx, boxY), Size(w * sx, boxL), CornerRadius(5f * sx, 5f * sy))
    drawRoundRect(Color.White, Offset(x * sx, boxY), Size(w * sx, boxL), CornerRadius(5f * sx, 5f * sy), style = Stroke(1.5f * sx))

    // Front Cab Windshield
    drawRoundRect(Color(0xFF1E293B), Offset((x + 4f) * sx, 8f * sy), Size((w - 8f) * sx, 8f * sy), CornerRadius(2f * sx, 2f * sy))
    // Side Rub Rails
    drawLine(Color.White.copy(alpha = 0.5f), Offset((x + 2f) * sx, 35f * sy), Offset((x + w - 2f) * sx, 35f * sy), 1.2f * sx)
    drawLine(Color.White.copy(alpha = 0.5f), Offset((x + 2f) * sx, 55f * sy), Offset((x + w - 2f) * sx, 55f * sy), 1.2f * sx)
}

// 18. Excavator (حفارة)
private fun DrawScope.drawTopDownExcavator(color: Color, sx: Float, sy: Float) {
    val w = 34f
    val x = (40f - w) / 2f

    // Dual Heavy Crawler Tracks
    drawRoundRect(Color(0xFF1F2937), Offset((x - 2f) * sx, 18f * sy), Size(7f * sx, 56f * sy), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(Color(0xFF1F2937), Offset((x + w - 5f) * sx, 18f * sy), Size(7f * sx, 56f * sy), CornerRadius(3f * sx, 3f * sy))

    // Rotating Cab & Body
    drawRoundRect(Color(0xFFF59E0B), Offset((x + 5f) * sx, 22f * sy), Size((w - 10f) * sx, 44f * sy), CornerRadius(6f * sx, 6f * sy))
    drawRoundRect(Color.White, Offset((x + 5f) * sx, 22f * sy), Size((w - 10f) * sx, 44f * sy), CornerRadius(6f * sx, 6f * sy), style = Stroke(1.3f * sx))

    // Operator Glass Cab
    drawRoundRect(Color(0xFF1E293B), Offset((x + 6f) * sx, 26f * sy), Size(9f * sx, 16f * sy), CornerRadius(2f * sx, 2f * sy))

    // Heavy Hydraulic Boom Arm extending forward
    val boom = Path().apply {
        moveTo(20f * sx, 32f * sy)
        lineTo(20f * sx, 4f * sy)
        lineTo(24f * sx, 2f * sy)
        lineTo(16f * sx, 2f * sy)
        close()
    }
    drawPath(boom, Color(0xFFD97706))
    drawPath(boom, Color.White, style = Stroke(1.2f * sx))
}

// 19. Wheel Loader (شفل / لودر)
private fun DrawScope.drawTopDownWheelLoader(color: Color, sx: Float, sy: Float) {
    val w = 34f
    val x = (40f - w) / 2f

    // Giant Heavy Tires
    val tireCol = Color(0xFF111827)
    drawRoundRect(tireCol, Offset((x - 3f) * sx, 16f * sy), Size(7f * sx, 18f * sy), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(tireCol, Offset((x + w - 4f) * sx, 16f * sy), Size(7f * sx, 18f * sy), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(tireCol, Offset((x - 3f) * sx, 48f * sy), Size(7f * sx, 18f * sy), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(tireCol, Offset((x + w - 4f) * sx, 48f * sy), Size(7f * sx, 18f * sy), CornerRadius(3f * sx, 3f * sy))

    // Loader Body
    drawRoundRect(Color(0xFFEAB308), Offset((x + 4f) * sx, 22f * sy), Size((w - 8f) * sx, 48f * sy), CornerRadius(5f * sx, 5f * sy))
    drawRoundRect(Color.White, Offset((x + 4f) * sx, 22f * sy), Size((w - 8f) * sx, 48f * sy), CornerRadius(5f * sx, 5f * sy), style = Stroke(1.3f * sx))

    // Front Massive Scoop Bucket
    drawRoundRect(Color(0xFF475569), Offset((x - 2f) * sx, 4f * sy), Size((w + 4f) * sx, 12f * sy), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(Color.White, Offset((x - 2f) * sx, 4f * sy), Size((w + 4f) * sx, 12f * sy), CornerRadius(3f * sx, 3f * sy), style = Stroke(1.3f * sx))
}

// 20. Delivery Motorcycle (دراجة توصيل)
private fun DrawScope.drawTopDownDeliveryBike(color: Color, sx: Float, sy: Float) {
    val cx = 20f * sx
    // Front Wheel
    drawRoundRect(Color(0xFF111827), Offset(cx - 2.5f * sx, 6f * sy), Size(5f * sx, 16f * sy), CornerRadius(2.5f * sx, 2.5f * sy))

    // Handlebars
    drawLine(Color.White, Offset(cx - 10f * sx, 18f * sy), Offset(cx + 10f * sx, 18f * sy), 3f * sx, cap = StrokeCap.Round)
    drawLine(Color(0xFF1F2937), Offset(cx - 10f * sx, 18f * sy), Offset(cx + 10f * sx, 18f * sy), 2f * sx, cap = StrokeCap.Round)

    // Motorcycle Frame & Gas Tank
    drawRoundRect(color, Offset(cx - 4.5f * sx, 22f * sy), Size(9f * sx, 24f * sy), CornerRadius(4.5f * sx, 4.5f * sy))
    drawRoundRect(Color.White, Offset(cx - 4.5f * sx, 22f * sy), Size(9f * sx, 24f * sy), CornerRadius(4.5f * sx, 4.5f * sy), style = Stroke(1.2f * sx))

    // Rider Helmet (Circle)
    drawCircle(Color(0xFFFACC15), radius = 5.5f * sx, center = Offset(cx, 32f * sy))
    drawCircle(Color.White, radius = 5.5f * sx, center = Offset(cx, 32f * sy), style = Stroke(1.2f * sx))

    // Rear Delivery Cargo Box
    drawRoundRect(Color(0xFFEF4444), Offset(cx - 9f * sx, 48f * sy), Size(18f * sx, 20f * sy), CornerRadius(3f * sx, 3f * sy))
    drawRoundRect(Color.White, Offset(cx - 9f * sx, 48f * sy), Size(18f * sx, 20f * sy), CornerRadius(3f * sx, 3f * sy), style = Stroke(1.3f * sx))

    // Rear Wheel
    drawRoundRect(Color(0xFF111827), Offset(cx - 2.5f * sx, 68f * sy), Size(5f * sx, 10f * sy), CornerRadius(2.5f * sx, 2.5f * sy))
}
