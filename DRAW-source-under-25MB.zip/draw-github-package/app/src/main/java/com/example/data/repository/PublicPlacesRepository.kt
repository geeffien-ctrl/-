package com.example.data.repository

import android.content.Context
import android.net.Uri
import android.util.Log
import com.example.R
import com.example.data.model.PlaceRating
import com.example.data.model.PublicPlace
import com.example.data.util.ImageCompressUtil
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private const val TAG = "PublicPlacesRepo"

class PublicPlacesRepository(
    private val context: Context? = null
) {
    private val prefs = context?.getSharedPreferences("draw_public_places", Context.MODE_PRIVATE)
    private val _placesFlow = MutableStateFlow<List<PublicPlace>>(loadSavedPlaces())
    private var snapshotListenerRegistration: ListenerRegistration? = null

    private val db: FirebaseFirestore? by lazy {
        try {
            context?.let { ctx ->
                val dbId = ctx.getString(R.string.firestore_database_id)
                FirebaseFirestore.getInstance(dbId)
            } ?: FirebaseFirestore.getInstance()
        } catch (_: Exception) {
            try {
                FirebaseFirestore.getInstance()
            } catch (_: Exception) {
                null
            }
        }
    }

    init {
        startFirestoreRealtimeListener()
    }

    private fun startFirestoreRealtimeListener() {
        try {
            val firestore = db ?: return
            snapshotListenerRegistration?.remove()
            snapshotListenerRegistration = firestore.collection("public_places")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Snapshot listener warning for public_places: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val fetchedPlaces = mutableListOf<PublicPlace>()
                        for (doc in snapshot.documents) {
                            try {
                                val imagesRaw = doc.get("images") as? List<*>
                                val images = imagesRaw?.mapNotNull { it?.toString() } ?: emptyList()
                                val place = PublicPlace(
                                    id = doc.id,
                                    title = doc.getString("title") ?: "",
                                    address = doc.getString("address") ?: "",
                                    description = doc.getString("description") ?: "",
                                    category = doc.getString("category") ?: "favorite",
                                    iconId = doc.getString("iconId") ?: "personal_favorite",
                                    latitude = doc.getDouble("latitude") ?: 0.0,
                                    longitude = doc.getDouble("longitude") ?: 0.0,
                                    images = images,
                                    creatorId = doc.getString("creatorId") ?: "",
                                    creatorName = doc.getString("creatorName") ?: "",
                                    creatorPhotoUrl = doc.getString("creatorPhotoUrl") ?: "",
                                    likesCount = doc.getLong("likesCount") ?: 0L,
                                    commentsCount = doc.getLong("commentsCount") ?: 0L,
                                    averageRating = doc.getDouble("averageRating") ?: 5.0,
                                    ratingsCount = doc.getLong("ratingsCount") ?: 1L,
                                    totalRatingScore = doc.getDouble("totalRatingScore") ?: 5.0,
                                    createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                                    updatedAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
                                )
                                if (place.title.isNotBlank()) {
                                    fetchedPlaces.add(place)
                                }
                            } catch (e: Exception) {
                                Log.w(TAG, "Error parsing place doc ${doc.id}", e)
                            }
                        }

                        val sorted = fetchedPlaces.sortedByDescending { it.createdAt }
                        persistPlacesLocally(sorted)
                        _placesFlow.value = sorted
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start Firestore listener", e)
        }
    }

    private fun loadSavedPlaces(): List<PublicPlace> {
        val raw = prefs?.getString("saved_places_list", null) ?: return emptyList()
        return try {
            val arr = JSONArray(raw)
            val list = mutableListOf<PublicPlace>()
            for (i in 0 until arr.length()) {
                val obj = arr.getJSONObject(i)
                val imagesArr = obj.optJSONArray("images") ?: JSONArray()
                val imagesList = mutableListOf<String>()
                for (j in 0 until imagesArr.length()) {
                    imagesList.add(imagesArr.getString(j))
                }
                list.add(
                    PublicPlace(
                        id = obj.optString("id"),
                        title = obj.optString("title"),
                        address = obj.optString("address"),
                        description = obj.optString("description"),
                        category = obj.optString("category", "favorite"),
                        iconId = obj.optString("iconId", "personal_favorite"),
                        latitude = obj.optDouble("latitude"),
                        longitude = obj.optDouble("longitude"),
                        images = imagesList,
                        creatorId = obj.optString("creatorId"),
                        creatorName = obj.optString("creatorName"),
                        creatorPhotoUrl = obj.optString("creatorPhotoUrl"),
                        likesCount = obj.optLong("likesCount", 0L),
                        commentsCount = obj.optLong("commentsCount", 0L),
                        averageRating = obj.optDouble("averageRating", 5.0),
                        ratingsCount = obj.optLong("ratingsCount", 1L),
                        totalRatingScore = obj.optDouble("totalRatingScore", 5.0),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = obj.optLong("updatedAt", System.currentTimeMillis())
                    )
                )
            }
            list
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun getInitialSeedPlaces(): List<PublicPlace> = emptyList()

    suspend fun purgeAllPlacesFromFirestoreAndLocal(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            prefs?.edit()?.clear()?.apply()
            _placesFlow.value = emptyList()

            val firestore = db ?: return@withContext Result.success(Unit)
            val snapshot = firestore.collection("public_places").get().await()
            val batch = firestore.batch()
            for (doc in snapshot.documents) {
                batch.delete(doc.reference)
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error purging public places", e)
            Result.failure(e)
        }
    }

    private fun persistPlacesLocally(list: List<PublicPlace>) {
        try {
            val arr = JSONArray()
            for (item in list) {
                val imgArr = JSONArray()
                item.images.forEach { imgArr.put(it) }
                val obj = JSONObject().apply {
                    put("id", item.id)
                    put("title", item.title)
                    put("address", item.address)
                    put("description", item.description)
                    put("category", item.category)
                    put("iconId", item.iconId)
                    put("latitude", item.latitude)
                    put("longitude", item.longitude)
                    put("images", imgArr)
                    put("creatorId", item.creatorId)
                    put("creatorName", item.creatorName)
                    put("creatorPhotoUrl", item.creatorPhotoUrl)
                    put("likesCount", item.likesCount)
                    put("commentsCount", item.commentsCount)
                    put("averageRating", item.averageRating)
                    put("ratingsCount", item.ratingsCount)
                    put("totalRatingScore", item.totalRatingScore)
                    put("createdAt", item.createdAt)
                    put("updatedAt", item.updatedAt)
                }
                arr.put(obj)
            }
            prefs?.edit()?.putString("saved_places_list", arr.toString())?.apply()
        } catch (e: Exception) {
            Log.e(TAG, "Error caching places locally", e)
        }
    }

    fun getPublicPlacesFlow(): Flow<List<PublicPlace>> = _placesFlow.asStateFlow()

    suspend fun getPlaceById(placeId: String): PublicPlace? = withContext(Dispatchers.IO) {
        if (placeId.isBlank()) return@withContext null
        val cached = _placesFlow.value.find { it.id == placeId }
        if (cached != null) return@withContext cached

        try {
            val doc = db?.collection("public_places")?.document(placeId)?.get()?.await()
            if (doc != null && doc.exists()) {
                val imagesRaw = doc.get("images") as? List<*>
                val images = imagesRaw?.mapNotNull { it?.toString() } ?: emptyList()
                return@withContext PublicPlace(
                    id = doc.id,
                    title = doc.getString("title") ?: "",
                    address = doc.getString("address") ?: "",
                    description = doc.getString("description") ?: "",
                    category = doc.getString("category") ?: "favorite",
                    iconId = doc.getString("iconId") ?: "personal_favorite",
                    latitude = doc.getDouble("latitude") ?: 0.0,
                    longitude = doc.getDouble("longitude") ?: 0.0,
                    images = images,
                    creatorId = doc.getString("creatorId") ?: "",
                    creatorName = doc.getString("creatorName") ?: "",
                    creatorPhotoUrl = doc.getString("creatorPhotoUrl") ?: "",
                    likesCount = doc.getLong("likesCount") ?: 0L,
                    commentsCount = doc.getLong("commentsCount") ?: 0L,
                    averageRating = doc.getDouble("averageRating") ?: 5.0,
                    ratingsCount = doc.getLong("ratingsCount") ?: 1L,
                    totalRatingScore = doc.getDouble("totalRatingScore") ?: 5.0,
                    createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                    updatedAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Error fetching place by id $placeId from Firestore", e)
        }
        null
    }

    suspend fun uploadPlaceImages(
        context: Context,
        uris: List<Uri>,
        placeId: String
    ): List<String> = withContext(Dispatchers.IO) {
        uris.mapIndexedNotNull { index, uri ->
            try {
                val base64 = ImageCompressUtil.compressUriToBase64(context, uri, 800)
                base64 ?: uri.toString()
            } catch (e: Exception) {
                Log.e(TAG, "Failed to encode image $index", e)
                uri.toString()
            }
        }
    }

    suspend fun createPublicPlace(place: PublicPlace): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (place.creatorId.isBlank() || place.creatorId.startsWith("guest_")) {
                return@withContext Result.failure(IllegalAccessException("Guest users cannot create public places"))
            }
            require(place.title.isNotBlank()) { "اسم المكان مطلوب." }
            require(place.description.isNotBlank()) { "وصف المكان مطلوب." }
            val id = place.id.ifBlank { "place_" + UUID.randomUUID().toString().take(12) }
            val newPlace = place.copy(
                id = id,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )

            // 1. Instantly update local state so creator sees place with 0 latency
            val current = _placesFlow.value.toMutableList()
            current.removeAll { it.id == id }
            current.add(0, newPlace)
            persistPlacesLocally(current)
            _placesFlow.value = current

            // 2. Persist to Firestore for real-time cloud sync to all users
            try {
                val placeData = hashMapOf(
                    "id" to id,
                    "title" to newPlace.title,
                    "address" to newPlace.address,
                    "description" to newPlace.description,
                    "category" to newPlace.category,
                    "iconId" to newPlace.iconId,
                    "latitude" to newPlace.latitude,
                    "longitude" to newPlace.longitude,
                    "images" to newPlace.images,
                    "creatorId" to newPlace.creatorId,
                    "creatorName" to newPlace.creatorName,
                    "creatorPhotoUrl" to newPlace.creatorPhotoUrl,
                    "likesCount" to newPlace.likesCount,
                    "commentsCount" to newPlace.commentsCount,
                    "averageRating" to newPlace.averageRating,
                    "ratingsCount" to newPlace.ratingsCount,
                    "totalRatingScore" to newPlace.totalRatingScore,
                    "createdAt" to newPlace.createdAt,
                    "updatedAt" to newPlace.updatedAt
                )
                db?.collection("public_places")?.document(id)?.set(placeData, SetOptions.merge())?.await()
            } catch (e: Exception) {
                Log.w(TAG, "Firestore write warning: ${e.message}")
            }

            Result.success(id)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun updatePublicPlace(place: PublicPlace, currentUserId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val current = _placesFlow.value.map {
                if (it.id == place.id) {
                    place.copy(updatedAt = System.currentTimeMillis())
                } else it
            }
            persistPlacesLocally(current)
            _placesFlow.value = current

            try {
                val updates = mapOf(
                    "title" to place.title,
                    "address" to place.address,
                    "description" to place.description,
                    "category" to place.category,
                    "iconId" to place.iconId,
                    "updatedAt" to System.currentTimeMillis()
                )
                db?.collection("public_places")?.document(place.id)?.update(updates)?.await()
            } catch (e: Exception) {
                Log.w(TAG, "Firestore update warning", e)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun deletePublicPlace(placeId: String, currentUserId: String): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val current = _placesFlow.value.filter { it.id != placeId }
            persistPlacesLocally(current)
            _placesFlow.value = current

            try {
                db?.collection("public_places")?.document(placeId)?.delete()?.await()
            } catch (e: Exception) {
                Log.w(TAG, "Firestore delete warning", e)
            }

            Result.success(Unit)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun submitRating(
        placeId: String,
        userId: String,
        userName: String,
        userPhotoUrl: String = "",
        ratingValue: Int,
        comment: String = ""
    ): Result<Double> = withContext(Dispatchers.IO) {
        val current = _placesFlow.value.toMutableList()
        val idx = current.indexOfFirst { it.id == placeId }
        if (idx >= 0) {
            val place = current[idx]
            val newRatingsCount = place.ratingsCount + 1
            val newTotal = place.totalRatingScore + ratingValue
            val newAvg = Math.round((newTotal / newRatingsCount) * 10.0) / 10.0
            val updated = place.copy(
                ratingsCount = newRatingsCount,
                totalRatingScore = newTotal,
                averageRating = newAvg
            )
            current[idx] = updated
            persistPlacesLocally(current)
            _placesFlow.value = current

            try {
                val updates = mapOf<String, Any>(
                    "ratingsCount" to newRatingsCount,
                    "totalRatingScore" to newTotal,
                    "averageRating" to newAvg,
                    "updatedAt" to System.currentTimeMillis()
                )
                db?.collection("public_places")?.document(placeId)?.update(updates)?.await()
            } catch (e: Exception) {
                Log.w(TAG, "Firestore rating update warning", e)
            }

            Result.success(newAvg)
        } else {
            Result.success(5.0)
        }
    }

    suspend fun getUserRating(placeId: String, userId: String): Result<PlaceRating?> = withContext(Dispatchers.IO) {
        Result.success(null)
    }
}
