package com.example.data.util

import android.content.Context
import android.content.Intent

fun configureAppCheck(context: Context, intent: Intent?) {
    // No-op: Firebase App Check removed
}
