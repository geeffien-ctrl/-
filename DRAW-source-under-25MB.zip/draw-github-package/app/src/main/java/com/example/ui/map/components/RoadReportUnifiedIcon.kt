package com.example.ui.map.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.size
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Construction
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.ReportProblem
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.Traffic
import androidx.compose.material.icons.filled.WaterDrop
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.Icon
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.DrawScope
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.example.data.model.RoadReportType

/**
 * Unified Road Report custom vector icon matching openfreemap.html map markers exactly.
 * Pure custom illustration without background containers, circles or squares.
 */
@Composable
fun RoadReportUnifiedIcon(
    type: RoadReportType,
    modifier: Modifier = Modifier,
    size: Dp = 34.dp
) {
    Box(
        modifier = modifier.size(size),
        contentAlignment = Alignment.Center
    ) {
        if (type == RoadReportType.TRAFFIC_ACCIDENT || type == RoadReportType.STOPPED_VEHICLE || type == RoadReportType.TRAFFIC_JAM) {
            ReadyMaterialReportIcon(type, size)
        } else Canvas(modifier = Modifier.size(size)) {
            val w = this.size.width
            val h = this.size.height

            // Scale factor relative to 34x34 design space
            val scaleX = w / 34f
            val scaleY = h / 34f

            when (type) {
                RoadReportType.TRAFFIC_ACCIDENT -> drawAccidentIcon(scaleX, scaleY)
                RoadReportType.TRAFFIC_JAM -> drawJamIcon(scaleX, scaleY)
                RoadReportType.POTHOLE -> drawPotholeIcon(scaleX, scaleY)
                RoadReportType.ROAD_HAZARD -> drawHazardIcon(scaleX, scaleY)
                RoadReportType.TRAFFIC_CHECKPOINT -> drawCheckpointIcon(scaleX, scaleY)
                RoadReportType.ROADWORKS -> drawRoadworksIcon(scaleX, scaleY)
                RoadReportType.ROAD_CLOSED -> drawRoadClosedIcon(scaleX, scaleY)
                RoadReportType.FLOOD_WATER -> drawFloodWaterIcon(scaleX, scaleY)
                RoadReportType.STOPPED_VEHICLE -> drawStoppedVehicleIcon(scaleX, scaleY)
                RoadReportType.SPEED_CAMERA -> drawSpeedCameraIcon(scaleX, scaleY)
                RoadReportType.SPEED_BUMP -> drawSpeedBumpIcon(scaleX, scaleY)
                RoadReportType.SLIPPERY_ROAD -> drawSlipperyRoadIcon(scaleX, scaleY)
            }
        }
    }
}

/** Ready Google Material Icons: DirectionsCar, WarningAmber and Traffic. */
@Composable
private fun ReadyMaterialReportIcon(type: RoadReportType, size: Dp) {
    if (type == RoadReportType.TRAFFIC_JAM) {
        Icon(Icons.Default.Traffic, contentDescription = null, tint = Color(0xFFEA580C), modifier = Modifier.size(size))
    } else {
        Box(modifier = Modifier.size(size), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.DirectionsCar, contentDescription = null,
                tint = if (type == RoadReportType.TRAFFIC_ACCIDENT) Color(0xFFDC2626) else Color(0xFFFACC15),
                modifier = Modifier.size(size * 0.88f))
            Icon(Icons.Default.WarningAmber, contentDescription = null, tint = Color(0xFF111827),
                modifier = Modifier.size(size * 0.36f).align(Alignment.TopEnd))
        }
    }
}

@Composable
private fun ReadyReportIcon(type: RoadReportType, size: Dp) {
    val primary = when (type) {
        RoadReportType.TRAFFIC_ACCIDENT -> Icons.Default.DirectionsCar
        RoadReportType.TRAFFIC_JAM -> Icons.Default.Traffic
        RoadReportType.POTHOLE -> Icons.Default.ReportProblem
        RoadReportType.STOPPED_VEHICLE -> Icons.Default.DirectionsCar
        RoadReportType.SPEED_BUMP -> Icons.Default.Speed
        RoadReportType.SLIPPERY_ROAD -> Icons.Default.WaterDrop
        else -> Icons.Default.Construction
    }
    val secondary = when (type) {
        RoadReportType.TRAFFIC_ACCIDENT -> Icons.Default.WarningAmber
        RoadReportType.TRAFFIC_JAM -> Icons.Default.DirectionsCar
        RoadReportType.POTHOLE -> Icons.Default.WarningAmber
        RoadReportType.STOPPED_VEHICLE -> Icons.Default.WarningAmber
        RoadReportType.SPEED_BUMP -> Icons.Default.DirectionsCar
        RoadReportType.SLIPPERY_ROAD -> Icons.Default.DirectionsCar
        else -> Icons.Default.Construction
    }
    val color = when (type) {
        RoadReportType.TRAFFIC_ACCIDENT -> Color(0xFFDC2626)
        RoadReportType.TRAFFIC_JAM -> Color(0xFFEA580C)
        RoadReportType.POTHOLE -> Color(0xFF374151)
        RoadReportType.STOPPED_VEHICLE -> Color(0xFFDC2626)
        RoadReportType.SPEED_BUMP -> Color(0xFFD97706)
        RoadReportType.SLIPPERY_ROAD -> Color(0xFF0284C7)
        else -> Color(0xFF64748B)
    }
    Box(modifier = Modifier.size(size), contentAlignment = Alignment.Center) {
        Icon(primary, contentDescription = null, tint = color, modifier = Modifier.size(size * 0.86f))
        Icon(secondary, contentDescription = null, tint = Color.White, modifier = Modifier.size(size * 0.40f).align(Alignment.BottomEnd))
    }
}

// 1. Traffic Accident (حادث مروري): Two colliding vehicles with impact burst & shockwave
private fun DrawScope.drawAccidentIcon(sx: Float, sy: Float) {
    val left = Path().apply { moveTo(3f*sx,20f*sy); lineTo(6f*sx,13f*sy); lineTo(12f*sx,13f*sy); lineTo(14.5f*sx,17f*sy); lineTo(17f*sx,18.5f*sy); lineTo(14.5f*sx,22f*sy); lineTo(3f*sx,22f*sy); close() }
    val right = Path().apply { moveTo(31f*sx,20f*sy); lineTo(28f*sx,13f*sy); lineTo(22f*sx,13f*sy); lineTo(19.5f*sx,17f*sy); lineTo(17f*sx,18.5f*sy); lineTo(19.5f*sx,22f*sy); lineTo(31f*sx,22f*sy); close() }
    drawPath(left, Color(0xFFDC2626)); drawPath(left, Color.White, style=Stroke(1.4f*sx, join=StrokeJoin.Round))
    drawPath(right, Color(0xFF334155)); drawPath(right, Color.White, style=Stroke(1.4f*sx, join=StrokeJoin.Round))
    drawCircle(Color(0xFF111827),2.5f*sx,Offset(7f*sx,22f*sy)); drawCircle(Color(0xFF111827),2.5f*sx,Offset(27f*sx,22f*sy))
    drawCircle(Color(0xFFFACC15),2.4f*sx,Offset(17f*sx,11f*sy)); drawCircle(Color(0xFF111827),1.1f*sx,Offset(17f*sx,11f*sy))
    drawLine(Color(0xFF111827),Offset(17f*sx,4f*sy),Offset(17f*sx,8f*sy),1.8f*sx,cap=StrokeCap.Round)
    drawLine(Color(0xFF111827),Offset(12f*sx,7f*sy),Offset(14f*sx,10f*sy),1.8f*sx,cap=StrokeCap.Round)
    drawLine(Color(0xFF111827),Offset(22f*sx,7f*sy),Offset(20f*sx,10f*sy),1.8f*sx,cap=StrokeCap.Round)
}

// 2. Traffic Jam (ازدحام مروري): 3 queueing vehicles in lane with glowing stop indicators
private fun DrawScope.drawJamIcon(sx: Float, sy: Float) {
    fun miniCar(x:Float,y:Float,c:Color) { val p=Path().apply{moveTo((x-6f)*sx,(y+4f)*sy);lineTo((x-4f)*sx,(y-3f)*sy);lineTo((x+4f)*sx,(y-3f)*sy);lineTo((x+6f)*sx,(y+4f)*sy);close()}; drawPath(p,c); drawPath(p,Color.White,style=Stroke(1.2f*sx)); drawCircle(Color(0xFF111827),1.5f*sx,Offset((x-4f)*sx,(y+4f)*sy)); drawCircle(Color(0xFF111827),1.5f*sx,Offset((x+4f)*sx,(y+4f)*sy)) }
    miniCar(9f,9f,Color(0xFFF97316)); miniCar(17f,17f,Color(0xFFFB923C)); miniCar(25f,25f,Color(0xFFF59E0B))
    drawCircle(Color(0xFFDC2626),3f*sx,Offset(29f*sx,5f*sy)); drawCircle(Color.White,1.1f*sx,Offset(29f*sx,5f*sy)); drawLine(Color(0xFFDC2626),Offset(29f*sx,10f*sy),Offset(29f*sx,17f*sy),2f*sx,cap=StrokeCap.Round)
}

// 3. Pothole: Black crater with crack lines
private fun DrawScope.drawPotholeIcon(sx: Float, sy: Float) {
    drawCircle(Color(0xFFFBBF24), radius = 2f * sx, center = Offset(5f * sx, 7f * sy))
    drawOval(
        color = Color(0xFF1F2937),
        topLeft = Offset(3f * sx, 10f * sy),
        size = Size(28f * sx, 16f * sy)
    )
    drawOval(
        color = Color.White,
        topLeft = Offset(3f * sx, 10f * sy),
        size = Size(28f * sx, 16f * sy),
        style = Stroke(1.6f * sx)
    )
    drawOval(
        color = Color.Black,
        topLeft = Offset(7.5f * sx, 13.5f * sy),
        size = Size(19f * sx, 10f * sy)
    )

    // Crack lines radiating outwards
    val cracks = listOf(
        Pair(Offset(17f * sx, 10f * sy), Offset(15f * sx, 5f * sy)),
        Pair(Offset(17f * sx, 26f * sy), Offset(18f * sx, 30f * sy)),
        Pair(Offset(3f * sx, 18f * sy), Offset(0f * sx, 17f * sy)),
        Pair(Offset(31f * sx, 18f * sy), Offset(34f * sx, 19f * sy)),
        Pair(Offset(7f * sx, 13f * sy), Offset(4f * sx, 10f * sy)),
        Pair(Offset(27f * sx, 13f * sy), Offset(30f * sx, 11f * sy)),
        Pair(Offset(8f * sx, 23f * sy), Offset(5f * sx, 26f * sy)),
        Pair(Offset(26f * sx, 23f * sy), Offset(29f * sx, 25f * sy))
    )
    for ((start, end) in cracks) {
        drawLine(Color.White, start, end, strokeWidth = 1.4f * sx, cap = StrokeCap.Round)
    }
}

// 4. Road Hazard: Dark red warning triangle with exclamation mark
private fun DrawScope.drawHazardIcon(sx: Float, sy: Float) {
    val outer = Path().apply {
        moveTo(17f * sx, 3f * sy)
        lineTo(32f * sx, 29f * sy)
        lineTo(2f * sx, 29f * sy)
        close()
    }
    drawPath(outer, Color(0xFF991B1B))
    drawPath(outer, Color.White, style = Stroke(2.4f * sx, join = StrokeJoin.Round))

    val inner = Path().apply {
        moveTo(17f * sx, 8f * sy)
        lineTo(29f * sx, 27f * sy)
        lineTo(5f * sx, 27f * sy)
        close()
    }
    drawPath(inner, Color(0xFF7F1D1D))

    // Exclamation mark
    drawLine(
        color = Color.White,
        start = Offset(17f * sx, 13f * sy),
        end = Offset(17f * sx, 20f * sy),
        strokeWidth = 2.8f * sx,
        cap = StrokeCap.Round
    )
    drawCircle(Color.White, radius = 1.6f * sx, center = Offset(17f * sx, 24f * sy))
}

// 5. Traffic Checkpoint: Purple checkpoint barrier with police star
private fun DrawScope.drawCheckpointIcon(sx: Float, sy: Float) {
    // Gate bar
    drawRoundRect(
        color = Color(0xFF9333EA),
        topLeft = Offset(3f * sx, 15f * sy),
        size = Size(28f * sx, 6.5f * sy),
        cornerRadius = CornerRadius(2f * sx, 2f * sy)
    )
    drawRoundRect(
        color = Color.White,
        topLeft = Offset(3f * sx, 15f * sy),
        size = Size(28f * sx, 6.5f * sy),
        cornerRadius = CornerRadius(2f * sx, 2f * sy),
        style = Stroke(1.6f * sx)
    )

    // Diagonal stripes on barrier
    drawLine(Color.White, Offset(7f * sx, 15f * sy), Offset(11f * sx, 21.5f * sy), strokeWidth = 2f * sx, cap = StrokeCap.Round)
    drawLine(Color.White, Offset(15f * sx, 15f * sy), Offset(19f * sx, 21.5f * sy), strokeWidth = 2f * sx, cap = StrokeCap.Round)
    drawLine(Color.White, Offset(23f * sx, 15f * sy), Offset(27f * sx, 21.5f * sy), strokeWidth = 2f * sx, cap = StrokeCap.Round)

    // Barrier legs
    drawLine(Color.White, Offset(6f * sx, 21.5f * sy), Offset(6f * sx, 30f * sy), strokeWidth = 2.2f * sx, cap = StrokeCap.Round)
    drawLine(Color.White, Offset(28f * sx, 21.5f * sy), Offset(28f * sx, 30f * sy), strokeWidth = 2.2f * sx, cap = StrokeCap.Round)

    // Officer shield badge
    val badge = Path().apply {
        moveTo(17f * sx, 4f * sy)
        lineTo(22.5f * sx, 7f * sy)
        lineTo(21.5f * sx, 13f * sy)
        lineTo(17f * sx, 15f * sy)
        lineTo(12.5f * sx, 13f * sy)
        lineTo(11.5f * sx, 7f * sy)
        close()
    }
    drawPath(badge, Color(0xFF7E22CE))
    drawPath(badge, Color.White, style = Stroke(1.3f * sx))
    drawCircle(Color(0xFFFACC15), radius = 2f * sx, center = Offset(17f * sx, 9f * sy))
}

// 6. Roadworks: Yellow cone and shovel
private fun DrawScope.drawRoadworksIcon(sx: Float, sy: Float) {
    // Traffic cone
    val cone = Path().apply {
        moveTo(17f * sx, 3f * sy)
        lineTo(23.5f * sx, 26f * sy)
        lineTo(10.5f * sx, 26f * sy)
        close()
    }
    drawPath(cone, Color(0xFFEAB308))
    drawPath(cone, Color.White, style = Stroke(1.6f * sx, join = StrokeJoin.Round))

    // White reflective band
    val band = Path().apply {
        moveTo(14f * sx, 13.5f * sy)
        lineTo(20f * sx, 13.5f * sy)
        lineTo(21.5f * sx, 19f * sy)
        lineTo(12.5f * sx, 19f * sy)
        close()
    }
    drawPath(band, Color.White)

    // Base plate
    drawRoundRect(
        color = Color(0xFFCA8A04),
        topLeft = Offset(6f * sx, 26f * sy),
        size = Size(22f * sx, 4.5f * sy),
        cornerRadius = CornerRadius(1.5f * sx, 1.5f * sy)
    )
    drawRoundRect(
        color = Color.White,
        topLeft = Offset(6f * sx, 26f * sy),
        size = Size(22f * sx, 4.5f * sy),
        cornerRadius = CornerRadius(1.5f * sx, 1.5f * sy),
        style = Stroke(1.3f * sx)
    )

    // Shovel
    drawLine(Color.White, Offset(23f * sx, 6f * sy), Offset(29f * sx, 12f * sy), strokeWidth = 1.6f * sx, cap = StrokeCap.Round)
    val shovelBlade = Path().apply {
        moveTo(26f * sx, 9f * sy)
        lineTo(23f * sx, 18f * sy)
        lineTo(21f * sx, 17f * sy)
        lineTo(24f * sx, 8f * sy)
        close()
    }
    drawPath(shovelBlade, Color(0xFFF59E0B))
    drawPath(shovelBlade, Color.White, style = Stroke(0.9f * sx))
}

// 7. Road Closed: Dark yellow no-entry circle with white bar
private fun DrawScope.drawRoadClosedIcon(sx: Float, sy: Float) {
    drawCircle(Color(0xFFCA8A04), radius = 14f * sx, center = Offset(17f * sx, 17f * sy))
    drawCircle(Color.White, radius = 14f * sx, center = Offset(17f * sx, 17f * sy), style = Stroke(2.2f * sx))
    drawCircle(Color(0xFFA16207), radius = 11f * sx, center = Offset(17f * sx, 17f * sy))

    // White horizontal barrier
    drawRoundRect(
        color = Color.White,
        topLeft = Offset(8f * sx, 14.5f * sy),
        size = Size(18f * sx, 5.5f * sy),
        cornerRadius = CornerRadius(1.6f * sx, 1.6f * sy)
    )
}

// 8. Flood / Water: Blue water waves
private fun DrawScope.drawFloodWaterIcon(sx: Float, sy: Float) {
    val yOffsets = listOf(11f, 18f, 25f)
    val colors = listOf(Color(0xFF2563EB), Color(0xFF1D4ED8), Color(0xFF1E40AF))

    for (i in yOffsets.indices) {
        val y = yOffsets[i] * sy
        val wavePath = Path().apply {
            moveTo(3f * sx, y)
            cubicTo(7f * sx, y - 3f * sy, 11f * sx, y - 3f * sy, 14f * sx, y)
            cubicTo(17f * sx, y + 3f * sy, 21f * sx, y + 3f * sy, 24f * sx, y)
            cubicTo(27f * sx, y - 3f * sy, 30f * sx, y - 2f * sy, 32f * sx, y)
        }
        drawPath(wavePath, Color.White, style = Stroke(width = 3.2f * sx, cap = StrokeCap.Round))
        drawPath(wavePath, colors[i], style = Stroke(width = 2.0f * sx, cap = StrokeCap.Round))
    }
}

// 9. Stopped Vehicle (مركبة متوقفة / معطلة): Broken-down vehicle with open bonnet, emergency hazard triangle & flashers
private fun DrawScope.drawStoppedVehicleIcon(sx: Float, sy: Float) {
    val car=Path().apply{moveTo(4f*sx,21f*sy);lineTo(7f*sx,15f*sy);lineTo(18f*sx,15f*sy);lineTo(20f*sx,21f*sy);lineTo(21f*sx,26f*sy);lineTo(3f*sx,26f*sy);close()}
    drawPath(car,Color(0xFFFACC15)); drawPath(car,Color.White,style=Stroke(1.4f*sx,join=StrokeJoin.Round))
    drawLine(Color(0xFF111827),Offset(17f*sx,21f*sy),Offset(23f*sx,12f*sy),2.2f*sx,cap=StrokeCap.Round)
    drawCircle(Color(0xFF111827),2.4f*sx,Offset(7f*sx,26f*sy)); drawCircle(Color(0xFF111827),2.4f*sx,Offset(17f*sx,26f*sy))
    val tri=Path().apply{moveTo(27f*sx,13f*sy);lineTo(32f*sx,25f*sy);lineTo(22f*sx,25f*sy);close()}
    drawPath(tri,Color(0xFF111827)); drawPath(tri,Color.White,style=Stroke(0.8f*sx)); drawLine(Color.White,Offset(27f*sx,17f*sy),Offset(27f*sx,21f*sy),1.2f*sx,cap=StrokeCap.Round); drawCircle(Color.White,0.7f*sx,Offset(27f*sx,23f*sy))
}

// 10. Speed Camera (كاميرا مراقبة السرعة): Dark navy housing with crisp white rim, glowing cyan radar lens & speed arcs
private fun DrawScope.drawSpeedCameraIcon(sx: Float, sy: Float) {
    // Glowing cyan/blue outer halo ring
    drawCircle(
        color = Color(0xFF38BDF8).copy(alpha = 0.35f),
        radius = 16f * sx,
        center = Offset(17f * sx, 17f * sy)
    )

    // Camera Stand Pole
    val polePath = Path().apply {
        moveTo(15.5f * sx, 25f * sy)
        lineTo(18.5f * sx, 25f * sy)
        lineTo(18.5f * sx, 32f * sy)
        lineTo(15.5f * sx, 32f * sy)
        close()
    }
    drawPath(polePath, Color(0xFF0D233A))
    drawPath(polePath, Color.White, style = Stroke(1.1f * sx))

    // Main Camera Housing: Dark Navy Box (#0D233A) with rounded corners
    val boxX = 6f * sx
    val boxY = 6f * sy
    val boxW = 22f * sx
    val boxH = 19f * sy
    drawRoundRect(
        color = Color(0xFF0D233A),
        topLeft = Offset(boxX, boxY),
        size = Size(boxW, boxH),
        cornerRadius = CornerRadius(4.5f * sx, 4.5f * sy)
    )
    drawRoundRect(
        color = Color.White,
        topLeft = Offset(boxX, boxY),
        size = Size(boxW, boxH),
        cornerRadius = CornerRadius(4.5f * sx, 4.5f * sy),
        style = Stroke(1.5f * sx)
    )

    // Optical Strobe Flash Window (Top Left)
    drawRoundRect(
        color = Color(0xFF38BDF8),
        topLeft = Offset(8.5f * sx, 8.5f * sy),
        size = Size(5.5f * sx, 4.5f * sy),
        cornerRadius = CornerRadius(1.2f * sx, 1.2f * sy)
    )
    drawRoundRect(
        color = Color.White,
        topLeft = Offset(9.5f * sx, 9.5f * sy),
        size = Size(3.5f * sx, 2.5f * sy),
        cornerRadius = CornerRadius(0.8f * sx, 0.8f * sy)
    )

    // High-Resolution Radar Speed Lens (Center Right)
    val lensCenter = Offset(19.5f * sx, 15.5f * sy)
    // Outer lens rim
    drawCircle(Color(0xFF38BDF8), radius = 5.2f * sx, center = lensCenter)
    drawCircle(Color.White, radius = 5.2f * sx, center = lensCenter, style = Stroke(1.2f * sx))
    // Dark optical aperture
    drawCircle(Color(0xFF081220), radius = 3.8f * sx, center = lensCenter)
    // Center glowing blue sensor dot
    drawCircle(Color(0xFF38BDF8), radius = 1.8f * sx, center = lensCenter)
    drawCircle(Color.White, radius = 0.8f * sx, center = Offset(18.5f * sx, 14.5f * sy))

    // Active Radar Emission Speed Waves (pulsing top right)
    val wavePath = Path().apply {
        moveTo(24f * sx, 3f * sy)
        cubicTo(27f * sx, 5f * sy, 29f * sx, 7f * sy, 31f * sx, 10f * sy)
    }
    drawPath(wavePath, Color(0xFF38BDF8), style = Stroke(2f * sx, cap = StrokeCap.Round))
    drawPath(wavePath, Color.White, style = Stroke(0.8f * sx, cap = StrokeCap.Round))
}

// 11. Speed Bump (مطبّ): Asphalt road baseline with raised curve hump, yellow caution chevrons & vibration shockwaves
private fun DrawScope.drawSpeedBumpIcon(sx: Float, sy: Float) {
    drawLine(Color(0xFFDC2626), Offset(3f * sx, 6f * sy), Offset(10f * sx, 6f * sy), strokeWidth = 2f * sx, cap = StrokeCap.Round)
    // Road baseline with raised hump
    val roadHumpPath = Path().apply {
        moveTo(2f * sx, 24f * sy)
        lineTo(8f * sx, 24f * sy)
        quadraticTo(17f * sx, 12f * sy, 26f * sx, 24f * sy)
        lineTo(32f * sx, 24f * sy)
    }
    // Outer white stroke for contrast
    drawPath(roadHumpPath, Color.White, style = Stroke(width = 4.5f * sx, cap = StrokeCap.Round, join = StrokeJoin.Round))
    // Solid Amber road surface
    drawPath(roadHumpPath, Color(0xFFD97706), style = Stroke(width = 3f * sx, cap = StrokeCap.Round, join = StrokeJoin.Round))

    // Hazard chevrons on hump
    val chevron1 = Path().apply {
        moveTo(12f * sx, 22f * sy)
        lineTo(17f * sx, 16f * sy)
        lineTo(22f * sx, 22f * sy)
    }
    drawPath(chevron1, Color.White, style = Stroke(width = 2.2f * sx, cap = StrokeCap.Round, join = StrokeJoin.Round))

    val chevron2 = Path().apply {
        moveTo(14f * sx, 23f * sy)
        lineTo(17f * sx, 19f * sy)
        lineTo(20f * sx, 23f * sy)
    }
    drawPath(chevron2, Color(0xFFFBBF24), style = Stroke(width = 1.4f * sx, cap = StrokeCap.Round, join = StrokeJoin.Round))

    // Shock absorption / vibration alert waves above hump
    drawLine(Color.White, Offset(17f * sx, 6f * sy), Offset(17f * sx, 11f * sy), strokeWidth = 2.2f * sx, cap = StrokeCap.Round)
    drawLine(Color(0xFFF59E0B), Offset(12f * sx, 8f * sy), Offset(13.5f * sx, 12f * sy), strokeWidth = 1.8f * sx, cap = StrokeCap.Round)
    drawLine(Color(0xFFF59E0B), Offset(22f * sx, 8f * sy), Offset(20.5f * sx, 12f * sy), strokeWidth = 1.8f * sx, cap = StrokeCap.Round)
}

// 12. Slippery Road (طريق زَلِق): Skidding vehicle viewed from rear with S-curve skid tracks & liquid splash droplets
private fun DrawScope.drawSlipperyRoadIcon(sx: Float, sy: Float) {
    drawCircle(Color(0xFF38BDF8), radius = 2f * sx, center = Offset(6f * sx, 6f * sy))
    // Left wavy skid track
    val leftSkid = Path().apply {
        moveTo(9f * sx, 19f * sy)
        quadraticTo(14f * sx, 23f * sy, 11f * sx, 27f * sy)
        quadraticTo(8f * sx, 30f * sy, 13f * sx, 32f * sy)
    }
    drawPath(leftSkid, Color.White, style = Stroke(width = 3.2f * sx, cap = StrokeCap.Round))
    drawPath(leftSkid, Color(0xFF0284C7), style = Stroke(width = 2f * sx, cap = StrokeCap.Round))

    // Right wavy skid track
    val rightSkid = Path().apply {
        moveTo(21f * sx, 19f * sy)
        quadraticTo(26f * sx, 23f * sy, 23f * sx, 27f * sy)
        quadraticTo(20f * sx, 30f * sy, 25f * sx, 32f * sy)
    }
    drawPath(rightSkid, Color.White, style = Stroke(width = 3.2f * sx, cap = StrokeCap.Round))
    drawPath(rightSkid, Color(0xFF0284C7), style = Stroke(width = 2f * sx, cap = StrokeCap.Round))

    // Skidding vehicle body (tilted)
    val carPath = Path().apply {
        moveTo(7f * sx, 9f * sy)
        lineTo(23f * sx, 6f * sy)
        lineTo(25f * sx, 17f * sy)
        lineTo(9f * sx, 20f * sy)
        close()
    }
    drawPath(carPath, Color(0xFF0284C7))
    drawPath(carPath, Color.White, style = Stroke(width = 1.6f * sx, join = StrokeJoin.Round))

    // Rear window
    val windowPath = Path().apply {
        moveTo(9.5f * sx, 10f * sy)
        lineTo(20.5f * sx, 8f * sy)
        lineTo(21.5f * sx, 12f * sy)
        lineTo(10.5f * sx, 14f * sy)
        close()
    }
    drawPath(windowPath, Color(0xFFE0F2FE))

    // Tail lights
    drawCircle(Color(0xFFEF4444), radius = 1.4f * sx, center = Offset(11f * sx, 18f * sy))
    drawCircle(Color(0xFFEF4444), radius = 1.4f * sx, center = Offset(23f * sx, 15.5f * sy))

    // Liquid / water splash droplets
    drawCircle(Color(0xFF38BDF8), radius = 1.4f * sx, center = Offset(5f * sx, 24f * sy))
    drawCircle(Color.White, radius = 0.8f * sx, center = Offset(5f * sx, 24f * sy))
    drawCircle(Color(0xFF38BDF8), radius = 1.4f * sx, center = Offset(29f * sx, 22f * sy))
    drawCircle(Color.White, radius = 0.8f * sx, center = Offset(29f * sx, 22f * sy))
}
