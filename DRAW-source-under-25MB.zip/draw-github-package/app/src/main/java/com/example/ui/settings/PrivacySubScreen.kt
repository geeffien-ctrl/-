package com.example.ui.settings

import android.content.Intent
import android.net.Uri
import android.provider.Settings
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.OpenInNew
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Wifi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@Composable
fun PrivacySubScreen(
    uiState: SettingsUiState,
    onRefreshPermissions: () -> Unit,
    modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val cardShape = RoundedCornerShape(22.dp)

  Column(
      modifier = modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // Top summary card
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, cardShape, spotColor = Color(0x18000000))
            .border(0.8.dp, Color(0x14000000), cardShape),
        shape = cardShape,
        color = Color.White,
    ) {
      Row(
          modifier = Modifier.padding(18.dp),
          verticalAlignment = Alignment.CenterVertically,
      ) {
        Box(
            modifier = Modifier
                .size(48.dp)
                .clip(CircleShape)
                .background(Color(0xFFE8F5E9)),
            contentAlignment = Alignment.Center,
        ) {
          Icon(
              imageVector = Icons.Default.Security,
              contentDescription = null,
              tint = Color(0xFF2E7D32),
              modifier = Modifier.size(28.dp),
          )
        }
        Spacer(modifier = Modifier.width(14.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
              text = "حماية الخصوصية والبيانات",
              fontSize = 16.sp,
              fontWeight = FontWeight.Bold,
              color = DrawTextNearBlack,
          )
          Text(
              text = "لا يتم مشاركة موقعك الجغرافي أو تسجيلاتك الصوتية مع أي أطراف إعلانية خارجية.",
              fontSize = 12.5.sp,
              color = DrawTextSecondary,
              lineHeight = 18.sp,
          )
        }
      }
    }

    // Permissions List Card
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, cardShape, spotColor = Color(0x18000000))
            .border(0.8.dp, Color(0x14000000), cardShape),
        shape = cardShape,
        color = Color.White,
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Text(
            text = "أذونات التطبيق على الجهاز",
            fontSize = 15.5.sp,
            fontWeight = FontWeight.Bold,
            color = DrawTextNearBlack,
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 1. Location
        PermissionStatusRow(
            icon = Icons.Default.MyLocation,
            title = "الموقع الجغرافي الدقيق",
            description = "لتحديد موقعك على الخريطة وحساب التوجيهات الملاحية المباشرة",
            isGranted = uiState.hasLocationPermission,
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0x14000000), thickness = 0.8.dp)

        // 2. Microphone
        PermissionStatusRow(
            icon = Icons.Default.Mic,
            title = "الميكروفون والتعرف الصوتي",
            description = "لإتاحة البحث الصوتي السريع عن الأماكن والوجهات باللغة العربية",
            isGranted = uiState.hasAudioPermission,
        )

        HorizontalDivider(modifier = Modifier.padding(vertical = 12.dp), color = Color(0x14000000), thickness = 0.8.dp)

        // 3. Internet
        PermissionStatusRow(
            icon = Icons.Default.Wifi,
            title = "الاتصال بالإنترنت",
            description = "لتحميل بلاطات OpenFreeMap وحساب مسارات OSRM في الوقت الفعلي",
            isGranted = true,
        )
      }
    }

    // System Settings Button
    OutlinedButton(
        onClick = {
          try {
            val intent = Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS).apply {
              data = Uri.fromParts("package", context.packageName, null)
            }
            context.startActivity(intent)
          } catch (e: Exception) {
            // fallback
          }
        },
        shape = RoundedCornerShape(16.dp),
        modifier = Modifier
            .fillMaxWidth()
            .height(48.dp)
            .testTag("privacy_open_settings_button"),
    ) {
      Icon(
          imageVector = Icons.Default.OpenInNew,
          contentDescription = null,
          tint = DrawRed,
          modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
          text = "إدارة أذونات التطبيق في إعدادات Android",
          color = DrawRed,
          fontWeight = FontWeight.SemiBold,
          fontSize = 14.sp,
      )
    }

    // Privacy Terms Details
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, cardShape, spotColor = Color(0x10000000))
            .border(0.8.dp, Color(0x12000000), cardShape),
        shape = cardShape,
        color = Color(0xFFFAFAFC),
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Text(
            text = "سياسة الخصوصية وأمان الخدمة",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = DrawTextNearBlack,
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
            text = "تلتزم DRAW بحماية خصوصيتك بالكامل. جميع المفضلة والأماكن المحفوظة مشفرة ومخزنة عبر قواعد بيانات Firebase Firestore الخاصة بحسابك، ولا يستطيع أي مستخدم آخر الوصول إلى سجلاتك أو بيانات مساراتك.",
            fontSize = 12.5.sp,
            color = DrawTextSecondary,
            lineHeight = 18.sp,
        )
      }
    }
  }
}

@Composable
private fun PermissionStatusRow(
    icon: ImageVector,
    title: String,
    description: String,
    isGranted: Boolean,
) {
  Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier.fillMaxWidth(),
  ) {
    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(if (isGranted) Color(0xFFE8F5E9) else Color(0xFFFFEBEE)),
        contentAlignment = Alignment.Center,
    ) {
      Icon(
          imageVector = icon,
          contentDescription = null,
          tint = if (isGranted) Color(0xFF2E7D32) else DrawRed,
          modifier = Modifier.size(22.dp),
      )
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
          text = title,
          fontSize = 14.5.sp,
          fontWeight = FontWeight.SemiBold,
          color = DrawTextNearBlack,
      )
      Text(
          text = description,
          fontSize = 12.sp,
          color = DrawTextSecondary,
          lineHeight = 16.sp,
      )
    }

    Spacer(modifier = Modifier.width(8.dp))

    Surface(
        shape = RoundedCornerShape(10.dp),
        color = if (isGranted) Color(0xFFE8F5E9) else Color(0xFFFFEBEE),
    ) {
      Row(
          modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
          verticalAlignment = Alignment.CenterVertically,
      ) {
        Icon(
            imageVector = if (isGranted) Icons.Default.CheckCircle else Icons.Default.Warning,
            contentDescription = null,
            tint = if (isGranted) Color(0xFF2E7D32) else DrawRed,
            modifier = Modifier.size(14.dp),
        )
        Spacer(modifier = Modifier.width(4.dp))
        Text(
            text = if (isGranted) "مفعّل" else "معطّل",
            fontSize = 11.5.sp,
            fontWeight = FontWeight.Bold,
            color = if (isGranted) Color(0xFF2E7D32) else DrawRed,
        )
      }
    }
  }
}
