package com.example.ui.auth

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import com.example.ui.components.BalloonButton
import com.example.ui.components.BalloonTextField
import com.example.ui.theme.DrawTextMuted
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import com.example.ui.theme.DrawWhite

@Composable
fun ForgotPasswordDialog(
    initialEmail: String = "",
    onDismiss: () -> Unit,
    onSubmit: (String) -> Unit,
) {
  var email by remember { mutableStateOf(initialEmail) }

  Dialog(onDismissRequest = onDismiss) {
    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = DrawWhite),
        elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
        modifier =
            Modifier
                .fillMaxWidth()
                .padding(16.dp)
                .testTag("forgot_password_dialog"),
    ) {
      Column(
          horizontalAlignment = Alignment.CenterHorizontally,
          modifier = Modifier.padding(24.dp),
      ) {
        Text(
            text = "Reset Password",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = DrawTextNearBlack,
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text =
                "Enter your registered email address and we will send you a password recovery link.",
            fontSize = 14.sp,
            color = DrawTextSecondary,
        )

        Spacer(modifier = Modifier.height(20.dp))

        BalloonTextField(
            value = email,
            onValueChange = { email = it },
            label = "Email Address",
            placeholder = "name@example.com",
            leadingIcon = Icons.Outlined.Email,
            testTag = "forgot_password_email_input",
        )

        Spacer(modifier = Modifier.height(24.dp))

        BalloonButton(
            text = "Send Reset Link",
            onClick = { onSubmit(email.trim()) },
            testTag = "forgot_password_submit_button",
        )

        Spacer(modifier = Modifier.height(8.dp))

        TextButton(
            onClick = onDismiss,
            modifier = Modifier.testTag("forgot_password_cancel_button"),
        ) {
          Text(
              text = "Cancel",
              color = DrawTextMuted,
              fontWeight = FontWeight.SemiBold,
          )
        }
      }
    }
  }
}
