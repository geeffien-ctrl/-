package com.example.ui.map.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.DiscoveredPlaceCandidate
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import java.util.Locale

/**
 * Clean iOS-styled card shown after nearest POI discovery, displaying place details,
 * real distance, and two actions: "تحديد المسار" and "إلغاء".
 */
@Composable
fun DiscoveredPlaceCard(
    candidate: DiscoveredPlaceCandidate,
    isCalculatingRoute: Boolean,
    onCalculateRoute: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
  val iconItem = PlaceIconRegistry.getIconById(candidate.iconId)
  val shape = RoundedCornerShape(26.dp)

  val distanceText = if (candidate.distanceMeters < 1000f) {
    "${candidate.distanceMeters.toInt()} متر"
  } else {
    String.format(Locale.US, "%.1f كم", candidate.distanceMeters / 1000f)
  }

  Surface(
      modifier = modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp)
          .shadow(elevation = 16.dp, shape = shape, spotColor = Color(0x38000000))
          .border(width = 0.8.dp, color = Color(0x18000000), shape = shape)
          .testTag("discovered_place_card"),
      shape = shape,
      color = Color(0xFDFDFDFF)
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp)
    ) {
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
          Box(
              modifier = Modifier
                  .size(42.dp)
                  .clip(CircleShape)
                  .background(iconItem.primaryColor),
              contentAlignment = Alignment.Center
          ) {
            Icon(
                imageVector = iconItem.iconVector,
                contentDescription = iconItem.nameArabic,
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column {
            Text(
                text = candidate.title,
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                  imageVector = Icons.Default.NearMe,
                  contentDescription = null,
                  tint = iconItem.primaryColor,
                  modifier = Modifier.size(13.dp)
              )
              Spacer(modifier = Modifier.width(3.dp))
              Text(
                  text = "أقرب ${iconItem.nameArabic} • يبعد $distanceText",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = iconItem.primaryColor
              )
            }
          }
        }

        IconButton(
            onClick = onDismiss,
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFFE5E5EA))
                .testTag("close_discovered_place_card")
        ) {
          Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Dismiss",
              tint = Color(0xFF3A3A3C),
              modifier = Modifier.size(15.dp)
          )
        }
      }

      if (candidate.address.isNotBlank() && candidate.address != candidate.title) {
        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = candidate.address,
            fontSize = 12.5.sp,
            color = DrawTextSecondary,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis,
            lineHeight = 17.sp
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Action Buttons: "تحديد المسار" and "إلغاء"
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedButton(
            onClick = onDismiss,
            shape = RoundedCornerShape(16.dp),
            modifier = Modifier
                .weight(1f)
                .height(46.dp)
                .testTag("discovered_place_cancel_button")
        ) {
          Text("إلغاء", color = Color(0xFF8E8E93), fontWeight = FontWeight.SemiBold, fontSize = 14.sp)
        }

        Button(
            onClick = onCalculateRoute,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007AFF)),
            modifier = Modifier
                .weight(1.4f)
                .height(46.dp)
                .testTag("discovered_place_route_button")
        ) {
          if (isCalculatingRoute) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 2.dp,
                modifier = Modifier.size(20.dp)
            )
          } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                  imageVector = Icons.Default.Directions,
                  contentDescription = null,
                  modifier = Modifier.size(19.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text("تحديد المسار", fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
            }
          }
        }
      }
    }
  }
}
