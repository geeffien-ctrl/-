package com.example.ui.map.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AltRoute
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RoadReportType
import com.example.ui.map.HazardDetourProposal
import com.example.ui.theme.DrawGreen
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * Prominent top alert banner proposing an alternative detour around a road hazard.
 * Features audio chime awareness, explicit driver consent buttons,
 * distance & time comparison, and road safety algorithmic disclaimer.
 */
@Composable
fun HazardDetourAlertBanner(
    proposal: HazardDetourProposal?,
    onAcceptDetour: () -> Unit,
    onDismissDetour: () -> Unit,
    modifier: Modifier = Modifier
) {
    AnimatedVisibility(
        visible = proposal != null,
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically(),
        modifier = modifier
    ) {
        if (proposal == null) return@AnimatedVisibility

        val cardShape = RoundedCornerShape(20.dp)
        val isRoadClosed = proposal.hazardReport.type == RoadReportType.ROAD_CLOSED

        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp, vertical = 6.dp)
                .shadow(8.dp, cardShape, spotColor = Color(0x38000000))
                .border(1.5.dp, if (isRoadClosed) DrawRed else Color(0xFFF59E0B), cardShape)
                .testTag("hazard_detour_banner"),
            shape = cardShape,
            color = Color.White
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(14.dp)
            ) {
                // 1. Header: Hazard Icon + Title & Proximity
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    RoadReportUnifiedIcon(
                        type = proposal.hazardReport.type,
                        size = 36.dp
                    )

                    Spacer(modifier = Modifier.width(10.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp)
                        ) {
                            Text(
                                text = if (isRoadClosed) "خطر إغلاق على مسارك" else "رصد خطر على مسارك",
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isRoadClosed) DrawRed else Color(0xFFD97706)
                            )
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(6.dp))
                                    .background(Color(0xFFFEF3C7))
                                    .padding(horizontal = 6.dp, vertical = 2.dp)
                            ) {
                                Text(
                                    text = formatDistance(proposal.hazardDistanceMeters),
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = Color(0xFF92400E)
                                )
                            }
                        }

                        Text(
                            text = "${proposal.hazardReport.type.titleArabic} • ${proposal.hazardReport.type.legalSafetyNotice}",
                            fontSize = 12.sp,
                            color = DrawTextNearBlack,
                            fontWeight = FontWeight.Medium,
                            maxLines = 2
                        )
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 2. Route Comparison Box
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF8FAFC),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x14000000)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    val timeDiffMinutes = kotlin.math.round(proposal.durationDiffSeconds / 60.0).toInt()
                    val distDiffKm = (proposal.distanceDiffMeters / 1000.0)
                    val (timeLabel, timeBg, timeColor) = when {
                        timeDiffMinutes < 0 -> Triple("يوفر ${kotlin.math.abs(timeDiffMinutes)} دقيقة", Color(0xFFE8F5E9), DrawGreen)
                        timeDiffMinutes == 0 -> Triple("نفس المدة تقريباً", Color(0xFFEFF6FF), Color(0xFF1D4ED8))
                        else -> Triple("+$timeDiffMinutes دقيقة", Color(0xFFFFFBEB), Color(0xFFD97706))
                    }

                    Column(modifier = Modifier.padding(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.AltRoute,
                                    contentDescription = null,
                                    tint = Color(0xFF007AFF),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = "المسار البديل المقترح",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF007AFF)
                                )
                            }

                            // Delta Badge
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(timeBg)
                                    .padding(horizontal = 8.dp, vertical = 3.dp)
                            ) {
                                Text(
                                    text = timeLabel,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = timeColor
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(4.dp))

                        val distFormatted = if (kotlin.math.abs(distDiffKm) < 0.1) {
                            "نفس المسافة تقريباً"
                        } else if (distDiffKm < 0.0) {
                            "أقصر بـ ${String.format(java.util.Locale.US, "%.1f", kotlin.math.abs(distDiffKm))} كم"
                        } else {
                            "+${String.format(java.util.Locale.US, "%.1f", distDiffKm)} كم"
                        }

                        Text(
                            text = "المسافة: $distFormatted • يتجنب المرور بنقطة البلاغ",
                            fontSize = 11.5.sp,
                            color = DrawTextSecondary
                        )
                    }
                }

                Spacer(modifier = Modifier.height(6.dp))

                // Algorithmic Disclaimer Notice
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = Color(0xFF94A3B8),
                        modifier = Modifier.size(13.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "المسارات المقترحة تقديرات خوارزمية لتعزيز السلامة وليست ضماناً كلياً لظروف الطريق.",
                        fontSize = 10.sp,
                        color = Color(0xFF64748B),
                        lineHeight = 13.sp
                    )
                }

                Spacer(modifier = Modifier.height(10.dp))

                // 3. Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Secondary Button: Continue on current route
                    OutlinedButton(
                        onClick = onDismissDetour,
                        modifier = Modifier
                            .weight(1f)
                            .testTag("dismiss_detour_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.outlinedButtonColors(
                            contentColor = DrawTextNearBlack
                        )
                    ) {
                        Text(
                            text = "المتابعة بالمسار الحالي",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }

                    // Primary Button: Accept detour proposal
                    Button(
                        onClick = onAcceptDetour,
                        modifier = Modifier
                            .weight(1.2f)
                            .testTag("accept_detour_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isRoadClosed) DrawRed else Color(0xFF007AFF)
                        )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Check,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "اعتماد المسار البديل",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

private fun formatDistance(meters: Float): String {
    return if (meters >= 1000f) {
        String.format(java.util.Locale.US, "بعد %.1f كم", meters / 1000f)
    } else {
        "بعد ${meters.toInt()} م"
    }
}
