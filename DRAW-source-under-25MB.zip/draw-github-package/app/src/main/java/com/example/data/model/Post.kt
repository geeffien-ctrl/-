package com.example.data.model

/**
 * Social Post model supporting single/multi-image galleries with optional audio,
 * or video previews linking to Reels.
 */
data class Post(
    val id: String = "",
    val creatorId: String = "",
    val creatorName: String = "",
    val creatorPhotoUrl: String = "",
    val caption: String = "",
    val type: String = "image", // "image" or "video"
    val images: List<String> = emptyList(),
    val videoUrl: String = "",
    val audioUrl: String = "",
    val audioTitle: String = "",
    val audioDuration: Long = 0L,
    val likesCount: Long = 0L,
    val commentsCount: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val likesCountInt: Int get() = likesCount.toInt()
    val commentsCountInt: Int get() = commentsCount.toInt()
    val isVideo: Boolean get() = type == "video" || videoUrl.isNotBlank()
    val hasAudio: Boolean get() = audioUrl.isNotBlank()
}
