package com.example.data.model

/**
 * 5-star rating entry for a published place in DRAW.
 */
data class PlaceRating(
    val userId: String = "",
    val userName: String = "",
    val userPhotoUrl: String = "",
    val rating: Int = 5, // 1 to 5 stars
    val comment: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
