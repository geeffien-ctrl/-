package com.example.ui.map.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.AddLocation
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Info
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * iOS-styled Dialog to create and publish a new place with:
 * - Title and Description
 * - 60 Categorized Icons selection
 * - Verified real coordinates
 * - Mandatory 2 to 5 photos with preview and deletion
 */
@Composable
fun AddCustomPlaceDialog(
    placeName: String,
    address: String = "",
    description: String,
    category: String,
    selectedIconId: String,
    latitude: Double,
    longitude: Double,
    selectedImageUris: List<Uri>,
    isPublishing: Boolean,
    onNameChange: (String) -> Unit,
    onAddressChange: (String) -> Unit = {},
    onDescriptionChange: (String) -> Unit,
    onCategoryChange: (String) -> Unit,
    onIconSelected: (String) -> Unit,
    onImagesPicked: (List<Uri>) -> Unit,
    onImageRemoved: (Int) -> Unit,
    onPublish: () -> Unit,
    onDismiss: () -> Unit
) {
  var selectedCategoryKey by remember { mutableStateOf("all") }
  val activeIcon = PlaceIconRegistry.getIconById(selectedIconId)

  val photoPickerLauncher = rememberLauncherForActivityResult(
      contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 5)
  ) { uris ->
    if (uris.isNotEmpty()) {
      onImagesPicked(uris)
    }
  }

  val canPublish = placeName.trim().length >= 2 && description.trim().length >= 3 && !isPublishing

  Dialog(
      onDismissRequest = onDismiss,
      properties = DialogProperties(usePlatformDefaultWidth = false)
  ) {
    val dialogShape = RoundedCornerShape(28.dp)

    Surface(
        shape = dialogShape,
        color = Color(0xFFFFFFFF),
        shadowElevation = 18.dp,
        modifier = Modifier
            .fillMaxWidth(0.94f)
            .heightIn(max = 680.dp)
            .padding(vertical = 12.dp)
            .testTag("add_custom_place_dialog")
    ) {
      Column(
          modifier = Modifier
              .fillMaxWidth()
              .verticalScroll(rememberScrollState())
              .padding(horizontal = 20.dp, vertical = 20.dp)
      ) {
        // 1. Header Row
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
          Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier.weight(1f)
          ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(activeIcon.primaryColor),
                contentAlignment = Alignment.Center
            ) {
              Icon(
                  imageVector = activeIcon.iconVector,
                  contentDescription = activeIcon.nameArabic,
                  tint = Color.White,
                  modifier = Modifier.size(22.dp)
              )
            }
            Spacer(modifier = Modifier.width(12.dp))
            Column {
              Text(
                  text = "نشر مكان جديد على DRAW",
                  fontSize = 17.sp,
                  fontWeight = FontWeight.Bold,
                  color = DrawTextNearBlack
              )
              Text(
                  text = "إحداثيات: ${String.format("%.4f", latitude)}, ${String.format("%.4f", longitude)}",
                  fontSize = 11.5.sp,
                  color = DrawTextSecondary
              )
            }
          }

          IconButton(
              onClick = onDismiss,
              modifier = Modifier
                  .size(30.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFE5E5EA))
                  .testTag("close_add_place_dialog")
          ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Close",
                tint = Color(0xFF3A3A3C),
                modifier = Modifier.size(16.dp)
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // 2. Place Name Input
        Text(
            text = "اسم المكان *",
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = DrawTextSecondary
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = placeName,
            onValueChange = onNameChange,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFF000000), fontSize = 14.sp),
            placeholder = { Text("مثال: جامع الراجحي، مطعم البيك...", fontSize = 13.5.sp, color = Color(0xFF8E8E93)) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color(0xFF000000),
                unfocusedTextColor = Color(0xFF000000),
                cursorColor = Color(0xFF000000),
                focusedBorderColor = activeIcon.primaryColor,
                unfocusedBorderColor = Color(0xFFD1D1D6),
                focusedContainerColor = Color(0xFFFFFFFF),
                unfocusedContainerColor = Color(0xFFFFFFFF),
                focusedPlaceholderColor = Color(0xFF8E8E93),
                unfocusedPlaceholderColor = Color(0xFF8E8E93)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("custom_place_name_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 3. Place Address Input
        Text(
            text = "العنوان *",
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = DrawTextSecondary
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = address,
            onValueChange = onAddressChange,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFF000000), fontSize = 14.sp),
            placeholder = { Text("مثال: حي العزيزية، طريق الملك فهد...", fontSize = 13.5.sp, color = Color(0xFF8E8E93)) },
            singleLine = true,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color(0xFF000000),
                unfocusedTextColor = Color(0xFF000000),
                cursorColor = Color(0xFF000000),
                focusedBorderColor = activeIcon.primaryColor,
                unfocusedBorderColor = Color(0xFFD1D1D6),
                focusedContainerColor = Color(0xFFFFFFFF),
                unfocusedContainerColor = Color(0xFFFFFFFF),
                focusedPlaceholderColor = Color(0xFF8E8E93),
                unfocusedPlaceholderColor = Color(0xFF8E8E93)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("custom_place_address_input")
        )

        Spacer(modifier = Modifier.height(12.dp))

        // 3. Place Description Input
        Text(
            text = "وصف المكان *",
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = DrawTextSecondary
        )
        Spacer(modifier = Modifier.height(4.dp))
        OutlinedTextField(
            value = description,
            onValueChange = onDescriptionChange,
            textStyle = androidx.compose.ui.text.TextStyle(color = Color(0xFF000000), fontSize = 13.5.sp),
            placeholder = { Text("اكتب وصفاً مختصراً عن الخدمات والمميزات...", fontSize = 13.sp, color = Color(0xFF8E8E93)) },
            minLines = 2,
            maxLines = 3,
            shape = RoundedCornerShape(16.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color(0xFF000000),
                unfocusedTextColor = Color(0xFF000000),
                cursorColor = Color(0xFF000000),
                focusedBorderColor = activeIcon.primaryColor,
                unfocusedBorderColor = Color(0xFFD1D1D6),
                focusedContainerColor = Color(0xFFFFFFFF),
                unfocusedContainerColor = Color(0xFFFFFFFF),
                focusedPlaceholderColor = Color(0xFF8E8E93),
                unfocusedPlaceholderColor = Color(0xFF8E8E93)
            ),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("custom_place_description_input")
        )

        Spacer(modifier = Modifier.height(14.dp))

        // 5. Category Selection from 60 Icons
        Text(
            text = "اختر فئة المكان من الـ 60 أيقونة",
            fontSize = 12.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = DrawTextSecondary
        )
        Spacer(modifier = Modifier.height(6.dp))

        // Category Filter Chips
        val catScrollState = rememberScrollState()
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(catScrollState),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          PlaceIconRegistry.categories.forEach { cat ->
            val isSelected = selectedCategoryKey == cat.key
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(20.dp))
                    .background(if (isSelected) cat.color else Color(0xFFF2F2F7))
                    .clickable { selectedCategoryKey = cat.key }
                    .padding(horizontal = 11.dp, vertical = 6.dp)
                    .testTag("add_place_filter_${cat.key}")
            ) {
              Text(
                  text = cat.nameArabic,
                  fontSize = 11.5.sp,
                  fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                  color = if (isSelected) Color.White else Color(0xFF3C3C43)
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(8.dp))

        // 60 Icons Selection Grid
        val filteredIcons = PlaceIconRegistry.getIconsByCategory(selectedCategoryKey)
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFFF9F9FB),
            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFEFEFF4)),
            modifier = Modifier.fillMaxWidth()
        ) {
          LazyVerticalGrid(
              columns = GridCells.Fixed(4),
              modifier = Modifier
                  .fillMaxWidth()
                  .heightIn(max = 200.dp)
                  .testTag("add_place_icons_grid"),
              contentPadding = PaddingValues(8.dp),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
              verticalArrangement = Arrangement.spacedBy(10.dp)
          ) {
            items(filteredIcons, key = { it.id }) { iconItem ->
              val isSelected = iconItem.id == selectedIconId
              Column(
                  horizontalAlignment = Alignment.CenterHorizontally,
                  modifier = Modifier
                      .fillMaxWidth()
                      .clip(RoundedCornerShape(12.dp))
                      .clickable {
                        onIconSelected(iconItem.id)
                        onCategoryChange(iconItem.categoryKey)
                      }
                      .padding(vertical = 3.dp)
                      .testTag("dialog_icon_${iconItem.id}")
              ) {
                Box(contentAlignment = Alignment.Center) {
                  Box(
                      modifier = Modifier
                          .size(46.dp)
                          .clip(CircleShape)
                          .border(
                              width = if (isSelected) 2.5.dp else 0.dp,
                              color = if (isSelected) iconItem.primaryColor else Color.Transparent,
                              shape = CircleShape
                          )
                          .padding(2.5.dp),
                      contentAlignment = Alignment.Center
                  ) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(if (isSelected) iconItem.primaryColor else iconItem.softBgColor),
                        contentAlignment = Alignment.Center
                    ) {
                      Icon(
                          imageVector = iconItem.iconVector,
                          contentDescription = iconItem.nameArabic,
                          tint = if (isSelected) Color.White else iconItem.primaryColor,
                          modifier = Modifier.size(20.dp)
                      )
                    }
                  }

                  if (isSelected) {
                    Box(
                        modifier = Modifier
                            .size(14.dp)
                            .align(Alignment.TopEnd)
                            .clip(CircleShape)
                            .background(iconItem.primaryColor)
                            .border(1.5.dp, Color.White, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                      Icon(
                          imageVector = Icons.Default.Check,
                          contentDescription = null,
                          tint = Color.White,
                          modifier = Modifier.size(9.dp)
                      )
                    }
                  }
                }

                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = iconItem.nameArabic,
                    fontSize = 10.5.sp,
                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                    color = if (isSelected) iconItem.primaryColor else DrawTextNearBlack,
                    maxLines = 1,
                    overflow = TextOverflow.Ellipsis
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(18.dp))

        // 6. Action Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
          TextButton(
              onClick = onDismiss,
              enabled = !isPublishing,
              shape = RoundedCornerShape(16.dp),
              modifier = Modifier
                  .weight(1f)
                  .height(48.dp)
                  .testTag("cancel_publish_place_button")
          ) {
            Text("إلغاء", color = Color(0xFF8E8E93), fontWeight = FontWeight.SemiBold, fontSize = 14.5.sp)
          }

          Button(
              onClick = onPublish,
              enabled = canPublish,
              shape = RoundedCornerShape(16.dp),
              colors = ButtonDefaults.buttonColors(
                  containerColor = DrawRed,
                  contentColor = Color.White,
                  disabledContainerColor = Color(0xFFE5E5EA),
                  disabledContentColor = Color(0xFF8E8E93)
              ),
              modifier = Modifier
                  .weight(1.4f)
                  .height(48.dp)
                  .testTag("publish_place_submit_button")
          ) {
            if (isPublishing) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                CircularProgressIndicator(color = Color.White, modifier = Modifier.size(20.dp), strokeWidth = 2.dp)
                Spacer(modifier = Modifier.width(8.dp))
                Text("جارٍ الرفع والحفظ...", color = Color.White, fontSize = 13.5.sp, fontWeight = FontWeight.Bold)
              }
            } else {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(imageVector = Icons.Default.AddLocation, contentDescription = null, modifier = Modifier.size(19.dp))
                Spacer(modifier = Modifier.width(6.dp))
                Text("إنشاء المكان", fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
              }
            }
          }
        }
      }
    }
  }
}
