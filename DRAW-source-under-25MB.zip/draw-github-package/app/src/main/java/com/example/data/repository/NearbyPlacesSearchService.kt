package com.example.data.repository

import android.location.Location
import com.example.data.model.NominatimResult
import com.example.data.model.PublicPlace
import com.example.data.model.SavedPlace
import com.example.data.network.OsmApiClient
import com.example.ui.map.components.PlaceIconItem
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class DiscoveredPlaceCandidate(
    val id: String,
    val title: String,
    val address: String,
    val latitude: Double,
    val longitude: Double,
    val categoryKey: String,
    val iconId: String,
    val distanceMeters: Float,
    val isCommunityPlace: Boolean = false,
    val publicPlaceData: PublicPlace? = null
)

class NearbyPlacesSearchService(
    private val publicPlacesRepository: PublicPlacesRepository
) {
  /**
   * Search for nearest real places by category icon, combining OpenStreetMap and DRAW community places.
   */
  suspend fun findNearestPlaces(
      userLat: Double,
      userLon: Double,
      iconItem: PlaceIconItem,
      allCommunityPlaces: List<PublicPlace>,
      userSavedPlaces: List<SavedPlace>
  ): Result<List<DiscoveredPlaceCandidate>> = withContext(Dispatchers.IO) {
    try {
      // 1. Personal categories check
      if (iconItem.categoryKey == "personal") {
        val personalMatches = userSavedPlaces.filter {
          it.iconId == iconItem.id || it.category == iconItem.id.removePrefix("personal_")
        }
        if (personalMatches.isNotEmpty()) {
          val candidates = personalMatches.map { saved ->
            val dist = FloatArray(1)
            Location.distanceBetween(userLat, userLon, saved.latitude, saved.longitude, dist)
            DiscoveredPlaceCandidate(
                id = saved.id,
                title = saved.title,
                address = saved.address.ifBlank { "موقعك الشخصي المحفوظ" },
                latitude = saved.latitude,
                longitude = saved.longitude,
                categoryKey = iconItem.categoryKey,
                iconId = iconItem.id,
                distanceMeters = dist[0]
            )
          }.sortedBy { it.distanceMeters }
          return@withContext Result.success(candidates)
        } else {
          return@withContext Result.failure(
              NoSuchElementException("لم تحفظ موقع '${iconItem.nameArabic}' في حسابك بعد. يمكنك تحديده بالضغط على الخريطة ثم اختيار حفظ.")
          )
        }
      }

      val candidates = mutableListOf<DiscoveredPlaceCandidate>()

      // 2. Query DRAW community places
      val matchingCommunity = allCommunityPlaces.filter {
        it.iconId == iconItem.id || it.category == iconItem.categoryKey
      }
      for (cp in matchingCommunity) {
        val dist = FloatArray(1)
        Location.distanceBetween(userLat, userLon, cp.latitude, cp.longitude, dist)
        candidates.add(
            DiscoveredPlaceCandidate(
                id = "comm_${cp.id}",
                title = cp.title,
                address = cp.description,
                latitude = cp.latitude,
                longitude = cp.longitude,
                categoryKey = cp.category,
                iconId = cp.iconId,
                distanceMeters = dist[0],
                isCommunityPlace = true,
                publicPlaceData = cp
            )
        )
      }

      // 3. Query OpenStreetMap Nominatim with expanding bounding box
      val queryKeyword = iconItem.osmKeyword.ifBlank { iconItem.nameArabic }
      var osmResults: List<NominatimResult> = emptyList()

      // Step 1: Immediate neighborhood (~5km, delta = 0.045 deg)
      var delta = 0.045
      val viewboxStep1 = "${userLon - delta},${userLat + delta},${userLon + delta},${userLat - delta}"
      try {
        osmResults = OsmApiClient.apiService.searchPlacesNear(
            query = queryKeyword,
            viewbox = viewboxStep1,
            bounded = 1,
            limit = 10
        )
      } catch (e: Exception) {
        // Fallback to general query if viewbox fails
        try {
          osmResults = OsmApiClient.apiService.searchPlaces(query = "$queryKeyword", limit = 10)
        } catch (_: Exception) {}
      }

      // Step 2: Expanded radius (~15-20km, delta = 0.15 deg) if no results found
      if (osmResults.isEmpty()) {
        delta = 0.15
        val viewboxStep2 = "${userLon - delta},${userLat + delta},${userLon + delta},${userLat - delta}"
        try {
          osmResults = OsmApiClient.apiService.searchPlacesNear(
              query = queryKeyword,
              viewbox = viewboxStep2,
              bounded = 0,
              limit = 10
          )
        } catch (_: Exception) {}
      }

      for (osm in osmResults) {
        val dist = FloatArray(1)
        Location.distanceBetween(userLat, userLon, osm.latitude, osm.longitude, dist)
        candidates.add(
            DiscoveredPlaceCandidate(
                id = "osm_${osm.placeId}",
                title = osm.shortTitle,
                address = osm.displayName,
                latitude = osm.latitude,
                longitude = osm.longitude,
                categoryKey = iconItem.categoryKey,
                iconId = iconItem.id,
                distanceMeters = dist[0]
            )
        )
      }

      // 4. Deduplicate (places within 30m) & sort ascending by distance
      val uniqueCandidates = mutableListOf<DiscoveredPlaceCandidate>()
      val sorted = candidates.sortedBy { it.distanceMeters }

      for (cand in sorted) {
        val isDuplicate = uniqueCandidates.any { existing ->
          val dist = FloatArray(1)
          Location.distanceBetween(cand.latitude, cand.longitude, existing.latitude, existing.longitude, dist)
          dist[0] < 35f
        }
        if (!isDuplicate) {
          uniqueCandidates.add(cand)
        }
      }

      if (uniqueCandidates.isNotEmpty()) {
        Result.success(uniqueCandidates)
      } else {
        Result.failure(
            NoSuchElementException("لم يتم العثور على أي مكان ينتمي إلى فئة '${iconItem.nameArabic}' بالقرب من موقعك الحالي.")
        )
      }
    } catch (e: Exception) {
      Result.failure(e)
    }
  }

  /**
   * Automatically discovers prominent known POIs (mosques, stations, hospitals, restaurants, hotels, etc.)
   * in the visible viewport for OpenFreeMap rendering, cleanly categorized into DRAW's 60 icons.
   */
  suspend fun fetchViewportKnownPlaces(
      minLat: Double,
      maxLat: Double,
      minLng: Double,
      maxLng: Double
  ): List<DiscoveredPlaceCandidate> = withContext(Dispatchers.IO) {
    val results = mutableListOf<DiscoveredPlaceCandidate>()
    val viewbox = "$minLng,$maxLat,$maxLng,$minLat"

    // Primary prominent navigation landmark types requested
    val queryCategories = listOf(
        Pair("مسجد", "tour_mosque" to "tourism"),
        Pair("مستشفى", "health_hospital" to "health"),
        Pair("محطة قطار", "trans_train" to "transport"),
        Pair("مطار", "trans_flight" to "transport"),
        Pair("مطعم", "food_restaurant" to "food"),
        Pair("فندق", "personal_hotel" to "personal"),
        Pair("صيدلية", "health_pharmacy" to "health"),
        Pair("محطة وقود", "trans_fuel" to "transport"),
        Pair("مقهى", "food_cafe" to "food")
    )

    for ((keyword, mapping) in queryCategories) {
      try {
        val pois = OsmApiClient.apiService.searchPlacesNear(
            query = keyword,
            viewbox = viewbox,
            bounded = 1,
            limit = 3
        )
        for (p in pois) {
          results.add(
              DiscoveredPlaceCandidate(
                  id = "known_${p.placeId}",
                  title = p.shortTitle,
                  address = p.displayName,
                  latitude = p.latitude,
                  longitude = p.longitude,
                  categoryKey = mapping.second,
                  iconId = mapping.first,
                  distanceMeters = 0f
              )
          )
        }
      } catch (_: Exception) {}
    }

    // Deduplicate within close proximity
    val unique = mutableListOf<DiscoveredPlaceCandidate>()
    for (r in results) {
      val exists = unique.any {
        Math.abs(it.latitude - r.latitude) < 0.0003 && Math.abs(it.longitude - r.longitude) < 0.0003
      }
      if (!exists) unique.add(r)
    }
    unique
  }
}

