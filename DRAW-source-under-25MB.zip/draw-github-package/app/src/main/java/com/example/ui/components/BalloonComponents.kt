package com.example.ui.components

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DrawBorderLight
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawSurfaceLight
import com.example.ui.theme.DrawTextMuted
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import com.example.ui.theme.DrawWhite

/**
 * Inflated 3D balloon-styled primary button inspired by the DRAW logo.
 */
@Composable
fun BalloonButton(
    text: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
    isLoading: Boolean = false,
    backgroundColor: Color = DrawRed,
    contentColor: Color = DrawWhite,
    testTag: String = "balloon_button",
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by animateFloatAsState(
      targetValue = if (isPressed) 0.96f else 1.0f,
      animationSpec = tween(durationMillis = 120),
      label = "button_scale",
  )

  Surface(
      onClick = onClick,
      enabled = enabled && !isLoading,
      shape = RoundedCornerShape(22.dp),
      color = if (enabled) backgroundColor else backgroundColor.copy(alpha = 0.5f),
      contentColor = contentColor,
      shadowElevation = if (isPressed) 2.dp else 6.dp,
      interactionSource = interactionSource,
      modifier =
          modifier
              .fillMaxWidth()
              .height(54.dp)
              .graphicsLayer {
                scaleX = scale
                scaleY = scale
              }
              .testTag(testTag),
  ) {
    Box(
        contentAlignment = Alignment.Center,
        modifier =
            Modifier
                .background(
                    Brush.verticalGradient(
                        colors =
                            listOf(
                                backgroundColor,
                                backgroundColor.copy(alpha = 0.95f),
                                DrawDarkRed.copy(alpha = 0.85f),
                            )
                    )
                )
                .padding(horizontal = 24.dp),
    ) {
      if (isLoading) {
        CircularProgressIndicator(
            color = contentColor,
            strokeWidth = 2.5.dp,
            modifier = Modifier.size(24.dp),
        )
      } else {
        Text(
            text = text,
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = contentColor,
            textAlign = TextAlign.Center,
        )
      }
    }
  }
}

/**
 * Friendly rounded input field with soft surface, clear error states, and optional icons.
 */
@Composable
fun BalloonTextField(
    value: String,
    onValueChange: (String) -> Unit,
    label: String,
    modifier: Modifier = Modifier,
    placeholder: String = "",
    errorMessage: String? = null,
    isError: Boolean = errorMessage != null,
    leadingIcon: ImageVector? = null,
    trailingIcon: @Composable (() -> Unit)? = null,
    visualTransformation: VisualTransformation = VisualTransformation.None,
    keyboardOptions: KeyboardOptions = KeyboardOptions.Default,
    keyboardActions: KeyboardActions = KeyboardActions.Default,
    singleLine: Boolean = true,
    testTag: String = "balloon_text_field",
) {
  Column(modifier = modifier.fillMaxWidth()) {
    Text(
        text = label,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = DrawTextSecondary,
        modifier = Modifier.padding(start = 4.dp, bottom = 6.dp),
    )

    OutlinedTextField(
        value = value,
        onValueChange = onValueChange,
        placeholder = {
          Text(
              text = placeholder,
              color = DrawTextMuted,
              fontSize = 15.sp,
          )
        },
        leadingIcon =
            leadingIcon?.let {
              {
                Icon(
                    imageVector = it,
                    contentDescription = null,
                    tint = if (isError) DrawRed else DrawTextSecondary,
                    modifier = Modifier.size(20.dp),
                )
              }
            },
        trailingIcon = trailingIcon,
        isError = isError,
        visualTransformation = visualTransformation,
        keyboardOptions = keyboardOptions,
        keyboardActions = keyboardActions,
        singleLine = singleLine,
        shape = RoundedCornerShape(16.dp),
        colors =
            OutlinedTextFieldDefaults.colors(
                focusedContainerColor = DrawWhite,
                unfocusedContainerColor = DrawSurfaceLight,
                errorContainerColor = DrawSurfaceLight,
                focusedBorderColor = DrawRed,
                unfocusedBorderColor = DrawBorderLight,
                errorBorderColor = DrawRed,
                focusedTextColor = DrawTextNearBlack,
                unfocusedTextColor = DrawTextNearBlack,
                cursorColor = DrawRed,
            ),
        modifier =
            Modifier
                .fillMaxWidth()
                .testTag(testTag),
    )

    if (errorMessage != null) {
      Text(
          text = errorMessage,
          color = DrawRed,
          fontSize = 12.sp,
          fontWeight = FontWeight.Medium,
          modifier =
              Modifier
                  .padding(start = 6.dp, top = 4.dp)
                  .testTag("${testTag}_error"),
      )
    }
  }
}

/**
 * Horizontal provider button (Guest, Google, Apple) with 3D tactile depth.
 */
@Composable
fun ProviderSignInCard(
    label: String = "",
    icon: @Composable () -> Unit,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String,
) {
  val interactionSource = remember { MutableInteractionSource() }
  val isPressed by interactionSource.collectIsPressedAsState()
  val scale by animateFloatAsState(
      targetValue = if (isPressed) 0.94f else 1.0f,
      animationSpec = tween(durationMillis = 100),
      label = "provider_scale",
  )

  Surface(
      onClick = onClick,
      shape = RoundedCornerShape(18.dp),
      color = DrawWhite,
      border = BorderStroke(1.dp, DrawBorderLight),
      shadowElevation = if (isPressed) 1.dp else 4.dp,
      interactionSource = interactionSource,
      modifier =
          modifier
              .height(52.dp)
              .graphicsLayer {
                scaleX = scale
                scaleY = scale
              }
              .testTag(testTag),
  ) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.Center,
        modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
    ) {
      icon()
      if (label.isNotBlank()) {
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = label,
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = DrawTextNearBlack,
        )
      }
    }
  }
}

/**
 * Top brand header displaying the DRAW 3D balloon logo and a welcoming title.
 */
@Composable
fun DrawBrandHeader(
    title: String,
    subtitle: String,
    modifier: Modifier = Modifier,
    logoSize: Dp = 88.dp,
) {
  Column(
      horizontalAlignment = Alignment.CenterHorizontally,
      modifier = modifier.fillMaxWidth(),
  ) {
    // 3D Balloon Logo with soft shadow
    Box(
        contentAlignment = Alignment.Center,
        modifier =
            Modifier
                .size(logoSize)
                .shadow(elevation = 12.dp, shape = RoundedCornerShape(26.dp), clip = false)
                .clip(RoundedCornerShape(26.dp))
                .background(DrawRed),
    ) {
      Image(
          painter = painterResource(id = R.drawable.draw_symbol),
          contentDescription = stringResource(id = R.string.draw_logo_description),
          contentScale = ContentScale.Fit,
          modifier =
              Modifier
                  .size(logoSize)
                  .testTag("draw_brand_header_logo"),
      )
    }

    Spacer(modifier = Modifier.height(18.dp))

    Text(
        text = title,
        fontSize = 24.sp,
        fontWeight = FontWeight.ExtraBold,
        color = DrawTextNearBlack,
        textAlign = TextAlign.Center,
    )

    Spacer(modifier = Modifier.height(4.dp))

    Text(
        text = subtitle,
        fontSize = 14.sp,
        color = DrawTextSecondary,
        textAlign = TextAlign.Center,
    )
  }
}

/**
 * 3D inflated container surface with soft shadow and rounded corners.
 */
@Composable
fun BalloonCard(
    modifier: Modifier = Modifier,
    backgroundColor: Color = DrawWhite,
    cornerRadius: Dp = 24.dp,
    elevation: Dp = 8.dp,
    content: @Composable () -> Unit
) {
  Surface(
      shape = RoundedCornerShape(cornerRadius),
      color = backgroundColor,
      shadowElevation = elevation,
      modifier = modifier
  ) {
    content()
  }
}
