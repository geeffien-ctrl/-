package com.example.ui.settings

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.DrawBrand
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@Composable
fun ProfileSubScreen(
    uiState: SettingsUiState,
    onSaveDisplayName: (String) -> Unit,
    onUploadPhoto: (Uri) -> Unit = {},
    onUpdateEmail: (String, String) -> Unit = { _, _ -> },
    onUpdatePassword: (String, String) -> Unit = { _, _ -> },
    modifier: Modifier = Modifier,
) {
  val initialName = uiState.userProfile?.displayName
      ?: uiState.firebaseUser?.displayName
      ?: uiState.firebaseUser?.email?.substringBefore("@")
      ?: ""

  var displayNameInput by remember(initialName) { mutableStateOf(initialName) }
  var isFullScreenPhotoVisible by remember { mutableStateOf(false) }

  // Email & Password update dialog state for Password users
  var isChangeEmailDialogVisible by remember { mutableStateOf(false) }
  var newEmailInput by remember { mutableStateOf("") }
  var emailCurrentPasswordInput by remember { mutableStateOf("") }

  var isChangePasswordDialogVisible by remember { mutableStateOf(false) }
  var currentPasswordInput by remember { mutableStateOf("") }
  var newPasswordInput by remember { mutableStateOf("") }

  val cardShape = RoundedCornerShape(22.dp)
  val currentPhotoUrl = DrawBrand.AVATAR_URI

  Column(
      modifier = modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 16.dp),
      horizontalAlignment = Alignment.CenterHorizontally,
  ) {
    // 1. Interactive Profile Avatar Badge
    Box(
        modifier = Modifier
            .size(96.dp)
            .clip(CircleShape)
            .background(Color(0xFFFFECEB))
            .border(2.5.dp, DrawRed.copy(alpha = 0.35f), CircleShape)
            .testTag("profile_avatar_badge"),
        contentAlignment = Alignment.Center,
    ) {
      if (!currentPhotoUrl.isNullOrBlank()) {
        AsyncImage(
            model = currentPhotoUrl,
            contentDescription = "الصورة الشخصية",
            contentScale = ContentScale.Crop,
            modifier = Modifier.fillMaxSize(),
        )
      } else {
        val firstLetter = initialName.firstOrNull()?.uppercaseChar()?.toString()
        if (!firstLetter.isNullOrBlank()) {
          Text(
              text = firstLetter,
              fontSize = 38.sp,
              fontWeight = FontWeight.Bold,
              color = DrawRed,
          )
        } else {
          Icon(
              imageVector = Icons.Default.AccountCircle,
              contentDescription = null,
              tint = DrawRed,
              modifier = Modifier.size(54.dp),
          )
        }
      }

    }

    Spacer(modifier = Modifier.height(10.dp))

    Text(
        text = initialName.ifEmpty { "مستخدم DRAW" },
        fontSize = 20.sp,
        fontWeight = FontWeight.Bold,
        color = DrawTextNearBlack,
    )

    Text(
        text = uiState.firebaseUser?.email ?: "حساب مسجل",
        fontSize = 13.sp,
        color = DrawTextSecondary,
    )

    Spacer(modifier = Modifier.height(20.dp))

    // 2. Profile Details Edit Card
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, cardShape, spotColor = Color(0x18000000))
            .border(0.8.dp, Color(0x14000000), cardShape),
        shape = cardShape,
        color = Color.White,
    ) {
      Column(
          modifier = Modifier
              .fillMaxWidth()
              .padding(20.dp),
      ) {
        Text(
            text = "تعديل البيانات الشخصية",
            fontSize = 16.sp,
            fontWeight = FontWeight.Bold,
            color = DrawTextNearBlack,
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Display Name input
        Text(
            text = "اسم العرض",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = DrawTextSecondary,
        )

        Spacer(modifier = Modifier.height(6.dp))

        OutlinedTextField(
            value = displayNameInput,
            onValueChange = { displayNameInput = it },
            singleLine = true,
            leadingIcon = {
              Icon(
                  imageVector = Icons.Default.Person,
                  contentDescription = null,
                  tint = DrawRed,
              )
            },
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color.Black,
                unfocusedTextColor = Color.Black,
                focusedBorderColor = DrawRed,
                unfocusedBorderColor = Color(0x33000000),
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
            ),
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .testTag("profile_display_name_input"),
        )

        Spacer(modifier = Modifier.height(18.dp))

        // Email section
        Text(
            text = "البريد الإلكتروني",
            fontSize = 13.sp,
            fontWeight = FontWeight.Medium,
            color = DrawTextSecondary,
        )

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
        ) {
          OutlinedTextField(
              value = uiState.firebaseUser?.email ?: "غير متوفر",
              onValueChange = {},
              readOnly = true,
              singleLine = true,
              leadingIcon = {
                Icon(
                    imageVector = Icons.Default.Email,
                    contentDescription = null,
                    tint = Color(0xFF8E8E93),
                )
              },
              colors = OutlinedTextFieldDefaults.colors(
                  focusedTextColor = Color.Black,
                  unfocusedTextColor = Color.Black,
                  focusedBorderColor = Color(0x33000000),
                  unfocusedBorderColor = Color(0x22000000),
                  focusedContainerColor = Color.White,
                  unfocusedContainerColor = Color.White,
              ),
              shape = RoundedCornerShape(14.dp),
              modifier = Modifier.weight(1f),
          )

          if (uiState.isPasswordUser) {
            Spacer(modifier = Modifier.width(8.dp))
            OutlinedButton(
                onClick = { isChangeEmailDialogVisible = true },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = DrawRed),
            ) {
              Text("تعديل", fontSize = 12.sp)
            }
          }
        }

        // Provider Badge
        if (uiState.isGoogleUser || uiState.isAppleUser) {
          Spacer(modifier = Modifier.height(10.dp))
          Row(
              modifier = Modifier
                  .fillMaxWidth()
                  .background(Color(0xFFF2F2F7), RoundedCornerShape(10.dp))
                  .padding(horizontal = 10.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
          ) {
            Icon(
                imageVector = Icons.Default.Security,
                contentDescription = null,
                tint = Color(0xFF007AFF),
                modifier = Modifier.size(16.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "حسابك موثق عبر ${if (uiState.isGoogleUser) "Google" else "Apple"}، وتتم إدارة كلمة المرور والبريد من حسابك مباشرة.",
                fontSize = 11.5.sp,
                color = DrawTextSecondary,
                lineHeight = 16.sp,
            )
          }
        }

        // Change Password Option for Password Accounts
        if (uiState.isPasswordUser) {
          Spacer(modifier = Modifier.height(18.dp))
          HorizontalDivider(color = Color(0x10000000), thickness = 0.8.dp)
          Spacer(modifier = Modifier.height(14.dp))

          OutlinedButton(
              onClick = { isChangePasswordDialogVisible = true },
              shape = RoundedCornerShape(14.dp),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = DrawTextNearBlack),
              modifier = Modifier.fillMaxWidth(),
          ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = null,
                tint = DrawRed,
                modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("تغيير كلمة المرور", fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
          }
        }

        Spacer(modifier = Modifier.height(24.dp))

        // Save Button (Red background with clean pure white text)
        Button(
            onClick = { onSaveDisplayName(displayNameInput) },
            enabled = !uiState.isSavingProfile && displayNameInput.trim().isNotEmpty(),
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = DrawRed,
                contentColor = Color.White,
                disabledContainerColor = DrawRed.copy(alpha = 0.5f),
                disabledContentColor = Color.White.copy(alpha = 0.7f),
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(48.dp)
                .testTag("profile_save_button"),
        ) {
          if (uiState.isSavingProfile) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 2.dp,
                modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("جاري الحفظ...", fontWeight = FontWeight.Bold, color = Color.White)
          } else {
            Icon(
                imageVector = Icons.Default.Check,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(18.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text("حفظ التغييرات في الحساب", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color.White)
          }
        }
      }
    }
  }

  // --- Full Screen Avatar Preview Dialog ---
  if (isFullScreenPhotoVisible && !currentPhotoUrl.isNullOrBlank()) {
    Dialog(
        onDismissRequest = { isFullScreenPhotoVisible = false },
        properties = DialogProperties(usePlatformDefaultWidth = false),
    ) {
      Box(
          modifier = Modifier
              .fillMaxSize()
              .background(Color(0xF0000000)),
      ) {
        AsyncImage(
            model = currentPhotoUrl,
            contentDescription = "الصورة الكاملة",
            contentScale = ContentScale.Fit,
            modifier = Modifier
                .fillMaxSize()
                .padding(24.dp),
        )

        IconButton(
            onClick = { isFullScreenPhotoVisible = false },
            modifier = Modifier
                .align(Alignment.TopEnd)
                .padding(top = 44.dp, end = 20.dp)
                .background(Color(0x66FFFFFF), CircleShape),
        ) {
          Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "إغلاق",
              tint = Color.White,
          )
        }
      }
    }
  }

  // --- Change Email Dialog (Password Users) ---
  if (isChangeEmailDialogVisible) {
    AlertDialog(
        onDismissRequest = { isChangeEmailDialogVisible = false },
        title = { Text("تعديل البريد الإلكتروني", fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("أدخل البريد الإلكتروني الجديد وكلمة المرور الحالية لتأكيد التعديل:", fontSize = 13.sp)
            OutlinedTextField(
                value = newEmailInput,
                onValueChange = { newEmailInput = it },
                label = { Text("البريد الإلكتروني الجديد") },
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Email),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = emailCurrentPasswordInput,
                onValueChange = { emailCurrentPasswordInput = it },
                label = { Text("كلمة المرور الحالية") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
          }
        },
        confirmButton = {
          Button(
              onClick = {
                onUpdateEmail(newEmailInput, emailCurrentPasswordInput)
                isChangeEmailDialogVisible = false
                newEmailInput = ""
                emailCurrentPasswordInput = ""
              },
              colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
          ) {
            Text("إرسال رابط التأكيد")
          }
        },
        dismissButton = {
          TextButton(onClick = { isChangeEmailDialogVisible = false }) {
            Text("إلغاء", color = DrawTextNearBlack)
          }
        },
        shape = RoundedCornerShape(20.dp),
    )
  }

  // --- Change Password Dialog (Password Users) ---
  if (isChangePasswordDialogVisible) {
    AlertDialog(
        onDismissRequest = { isChangePasswordDialogVisible = false },
        title = { Text("تغيير كلمة المرور", fontWeight = FontWeight.Bold) },
        text = {
          Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Text("أدخل كلمة المرور الحالية وكلمة المرور الجديدة:", fontSize = 13.sp)
            OutlinedTextField(
                value = currentPasswordInput,
                onValueChange = { currentPasswordInput = it },
                label = { Text("كلمة المرور الحالية") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
            OutlinedTextField(
                value = newPasswordInput,
                onValueChange = { newPasswordInput = it },
                label = { Text("كلمة المرور الجديدة (6 أحرف فأكثر)") },
                visualTransformation = PasswordVisualTransformation(),
                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                singleLine = true,
                modifier = Modifier.fillMaxWidth(),
            )
          }
        },
        confirmButton = {
          Button(
              onClick = {
                onUpdatePassword(currentPasswordInput, newPasswordInput)
                isChangePasswordDialogVisible = false
                currentPasswordInput = ""
                newPasswordInput = ""
              },
              colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
          ) {
            Text("تغيير كلمة المرور")
          }
        },
        dismissButton = {
          TextButton(onClick = { isChangePasswordDialogVisible = false }) {
            Text("إلغاء", color = DrawTextNearBlack)
          }
        },
        shape = RoundedCornerShape(20.dp),
    )
  }
}
