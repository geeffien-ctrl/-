package com.example.data.model

/**
 * Model representing a user comment on a DRAW public place post.
 */
data class PlaceComment(
    val id: String = "",
    val placeId: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhotoUrl: String = "",
    val text: String = "",
    val likesCount: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
) {
    val likesCountInt: Int get() = likesCount.toInt()
}
