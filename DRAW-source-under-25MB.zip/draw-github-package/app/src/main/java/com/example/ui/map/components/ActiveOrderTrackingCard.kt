package com.example.ui.map.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Cancel
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Send
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OrderStatus
import com.example.data.model.ServiceOrder
import com.example.ui.theme.DrawGreen
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@Composable
fun ActiveOrderTrackingCard(
    order: ServiceOrder?,
    currentUserId: String,
    onAdvanceStatus: (ServiceOrder, OrderStatus) -> Unit,
    onCancelOrder: (ServiceOrder) -> Unit,
    onDismissCard: () -> Unit,
    onSubmitReview: ((order: ServiceOrder, liked: Boolean, comment: String?) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    var hasLiked by remember(order?.id) { mutableStateOf(order?.passengerLiked == true) }
    var reviewComment by remember(order?.id) { mutableStateOf(order?.passengerComment ?: "") }
    var reviewSubmitted by remember(order?.id) { mutableStateOf(order?.passengerLiked != null) }

    AnimatedVisibility(
        visible = order != null,
        enter = slideInVertically(initialOffsetY = { it }) + fadeIn(),
        exit = slideOutVertically(targetOffsetY = { it }) + fadeOut(),
        modifier = modifier,
    ) {
        if (order != null) {
            val driverUid = order.effectiveDriverId
            val isDriver = driverUid == currentUserId
            val isFinalState = order.status == OrderStatus.COMPLETED ||
                order.status == OrderStatus.REJECTED ||
                order.status == OrderStatus.CANCELLED

            val statusTitle = when (order.status) {
                OrderStatus.WAITING_APPROVAL -> if (isDriver) "طلب تاكسي جديد بانتظار موافقتك" else "بانتظار موافقة السائق..."
                OrderStatus.ACCEPTED -> if (isDriver) "قبلت الطلب! توجه للراكب" else "تم قبول طلبك! السائق يستعد للتحرك"
                OrderStatus.DRIVER_EN_ROUTE -> if (isDriver) "أنت في الطريق للراكب" else "السائق في الطريق إليك الآن"
                OrderStatus.ARRIVED -> if (isDriver) "وصلت لموقع الراكب" else "وصل السائق إلى موقعك!"
                OrderStatus.IN_PROGRESS -> "الرحلة جارية نحو الوجهة المطلوبة"
                OrderStatus.COMPLETED -> "اكتمل المشوار بنجاح!"
                OrderStatus.REJECTED -> "عذراً، اعتذر السائق عن المشوار"
                OrderStatus.CANCELLED -> "تم إلغاء الطلب"
            }

            val statusColor = when (order.status) {
                OrderStatus.WAITING_APPROVAL -> Color(0xFFFB8C00)
                OrderStatus.ACCEPTED, OrderStatus.DRIVER_EN_ROUTE -> Color(0xFF1976D2)
                OrderStatus.ARRIVED, OrderStatus.IN_PROGRESS -> DrawGreen
                OrderStatus.COMPLETED -> DrawGreen
                OrderStatus.REJECTED, OrderStatus.CANCELLED -> DrawRed
            }

            Surface(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 8.dp)
                    .shadow(6.dp, RoundedCornerShape(22.dp), spotColor = Color(0x24000000))
                    .border(1.dp, Color(0x18000000), RoundedCornerShape(22.dp))
                    .testTag("active_order_tracking_card"),
                shape = RoundedCornerShape(22.dp),
                color = Color.White,
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                ) {
                    // Status Header Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween,
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(34.dp)
                                    .clip(CircleShape)
                                    .background(statusColor.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center,
                            ) {
                                if (order.status == OrderStatus.WAITING_APPROVAL) {
                                    CircularProgressIndicator(
                                        color = statusColor,
                                        strokeWidth = 2.dp,
                                        modifier = Modifier.size(16.dp),
                                    )
                                } else if (order.status == OrderStatus.COMPLETED) {
                                    Icon(
                                        imageVector = Icons.Default.CheckCircle,
                                        contentDescription = null,
                                        tint = statusColor,
                                        modifier = Modifier.size(20.dp),
                                    )
                                } else {
                                    Icon(
                                        imageVector = Icons.Default.LocalTaxi,
                                        contentDescription = null,
                                        tint = statusColor,
                                        modifier = Modifier.size(18.dp),
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.width(10.dp))

                            Column {
                                Text(
                                    text = statusTitle,
                                    fontSize = 14.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DrawTextNearBlack,
                                )
                                Text(
                                    text = if (isDriver) "الراكب: ${order.effectiveCustomerName.ifBlank { "راكب DRAW" }}"
                                    else "السائق: ${order.driverName.ifBlank { "سائق DRAW" }} • ${order.taxiCarModel.ifBlank { "تاكسي" }}",
                                    fontSize = 12.sp,
                                    color = DrawTextSecondary,
                                )
                            }
                        }

                        // Estimated Fare Chip
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = Color(0xFFECFDF5),
                            border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0xFFA7F3D0))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Payments, contentDescription = null, tint = DrawGreen, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (order.estimatedFare > 0) order.formattedEstimatedFare else if (order.farePerKm > 0.0) "${order.farePerKm.toInt()} لكل كم" else "السعر غير محدد",
                                    fontSize = 11.5.sp,
                                    color = Color(0xFF047857),
                                    fontWeight = FontWeight.Bold,
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // Post-trip Review Section for Passenger
                    if (order.status == OrderStatus.COMPLETED && !isDriver) {
                        Surface(
                            shape = RoundedCornerShape(14.dp),
                            color = Color(0xFFF9FAFB),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x14000000)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "تقييم المشوار مع السائق",
                                    fontSize = 13.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DrawTextNearBlack
                                )
                                Spacer(modifier = Modifier.height(8.dp))

                                if (reviewSubmitted) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = DrawGreen, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "شكراً لتقييمك! تم توثيق رحلتك ودعم السائق.",
                                            fontSize = 12.sp,
                                            color = DrawGreen,
                                            fontWeight = FontWeight.Medium
                                        )
                                    }
                                } else {
                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                                    ) {
                                        Surface(
                                            onClick = { hasLiked = true },
                                            shape = RoundedCornerShape(10.dp),
                                            color = if (hasLiked) Color(0xFFDBEAFE) else Color.White,
                                            border = androidx.compose.foundation.BorderStroke(
                                                width = if (hasLiked) 1.5.dp else 1.dp,
                                                color = if (hasLiked) Color(0xFF2563EB) else Color(0x20000000)
                                            ),
                                            modifier = Modifier.weight(1f)
                                        ) {
                                            Row(
                                                modifier = Modifier.padding(vertical = 8.dp),
                                                horizontalArrangement = Arrangement.Center,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Icon(
                                                    Icons.Default.ThumbUp,
                                                    contentDescription = null,
                                                    tint = if (hasLiked) Color(0xFF1D4ED8) else Color(0xFF6B7280),
                                                    modifier = Modifier.size(16.dp)
                                                )
                                                Spacer(modifier = Modifier.width(6.dp))
                                                Text(
                                                    text = "إعجاب بالخدمة",
                                                    fontSize = 12.sp,
                                                    fontWeight = if (hasLiked) FontWeight.Bold else FontWeight.Normal,
                                                    color = if (hasLiked) Color(0xFF1D4ED8) else DrawTextNearBlack
                                                )
                                            }
                                        }
                                    }

                                    Spacer(modifier = Modifier.height(8.dp))

                                    OutlinedTextField(
                                        value = reviewComment,
                                        onValueChange = { reviewComment = it },
                                        placeholder = { Text("تعليق اختياري عن المشوار...", fontSize = 12.sp) },
                                        singleLine = true,
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth(),
                                        colors = OutlinedTextFieldDefaults.colors(
                                            focusedBorderColor = DrawGreen,
                                            unfocusedBorderColor = Color(0x20000000)
                                        )
                                    )

                                    Spacer(modifier = Modifier.height(10.dp))

                                    Button(
                                        onClick = {
                                            reviewSubmitted = true
                                            onSubmitReview?.invoke(order, hasLiked, reviewComment.ifBlank { null })
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = DrawGreen),
                                        shape = RoundedCornerShape(10.dp),
                                        modifier = Modifier.fillMaxWidth().height(42.dp)
                                    ) {
                                        Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(15.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("إرسال التقييم", fontSize = 13.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                    }

                    // Driver Controls / Customer Controls
                    if (isDriver && !isFinalState) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(10.dp),
                        ) {
                            when (order.status) {
                                OrderStatus.ACCEPTED -> {
                                    Button(
                                        onClick = { onAdvanceStatus(order, OrderStatus.DRIVER_EN_ROUTE) },
                                        colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f).height(46.dp).testTag("driver_start_route_button"),
                                    ) {
                                        Text("بدء التوجه للراكب", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                    }
                                }
                                OrderStatus.DRIVER_EN_ROUTE -> {
                                    Button(
                                        onClick = { onAdvanceStatus(order, OrderStatus.ARRIVED) },
                                        colors = ButtonDefaults.buttonColors(containerColor = DrawGreen),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f).height(46.dp).testTag("driver_arrived_button"),
                                    ) {
                                        Text("وصلت لموقع الراكب", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                    }
                                }
                                OrderStatus.ARRIVED -> {
                                    Button(
                                        onClick = { onAdvanceStatus(order, OrderStatus.IN_PROGRESS) },
                                        colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f).height(46.dp).testTag("driver_start_trip_button"),
                                    ) {
                                        Text("بدء المشوار", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                    }
                                }
                                OrderStatus.IN_PROGRESS -> {
                                    Button(
                                        onClick = { onAdvanceStatus(order, OrderStatus.COMPLETED) },
                                        colors = ButtonDefaults.buttonColors(containerColor = DrawGreen),
                                        shape = RoundedCornerShape(12.dp),
                                        modifier = Modifier.weight(1f).height(46.dp).testTag("driver_complete_trip_button"),
                                    ) {
                                        Text("إنهاء المشوار بنجاح", fontWeight = FontWeight.Bold, fontSize = 13.5.sp)
                                    }
                                }
                                else -> Unit
                            }

                            OutlinedButton(
                                onClick = { onCancelOrder(order) },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.height(46.dp).testTag("driver_cancel_order_button"),
                            ) {
                                Text("إلغاء", color = Color(0xFF8E8E93), fontSize = 12.5.sp)
                            }
                        }
                    } else if (!isFinalState) {
                        // Customer actions
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                        ) {
                            OutlinedButton(
                                onClick = { onCancelOrder(order) },
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier.height(42.dp).testTag("customer_cancel_order_button"),
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Cancel,
                                    contentDescription = null,
                                    tint = DrawRed,
                                    modifier = Modifier.size(16.dp),
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("إلغاء الطلب", color = DrawRed, fontSize = 12.5.sp, fontWeight = FontWeight.SemiBold)
                            }
                        }
                    } else {
                        // Final state: Close button
                        Button(
                            onClick = onDismissCard,
                            colors = ButtonDefaults.buttonColors(containerColor = DrawTextNearBlack),
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth().height(42.dp).testTag("dismiss_order_card_button"),
                        ) {
                            Text("إغلاق الإشعار", color = Color.White, fontSize = 13.sp)
                        }
                    }
                }
            }
        }
    }
}
