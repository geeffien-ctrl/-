package com.example.ui.map.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GpsFixed
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RoadReport
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * Verification state for GPS-based report resolution.
 */
enum class VerificationPhase {
    IDLE,
    APPROACHING, // Need to reach within 20m of the hazard
    AT_HAZARD,   // Reached hazard, now must travel 10m beyond it
    COMPLETED,
    FAILED
}

data class RoadReportVerificationSession(
    val reportId: String,
    val phase: VerificationPhase = VerificationPhase.APPROACHING,
    val distanceToHazardMeters: Float = 0.0f,
    val minDistanceToHazardReached: Float = Float.MAX_VALUE,
    val distanceTraveledBeyondMeters: Float = 0.0f,
    val requiredDistanceBeyondMeters: Float = 10.0f,
    val statusMessage: String = "جارٍ التحقق: يرجى المرور عبر موقع البلاغ لتأكيد زوال الخطر",
    val isGpsUnreliable: Boolean = false
)

/**
 * Bottom Sheet displaying details of a selected Road Report on the map.
 * Contains item 10: The Green "Road is Clear / تمت إزالة الخطر" verification action.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportDetailsBottomSheet(
    report: RoadReport,
    currentUserId: String,
    verificationSession: RoadReportVerificationSession?,
    onDismissRequest: () -> Unit,
    onStartResolution: () -> Unit,
    onCancelResolution: () -> Unit,
    onDeleteReport: (String) -> Unit = {},
    modifier: Modifier = Modifier
) {
    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        modifier = modifier.testTag("report_details_bottom_sheet"),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        containerColor = Color.White,
        dragHandle = {
            BottomSheetDefaults.DragHandle(
                color = Color(0xFFD1D1D6),
                width = 36.dp,
                height = 4.dp
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 6.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier.size(44.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        RoadReportUnifiedIcon(type = report.type, size = 38.dp)
                    }

                    Column {
                        Text(
                            text = report.type.titleArabic,
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = DrawTextNearBlack
                        )
                        Text(
                            text = report.type.titleEnglish,
                            fontSize = 12.sp,
                            color = DrawTextSecondary
                        )
                    }
                }

                IconButton(
                    onClick = onDismissRequest,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color(0xFF8E8E93)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Report Details Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color(0xFFF9F9F9)),
                elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (report.description.isNotBlank()) {
                        Text(
                            text = "الملاحظات: ${report.description}",
                            fontSize = 13.5.sp,
                            color = DrawTextNearBlack,
                            fontWeight = FontWeight.Medium
                        )
                    }

                    if (report.type.legalSafetyNotice.isNotBlank()) {
                        Surface(
                            color = report.type.composeColor.copy(alpha = 0.08f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, report.type.composeColor.copy(alpha = 0.25f))
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = report.type.composeColor,
                                    modifier = Modifier.size(16.dp)
                                )
                                Text(
                                    text = report.type.legalSafetyNotice,
                                    fontSize = 11.5.sp,
                                    color = DrawTextNearBlack,
                                    fontWeight = FontWeight.Medium
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "المبلّغ: ${if (report.creatorName.isNotBlank()) report.creatorName else "سائق في مجتمع DRAW"}",
                            fontSize = 12.sp,
                            color = DrawTextSecondary
                        )

                        val isConfirmed = report.isConfirmed || report.confirmationsCount >= 3
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (isConfirmed) Color(0xFFDCFCE7) else Color(0xFFFEF3C7)
                        ) {
                            Text(
                                text = if (isConfirmed) "بلاغ مؤكّد (${report.confirmationsCount})" else "بلاغ مستخدم (غير مؤكّد)",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isConfirmed) Color(0xFF15803D) else Color(0xFFB45309),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            val isOwner = currentUserId.isNotBlank() && report.creatorId.isNotBlank() && report.creatorId == currentUserId
            var showDeleteConfirmationDialog by remember { mutableStateOf(false) }

            if (showDeleteConfirmationDialog) {
                AlertDialog(
                    onDismissRequest = { showDeleteConfirmationDialog = false },
                    title = {
                        Text(
                            text = "حذف البلاغ",
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )
                    },
                    text = {
                        Text(
                            text = "هل أنت متأكد من حذف هذا البلاغ نهائياً من الخريطة؟ لن يتمكن السائقون الآخرون من رؤيته.",
                            fontSize = 14.sp,
                            color = DrawTextNearBlack
                        )
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                showDeleteConfirmationDialog = false
                                onDeleteReport(report.id)
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFDC2626)),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Text("نعم، احذف البلاغ", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { showDeleteConfirmationDialog = false }) {
                            Text("إلغاء", color = Color(0xFF6B7280))
                        }
                    },
                    containerColor = Color.White,
                    shape = RoundedCornerShape(20.dp)
                )
            }

            // Owner explicit Delete Button
            if (isOwner) {
                Button(
                    onClick = { showDeleteConfirmationDialog = true },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(48.dp)
                        .testTag("delete_my_report_button"),
                    shape = RoundedCornerShape(14.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFFFEE2E2),
                        contentColor = Color(0xFFDC2626)
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 0.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "حذف",
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(18.dp)
                        )
                        Text(
                            text = "حذف بلاغي من الخريطة",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFFDC2626)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Item 10: "Road is Clear / تمت إزالة الخطر" Action & Verification UI
            val isResolving = verificationSession != null && verificationSession.reportId == report.id

            if (!isResolving) {
                // Initial Green Button
                Button(
                    onClick = onStartResolution,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("road_is_clear_button"),
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = Color(0xFF16A34A) // Green (#16A34A)
                    ),
                    elevation = ButtonDefaults.buttonElevation(defaultElevation = 3.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                        Text(
                            text = "تمت إزالة الخطر / Road is Clear",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "يتطلب التحقق عبر نظام GPS المرور بموقع البلاغ وتجاوزه بـ 10 أمتار",
                    fontSize = 11.sp,
                    color = DrawTextSecondary,
                    textAlign = TextAlign.Center
                )
            } else {
                // Active GPS Verification Panel
                val session = verificationSession!!
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .border(1.5.dp, Color(0xFF16A34A).copy(alpha = 0.5f), RoundedCornerShape(16.dp)),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFF0FDF4))
                ) {
                    Column(
                        modifier = Modifier.padding(14.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(6.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GpsFixed,
                                    contentDescription = null,
                                    tint = Color(0xFF16A34A),
                                    modifier = Modifier.size(18.dp)
                                )
                                Text(
                                    text = "التحقق الموقعي الذكي عبر GPS",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF16A34A)
                                )
                            }
                            TextButton(
                                onClick = onCancelResolution,
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text("إلغاء", fontSize = 12.sp, color = Color(0xFFDC2626))
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = session.statusMessage,
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Medium,
                            color = DrawTextNearBlack,
                            textAlign = TextAlign.Center
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Progress Indicator
                        val progress = if (session.phase == VerificationPhase.AT_HAZARD) {
                            (session.distanceTraveledBeyondMeters / session.requiredDistanceBeyondMeters).coerceIn(0f, 1f)
                        } else {
                            0f
                        }

                        LinearProgressIndicator(
                            progress = { progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = Color(0xFF16A34A),
                            trackColor = Color(0xFFDCFCE7)
                        )

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "البعد عن الخطر: ${session.distanceToHazardMeters.toInt()} م",
                                fontSize = 11.5.sp,
                                color = DrawTextSecondary
                            )
                            Text(
                                text = "المسافة بعد تجاوزه: ${session.distanceTraveledBeyondMeters.toInt()} / 10 م",
                                fontSize = 11.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF16A34A)
                            )
                        }

                        if (session.isGpsUnreliable) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "⚠️ إشارة GPS غير دقيقة حالياً، بانتظار قراءة مؤكدة...",
                                fontSize = 11.sp,
                                color = Color(0xFFB45309),
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }
    }
}
