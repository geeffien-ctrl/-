package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.CubicBezierEasing
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.size
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.repository.UserRepository
import com.example.data.util.configureAppCheck
import com.example.ui.auth.AuthScreen
import com.example.ui.auth.AuthScreenType
import com.example.ui.auth.AuthViewModel
import com.example.ui.map.MapScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTheme
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

enum class AppDestination {
  SPLASH,
  AUTH,
  MAP,
  SETTINGS,
}

class MainActivity : ComponentActivity() {
  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    configureAppCheck(this, intent)
    enableEdgeToEdge()

    // Immersive mode: clean edge-to-edge experience
    WindowCompat.setDecorFitsSystemWindows(window, false)
    val insetsController = WindowCompat.getInsetsController(window, window.decorView)
    insetsController.systemBarsBehavior =
        WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
    insetsController.hide(WindowInsetsCompat.Type.systemBars())

    setContent {
      DrawTheme {
        val context = LocalContext.current
        val userRepository = remember { UserRepository(context) }
        val sessionManager = remember { com.example.data.repository.AuthSessionManager.getInstance(context) }
        val authViewModel: AuthViewModel = viewModel { AuthViewModel(userRepository, sessionManager) }
        val uiState by authViewModel.uiState.collectAsStateWithLifecycle()

        var destination by remember { mutableStateOf(AppDestination.SPLASH) }

        // Reactively route when authentication state changes (e.g. after sign-in or logout)
        LaunchedEffect(uiState.currentUser) {
          if (destination != AppDestination.SPLASH) {
            destination =
                if (uiState.currentUser != null) AppDestination.MAP else AppDestination.AUTH
          }
        }

        Box(
            modifier =
                Modifier
                    .fillMaxSize()
                    .background(DrawRed),
        ) {
          AnimatedContent(
              targetState = destination,
              transitionSpec = {
                if (initialState == AppDestination.MAP && targetState == AppDestination.SETTINGS) {
                  (slideInHorizontally(tween(300)) { it } + fadeIn(tween(300))) togetherWith
                      (slideOutHorizontally(tween(300)) { -it } + fadeOut(tween(300)))
                } else if (initialState == AppDestination.SETTINGS && targetState == AppDestination.MAP) {
                  (slideInHorizontally(tween(300)) { -it } + fadeIn(tween(300))) togetherWith
                      (slideOutHorizontally(tween(300)) { it } + fadeOut(tween(300)))
                } else {
                  fadeIn(animationSpec = tween(400)) togetherWith
                      fadeOut(animationSpec = tween(300))
                }
              },
              label = "app_destination_transition",
          ) { target ->
            when (target) {
              AppDestination.SPLASH -> {
                DrawSplashScreen(
                    onSplashFinished = {
                      // If user has a valid active session, transition directly to the Map
                      // Otherwise, open the Auth / Login screen
                      destination =
                          if (uiState.currentUser != null) {
                            AppDestination.MAP
                          } else {
                            AppDestination.AUTH
                          }
                    }
                )
              }
              AppDestination.AUTH -> {
                AuthScreen(
                    viewModel = authViewModel,
                    modifier = Modifier.fillMaxSize(),
                )
              }
              AppDestination.MAP -> {
                MapScreen(
                    modifier = Modifier.fillMaxSize(),
                    onOpenSettings = {
                      destination = AppDestination.SETTINGS
                    },
                    onSignOutRequested = {
                      destination = AppDestination.AUTH
                    },
                    onNavigateToAuth = { targetScreen ->
                      authViewModel.navigateTo(targetScreen)
                      destination = AppDestination.AUTH
                    }
                )
              }
              AppDestination.SETTINGS -> {
                SettingsScreen(
                    onBack = {
                      destination = AppDestination.MAP
                    },
                    onSignOut = {
                      authViewModel.signOut()
                      destination = AppDestination.AUTH
                    },
                    modifier = Modifier.fillMaxSize(),
                )
              }
            }
          }
        }
      }
    }
  }
}

/**
 * DRAW Phase 1: Launch Splash Screen (3D Balloon D with Forward Arrow)
 *
 * Implements a vivid, rich red (#FF0000) full-screen presentation with the
 * centered white 3D balloon D and integrated forward arrow emblem.
 *
 * Animation Sequence (approx. 2 seconds total):
 * 1. Start with vivid red background (#FF0000) and no visible logo (alpha = 0, scale = 0.92)
 * 2. Fade in smoothly (700ms) with subtle scale-up (0.92 -> 1.0) enhancing the inflated 3D feel
 * 3. Hold the logo briefly at full visibility (600ms)
 * 4. Fade out smoothly into the red background (700ms)
 * 5. Calls onSplashFinished to transition to the authenticated destination (Map or Login)
 */
@Composable
fun DrawSplashScreen(
    onSplashFinished: () -> Unit = {},
) {
  val alpha = remember { Animatable(0f) }
  val scale = remember { Animatable(0.92f) }

  LaunchedEffect(Unit) {
    // Step 1 & 2: Smooth fade-in + subtle inflation scale-up (700ms)
    coroutineScope {
      launch {
        alpha.animateTo(
            targetValue = 1f,
            animationSpec =
                tween(
                    durationMillis = 700,
                    easing = CubicBezierEasing(0.2f, 0.0f, 0.2f, 1.0f),
                ),
        )
      }
      launch {
        scale.animateTo(
            targetValue = 1.0f,
            animationSpec =
                tween(
                    durationMillis = 700,
                    easing = CubicBezierEasing(0.2f, 0.0f, 0.2f, 1.0f),
                ),
        )
      }
    }

    // Step 3: Brief hold of fully visible logo at final size (600ms)
    delay(600)

    // Step 4: Smooth fade-out into the red background (700ms)
    alpha.animateTo(
        targetValue = 0f,
        animationSpec =
            tween(
                durationMillis = 700,
                easing = CubicBezierEasing(0.4f, 0.0f, 0.6f, 1.0f),
            ),
    )

    // Step 5: Route to appropriate destination based on Firebase auth state
    onSplashFinished()
  }

  Box(
      modifier =
          Modifier
              .fillMaxSize()
              .background(DrawRed)
              .testTag("splash_screen_container"),
      contentAlignment = Alignment.Center,
  ) {
    Image(
        painter = painterResource(id = R.drawable.draw_symbol),
        contentDescription = stringResource(id = R.string.draw_logo_description),
        contentScale = ContentScale.Fit,
        modifier =
            Modifier
                .size(160.dp)
                .graphicsLayer {
                  scaleX = scale.value
                  scaleY = scale.value
                  this.alpha = alpha.value
                }
                .testTag("draw_splash_logo"),
    )
  }
}

@Preview(showBackground = true, backgroundColor = 0xFFFF0000)
@Composable
fun DrawSplashScreenPreview() {
  DrawTheme {
    Box(
        modifier =
            Modifier
                .fillMaxSize()
                .background(DrawRed),
        contentAlignment = Alignment.Center,
    ) {
      Image(
          painter = painterResource(id = R.drawable.draw_symbol),
          contentDescription = stringResource(id = R.string.draw_logo_description),
          modifier = Modifier.size(160.dp),
      )
    }
  }
}
