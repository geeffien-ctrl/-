package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.DrawBrand
import com.example.data.model.AppUser
import com.example.data.model.PlaceComment
import com.example.data.model.UserNotification
import com.google.firebase.firestore.FieldValue
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID

private const val TAG = "PlaceInteractionsRepo"

class PlaceInteractionsRepository(
    private val context: Context? = null
) {
    private val prefs = context?.getSharedPreferences("draw_interactions_prefs", Context.MODE_PRIVATE)

    private val db: FirebaseFirestore? by lazy {
        try {
            context?.let { ctx ->
                val dbId = ctx.getString(R.string.firestore_database_id)
                FirebaseFirestore.getInstance(dbId)
            } ?: FirebaseFirestore.getInstance()
        } catch (_: Exception) {
            try {
                FirebaseFirestore.getInstance()
            } catch (_: Exception) {
                null
            }
        }
    }

    // Cached states in memory
    private val likedPlacesByUser = mutableMapOf<String, MutableSet<String>>() // userId -> Set<placeId>
    private val commentsByPlace = mutableMapOf<String, MutableList<PlaceComment>>()
    private val likedCommentsByUser = mutableMapOf<String, MutableSet<String>>() // userId -> Set<commentId>
    private val notificationsByUser = mutableMapOf<String, MutableList<UserNotification>>()

    private val likedPlacesFlowMap = mutableMapOf<String, MutableStateFlow<Boolean>>()
    private val commentsFlowMap = mutableMapOf<String, MutableStateFlow<List<PlaceComment>>>()
    private val likedCommentsFlowMap = mutableMapOf<String, MutableStateFlow<Set<String>>>()
    private val notificationsFlowMap = mutableMapOf<String, MutableStateFlow<List<UserNotification>>>()

    private val activeListeners = mutableMapOf<String, ListenerRegistration>()

    init {
        loadSavedInteractions()
    }

    private fun loadSavedInteractions() {
        // Clear all cached sample interactions - clean state
        commentsByPlace.clear()
    }

    // --- 1. Place Likes ---
    fun isPlaceLikedFlow(placeId: String, userId: String): Flow<Boolean> {
        val key = "${userId}_$placeId"
        val flow = likedPlacesFlowMap.getOrPut(key) {
            val isLiked = likedPlacesByUser[userId]?.contains(placeId) ?: false
            MutableStateFlow(isLiked)
        }

        // Attach real-time snapshot listener from Firestore if not already attached
        if (!activeListeners.containsKey("like_$key") && userId.isNotBlank() && !userId.startsWith("guest_") && placeId.isNotBlank()) {
            try {
                val listener = db?.collection("public_places")
                    ?.document(placeId)
                    ?.collection("likes")
                    ?.document(userId)
                    ?.addSnapshotListener { snapshot, err ->
                        if (err == null && snapshot != null) {
                            val liked = snapshot.exists()
                            val set = likedPlacesByUser.getOrPut(userId) { mutableSetOf() }
                            if (liked) set.add(placeId) else set.remove(placeId)
                            flow.value = liked
                        }
                    }
                listener?.let { activeListeners["like_$key"] = it }
            } catch (e: Exception) {
                Log.w(TAG, "Error listening to place like: ${e.message}")
            }
        }

        return flow.asStateFlow()
    }

    suspend fun togglePlaceLike(
        placeId: String,
        placeTitle: String,
        placeCreatorId: String,
        currentUser: AppUser
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        if (currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
            return@withContext Result.failure(IllegalAccessException("Guest users cannot like places"))
        }
        val userId = currentUser.uid
        val userLikes = likedPlacesByUser.getOrPut(userId) { mutableSetOf() }
        val isCurrentlyLiked = userLikes.contains(placeId)
        val newLiked = !isCurrentlyLiked

        if (newLiked) {
            userLikes.add(placeId)
        } else {
            userLikes.remove(placeId)
        }

        val key = "${userId}_$placeId"
        likedPlacesFlowMap[key]?.value = newLiked

        // Persist to Firestore: /public_places/{placeId}/likes/{userId}
        try {
            val firestore = db
            if (firestore != null && placeId.isNotBlank()) {
                val likeDocRef = firestore.collection("public_places").document(placeId).collection("likes").document(userId)
                val placeDocRef = firestore.collection("public_places").document(placeId)
                if (newLiked) {
                    val data = mapOf(
                        "userId" to userId,
                        "createdAt" to System.currentTimeMillis()
                    )
                    likeDocRef.set(data, SetOptions.merge()).await()
                    try {
                        placeDocRef.update("likesCount", FieldValue.increment(1)).await()
                    } catch (_: Exception) {}
                } else {
                    likeDocRef.delete().await()
                    try {
                        placeDocRef.update("likesCount", FieldValue.increment(-1)).await()
                    } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore togglePlaceLike error: ${e.message}")
        }

        if (newLiked && placeCreatorId.isNotBlank() && placeCreatorId != userId) {
            sendNotification(
                recipientId = placeCreatorId,
                actor = currentUser,
                type = "PLACE_LIKE",
                placeId = placeId,
                placeTitle = placeTitle
            )
        }
        Result.success(newLiked)
    }

    // --- 2. Place Comments ---
    fun getCommentsFlow(placeId: String): Flow<List<PlaceComment>> {
        val flow = commentsFlowMap.getOrPut(placeId) {
            val list = commentsByPlace.getOrPut(placeId) { mutableListOf() }
            MutableStateFlow(list.toList())
        }

        // Attach real-time snapshot listener from Firestore
        if (!activeListeners.containsKey("comments_$placeId") && placeId.isNotBlank()) {
            try {
                val listener = db?.collection("public_places")
                    ?.document(placeId)
                    ?.collection("comments")
                    ?.addSnapshotListener { snapshot, err ->
                        if (err == null && snapshot != null) {
                            val list = mutableListOf<PlaceComment>()
                            for (doc in snapshot.documents) {
                                try {
                                    val c = PlaceComment(
                                        id = doc.id,
                                        placeId = doc.getString("placeId") ?: placeId,
                                        userId = doc.getString("userId") ?: "",
                                        userName = doc.getString("userName") ?: "",
                                        userPhotoUrl = doc.getString("userPhotoUrl") ?: "",
                                        text = doc.getString("text") ?: "",
                                        likesCount = doc.getLong("likesCount") ?: 0L,
                                        createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                                    )
                                    if (c.text.isNotBlank()) {
                                        list.add(c)
                                    }
                                } catch (_: Exception) {}
                            }
                            val sorted = list.sortedBy { it.createdAt }
                            commentsByPlace[placeId] = sorted.toMutableList()
                            flow.value = sorted
                        }
                    }
                listener?.let { activeListeners["comments_$placeId"] = it }
            } catch (e: Exception) {
                Log.w(TAG, "Error attaching comments listener for $placeId", e)
            }
        }

        return flow.asStateFlow()
    }

    suspend fun addComment(
        placeId: String,
        placeTitle: String,
        placeCreatorId: String,
        currentUser: AppUser,
        text: String
    ): Result<PlaceComment> = withContext(Dispatchers.IO) {
        if (currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
            return@withContext Result.failure(IllegalAccessException("Guest users cannot add comments"))
        }
        val trimmed = text.trim()
        if (trimmed.isEmpty()) return@withContext Result.failure(IllegalArgumentException("التعليق فارغ"))

        val commentId = "c_" + UUID.randomUUID().toString().take(10)
        val newComment = PlaceComment(
            id = commentId,
            placeId = placeId,
            userId = currentUser.uid,
            userName = currentUser.displayName ?: currentUser.email?.substringBefore("@") ?: "مستخدم DRAW",
            userPhotoUrl = DrawBrand.AVATAR_URI,
            text = trimmed,
            likesCount = 0L,
            createdAt = System.currentTimeMillis()
        )

        // 1. Update local cache immediately
        val list = commentsByPlace.getOrPut(placeId) { mutableListOf() }
        list.add(newComment)
        commentsFlowMap[placeId]?.value = list.toList()

        // 2. Persist to Firestore: /public_places/{placeId}/comments/{commentId}
        try {
            val firestore = db
            if (firestore != null && placeId.isNotBlank()) {
                val commentData = mapOf(
                    "id" to commentId,
                    "placeId" to placeId,
                    "userId" to currentUser.uid,
                    "userName" to newComment.userName,
                    "userPhotoUrl" to newComment.userPhotoUrl,
                    "text" to trimmed,
                    "likesCount" to 0L,
                    "createdAt" to newComment.createdAt
                )
                firestore.collection("public_places").document(placeId).collection("comments").document(commentId)
                    .set(commentData, SetOptions.merge()).await()
                try {
                    firestore.collection("public_places").document(placeId).update("commentsCount", FieldValue.increment(1)).await()
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore addComment error: ${e.message}")
        }

        if (placeCreatorId.isNotBlank() && placeCreatorId != currentUser.uid) {
            sendNotification(
                recipientId = placeCreatorId,
                actor = currentUser,
                type = "PLACE_COMMENT",
                placeId = placeId,
                placeTitle = placeTitle,
                commentId = newComment.id,
                commentSnippet = trimmed.take(60)
            )
        }
        Result.success(newComment)
    }

    suspend fun deleteComment(
        placeId: String,
        commentId: String,
        userId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        if (userId.isBlank() || userId.startsWith("guest_")) {
            return@withContext Result.failure(IllegalAccessException("لا تملك صلاحية حذف هذا التعليق"))
        }

        // 1. Remove from in-memory cache
        val currentComments = commentsByPlace[placeId]
        val target = currentComments?.firstOrNull { it.id == commentId }
        if (target != null && target.userId != userId) {
            return@withContext Result.failure(IllegalAccessException("لا يمكنك حذف تعليق مستخدم آخر"))
        }

        currentComments?.removeAll { it.id == commentId }
        commentsFlowMap[placeId]?.value = currentComments?.toList() ?: emptyList()

        // 2. Remove from Firestore
        try {
            val firestore = db
            if (firestore != null) {
                val commentRef = firestore.collection("public_places").document(placeId)
                    .collection("comments").document(commentId)
                val snapshot = commentRef.get().await()
                val docAuthorId = snapshot.getString("userId") ?: ""
                if (docAuthorId.isNotBlank() && docAuthorId != userId) {
                    return@withContext Result.failure(IllegalAccessException("لا يمكنك حذف تعليق مستخدم آخر"))
                }
                commentRef.delete().await()
                try {
                    firestore.collection("public_places").document(placeId)
                        .update("commentsCount", FieldValue.increment(-1)).await()
                } catch (_: Exception) {}
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore deleteComment error: ${e.message}")
            return@withContext Result.failure(e)
        }

        Result.success(Unit)
    }

    // --- 3. Comment Likes ---
    fun getUserLikedCommentsFlow(placeId: String, userId: String): Flow<Set<String>> {
        val flow = likedCommentsFlowMap.getOrPut(userId) {
            val set = likedCommentsByUser.getOrPut(userId) { mutableSetOf() }
            MutableStateFlow(set.toSet())
        }
        return flow.asStateFlow()
    }

    suspend fun toggleCommentLike(
        placeId: String,
        commentId: String,
        commentAuthorId: String,
        placeTitle: String,
        currentUser: AppUser
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        if (currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
            return@withContext Result.failure(IllegalAccessException("Guest users cannot like comments"))
        }
        val userId = currentUser.uid
        val userLikedSet = likedCommentsByUser.getOrPut(userId) { mutableSetOf() }
        val isLiked = userLikedSet.contains(commentId)
        val newLiked = !isLiked

        if (newLiked) {
            userLikedSet.add(commentId)
        } else {
            userLikedSet.remove(commentId)
        }

        likedCommentsFlowMap[userId]?.value = userLikedSet.toSet()

        // Update comment like counter in local list
        commentsByPlace[placeId]?.let { comments ->
            val idx = comments.indexOfFirst { it.id == commentId }
            if (idx >= 0) {
                val old = comments[idx]
                val nextCount = (old.likesCount + if (newLiked) 1L else -1L).coerceAtLeast(0L)
                comments[idx] = old.copy(likesCount = nextCount)
                commentsFlowMap[placeId]?.value = comments.toList()
            }
        }

        // Persist to Firestore: /public_places/{placeId}/comments/{commentId}/likes/{userId}
        try {
            val firestore = db
            if (firestore != null && placeId.isNotBlank() && commentId.isNotBlank()) {
                val likeDocRef = firestore.collection("public_places").document(placeId)
                    .collection("comments").document(commentId)
                    .collection("likes").document(userId)
                val commentDocRef = firestore.collection("public_places").document(placeId)
                    .collection("comments").document(commentId)

                if (newLiked) {
                    likeDocRef.set(mapOf("userId" to userId, "createdAt" to System.currentTimeMillis()), SetOptions.merge()).await()
                    try {
                        commentDocRef.update("likesCount", FieldValue.increment(1)).await()
                    } catch (_: Exception) {}
                } else {
                    likeDocRef.delete().await()
                    try {
                        commentDocRef.update("likesCount", FieldValue.increment(-1)).await()
                    } catch (_: Exception) {}
                }
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firestore toggleCommentLike error: ${e.message}")
        }

        if (newLiked && commentAuthorId.isNotBlank() && commentAuthorId != userId) {
            sendNotification(
                recipientId = commentAuthorId,
                actor = currentUser,
                type = "COMMENT_LIKE",
                placeId = placeId,
                placeTitle = placeTitle,
                commentId = commentId
            )
        }
        Result.success(newLiked)
    }

    // --- 4. Notifications Center ---
    fun getNotificationsFlow(userId: String): Flow<List<UserNotification>> {
        val flow = notificationsFlowMap.getOrPut(userId) {
            val list = notificationsByUser.getOrPut(userId) { mutableListOf() }
            MutableStateFlow(list.toList())
        }

        if (!activeListeners.containsKey("notifs_$userId") && userId.isNotBlank() && !userId.startsWith("guest_")) {
            try {
                val listener = db?.collection("users")?.document(userId)?.collection("notifications")
                    ?.addSnapshotListener { snapshot, err ->
                        if (err == null && snapshot != null) {
                            val list = mutableListOf<UserNotification>()
                            for (doc in snapshot.documents) {
                                try {
                                    val notif = UserNotification(
                                        id = doc.id,
                                        recipientId = doc.getString("recipientId") ?: userId,
                                        actorId = doc.getString("actorId") ?: "",
                                        actorName = doc.getString("actorName") ?: "مستخدم",
                                        actorPhotoUrl = doc.getString("actorPhotoUrl") ?: "",
                                        type = doc.getString("type") ?: "GENERAL",
                                        placeId = doc.getString("placeId") ?: "",
                                        placeTitle = doc.getString("placeTitle") ?: "",
                                        commentId = doc.getString("commentId"),
                                        commentTextSnippet = doc.getString("commentTextSnippet"),
                                        read = doc.getBoolean("read") ?: false,
                                        createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
                                    )
                                    list.add(notif)
                                } catch (_: Exception) {}
                            }
                            val sorted = list.sortedByDescending { it.createdAt }
                            notificationsByUser[userId] = sorted.toMutableList()
                            flow.value = sorted
                        }
                    }
                listener?.let { activeListeners["notifs_$userId"] = it }
            } catch (e: Exception) {
                Log.w(TAG, "Error attaching notifications listener for $userId", e)
            }
        }

        return flow.asStateFlow()
    }

    suspend fun markNotificationAsRead(userId: String, notificationId: String): Result<Unit> = withContext(Dispatchers.IO) {
        notificationsByUser[userId]?.let { list ->
            val idx = list.indexOfFirst { it.id == notificationId }
            if (idx >= 0) {
                list[idx] = list[idx].copy(read = true)
                notificationsFlowMap[userId]?.value = list.toList()
            }
        }
        try {
            db?.collection("users")?.document(userId)?.collection("notifications")?.document(notificationId)
                ?.update("read", true)?.await()
        } catch (_: Exception) {}
        Result.success(Unit)
    }

    suspend fun markAllNotificationsAsRead(userId: String): Result<Unit> = withContext(Dispatchers.IO) {
        notificationsByUser[userId]?.let { list ->
            for (i in list.indices) {
                list[i] = list[i].copy(read = true)
            }
            notificationsFlowMap[userId]?.value = list.toList()
        }
        try {
            val notifs = db?.collection("users")?.document(userId)?.collection("notifications")?.get()?.await()
            notifs?.documents?.forEach { doc ->
                doc.reference.update("read", true)
            }
        } catch (_: Exception) {}
        Result.success(Unit)
    }

    private fun sendNotification(
        recipientId: String,
        actor: AppUser,
        type: String,
        placeId: String,
        placeTitle: String,
        commentId: String? = null,
        commentSnippet: String? = null
    ) {
        if (recipientId.isBlank() || recipientId == actor.uid) return
        val notifId = "notif_" + UUID.randomUUID().toString().take(10)
        val notif = UserNotification(
            id = notifId,
            recipientId = recipientId,
            actorId = actor.uid,
            actorName = actor.displayName ?: actor.email?.substringBefore("@") ?: "مستخدم DRAW",
            actorPhotoUrl = actor.photoUrl?.toString() ?: "",
            type = type,
            placeId = placeId,
            placeTitle = placeTitle,
            commentId = commentId,
            commentTextSnippet = commentSnippet,
            read = false,
            createdAt = System.currentTimeMillis()
        )
        val list = notificationsByUser.getOrPut(recipientId) { mutableListOf() }
        list.add(0, notif)
        notificationsFlowMap[recipientId]?.value = list.toList()

        try {
            val data = mapOf(
                "id" to notifId,
                "recipientId" to recipientId,
                "actorId" to notif.actorId,
                "actorName" to notif.actorName,
                "actorPhotoUrl" to notif.actorPhotoUrl,
                "type" to type,
                "placeId" to placeId,
                "placeTitle" to placeTitle,
                "commentId" to (commentId ?: ""),
                "commentTextSnippet" to (commentSnippet ?: ""),
                "read" to false,
                "createdAt" to notif.createdAt
            )
            db?.collection("users")?.document(recipientId)?.collection("notifications")?.document(notifId)
                ?.set(data, SetOptions.merge())
        } catch (e: Exception) {
            Log.w(TAG, "Error writing notification to Firestore: ${e.message}")
        }
    }
}
