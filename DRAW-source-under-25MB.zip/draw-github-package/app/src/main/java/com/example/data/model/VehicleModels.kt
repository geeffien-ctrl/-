package com.example.data.model

import androidx.compose.ui.graphics.Color
import java.util.UUID

/**
 * 3 Official Taxi Color Options for DRAW Taxi feature.
 * 1. Yellow & Black
 * 2. Red & Black
 * 3. Ink Blue & Black
 */
data class TaxiColorOption(
    val id: String,
    val nameArabic: String,
    val hex: String,
    val primaryColor: Color,
    val accentColor: Color = Color(0xFF111827) // Black trims
)

object TaxiColorPresets {
    val YELLOW = TaxiColorOption(
        id = "yellow",
        nameArabic = "أصفر وأسود",
        hex = "#F59E0B",
        primaryColor = Color(0xFFF59E0B)
    )
    val RED = TaxiColorOption(
        id = "red",
        nameArabic = "أحمر وأسود",
        hex = "#DC2626",
        primaryColor = Color(0xFFDC2626)
    )
    val INK_BLUE = TaxiColorOption(
        id = "ink_blue",
        nameArabic = "أزرق حبري وأسود",
        hex = "#1E3A8A",
        primaryColor = Color(0xFF1E3A8A)
    )

    val ALL: List<TaxiColorOption> = listOf(YELLOW, RED, INK_BLUE)

    fun findByHex(hex: String): TaxiColorOption {
        return ALL.firstOrNull { it.hex.equals(hex, ignoreCase = true) } ?: YELLOW
    }

    fun findById(id: String): TaxiColorOption {
        return ALL.firstOrNull { it.id.equals(id, ignoreCase = true) } ?: YELLOW
    }
}

/**
 * Taxi Driver State Lifecycle:
 * AVAILABLE, REQUEST_RECEIVED, EN_ROUTE_TO_PICKUP, IN_TRIP, UNAVAILABLE
 */
enum class TaxiDriverStatus(val id: String, val titleArabic: String, val descriptionArabic: String) {
    AVAILABLE("available", "متاح للطلب", "التاكسي ظاهر على الخريطة ومستعد لاستقبال الركاب"),
    REQUEST_RECEIVED("request_received", "وصله طلب", "بانتظار موافقة السائق على الطلب"),
    EN_ROUTE_TO_PICKUP("en_route", "في الطريق للراكب", "السائق متوجه لموقع صعود الراكب"),
    IN_TRIP("in_trip", "في رحلة حالية", "الرحلة جارية نحو الوجهة المطلوبة"),
    UNAVAILABLE("unavailable", "غير متاح", "التاكسي مخفي ولا يستقبل طلبات");

    companion object {
        fun fromId(id: String): TaxiDriverStatus {
            return values().firstOrNull { it.id.equals(id, ignoreCase = true) } ?: AVAILABLE
        }
    }
}

/**
 * Backward compatibility categories.
 */
enum class VehicleCategory(val id: String, val titleArabic: String, val titleEnglish: String) {
    PERSONAL_CARS("personal_cars", "سيارات شخصية", "Personal Cars"),
    PUBLIC_SERVICES("public_services", "باصات وخدمات وطوارئ", "Buses & Public Services"),
    TRUCKS("trucks", "شاحنات", "Trucks"),
    HEAVY_AND_BIKES("heavy_and_bikes", "معدات ودراجات", "Heavy Equipment & Bikes"),

    // Backward compatibility aliases
    SMALL_CARS("personal_cars", "سيارات شخصية", "Personal Cars"),
    LARGE_LONG_VEHICLES("public_services", "باصات وخدمات وطوارئ", "Buses & Public Services"),
    PASSENGER("personal_cars", "سيارات شخصية", "Personal Cars"),
    TAXI_VIP("personal_cars", "سيارات شخصية", "Personal Cars"),
    DELIVERY_BIKES("heavy_and_bikes", "معدات ودراجات", "Heavy Equipment & Bikes"),
    VANS_BUSES("public_services", "باصات وخدمات وطوارئ", "Buses & Public Services"),
    TRUCKS_CARGO("trucks", "شاحنات", "Trucks"),
    SERVICES_MOBILE("public_services", "باصات وخدمات وطوارئ", "Buses & Public Services"),
    SEDAN("personal_cars", "سيارات شخصية", "Personal Cars"),
    TAXI("personal_cars", "سيارات شخصية", "Personal Cars"),
    DELIVERY("heavy_and_bikes", "معدات ودراجات", "Heavy Equipment & Bikes"),
    UTILITY_SERVICES("public_services", "باصات وخدمات وطوارئ", "Buses & Public Services");

    val titleAr: String get() = titleArabic
}

/**
 * Metadata for Vehicle Models.
 */
data class VehicleModelItem(
    val id: String = "taxi_city",
    val titleArabic: String = "سيارة أجرة (تكسي)",
    val titleEnglish: String = "City Taxi",
    val category: VehicleCategory = VehicleCategory.PERSONAL_CARS,
    val defaultColorHex: String = "#F59E0B",
    val supportsCustomColor: Boolean = true,
    val serviceTypeDefault: String = "تاكسي"
) {
    val nameAr: String get() = titleArabic
}

/**
 * Vehicle Library - Solely focused on City Taxi for DRAW.
 */
object VehicleLibrary {
    val TAXI_MODEL = VehicleModelItem(
        id = "taxi_city",
        titleArabic = "سيارة أجرة (تكسي)",
        titleEnglish = "City Taxi",
        category = VehicleCategory.PERSONAL_CARS,
        defaultColorHex = "#F59E0B",
        supportsCustomColor = true,
        serviceTypeDefault = "تاكسي"
    )

    val models: List<VehicleModelItem> = listOf(TAXI_MODEL)
    val ALL_VEHICLES: List<VehicleModelItem> get() = models

    fun getModelById(id: String): VehicleModelItem {
        return TAXI_MODEL
    }

    fun findById(id: String): VehicleModelItem? {
        return TAXI_MODEL
    }
}

/**
 * 3 Location Visibility Modes.
 */
enum class LocationVisibilityMode(
    val id: String,
    val titleArabic: String,
    val descriptionArabic: String
) {
    HIDDEN_FROM_OTHERS(
        id = "hidden",
        titleArabic = "مخفي عن الآخرين",
        descriptionArabic = "أنت فقط ترى سيارتك على خريطتك، ولا يراها أحد من المستخدمين الآخرين."
    ),
    PUBLIC_TO_ALL(
        id = "public",
        titleArabic = "مرئي للعامة",
        descriptionArabic = "التاكسي ظاهر للركاب على الخريطة وتستطيع استقبال طلبات المشاوير."
    ),
    PEDESTRIAN_MODE(
        id = "pedestrian",
        titleArabic = "وضع المشاة",
        descriptionArabic = "إيقاف تمثيل السيارة والاعتماد على نقطة الموقع العادية."
    );

    companion object {
        fun fromId(id: String): LocationVisibilityMode {
            return values().firstOrNull { it.id.equals(id, ignoreCase = true) } ?: HIDDEN_FROM_OTHERS
        }
    }
}

/**
 * User Vehicle Profile stored in user preferences & Firestore.
 * Contains Taxi-specific settings:
 * - isTaxiOwner: Toggle "أنا صاحب تاكسي"
 * - taxiDriverName: Driver display name
 * - taxiCarModel: Car make, name and model
 * - taxiFarePerKm: Fare in IQD per kilometer (e.g. 1000)
 * - taxiColorHex: Taxi body color (Yellow, Red, Ink Blue)
 * - taxiStatus: Status (AVAILABLE, IN_TRIP, UNAVAILABLE, etc.)
 */
data class UserVehicleProfile(
    val userId: String = "",
    val vehicleModelId: String = "taxi_city",
    val colorHex: String = "#F59E0B",
    val customName: String = "",
    val maker: String = "",
    val model: String = "",
    val year: String = "",
    val usageType: String = "تاكسي",
    val visibilityMode: LocationVisibilityMode = LocationVisibilityMode.HIDDEN_FROM_OTHERS,
    val isSharingLocation: Boolean = false,
    val isAcceptingOrders: Boolean = false,
    val lastUpdatedAt: Long = System.currentTimeMillis(),
    val driverName: String = "",
    val makeModel: String = "",
    val modelYear: String = "",
    val plateNumber: String = "",
    val serviceCategory: String = "تاكسي",
    val updatedAt: Long = System.currentTimeMillis(),

    // --- Taxi Specific Features ---
    val isTaxiOwner: Boolean = false,
    val taxiDriverName: String = "",
    val taxiCarModel: String = "",
    val taxiFarePerKm: Double = 0.0,
    val taxiColorHex: String = "#F59E0B",
    val taxiStatus: TaxiDriverStatus = TaxiDriverStatus.AVAILABLE,
    val totalLikes: Int = 0,
    val totalComments: Int = 0,
    val totalCompletedTrips: Int = 0
) {
    val effectiveIsPublic: Boolean
        get() = (isTaxiOwner && isSharingLocation) || visibilityMode == LocationVisibilityMode.PUBLIC_TO_ALL
    val effectiveIsHidden: Boolean
        get() = !isTaxiOwner || visibilityMode == LocationVisibilityMode.HIDDEN_FROM_OTHERS
    val effectiveIsPedestrian: Boolean
        get() = visibilityMode == LocationVisibilityMode.PEDESTRIAN_MODE
    val effectiveDriverName: String
        get() = taxiDriverName.ifBlank { driverName.ifBlank { customName } }
    val effectiveMakeModel: String
        get() = taxiCarModel.ifBlank { makeModel.ifBlank { if (maker.isNotBlank() || model.isNotBlank()) "$maker $model".trim() else customName } }
    val effectiveModelYear: String
        get() = modelYear.ifBlank { year }
    val effectiveServiceCategory: String
        get() = "تاكسي"
    val effectiveFarePerKmFormatted: String
        get() = "${taxiFarePerKm.toInt()} د.ع / كم"
}

/**
 * Live vehicle active on the map, shared via Firestore collection `live_vehicles`.
 */
data class LiveVehicle(
    val id: String = "", // driverUid
    val driverName: String = "سائق DRAW",
    val vehicleModelId: String = "taxi_city",
    val colorHex: String = "#F59E0B",
    val serviceType: String = "تاكسي",
    val maker: String = "",
    val model: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val bearing: Float = 0.0f,
    val speed: Float = 0.0f,
    val isSharingLocation: Boolean = true,
    val isAcceptingOrders: Boolean = true,
    val lastUpdatedAt: Long = System.currentTimeMillis(),
    val distanceToUserMeters: Float = 0.0f,
    val userId: String = "",
    val speedKmh: Double = 0.0,
    val isAvailableForOrders: Boolean = true,
    val serviceCategory: String = "تاكسي",

    // Taxi specific live attributes
    val isTaxiOwner: Boolean = true,
    val taxiCarModel: String = "",
    val taxiColorHex: String = "#F59E0B",
    val farePerKm: Double = 0.0,
    val taxiStatus: String = "available", // available, busy, in_trip
    val likesCount: Int = 0,
    val commentsCount: Int = 0,
    val completedTripsCount: Int = 0
) {
    val effectiveUserId: String
        get() = userId.ifBlank { id }
    val effectiveSpeedKmh: Double
        get() = if (speedKmh > 0.0) speedKmh else (speed * 3.6).toDouble()
    val effectiveIsAvailable: Boolean
        get() = (taxiStatus == "available" || isAcceptingOrders) && taxiStatus != "in_trip" && taxiStatus != "busy" && taxiStatus != "unavailable"
    val effectiveServiceCategory: String
        get() = "تاكسي"
    val effectiveColorHex: String
        get() = taxiColorHex.ifBlank { colorHex }
    val effectiveCarModel: String
        get() = taxiCarModel.ifBlank { if (maker.isNotBlank() || model.isNotBlank()) "$maker $model".trim() else "سيارة تاكسي" }
    val effectiveFareFormatted: String
        get() = "${farePerKm.toInt()} د.ع / كم"
}

/**
 * Order status states for service requests.
 */
enum class OrderStatus(val id: String, val titleArabic: String, val titleEnglish: String) {
    WAITING_APPROVAL("waiting_approval", "بانتظار موافقة السائق", "Waiting Approval"),
    ACCEPTED("accepted", "تمت الموافقة", "Accepted"),
    REJECTED("rejected", "تم الرفض", "Rejected"),
    DRIVER_EN_ROUTE("driver_en_route", "السائق في الطريق إليك", "Driver En Route"),
    ARRIVED("arrived", "وصل السائق", "Driver Arrived"),
    IN_PROGRESS("in_progress", "الرحلة قيد التنفيذ", "In Progress"),
    COMPLETED("completed", "اكتملت الرحلة", "Completed"),
    CANCELLED("cancelled", "تم الإلغاء", "Cancelled")
}

/**
 * Ride / Service Request between Passenger and Taxi Driver in collection `service_orders`.
 */
data class ServiceOrder(
    val id: String = UUID.randomUUID().toString(),
    val passengerUid: String = "",
    val passengerName: String = "الراكب",
    val driverUid: String = "",
    val driverName: String = "السائق",
    val serviceType: String = "تاكسي",
    val vehicleModelId: String = "taxi_city",
    val pickupLat: Double = 0.0,
    val pickupLng: Double = 0.0,
    val pickupAddress: String = "",
    val dropoffLat: Double? = null,
    val dropoffLng: Double? = null,
    val dropoffAddress: String? = null,
    val status: OrderStatus = OrderStatus.WAITING_APPROVAL,
    val driverLat: Double? = null,
    val driverLng: Double? = null,
    val estimatedDistanceMeters: Float = 0.0f,
    val notes: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val customerId: String = "",
    val customerName: String = "",
    val driverId: String = "",
    val serviceTitle: String = "مشوار تاكسي",
    val pickupLatitude: Double = 0.0,
    val pickupLongitude: Double = 0.0,

    // Taxi trip calculation and review fields
    val farePerKm: Double = 0.0,
    val estimatedFare: Double = 0.0,
    val finalFare: Double = 0.0,
    val passengerLiked: Boolean? = null,
    val passengerComment: String? = null,
    val taxiColorHex: String = "#F59E0B",
    val taxiCarModel: String = "",
    val isReported: Boolean = false,
    val reportedReason: String? = null
) {
    val effectiveCustomerId: String
        get() = customerId.ifBlank { passengerUid }
    val effectiveCustomerName: String
        get() = customerName.ifBlank { passengerName }
    val effectiveDriverId: String
        get() = driverId.ifBlank { driverUid }
    val effectiveServiceTitle: String
        get() = serviceTitle.ifBlank { serviceType }
    val effectivePickupLat: Double
        get() = if (pickupLatitude != 0.0) pickupLatitude else pickupLat
    val effectivePickupLng: Double
        get() = if (pickupLongitude != 0.0) pickupLongitude else pickupLng
    val formattedEstimatedFare: String
        get() = "${estimatedFare.toInt()} د.ع"
}

data class TaxiComment(
    val id: String = "",
    val driverId: String = "",
    val userId: String = "",
    val userName: String = "",
    val userPhotoUrl: String = "",
    val text: String = "",
    val likesCount: Long = 0L,
    val createdAt: Long = System.currentTimeMillis()
)
