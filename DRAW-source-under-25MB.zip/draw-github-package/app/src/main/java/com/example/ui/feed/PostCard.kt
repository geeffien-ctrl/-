package com.example.ui.feed

import android.content.Context
import android.content.Intent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Share
import androidx.compose.material.icons.filled.VolumeMute
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.Post
import com.example.data.util.AudioPlayerManager
import com.example.ui.map.components.formatRelativeTimeArabic
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@Composable
fun PostCard(
    post: Post,
    isLiked: Boolean,
    isSaved: Boolean,
    isFollowing: Boolean,
    currentUserId: String,
    onToggleLike: () -> Unit,
    onToggleSave: () -> Unit,
    onToggleFollow: () -> Unit,
    onOpenComments: () -> Unit,
    onOpenVideoInReels: (Post) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    var isExpandedCaption by remember { mutableStateOf(false) }

    val currentPlayingUrl by AudioPlayerManager.currentAudioUrl.collectAsStateWithLifecycle()
    val isAudioPlaying by AudioPlayerManager.isPlaying.collectAsStateWithLifecycle()
    val isPostAudioActive = post.hasAudio && currentPlayingUrl == post.audioUrl && isAudioPlaying

    val heartColor by animateColorAsState(
        targetValue = if (isLiked) DrawRed else Color(0xFF1C1C1E),
        label = "heart_color"
    )

    Card(
        shape = RoundedCornerShape(24.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 3.dp),
        modifier = modifier
            .fillMaxWidth()
            .padding(horizontal = 12.dp, vertical = 6.dp)
            .testTag("post_card_${post.id}")
    ) {
        Column(modifier = Modifier.fillMaxWidth()) {
            // 1. Author Header Row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // User Avatar
                if (post.creatorPhotoUrl.isNotBlank()) {
                    AsyncImage(
                        model = post.creatorPhotoUrl,
                        contentDescription = post.creatorName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .border(1.dp, Color(0x18000000), CircleShape)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFECEB)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = DrawRed,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = post.creatorName.ifBlank { "مستخدم ZOLAVOR" },
                        fontSize = 14.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = DrawTextNearBlack,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                    Text(
                        text = formatRelativeTimeArabic(post.createdAt),
                        fontSize = 11.5.sp,
                        color = DrawTextSecondary
                    )
                }

                // Follow / Following pill if not self
                if (currentUserId.isNotBlank() && currentUserId != post.creatorId) {
                    Surface(
                        onClick = onToggleFollow,
                        shape = RoundedCornerShape(12.dp),
                        color = if (isFollowing) Color(0xFFF2F2F7) else DrawRed,
                        modifier = Modifier.testTag("post_follow_btn_${post.id}")
                    ) {
                        Text(
                            text = if (isFollowing) "متابَع" else "متابعة",
                            color = if (isFollowing) DrawTextNearBlack else Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                    }
                }
            }

            // Optional Audio Banner
            if (post.hasAudio) {
                Surface(
                    onClick = {
                        if (isPostAudioActive) {
                            AudioPlayerManager.stop(fade = true)
                        } else {
                            AudioPlayerManager.play(context, post.audioUrl, post.audioTitle)
                        }
                    },
                    shape = RoundedCornerShape(12.dp),
                    color = if (isPostAudioActive) Color(0xFFFFECEB) else Color(0xFFF9F9FB),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 4.dp)
                        .testTag("post_audio_pill_${post.id}")
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (isPostAudioActive) Icons.Default.GraphicEq else Icons.Default.VolumeUp,
                            contentDescription = "Audio track",
                            tint = if (isPostAudioActive) DrawRed else DrawTextSecondary,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = post.audioTitle.ifBlank { "مقطع صوتي مرفق" },
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Medium,
                            color = if (isPostAudioActive) DrawRed else DrawTextNearBlack,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                            modifier = Modifier.weight(1f)
                        )
                        Text(
                            text = if (isPostAudioActive) "إيقاف الصوت" else "تشغيل الصوت",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = DrawRed
                        )
                    }
                }
            }

            // 2. Media Presentation: Single Image, Multi-Image Pager, or Video Preview
            if (post.isVideo) {
                // Video Preview Card with Play overlay linking to Reels
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.2f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFF141416))
                        .clickable { onOpenVideoInReels(post) }
                        .testTag("post_video_preview_${post.id}"),
                    contentAlignment = Alignment.Center
                ) {
                    if (post.images.isNotEmpty()) {
                        AsyncImage(
                            model = post.images.first(),
                            contentDescription = "Video Thumbnail",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    // Dark scrim overlay
                    Box(
                        modifier = Modifier
                            .fillMaxSize()
                            .background(Color.Black.copy(alpha = 0.35f))
                    )
                    // Big Play Icon
                    Box(
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(Color.Black.copy(alpha = 0.6f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayCircle,
                            contentDescription = "Play in Reels",
                            tint = Color.White,
                            modifier = Modifier.size(54.dp)
                        )
                    }
                    // Reels Tag Badge
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = Color.Black.copy(alpha = 0.7f),
                        modifier = Modifier
                            .align(Alignment.BottomEnd)
                            .padding(12.dp)
                    ) {
                        Text(
                            text = "مشاهدة في Reels ▷",
                            color = Color.White,
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 5.dp)
                        )
                    }
                }
            } else if (post.images.size > 1) {
                // Multi-Image Gallery with Swipe & Indicator
                val pagerState = rememberPagerState(pageCount = { post.images.size })
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.05f)
                        .clip(RoundedCornerShape(14.dp))
                        .background(Color(0xFFF2F2F7))
                ) {
                    HorizontalPager(
                        state = pagerState,
                        modifier = Modifier.fillMaxSize()
                    ) { pageIdx ->
                        AsyncImage(
                            model = post.images[pageIdx],
                            contentDescription = "Image ${pageIdx + 1}",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )
                    }

                    // Indicator Pill (e.g. 1/3)
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = Color.Black.copy(alpha = 0.65f),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(10.dp)
                    ) {
                        Text(
                            text = "${pagerState.currentPage + 1}/${post.images.size}",
                            color = Color.White,
                            fontSize = 11.5.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
                        )
                    }

                    // Dot Indicators at the bottom
                    Row(
                        modifier = Modifier
                            .align(Alignment.BottomCenter)
                            .padding(bottom = 8.dp)
                            .background(Color.Black.copy(alpha = 0.4f), RoundedCornerShape(10.dp))
                            .padding(horizontal = 6.dp, vertical = 3.dp),
                        horizontalArrangement = Arrangement.spacedBy(4.dp)
                    ) {
                        repeat(post.images.size) { i ->
                            Box(
                                modifier = Modifier
                                    .size(if (pagerState.currentPage == i) 7.dp else 5.dp)
                                    .clip(CircleShape)
                                    .background(if (pagerState.currentPage == i) Color.White else Color.White.copy(alpha = 0.5f))
                            )
                        }
                    }
                }
            } else if (post.images.size == 1) {
                // Single Image
                AsyncImage(
                    model = post.images.first(),
                    contentDescription = "Post Image",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier
                        .fillMaxWidth()
                        .aspectRatio(1.1f)
                        .clip(RoundedCornerShape(14.dp))
                )
            }

            // 3. Actions Row (Heart, Comments, Share, Bookmark)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Like Button
                IconButton(
                    onClick = onToggleLike,
                    modifier = Modifier.testTag("post_like_button_${post.id}")
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Like",
                        tint = heartColor,
                        modifier = Modifier.size(24.dp)
                    )
                }

                // Comment Button
                IconButton(
                    onClick = onOpenComments,
                    modifier = Modifier.testTag("post_comment_button_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Comment",
                        tint = Color(0xFF1C1C1E),
                        modifier = Modifier.size(22.dp)
                    )
                }

                // Share Button
                IconButton(
                    onClick = {
                        val shareIntent = Intent(Intent.ACTION_SEND).apply {
                            type = "text/plain"
                            putExtra(
                                Intent.EXTRA_TEXT,
                                "${post.caption}\n\nنشر بواسطة: ${post.creatorName} عبر تطبيق ZOLAVOR"
                            )
                        }
                        context.startActivity(Intent.createChooser(shareIntent, "مشاركة المنشور"))
                    },
                    modifier = Modifier.testTag("post_share_button_${post.id}")
                ) {
                    Icon(
                        imageVector = Icons.Default.Share,
                        contentDescription = "Share",
                        tint = Color(0xFF1C1C1E),
                        modifier = Modifier.size(22.dp)
                    )
                }

                Spacer(modifier = Modifier.weight(1f))

                // Bookmark / Save Button
                IconButton(
                    onClick = onToggleSave,
                    modifier = Modifier.testTag("post_save_button_${post.id}")
                ) {
                    Icon(
                        imageVector = if (isSaved) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                        contentDescription = "Save",
                        tint = if (isSaved) DrawRed else Color(0xFF1C1C1E),
                        modifier = Modifier.size(24.dp)
                    )
                }
            }

            // 4. Counts Row (Likes & Comments)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 14.dp),
                horizontalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                if (post.likesCount > 0) {
                    Text(
                        text = "${post.likesCount} إعجاب",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = DrawTextNearBlack
                    )
                }
                if (post.commentsCount > 0) {
                    Text(
                        text = "${post.commentsCount} تعليق",
                        fontSize = 13.sp,
                        color = DrawTextSecondary,
                        modifier = Modifier.clickable { onOpenComments() }
                    )
                }
            }

            // 5. Expandable Caption
            if (post.caption.isNotBlank()) {
                Spacer(modifier = Modifier.height(4.dp))
                Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 4.dp)) {
                    Text(
                        text = post.caption,
                        fontSize = 13.5.sp,
                        color = Color(0xFF2C2C2E),
                        lineHeight = 19.sp,
                        maxLines = if (isExpandedCaption) Int.MAX_VALUE else 2,
                        overflow = TextOverflow.Ellipsis
                    )
                    if (post.caption.length > 70) {
                        Text(
                            text = if (isExpandedCaption) "عرض أقل" else "المزيد...",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = DrawTextSecondary,
                            modifier = Modifier
                                .clickable { isExpandedCaption = !isExpandedCaption }
                                .padding(top = 2.dp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))
        }
    }
}
