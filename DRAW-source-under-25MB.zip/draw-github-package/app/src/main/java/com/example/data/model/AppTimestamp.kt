package com.example.data.model

import java.util.Date

/**
 * Decoupled Timestamp model representing server / document timestamps in DRAW.
 * Has identical fields (seconds, nanoseconds, date) as com.google.firebase.Timestamp.
 */
data class AppTimestamp(
    val seconds: Long = System.currentTimeMillis() / 1000L,
    val nanoseconds: Int = 0
) {
    constructor(date: Date) : this(
        seconds = date.time / 1000L,
        nanoseconds = ((date.time % 1000) * 1_000_000).toInt()
    )

    val date: Date
        get() = Date(seconds * 1000L)

    companion object {
        fun now(): AppTimestamp {
            val millis = System.currentTimeMillis()
            return AppTimestamp(
                seconds = millis / 1000L,
                nanoseconds = ((millis % 1000) * 1_000_000).toInt()
            )
        }
    }
}
