package com.example.ui

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.PlayCircle
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Map
import androidx.compose.material.icons.outlined.PlayCircleOutline
import androidx.compose.material.icons.outlined.Settings
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Post
import com.example.ui.components.CreatePostDialog
import com.example.ui.components.CreateStoryDialog
import com.example.ui.feed.SocialFeedScreen
import com.example.ui.map.MapScreen
import com.example.ui.reels.ReelsScreen
import com.example.ui.settings.SettingsScreen
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack

enum class SocialTab {
    FEED,
    REELS,
    MAP,
    SETTINGS
}

@Composable
fun MainSocialContainerScreen(
    onSignOutRequested: () -> Unit,
    modifier: Modifier = Modifier
) {
    var currentTab by remember { mutableStateOf(SocialTab.FEED) }
    var focusedReelPostId by remember { mutableStateOf<String?>(null) }

    var isCreateMenuOpen by remember { mutableStateOf(false) }
    var isCreatePostOpen by remember { mutableStateOf(false) }
    var isCreateStoryOpen by remember { mutableStateOf(false) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.White)
            .testTag("main_social_container")
    ) {
        // Tab Content
        Box(modifier = Modifier.fillMaxSize()) {
            AnimatedContent(
                targetState = currentTab,
                transitionSpec = {
                    fadeIn(animationSpec = tween(220)) togetherWith
                            fadeOut(animationSpec = tween(180))
                },
                label = "social_tab_transition"
            ) { tab ->
                when (tab) {
                    SocialTab.FEED -> {
                        SocialFeedScreen(
                            onOpenVideoInReels = { post: Post ->
                                focusedReelPostId = post.id
                                currentTab = SocialTab.REELS
                            },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    SocialTab.REELS -> {
                        ReelsScreen(
                            initialPostId = focusedReelPostId,
                            onBack = { currentTab = SocialTab.FEED },
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                    SocialTab.MAP -> {
                        MapScreen(
                            modifier = Modifier.fillMaxSize(),
                            onOpenSettings = { currentTab = SocialTab.SETTINGS },
                            onSignOutRequested = onSignOutRequested
                        )
                    }
                    SocialTab.SETTINGS -> {
                        SettingsScreen(
                            onBack = { currentTab = SocialTab.FEED },
                            onSignOut = onSignOutRequested,
                            modifier = Modifier.fillMaxSize()
                        )
                    }
                }
            }
        }

        // Bottom Navigation Bar
        val navShape = RoundedCornerShape(topStart = 22.dp, topEnd = 22.dp)
        Surface(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .shadow(elevation = 14.dp, shape = navShape, spotColor = Color(0x30000000))
                .border(width = 0.8.dp, color = Color(0x14000000), shape = navShape)
                .testTag("social_bottom_navigation_bar"),
            shape = navShape,
            color = Color.White
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
                    .height(64.dp)
                    .padding(horizontal = 8.dp),
                horizontalArrangement = Arrangement.SpaceAround,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // 1. Home Feed Tab
                BottomNavItem(
                    label = "الرئيسية",
                    selectedIcon = Icons.Filled.Home,
                    unselectedIcon = Icons.Outlined.Home,
                    isSelected = currentTab == SocialTab.FEED,
                    onClick = { currentTab = SocialTab.FEED },
                    testTag = "nav_tab_feed"
                )

                // 2. Reels Tab
                BottomNavItem(
                    label = "Reels",
                    selectedIcon = Icons.Filled.PlayCircle,
                    unselectedIcon = Icons.Outlined.PlayCircleOutline,
                    isSelected = currentTab == SocialTab.REELS,
                    onClick = {
                        focusedReelPostId = null
                        currentTab = SocialTab.REELS
                    },
                    testTag = "nav_tab_reels"
                )

                // 3. Center Create (+) Button
                Box(
                    modifier = Modifier
                        .size(48.dp)
                        .clip(CircleShape)
                        .background(DrawRed)
                        .clickable { isCreateMenuOpen = true }
                        .testTag("nav_create_button"),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Add,
                        contentDescription = "Create",
                        tint = Color.White,
                        modifier = Modifier.size(28.dp)
                    )

                    DropdownMenu(
                        expanded = isCreateMenuOpen,
                        onDismissRequest = { isCreateMenuOpen = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("منشور صور / فيديو", fontWeight = FontWeight.Bold) },
                            onClick = {
                                isCreateMenuOpen = false
                                isCreatePostOpen = true
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("قصة يومية جديدة (Story)", fontWeight = FontWeight.Bold) },
                            onClick = {
                                isCreateMenuOpen = false
                                isCreateStoryOpen = true
                            }
                        )
                    }
                }

                // 4. Map Tab
                BottomNavItem(
                    label = "الخريطة",
                    selectedIcon = Icons.Filled.Map,
                    unselectedIcon = Icons.Outlined.Map,
                    isSelected = currentTab == SocialTab.MAP,
                    onClick = { currentTab = SocialTab.MAP },
                    testTag = "nav_tab_map"
                )

                // 5. Settings Tab
                BottomNavItem(
                    label = "الإعدادات",
                    selectedIcon = Icons.Filled.Settings,
                    unselectedIcon = Icons.Outlined.Settings,
                    isSelected = currentTab == SocialTab.SETTINGS,
                    onClick = { currentTab = SocialTab.SETTINGS },
                    testTag = "nav_tab_settings"
                )
            }
        }

        // Creation Dialogs
        if (isCreatePostOpen) {
            CreatePostDialog(
                onDismiss = { isCreatePostOpen = false },
                onPostCreated = {
                    isCreatePostOpen = false
                    currentTab = SocialTab.FEED
                }
            )
        }

        if (isCreateStoryOpen) {
            CreateStoryDialog(
                onDismiss = { isCreateStoryOpen = false },
                onStoryCreated = {
                    isCreateStoryOpen = false
                    currentTab = SocialTab.FEED
                }
            )
        }
    }
}

@Composable
private fun BottomNavItem(
    label: String,
    selectedIcon: ImageVector,
    unselectedIcon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(horizontal = 10.dp, vertical = 6.dp)
            .testTag(testTag)
    ) {
        Icon(
            imageVector = if (isSelected) selectedIcon else unselectedIcon,
            contentDescription = label,
            tint = if (isSelected) DrawRed else Color(0xFF8E8E93),
            modifier = Modifier.size(24.dp)
        )
        Spacer(modifier = Modifier.height(2.dp))
        Text(
            text = label,
            fontSize = 10.5.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
            color = if (isSelected) DrawRed else Color(0xFF8E8E93)
        )
    }
}
