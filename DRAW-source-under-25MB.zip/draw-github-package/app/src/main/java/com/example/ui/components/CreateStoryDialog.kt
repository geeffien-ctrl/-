package com.example.ui.components

import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.AudioTrack
import com.example.data.repository.AuthSessionManager
import com.example.data.repository.StoriesRepository
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import kotlinx.coroutines.launch

@Composable
fun CreateStoryDialog(
    onDismiss: () -> Unit,
    onStoryCreated: () -> Unit
) {
    val context = LocalContext.current
    val storiesRepository = remember { StoriesRepository(context) }
    val scope = rememberCoroutineScope()
    val currentUser = remember { AuthSessionManager.getInstance(context).currentUser.value }

    val selectedImages = remember { mutableStateListOf<Uri>() }
    var selectedAudio by remember { mutableStateOf<AudioTrack?>(null) }
    var isAudioPickerOpen by remember { mutableStateOf(false) }
    var isPublishing by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf<String?>(null) }

    val photoPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickMultipleVisualMedia(maxItems = 5)
    ) { uris ->
        if (uris.isNotEmpty()) {
            selectedImages.clear()
            selectedImages.addAll(uris)
        }
    }

    Dialog(
        onDismissRequest = onDismiss,
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        val shape = RoundedCornerShape(26.dp)
        Surface(
            shape = shape,
            color = Color.White,
            shadowElevation = 16.dp,
            modifier = Modifier
                .fillMaxWidth(0.92f)
                .padding(vertical = 20.dp)
                .testTag("create_story_dialog")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .verticalScroll(rememberScrollState())
                    .padding(20.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Header
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "إضافة قصة يومية (Story)",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = DrawTextNearBlack
                    )
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(30.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFE5E5EA))
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Close",
                            tint = Color(0xFF3A3A3C),
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Image Selection Area
                if (selectedImages.isEmpty()) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .background(Color(0xFFF9F9FB))
                            .border(1.5.dp, Color(0x18000000), RoundedCornerShape(20.dp))
                            .clickable {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            }
                            .testTag("story_pick_image_box"),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Icon(
                                imageVector = Icons.Default.AddPhotoAlternate,
                                contentDescription = null,
                                tint = DrawRed,
                                modifier = Modifier.size(44.dp)
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "اضغط لاختيار صورة القصة",
                                fontSize = 14.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = DrawTextNearBlack
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "تنتهي القصة تلقائياً بعد 24 ساعة",
                                fontSize = 12.sp,
                                color = DrawTextSecondary
                            )
                        }
                    }
                } else {
                    // Preview of selected image
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(220.dp)
                            .clip(RoundedCornerShape(20.dp))
                            .border(1.dp, Color(0x18000000), RoundedCornerShape(20.dp))
                    ) {
                        AsyncImage(
                            model = selectedImages.first(),
                            contentDescription = "Story Preview",
                            contentScale = ContentScale.Crop,
                            modifier = Modifier.fillMaxSize()
                        )

                        // If multiple images selected, note that separate stories will be published
                        if (selectedImages.size > 1) {
                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = Color.Black.copy(alpha = 0.7f),
                                modifier = Modifier
                                    .align(Alignment.TopStart)
                                    .padding(10.dp)
                            ) {
                                Text(
                                    text = "سيتم إنشاء ${selectedImages.size} قصص مستقلة",
                                    color = Color.White,
                                    fontSize = 11.5.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        // Change Image button
                        IconButton(
                            onClick = {
                                photoPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            modifier = Modifier
                                .align(Alignment.TopEnd)
                                .padding(8.dp)
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(Color.Black.copy(alpha = 0.6f))
                        ) {
                            Icon(
                                imageVector = Icons.Default.Close,
                                contentDescription = "تغيير",
                                tint = Color.White,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(16.dp))

                // Optional Audio Attachment Button «Sound»
                Surface(
                    onClick = { isAudioPickerOpen = true },
                    shape = RoundedCornerShape(16.dp),
                    color = if (selectedAudio != null) Color(0xFFFFECEB) else Color(0xFFF2F2F7),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (selectedAudio != null) DrawRed else Color(0x14000000)
                    ),
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("story_sound_button")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = if (selectedAudio != null) Icons.Default.GraphicEq else Icons.Default.MusicNote,
                            contentDescription = "Sound",
                            tint = if (selectedAudio != null) DrawRed else DrawTextNearBlack,
                            modifier = Modifier.size(22.dp)
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = if (selectedAudio != null) selectedAudio!!.title else "إضافة صوت (اختياري)",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (selectedAudio != null) DrawRed else DrawTextNearBlack
                            )
                            Text(
                                text = if (selectedAudio != null) "الصوت مرفق بالقصة" else "اختر موسيقى أو مقطع صوتي",
                                fontSize = 11.5.sp,
                                color = DrawTextSecondary
                            )
                        }
                        if (selectedAudio != null) {
                            IconButton(
                                onClick = { selectedAudio = null },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Close,
                                    contentDescription = "حذف الصوت",
                                    tint = DrawRed,
                                    modifier = Modifier.size(16.dp)
                                )
                            }
                        }
                    }
                }

                if (errorMessage != null) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = errorMessage!!,
                        color = DrawRed,
                        fontSize = 12.5.sp,
                        fontWeight = FontWeight.Medium
                    )
                }

                Spacer(modifier = Modifier.height(20.dp))

                // Action Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedButton(
                        onClick = onDismiss,
                        enabled = !isPublishing,
                        shape = RoundedCornerShape(16.dp),
                        modifier = Modifier
                            .weight(1f)
                            .height(48.dp)
                    ) {
                        Text("إلغاء", color = Color(0xFF8E8E93), fontWeight = FontWeight.SemiBold)
                    }

                    Button(
                        onClick = {
                            if (currentUser == null) {
                                errorMessage = "يرجى تسجيل الدخول أولاً"
                                return@Button
                            }
                            if (selectedImages.isEmpty()) {
                                errorMessage = "يرجى اختيار صورة للقصة"
                                return@Button
                            }
                            isPublishing = true
                            errorMessage = null
                            scope.launch {
                                val res = if (selectedImages.size == 1) {
                                    storiesRepository.createSingleStory(
                                        currentUser = currentUser,
                                        imageUri = selectedImages.first(),
                                        audioTrack = selectedAudio,
                                        context = context
                                    ).map { 1 }
                                } else {
                                    storiesRepository.createMultipleStories(
                                        currentUser = currentUser,
                                        imageUris = selectedImages,
                                        audioTrack = selectedAudio,
                                        context = context
                                    )
                                }
                                isPublishing = false
                                res.onSuccess {
                                    onStoryCreated()
                                    onDismiss()
                                }.onFailure { e ->
                                    errorMessage = "فشل نشر القصة: ${e.message}"
                                }
                            }
                        },
                        enabled = selectedImages.isNotEmpty() && !isPublishing,
                        shape = RoundedCornerShape(16.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
                        modifier = Modifier
                            .weight(1.3f)
                            .height(48.dp)
                            .testTag("publish_story_button")
                    ) {
                        if (isPublishing) {
                            CircularProgressIndicator(
                                color = Color.White,
                                modifier = Modifier.size(20.dp),
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("جاري النشر...", color = Color.White, fontWeight = FontWeight.Bold)
                        } else {
                            Text("نشر القصة", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                        }
                    }
                }
            }
        }
    }

    if (isAudioPickerOpen) {
        AudioPickerSheet(
            currentAudio = selectedAudio,
            onAudioSelected = { track ->
                selectedAudio = track
                isAudioPickerOpen = false
            },
            onDismiss = { isAudioPickerOpen = false }
        )
    }
}
