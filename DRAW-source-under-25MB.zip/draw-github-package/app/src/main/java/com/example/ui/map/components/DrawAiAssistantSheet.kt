package com.example.ui.map.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AddComment
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Stop
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.repository.AiConversationSession
import com.example.data.repository.AiPlaceSuggestion
import com.example.ui.map.AiAssistantMessageUi
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * iOS-styled full conversational DRAW AI Assistant modal bottom sheet.
 * Supports:
 * - Real-time Voice speech or text input
 * - Quick prompt suggestions (Fuel, Dining, Cafes, Scenic routes, Traffic tips)
 * - Map control intents (centering, 2D/3D toggle, clear route, nearest landmarks)
 * - Conversation history management with Cloud Firestore
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DrawAiAssistantSheet(
    messages: List<AiAssistantMessageUi>,
    isLoading: Boolean,
    isListening: Boolean,
    conversationSessions: List<AiConversationSession> = emptyList(),
    isGuest: Boolean = false,
    isAiSpeaking: Boolean = false,
    currentlySpeakingMessageId: String? = null,
    isAutoPlayEnabled: Boolean = true,
    onSendMessage: (String) -> Unit,
    onStartVoiceInput: () -> Unit,
    onSelectSuggestion: (AiPlaceSuggestion, Boolean) -> Unit,
    onSelectSession: (String) -> Unit = {},
    onNewChat: () -> Unit = {},
    onToggleSpeech: (messageId: String, text: String) -> Unit = { _, _ -> },
    onToggleAutoPlay: () -> Unit = {},
    onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var inputText by remember { mutableStateOf("") }
  var isHistoryDialogVisible by remember { mutableStateOf(false) }
  val listState = rememberLazyListState()

  // Scroll to bottom when new messages arrive
  LaunchedEffect(messages.size, isLoading) {
    if (messages.isNotEmpty()) {
      listState.animateScrollToItem(messages.size - 1)
    }
  }

  val quickPrompts = remember {
    listOf(
        "أقرب مسجد 🕌",
        "أقرب محطة وقود ⛽",
        "مطاعم مميزة قريبة 🍽️",
        "مقاهي هادئة ☕",
        "ارجع إلى موقعي 📍",
        "بدّل عرض الخريطة 3D 🏙️",
        "قل لي نكتة 😄"
    )
  }

  ModalBottomSheet(
      onDismissRequest = onDismiss,
      sheetState = sheetState,
      containerColor = Color.White,
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      dragHandle = null,
      modifier = Modifier
          .fillMaxWidth()
          .imePadding()
          .testTag("draw_ai_assistant_sheet")
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .heightIn(max = 640.dp)
            .padding(top = 16.dp, bottom = 12.dp)
    ) {
      // 1. Header with title and session actions
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 20.dp, vertical = 6.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
          Box(
              modifier = Modifier
                  .size(38.dp)
                  .clip(CircleShape)
                  .background(
                      Brush.linearGradient(
                          listOf(DrawRed, Color(0xFFFF5252), DrawDarkRed)
                      )
                  ),
              contentAlignment = Alignment.Center
          ) {
            Icon(
                imageVector = Icons.Default.AutoAwesome,
                contentDescription = null,
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
                text = "مساعد DRAW الذكي",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack
            )
            Text(
                text = "المساعد الصوتي والملاحي المباشر",
                fontSize = 12.sp,
                color = DrawTextSecondary
            )
          }
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          // Auto-play Voice Toggle Button
          IconButton(
              onClick = onToggleAutoPlay,
              modifier = Modifier
                  .size(32.dp)
                  .clip(CircleShape)
                  .background(if (isAutoPlayEnabled) Color(0xFFFFECEB) else Color(0xFFF2F2F7))
                  .testTag("ai_toggle_autoplay_button")
          ) {
            Icon(
                imageVector = if (isAutoPlayEnabled) Icons.Default.VolumeUp else Icons.Default.VolumeOff,
                contentDescription = if (isAutoPlayEnabled) "القراءة التلقائية مفعلة" else "القراءة التلقائية معطلة",
                tint = if (isAutoPlayEnabled) DrawRed else DrawTextSecondary,
                modifier = Modifier.size(17.dp)
            )
          }

          // New Chat Button
          IconButton(
              onClick = onNewChat,
              modifier = Modifier
                  .size(32.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFF2F2F7))
                  .testTag("ai_new_chat_button")
          ) {
            Icon(
                imageVector = Icons.Default.AddComment,
                contentDescription = "محادثة جديدة",
                tint = DrawTextNearBlack,
                modifier = Modifier.size(17.dp)
            )
          }

          // History Button
          IconButton(
              onClick = { isHistoryDialogVisible = true },
              modifier = Modifier
                  .size(32.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFF2F2F7))
                  .testTag("ai_history_button")
          ) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = "سجل المحادثات",
                tint = DrawTextNearBlack,
                modifier = Modifier.size(17.dp)
            )
          }

          // Close Button
          IconButton(
              onClick = onDismiss,
              modifier = Modifier
                  .size(32.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFE5E5EA))
                  .testTag("close_ai_assistant_button")
          ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "إغلاق",
                tint = Color(0xFF3A3A3C),
                modifier = Modifier.size(16.dp)
            )
          }
        }
      }

      // 2. Quick suggestion chips
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .horizontalScroll(rememberScrollState())
              .padding(horizontal = 16.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.spacedBy(8.dp)
      ) {
        quickPrompts.forEach { prompt ->
          Surface(
              onClick = {
                onSendMessage(prompt)
              },
              shape = RoundedCornerShape(18.dp),
              color = Color(0xFFF2F2F7),
              border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0x18000000)),
              modifier = Modifier.testTag("ai_quick_prompt_${prompt.take(5)}")
          ) {
            Text(
                text = prompt,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Medium,
                color = DrawTextNearBlack,
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
            )
          }
        }
      }

      // 3. Conversation Messages
      LazyColumn(
          state = listState,
          modifier = Modifier
              .weight(1f)
              .fillMaxWidth()
              .padding(horizontal = 16.dp),
          verticalArrangement = Arrangement.spacedBy(10.dp),
          contentPadding = PaddingValues(vertical = 8.dp)
      ) {
        if (messages.isEmpty() && !isLoading) {
          item {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 32.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Box(
                  modifier = Modifier
                      .size(64.dp)
                      .clip(CircleShape)
                      .background(Color(0xFFFFECEB)),
                  contentAlignment = Alignment.Center
              ) {
                Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = null,
                    tint = DrawRed,
                    modifier = Modifier.size(32.dp)
                )
              }
              Spacer(modifier = Modifier.height(14.dp))
              Text(
                  text = "مرحباً بك! أنا مساعد DRAW للملاحة",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = DrawTextNearBlack
              )
              Spacer(modifier = Modifier.height(4.dp))
              Text(
                  text = "اسألني عن أقرب المساجد والمطاعم، أو اطلب مني تبديل الخريطة، العودة لموقعك، أو حكاية طرفة!",
                  fontSize = 13.sp,
                  color = DrawTextSecondary,
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(horizontal = 24.dp)
              )
            }
          }
        }

        items(messages, key = { it.id }) { message ->
          AiMessageBubble(
              message = message,
              isAiSpeaking = isAiSpeaking,
              currentlySpeakingMessageId = currentlySpeakingMessageId,
              onToggleSpeech = onToggleSpeech,
              onSelectSuggestion = onSelectSuggestion
          )
        }

        if (isLoading) {
          item {
            AssistantLoadingBubble()
          }
        }
      }

      // 4. Voice Listening Pulse Pill
      AnimatedVisibility(
          visible = isListening,
          enter = fadeIn(),
          exit = fadeOut(),
          modifier = Modifier.padding(horizontal = 16.dp, vertical = 4.dp)
      ) {
        val infiniteTransition = rememberInfiniteTransition(label = "voice_pulse")
        val scale by infiniteTransition.animateFloat(
            initialValue = 0.95f,
            targetValue = 1.05f,
            animationSpec = infiniteRepeatable(
                animation = tween(600),
                repeatMode = RepeatMode.Reverse
            ),
            label = "pulse_scale"
        )
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = Color(0xFFFFECEB),
            border = androidx.compose.foundation.BorderStroke(1.dp, DrawRed),
            modifier = Modifier
                .fillMaxWidth()
                .scale(scale)
        ) {
          Row(
              modifier = Modifier.padding(horizontal = 16.dp, vertical = 8.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.Center
          ) {
            Icon(
                imageVector = Icons.Default.Mic,
                contentDescription = null,
                tint = DrawRed,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "جاري الاستماع لصوتك الآن... تحدث بوضوح",
                color = DrawRed,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold
            )
          }
        }
      }

      // 5. Input Bar
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 6.dp),
          verticalAlignment = Alignment.CenterVertically
      ) {
        OutlinedTextField(
            value = inputText,
            onValueChange = { inputText = it },
            placeholder = {
              Text(
                  text = "اكتب استفسارك",
                  fontSize = 14.sp,
                  color = Color(0xFF757575)
              )
            },
            shape = RoundedCornerShape(24.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedTextColor = Color(0xFF111111),
                unfocusedTextColor = Color(0xFF111111),
                focusedContainerColor = Color.White,
                unfocusedContainerColor = Color.White,
                cursorColor = Color(0xFF111111),
                focusedBorderColor = DrawRed,
                unfocusedBorderColor = Color(0x33000000),
                focusedPlaceholderColor = Color(0xFF757575),
                unfocusedPlaceholderColor = Color(0xFF757575)
            ),
            trailingIcon = {
              IconButton(
                  onClick = onStartVoiceInput,
                  modifier = Modifier.size(34.dp)
              ) {
                Icon(
                    imageVector = Icons.Default.Mic,
                    contentDescription = "Voice Input",
                    tint = if (isListening) DrawRed else Color(0xFF8E8E93),
                    modifier = Modifier.size(20.dp)
                )
              }
            },
            singleLine = true,
            modifier = Modifier
                .weight(1f)
                .testTag("ai_assistant_input_field")
        )

        Spacer(modifier = Modifier.width(8.dp))

        // Send Button
        IconButton(
            onClick = {
              if (inputText.isNotBlank()) {
                val toSend = inputText
                inputText = ""
                onSendMessage(toSend)
              }
            },
            enabled = inputText.isNotBlank() && !isLoading,
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(
                    if (inputText.isNotBlank() && !isLoading) DrawRed else Color(0xFFE5E5EA)
                )
                .testTag("ai_assistant_send_button")
        ) {
          Icon(
              imageVector = Icons.AutoMirrored.Filled.Send,
              contentDescription = "Send",
              tint = if (inputText.isNotBlank() && !isLoading) Color.White else Color(0xFF8E8E93),
              modifier = Modifier.size(20.dp)
          )
        }
      }
    }
  }

  // Conversation History Dialog
  if (isHistoryDialogVisible) {
    AlertDialog(
        onDismissRequest = { isHistoryDialogVisible = false },
        title = {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.History,
                contentDescription = null,
                tint = DrawRed,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "سجل المحادثات السابقة",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp
            )
          }
        },
        text = {
          if (isGuest) {
            Text(
                text = "أنت تتصفح كضيف. سجل المحادثات والذاكرة السحابية متاحان عند تسجيل الدخول لحسابك لحفظ محادثاتك بأمان ومزامنتها.",
                fontSize = 13.5.sp,
                color = DrawTextSecondary,
                lineHeight = 20.sp
            )
          } else if (conversationSessions.isEmpty()) {
            Text(
                text = "لا توجد محادثات سابقة محفوظة في حسابك بعد. ابدأ بسؤال المساعد الذكي وستُحفظ محادثاتك تلقائياً في السحابة.",
                fontSize = 13.5.sp,
                color = DrawTextSecondary,
                lineHeight = 20.sp
            )
          } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 300.dp),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              items(conversationSessions) { session ->
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFF9F9FB),
                    border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0x14000000)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                          onSelectSession(session.id)
                          isHistoryDialogVisible = false
                        }
                ) {
                  Row(
                      modifier = Modifier.padding(12.dp),
                      verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = null,
                        tint = DrawRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(10.dp))
                    Column(modifier = Modifier.weight(1f)) {
                      Text(
                          text = session.title.ifBlank { "محادثة سابقة" },
                          fontSize = 13.5.sp,
                          fontWeight = FontWeight.SemiBold,
                          color = DrawTextNearBlack,
                          maxLines = 1,
                          overflow = TextOverflow.Ellipsis
                      )
                      if (session.lastSnippet.isNotBlank()) {
                        Text(
                            text = session.lastSnippet,
                            fontSize = 11.5.sp,
                            color = DrawTextSecondary,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                      }
                    }
                  }
                }
              }
            }
          }
        },
        confirmButton = {
          TextButton(onClick = { isHistoryDialogVisible = false }) {
            Text("إغلاق", color = DrawTextNearBlack, fontWeight = FontWeight.Bold)
          }
        },
        shape = RoundedCornerShape(20.dp)
    )
  }
}

@Composable
private fun AiMessageBubble(
    message: AiAssistantMessageUi,
    isAiSpeaking: Boolean = false,
    currentlySpeakingMessageId: String? = null,
    onToggleSpeech: (messageId: String, text: String) -> Unit = { _, _ -> },
    onSelectSuggestion: (AiPlaceSuggestion, Boolean) -> Unit
) {
  val isUser = message.sender == "user"

  Column(
      modifier = Modifier.fillMaxWidth(),
      horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
  ) {
    Surface(
        shape = RoundedCornerShape(
            topStart = 18.dp,
            topEnd = 18.dp,
            bottomStart = if (isUser) 18.dp else 4.dp,
            bottomEnd = if (isUser) 4.dp else 18.dp
        ),
        color = if (isUser) DrawRed else Color(0xFFF2F2F7),
        border = if (isUser) null else androidx.compose.foundation.BorderStroke(0.5.dp, Color(0x14000000)),
        modifier = Modifier
            .fillMaxWidth(0.85f)
            .shadow(if (isUser) 1.dp else 0.dp, RoundedCornerShape(18.dp))
            .testTag(if (isUser) "ai_user_bubble" else "ai_assistant_bubble")
    ) {
      Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp)) {
        Text(
            text = message.text,
            fontSize = 14.sp,
            color = if (isUser) Color.White else DrawTextNearBlack,
            lineHeight = 20.sp
        )

        // Suggested place card attached to response
        if (message.suggestedPlace != null) {
          val place = message.suggestedPlace
          Spacer(modifier = Modifier.height(10.dp))
          Surface(
              shape = RoundedCornerShape(14.dp),
              color = Color.White,
              border = androidx.compose.foundation.BorderStroke(0.8.dp, Color(0x18000000)),
              modifier = Modifier.fillMaxWidth()
          ) {
            Column(modifier = Modifier.padding(12.dp)) {
              Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(32.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFFFECEB)),
                    contentAlignment = Alignment.Center
                ) {
                  Icon(
                      imageVector = Icons.Default.Place,
                      contentDescription = null,
                      tint = DrawRed,
                      modifier = Modifier.size(18.dp)
                  )
                }
                Spacer(modifier = Modifier.width(8.dp))
                Column(modifier = Modifier.weight(1f)) {
                  Text(
                      text = place.name,
                      fontSize = 13.5.sp,
                      fontWeight = FontWeight.Bold,
                      color = DrawTextNearBlack,
                      maxLines = 1,
                      overflow = TextOverflow.Ellipsis
                  )
                  if (place.description.isNotBlank()) {
                    Text(
                        text = place.description,
                        fontSize = 11.5.sp,
                        color = DrawTextSecondary,
                        maxLines = 1,
                        overflow = TextOverflow.Ellipsis
                    )
                  }
                }
              }

              Spacer(modifier = Modifier.height(10.dp))

              Row(
                  modifier = Modifier.fillMaxWidth(),
                  horizontalArrangement = Arrangement.spacedBy(6.dp)
              ) {
                // Show on Map
                Button(
                    onClick = { onSelectSuggestion(place, false) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF2F2F7)),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                ) {
                  Text(
                      text = "تحديد على الخريطة",
                      fontSize = 11.5.sp,
                      fontWeight = FontWeight.Medium,
                      color = DrawTextNearBlack
                  )
                }

                // Start Navigation
                Button(
                    onClick = { onSelectSuggestion(place, true) },
                    shape = RoundedCornerShape(12.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007AFF)),
                    modifier = Modifier
                        .weight(1f)
                        .height(34.dp)
                ) {
                  Row(
                      horizontalArrangement = Arrangement.Center,
                      verticalAlignment = Alignment.CenterVertically
                  ) {
                    Icon(
                        imageVector = Icons.Default.Directions,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(14.dp)
                    )
                    Spacer(modifier = Modifier.width(4.dp))
                    Text(
                        text = "بدء المسار",
                        fontSize = 11.5.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                  }
                }
              }
            }
          }
        }

        // Voice TTS Speak / Stop Button for assistant responses
        if (!isUser) {
          val isCurrentSpeaking = isAiSpeaking && currentlySpeakingMessageId == message.id
          Spacer(modifier = Modifier.height(6.dp))
          Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.End,
              verticalAlignment = Alignment.CenterVertically
          ) {
            Surface(
                onClick = { onToggleSpeech(message.id, message.text) },
                shape = RoundedCornerShape(12.dp),
                color = if (isCurrentSpeaking) Color(0xFFFFECEB) else Color(0x0C000000),
                modifier = Modifier.testTag("ai_speech_button_${message.id.take(6)}")
            ) {
              Row(
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                  verticalAlignment = Alignment.CenterVertically
              ) {
                Icon(
                    imageVector = if (isCurrentSpeaking) Icons.Default.Stop else Icons.Default.VolumeUp,
                    contentDescription = if (isCurrentSpeaking) "إيقاف الصوت" else "نطق الإجابة",
                    tint = if (isCurrentSpeaking) DrawRed else DrawTextSecondary,
                    modifier = Modifier.size(14.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = if (isCurrentSpeaking) "إيقاف الصوت" else "نطق الإجابة",
                    fontSize = 11.5.sp,
                    fontWeight = FontWeight.Medium,
                    color = if (isCurrentSpeaking) DrawRed else DrawTextSecondary
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun AssistantLoadingBubble() {
  Surface(
      shape = RoundedCornerShape(18.dp),
      color = Color(0xFFF2F2F7),
      border = androidx.compose.foundation.BorderStroke(0.5.dp, Color(0x18000000)),
      modifier = Modifier.padding(vertical = 4.dp)
  ) {
    Row(
        modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
      CircularProgressIndicator(
          strokeWidth = 2.dp,
          color = DrawRed,
          modifier = Modifier.size(16.dp)
      )
      Spacer(modifier = Modifier.width(10.dp))
      Text(
          text = "مساعد DRAW يفكر في إجابتك...",
          fontSize = 13.sp,
          color = DrawTextSecondary
      )
    }
  }
}
