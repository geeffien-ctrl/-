package com.example.ui.map.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.TurnRight
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.OsrmRoute
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * Bottom card displaying route overview, distance, time, and "Start Navigation" button.
 */
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import com.example.ui.map.navigation.RouteOption

/**
 * Bottom card displaying route options (up to 4 with Blue, Red, Orange, Yellow),
 * distance, duration, and "Start Navigation" button.
 */
@Composable
fun RouteSummaryCard(
    routeOptions: List<RouteOption>,
    selectedRouteIndex: Int,
    destinationName: String,
    onSelectRoute: (Int) -> Unit,
    onStartNavigation: () -> Unit,
    onDismissRoute: () -> Unit,
    modifier: Modifier = Modifier
) {
  val activeOption = routeOptions.find { it.index == selectedRouteIndex }
      ?: routeOptions.firstOrNull()
  val activeRoute = activeOption?.route

  val shape = RoundedCornerShape(26.dp)

  Surface(
      modifier = modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp)
          .shadow(elevation = 14.dp, shape = shape, spotColor = Color(0x38000000))
          .border(width = 0.8.dp, color = Color(0x18000000), shape = shape)
          .testTag("route_summary_card"),
      shape = shape,
      color = Color(0xFDFDFDFF)
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp)
    ) {
      // Header: Route title & close button
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        val activeColor = activeOption?.let {
          try { Color(android.graphics.Color.parseColor(it.colorHex)) } catch (e: Exception) { Color(0xFF007AFF) }
        } ?: Color(0xFF007AFF)

        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
              modifier = Modifier
                  .size(32.dp)
                  .clip(CircleShape)
                  .background(activeColor.copy(alpha = 0.15f)),
              contentAlignment = Alignment.Center
          ) {
            Icon(
                imageVector = Icons.Default.DirectionsCar,
                contentDescription = null,
                tint = activeColor,
                modifier = Modifier.size(18.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
              text = if (routeOptions.size > 1) {
                "${activeOption?.colorNameArabic ?: "المسار"} (${activeOption?.rankDescriptionArabic ?: "الأمثل"})"
              } else {
                "مسار القيادة الأنسب"
              },
              fontSize = 13.5.sp,
              fontWeight = FontWeight.Bold,
              color = activeColor
          )
        }

        IconButton(
            onClick = onDismissRoute,
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFFE5E5EA))
                .testTag("dismiss_route_button")
        ) {
          Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Dismiss Route",
              tint = Color(0xFF3A3A3C),
              modifier = Modifier.size(16.dp)
          )
        }
      }

      // Multi-Route Selector Pills (Blue, Red, Orange, Yellow)
      if (routeOptions.size > 1) {
        Spacer(modifier = Modifier.height(12.dp))
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          routeOptions.forEach { opt ->
            val isSelected = (opt.index == selectedRouteIndex)
            val pillColor = try {
              Color(android.graphics.Color.parseColor(opt.colorHex))
            } catch (e: Exception) {
              Color(0xFF007AFF)
            }

            Surface(
                shape = RoundedCornerShape(16.dp),
                color = if (isSelected) pillColor.copy(alpha = 0.12f) else Color(0xFFF2F2F7),
                border = androidx.compose.foundation.BorderStroke(
                    width = if (isSelected) 2.dp else 1.dp,
                    color = if (isSelected) pillColor else Color(0xFFE5E5EA)
                ),
                modifier = Modifier
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onSelectRoute(opt.index) }
                    .testTag("route_option_chip_${opt.index}")
            ) {
              Row(
                  modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                  verticalAlignment = Alignment.CenterVertically
              ) {
                Box(
                    modifier = Modifier
                        .size(12.dp)
                        .clip(CircleShape)
                        .background(pillColor)
                )
                Spacer(modifier = Modifier.width(8.dp))
                Column {
                  Text(
                      text = opt.colorNameArabic,
                      fontSize = 12.sp,
                      fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                      color = if (isSelected) pillColor else DrawTextNearBlack
                  )
                  Text(
                      text = "${opt.route.formattedDistance} • ${opt.route.formattedDuration}",
                      fontSize = 10.5.sp,
                      color = DrawTextSecondary
                  )
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // Main stats: Duration & Distance
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.Bottom
      ) {
        Column {
          Text(
              text = activeRoute?.formattedDuration ?: "0 min",
              fontSize = 26.sp,
              fontWeight = FontWeight.ExtraBold,
              color = Color(0xFF34C759) // iOS Green
          )
          Text(
              text = "المسافة: ${activeRoute?.formattedDistance ?: "0 m"}",
              fontSize = 14.sp,
              fontWeight = FontWeight.Medium,
              color = DrawTextSecondary
          )
        }

        // Destination name tag
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFF2F2F7))
                .padding(horizontal = 10.dp, vertical = 6.dp)
        ) {
          Text(
              text = destinationName,
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              color = DrawTextNearBlack,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
          )
        }
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Start Navigation Button
      Button(
          onClick = onStartNavigation,
          shape = RoundedCornerShape(20.dp),
          colors = ButtonDefaults.buttonColors(
              containerColor = DrawRed,
              contentColor = Color.White
          ),
          modifier = Modifier
              .fillMaxWidth()
              .height(52.dp)
              .testTag("start_navigation_button")
      ) {
        Icon(
            imageVector = Icons.Default.Navigation,
            contentDescription = null,
            modifier = Modifier.size(20.dp)
        )
        Spacer(modifier = Modifier.width(8.dp))
        Text(
            text = "بدء الملاحة الآن",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp
        )
      }
    }
  }
}

/**
 * Backward compatibility overload for single route.
 */
@Composable
fun RouteSummaryCard(
    route: OsrmRoute,
    destinationName: String,
    onStartNavigation: () -> Unit,
    onDismissRoute: () -> Unit,
    modifier: Modifier = Modifier
) {
  RouteSummaryCard(
      routeOptions = listOf(
          RouteOption(
              index = 0,
              colorHex = "#007AFF",
              colorNameArabic = "المسار الأزرق",
              rankDescriptionArabic = "أقصر مسار",
              route = route
          )
      ),
      selectedRouteIndex = 0,
      destinationName = destinationName,
      onSelectRoute = {},
      onStartNavigation = onStartNavigation,
      onDismissRoute = onDismissRoute,
      modifier = modifier
  )
}

/**
 * Arrival Celebration Card with checkmark, red luxury styling, and confirmation button.
 */
@Composable
fun ArrivalCelebrationCard(
    destinationName: String,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier
) {
  val shape = RoundedCornerShape(28.dp)

  Surface(
      modifier = modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 12.dp)
          .shadow(elevation = 18.dp, shape = shape, spotColor = Color(0x55E50914))
          .border(width = 1.5.dp, color = Color.White.copy(alpha = 0.4f), shape = shape)
          .testTag("arrival_celebration_card"),
      shape = shape,
      color = DrawRed
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
      Box(
          modifier = Modifier
              .size(68.dp)
              .clip(CircleShape)
              .background(Color.White.copy(alpha = 0.22f)),
          contentAlignment = Alignment.Center
      ) {
        Icon(
            imageVector = Icons.Default.CheckCircle,
            contentDescription = "تم الوصول بنجاح",
            tint = Color.White,
            modifier = Modifier.size(46.dp)
        )
      }

      Spacer(modifier = Modifier.height(14.dp))

      Text(
          text = "نجحت المهمة! وصلت إلى وجهتك",
          fontSize = 20.sp,
          fontWeight = FontWeight.ExtraBold,
          color = Color.White,
          textAlign = androidx.compose.ui.text.style.TextAlign.Center
      )

      if (destinationName.isNotBlank()) {
        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = destinationName,
            fontSize = 14.5.sp,
            fontWeight = FontWeight.Medium,
            color = Color.White.copy(alpha = 0.92f),
            textAlign = androidx.compose.ui.text.style.TextAlign.Center,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.height(20.dp))

      Button(
          onClick = onDismiss,
          shape = RoundedCornerShape(16.dp),
          colors = ButtonDefaults.buttonColors(
              containerColor = Color.White,
              contentColor = DrawRed
          ),
          modifier = Modifier
              .fillMaxWidth()
              .height(48.dp)
              .testTag("arrival_dismiss_button")
      ) {
        Text(
            text = "إغلاق ✓",
            fontWeight = FontWeight.Bold,
            fontSize = 16.sp,
            color = DrawRed
        )
      }
    }
  }
}

/**
 * Top turn-by-turn banner displayed during active navigation.
 */
@Composable
fun NavigationTurnBanner(
    route: OsrmRoute,
    currentStepIndex: Int,
    isVoiceMuted: Boolean = false,
    onToggleMute: () -> Unit = {},
    onNextStep: () -> Unit,
    onStopNavigation: () -> Unit,
    modifier: Modifier = Modifier
) {
  val steps = route.legs.firstOrNull()?.steps ?: emptyList()
  val step = steps.getOrNull(currentStepIndex)
  val stepInstruction = step?.maneuver?.instruction
      ?: step?.name?.let { if (it.isNotBlank()) "تابع على $it" else null }
      ?: "تابع السير على المسار المحدد"

  val stepDistance = step?.let {
    if (it.distance < 1000) "${it.distance.toInt()} م" else "%.1f كم".format(it.distance / 1000.0)
  } ?: "300 م"

  val shape = RoundedCornerShape(24.dp)

  Surface(
      modifier = modifier
          .fillMaxWidth()
          .padding(horizontal = 14.dp, vertical = 8.dp)
          .shadow(elevation = 12.dp, shape = shape, spotColor = Color(0x38000000))
          .border(width = 1.dp, color = Color(0x22000000), shape = shape)
          .testTag("navigation_turn_banner"),
      shape = shape,
      color = Color(0xF51C1C1E) // iOS Dark Blur Style for high contrast navigation
  ) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 16.dp, vertical = 14.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
      // Maneuver Turn Icon
      Box(
          modifier = Modifier
              .size(44.dp)
              .clip(CircleShape)
              .background(Color(0xFF34C759)),
          contentAlignment = Alignment.Center
      ) {
        Icon(
            imageVector = Icons.Default.TurnRight,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(26.dp)
        )
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        Text(
            text = "بعد $stepDistance",
            fontSize = 13.sp,
            fontWeight = FontWeight.SemiBold,
            color = Color(0xFF34C759)
        )
        Text(
            text = stepInstruction,
            fontSize = 15.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      // Voice guidance mute toggle
      IconButton(
          onClick = onToggleMute,
          modifier = Modifier
              .size(36.dp)
              .clip(CircleShape)
              .background(Color(0xFF2C2C2E))
              .testTag("nav_voice_mute_button")
      ) {
        Icon(
            imageVector = if (isVoiceMuted) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
            contentDescription = if (isVoiceMuted) "تشغيل الصوت" else "كتم الصوت",
            tint = if (isVoiceMuted) Color(0xFFFF9500) else Color.White,
            modifier = Modifier.size(18.dp)
        )
      }
      Spacer(modifier = Modifier.width(6.dp))

      // Next step arrow
      if (currentStepIndex < steps.size - 1) {
        IconButton(
            onClick = onNextStep,
            modifier = Modifier
                .size(36.dp)
                .clip(CircleShape)
                .background(Color(0xFF2C2C2E))
        ) {
          Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowForward,
              contentDescription = "Next maneuver",
              tint = Color.White,
              modifier = Modifier.size(18.dp)
          )
        }
        Spacer(modifier = Modifier.width(6.dp))
      }

      // Exit navigation button
      Button(
          onClick = onStopNavigation,
          shape = RoundedCornerShape(14.dp),
          colors = ButtonDefaults.buttonColors(
              containerColor = DrawRed,
              contentColor = Color.White
          ),
          modifier = Modifier
              .height(36.dp)
              .testTag("exit_navigation_button")
      ) {
        Text(
            text = "إنهاء",
            fontWeight = FontWeight.Bold,
            fontSize = 13.sp
        )
      }
    }
  }
}
