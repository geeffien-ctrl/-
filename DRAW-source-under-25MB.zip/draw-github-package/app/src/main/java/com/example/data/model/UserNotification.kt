package com.example.data.model

/**
 * Model representing an activity notification for a user (likes on their place, comments, comment likes).
 */
data class UserNotification(
    val id: String = "",
    val recipientId: String = "",
    val actorId: String = "",
    val actorName: String = "",
    val actorPhotoUrl: String = "",
    val type: String = "", // "PLACE_LIKE", "PLACE_COMMENT", "COMMENT_LIKE"
    val placeId: String = "",
    val placeTitle: String = "",
    val commentId: String? = null,
    val commentTextSnippet: String? = null,
    val read: Boolean = false,
    val createdAt: Long = System.currentTimeMillis()
)
