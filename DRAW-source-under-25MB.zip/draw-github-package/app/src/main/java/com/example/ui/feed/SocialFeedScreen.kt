package com.example.ui.feed

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DynamicFeed
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Tune
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.derivedStateOf
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.runtime.snapshotFlow
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.Post
import com.example.data.model.Story
import com.example.data.repository.PostsRepository
import com.example.data.repository.StoriesRepository
import com.example.data.repository.AuthSessionManager
import com.example.data.util.AudioPlayerManager
import com.example.ui.components.CreatePostDialog
import com.example.ui.components.CreateStoryDialog
import com.example.ui.components.StoryViewerDialog
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

/**
 * ZOLAVOR Social Home Page structured in exact vertical order:
 * 1. Top Search Bar
 * 2. Stories Row (24h Daily Stories)
 * 3. Vertical Feed of Posts (Single/Multi-Image with audio, or video previews)
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun SocialFeedScreen(
    onOpenVideoInReels: (Post) -> Unit,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val focusManager = LocalFocusManager.current
    val postsRepository = remember { PostsRepository(context) }
    val storiesRepository = remember { StoriesRepository(context) }
    val sessionManager = remember { AuthSessionManager.getInstance(context) }
    val currentUser by sessionManager.currentUser.collectAsStateWithLifecycle()
    val user = currentUser
    val currentUserId = user?.uid ?: ""

    // 1. User following list
    val followingUserIds by postsRepository.getFollowingUserIdsFlow(currentUserId)
        .collectAsStateWithLifecycle(initialValue = emptySet())

    // 2. Feed posts (following accounts, or recent community posts if following is empty)
    val feedPosts by postsRepository.getFeedPostsFlow(followingUserIds, currentUserId)
        .collectAsStateWithLifecycle(initialValue = emptyList())

    // 3. Active 24h stories
    val activeStories by storiesRepository.getActiveStoriesFlow(followingUserIds, currentUserId)
        .collectAsStateWithLifecycle(initialValue = emptyList())

    // Search query state
    var searchQuery by remember { mutableStateOf("") }
    val filteredPosts = remember(feedPosts, searchQuery) {
        if (searchQuery.trim().isBlank()) {
            feedPosts
        } else {
            val q = searchQuery.trim().lowercase()
            feedPosts.filter {
                it.caption.lowercase().contains(q) ||
                        it.creatorName.lowercase().contains(q)
            }
        }
    }

    // Story viewer & creation dialogs
    var isStoryViewerOpen by remember { mutableStateOf(false) }
    var viewerInitialStoryIndex by remember { mutableIntStateOf(0) }
    var isCreateStoryOpen by remember { mutableStateOf(false) }
    var isCreatePostOpen by remember { mutableStateOf(false) }
    var activeCommentPostId by remember { mutableStateOf<String?>(null) }

    // LazyColumn scroll state for audio crossfade transitions
    val listState = rememberLazyListState()

    // Audio Cross-fade Transition: Monitor currently visible item in viewport
    LaunchedEffect(listState) {
        snapshotFlow { listState.firstVisibleItemIndex }
            .distinctUntilChanged()
            .collect { firstIndex ->
                // First index might be 0 (Search/Stories header)
                val postIndex = firstIndex - 1
                if (postIndex in filteredPosts.indices) {
                    val visiblePost = filteredPosts[postIndex]
                    if (visiblePost.hasAudio) {
                        AudioPlayerManager.play(context, visiblePost.audioUrl, visiblePost.audioTitle)
                    } else {
                        AudioPlayerManager.stop(fade = true)
                    }
                } else {
                    AudioPlayerManager.stop(fade = true)
                }
            }
    }

    DisposableEffect(Unit) {
        onDispose {
            AudioPlayerManager.stop(fade = false)
        }
    }

    val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color(0xFFF6F6F8))
            .testTag("social_feed_screen")
    ) {
        LazyColumn(
            state = listState,
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(bottom = 90.dp)
        ) {
            // Section 1 & 2: Search Bar + Stories Row (Pinned at the top of the feed)
            item(key = "feed_top_header") {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = statusBarPadding + 10.dp)
                ) {
                    // 1. TOP SEARCH BAR
                    Surface(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp)
                            .height(50.dp)
                            .shadow(elevation = 4.dp, shape = RoundedCornerShape(22.dp), spotColor = Color(0x18000000))
                            .border(width = 0.8.dp, color = Color(0x18000000), shape = RoundedCornerShape(22.dp))
                            .testTag("social_feed_search_bar"),
                        shape = RoundedCornerShape(22.dp),
                        color = Color.White
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 14.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Search,
                                contentDescription = "Search",
                                tint = Color(0xFF8E8E93),
                                modifier = Modifier.size(20.dp)
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Box(
                                modifier = Modifier.weight(1f),
                                contentAlignment = Alignment.CenterStart
                            ) {
                                if (searchQuery.isEmpty()) {
                                    Text(
                                        text = "ابحث عن منشور، منشئ محتوى، أو فكرة...",
                                        color = Color(0xFF8E8E93),
                                        fontSize = 14.sp,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis
                                    )
                                }
                                BasicTextField(
                                    value = searchQuery,
                                    onValueChange = { searchQuery = it },
                                    singleLine = true,
                                    textStyle = TextStyle(
                                        color = DrawTextNearBlack,
                                        fontSize = 14.5.sp,
                                        fontWeight = FontWeight.Normal
                                    ),
                                    keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
                                    keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
                                    modifier = Modifier.fillMaxWidth().testTag("social_search_input")
                                )
                            }
                            if (searchQuery.isNotEmpty()) {
                                IconButton(
                                    onClick = {
                                        searchQuery = ""
                                        focusManager.clearFocus()
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Close,
                                        contentDescription = "Clear",
                                        tint = Color(0xFF8E8E93),
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    // 2. STORIES ROW (Daily 24h Stories)
                    StoriesRow(
                        stories = activeStories,
                        currentUser = user,
                        onCreateStoryClick = { isCreateStoryOpen = true },
                        onStoryClick = { list, idx ->
                            viewerInitialStoryIndex = idx
                            isStoryViewerOpen = true
                        }
                    )

                    Spacer(modifier = Modifier.height(8.dp))
                    HorizontalDivider(color = Color(0x10000000), thickness = 0.8.dp)
                    Spacer(modifier = Modifier.height(4.dp))
                }
            }

            // Section 3: FEED POSTS
            if (filteredPosts.isEmpty()) {
                item(key = "feed_empty_state") {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 48.dp, horizontal = 24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(
                            horizontalAlignment = Alignment.CenterHorizontally,
                            verticalArrangement = Arrangement.spacedBy(10.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(68.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFFFFECEB)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.DynamicFeed,
                                    contentDescription = null,
                                    tint = DrawRed,
                                    modifier = Modifier.size(36.dp)
                                )
                            }
                            Text(
                                text = if (searchQuery.isNotBlank()) "لم يتم العثور على نتائج" else "موجز المنشورات فارغ حالياً",
                                fontSize = 16.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = DrawTextNearBlack
                            )
                            Text(
                                text = if (searchQuery.isNotBlank()) "جرب البحث بكلمات أخرى" else "تابع مستخدمين أو انشر أول صورة/فيديو مع صوت عبر زر الإنشاء (+)",
                                fontSize = 13.sp,
                                color = DrawTextSecondary,
                                textAlign = TextAlign.Center
                            )
                        }
                    }
                }
            } else {
                items(filteredPosts, key = { it.id }) { post ->
                    val isLiked by postsRepository.isPostLikedFlow(post.id, currentUserId)
                        .collectAsStateWithLifecycle(initialValue = false)
                    val isSaved by postsRepository.isPostSavedFlow(currentUserId, post.id)
                        .collectAsStateWithLifecycle(initialValue = false)
                    val isFollowing = followingUserIds.contains(post.creatorId)

                    PostCard(
                        post = post,
                        isLiked = isLiked,
                        isSaved = isSaved,
                        isFollowing = isFollowing,
                        currentUserId = currentUserId,
                        onToggleLike = {
                            if (user != null) {
                                scope.launch { postsRepository.togglePostLike(post.id, user) }
                            }
                        },
                        onToggleSave = {
                            if (user != null) {
                                scope.launch { postsRepository.toggleSavePost(currentUserId, post.id) }
                            }
                        },
                        onToggleFollow = {
                            if (user != null) {
                                scope.launch { postsRepository.toggleFollow(currentUserId, post.creatorId) }
                            }
                        },
                        onOpenComments = { activeCommentPostId = post.id },
                        onOpenVideoInReels = { onOpenVideoInReels(post) }
                    )
                }
            }
        }

        // Dialogs
        if (isStoryViewerOpen && activeStories.isNotEmpty()) {
            StoryViewerDialog(
                stories = activeStories,
                initialIndex = viewerInitialStoryIndex,
                onDismiss = { isStoryViewerOpen = false }
            )
        }

        if (isCreateStoryOpen) {
            CreateStoryDialog(
                onDismiss = { isCreateStoryOpen = false },
                onStoryCreated = { isCreateStoryOpen = false }
            )
        }

        if (isCreatePostOpen) {
            CreatePostDialog(
                onDismiss = { isCreatePostOpen = false },
                onPostCreated = { isCreatePostOpen = false }
            )
        }

        if (activeCommentPostId != null) {
            PostCommentsBottomSheet(
                postId = activeCommentPostId!!,
                onDismiss = { activeCommentPostId = null }
            )
        }
    }
}
