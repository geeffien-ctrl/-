package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.webkit.WebView
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

/**
 * Manages user local preferences for DRAW navigation.
 */
class SettingsPreferences(private val context: Context) {

  private val prefs: SharedPreferences =
      context.getSharedPreferences("draw_app_preferences", Context.MODE_PRIVATE)

  private val _defaultTo3D = MutableStateFlow(prefs.getBoolean(KEY_DEFAULT_3D, false))
  val defaultTo3D: StateFlow<Boolean> = _defaultTo3D.asStateFlow()

  private val _voiceGuidanceEnabled = MutableStateFlow(prefs.getBoolean(KEY_VOICE_GUIDANCE, true))
  val voiceGuidanceEnabled: StateFlow<Boolean> = _voiceGuidanceEnabled.asStateFlow()

  // Requirement 5.a: Master Voice for Navigation (Alerts only: turn instructions, hazards, speed cameras)
  private val _masterVoiceEnabled = MutableStateFlow(prefs.getBoolean(KEY_MASTER_VOICE, true))
  val masterVoiceEnabled: StateFlow<Boolean> = _masterVoiceEnabled.asStateFlow()

  // Requirement 5.b: Talking AI Driving Companion (Periodic 10s tips, weather, route, safety)
  private val _aiCompanionVoiceEnabled = MutableStateFlow(prefs.getBoolean(KEY_AI_COMPANION_VOICE, true))
  val aiCompanionVoiceEnabled: StateFlow<Boolean> = _aiCompanionVoiceEnabled.asStateFlow()

  private val _show3DBuildings = MutableStateFlow(prefs.getBoolean(KEY_3D_BUILDINGS, true))
  val show3DBuildings: StateFlow<Boolean> = _show3DBuildings.asStateFlow()

  private val _transportMode = MutableStateFlow(prefs.getString(KEY_TRANSPORT_MODE, "driving") ?: "driving")
  val transportMode: StateFlow<String> = _transportMode.asStateFlow()

  private val _distanceUnit = MutableStateFlow(prefs.getString(KEY_DISTANCE_UNIT, "km") ?: "km")
  val distanceUnit: StateFlow<String> = _distanceUnit.asStateFlow()

  fun setDefaultTo3D(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_DEFAULT_3D, enabled).apply()
    _defaultTo3D.value = enabled
  }

  fun setVoiceGuidanceEnabled(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_VOICE_GUIDANCE, enabled).apply()
    _voiceGuidanceEnabled.value = enabled
    setMasterVoiceEnabled(enabled)
  }

  fun setMasterVoiceEnabled(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_MASTER_VOICE, enabled).apply()
    _masterVoiceEnabled.value = enabled
  }

  fun setAiCompanionVoiceEnabled(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_AI_COMPANION_VOICE, enabled).apply()
    _aiCompanionVoiceEnabled.value = enabled
  }

  fun setShow3DBuildings(enabled: Boolean) {
    prefs.edit().putBoolean(KEY_3D_BUILDINGS, enabled).apply()
    _show3DBuildings.value = enabled
  }

  fun setTransportMode(mode: String) {
    prefs.edit().putString(KEY_TRANSPORT_MODE, mode).apply()
    _transportMode.value = mode
  }

  fun setDistanceUnit(unit: String) {
    prefs.edit().putString(KEY_DISTANCE_UNIT, unit).apply()
    _distanceUnit.value = unit
  }

  fun clearMapCache(): Boolean {
    return try {
      val webView = WebView(context.applicationContext)
      webView.clearCache(true)
      true
    } catch (e: Exception) {
      false
    }
  }

  companion object {
    private const val KEY_DEFAULT_3D = "pref_default_3d"
    private const val KEY_VOICE_GUIDANCE = "pref_voice_guidance"
    private const val KEY_MASTER_VOICE = "pref_master_voice"
    private const val KEY_AI_COMPANION_VOICE = "pref_ai_companion_voice"
    private const val KEY_3D_BUILDINGS = "pref_3d_buildings"
    private const val KEY_TRANSPORT_MODE = "pref_transport_mode"
    private const val KEY_DISTANCE_UNIT = "pref_distance_unit"
  }
}
