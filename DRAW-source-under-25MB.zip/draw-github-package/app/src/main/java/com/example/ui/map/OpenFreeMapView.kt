package com.example.ui.map

import android.annotation.SuppressLint
import android.location.Location
import android.os.Handler
import android.os.Looper
import android.util.Log
import android.view.View
import android.view.ViewGroup
import android.webkit.JavascriptInterface
import android.webkit.WebChromeClient
import android.webkit.WebSettings
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.example.data.model.LiveVehicle
import com.example.data.model.NominatimResult
import com.example.data.model.OsrmRoute
import com.example.data.model.PublicPlace
import com.example.data.model.RoadReport
import com.example.data.model.UserVehicleProfile
import com.example.ui.map.components.PlaceIconRegistry
import com.example.ui.map.navigation.RouteOption
import org.json.JSONArray
import org.json.JSONObject

class OpenFreeMapBridge(
    private val onPerspectiveChangedListener: (Boolean) -> Unit,
    private val onMapReadyListener: () -> Unit,
    private val onMapClickListener: (Double, Double) -> Unit,
    private val onPublicPlaceClickListener: (String) -> Unit,
    private val onMapBoundsChangedListener: (Double, Double, Double, Double) -> Unit = { _, _, _, _ -> },
    private val onUserReverseListener: (Double, Double) -> Unit = { _, _ -> },
    private val onRoadReportClickListener: (String) -> Unit = {},
    private val onVehicleClickListener: (String) -> Unit = {}
) {
  private val mainHandler = Handler(Looper.getMainLooper())

  @JavascriptInterface
  fun onPerspectiveChanged(is3D: Boolean) {
    mainHandler.post {
      onPerspectiveChangedListener(is3D)
    }
  }

  @JavascriptInterface
  fun onMapReady() {
    mainHandler.post {
      onMapReadyListener()
    }
  }

  @JavascriptInterface
  fun onMapClicked(lat: Double, lng: Double) {
    mainHandler.post {
      onMapClickListener(lat, lng)
    }
  }

  @JavascriptInterface
  fun onPublicPlaceClicked(placeId: String) {
    mainHandler.post {
      onPublicPlaceClickListener(placeId)
    }
  }

  @JavascriptInterface
  fun onMapBoundsChanged(minLat: Double, maxLat: Double, minLng: Double, maxLng: Double) {
    mainHandler.post {
      onMapBoundsChangedListener(minLat, maxLat, minLng, maxLng)
    }
  }

  @JavascriptInterface
  fun onUserMovedInReverse(lat: Double, lng: Double) {
    mainHandler.post {
      onUserReverseListener(lat, lng)
    }
  }

  @JavascriptInterface
  fun onRoadReportClicked(reportId: String) {
    mainHandler.post {
      onRoadReportClickListener(reportId)
    }
  }

  @JavascriptInterface
  fun onVehicleClicked(vehicleId: String) {
    mainHandler.post {
      onVehicleClickListener(vehicleId)
    }
  }
}

/**
 * OpenFreeMap view using MapLibre GL JS engine.
 * Renders OpenFreeMap Positron vector tiles (https://tiles.openfreemap.org/styles/positron)
 * with full interactivity: 2D/3D perspective toggle, GPS marker, tap-to-pin, and OSRM route line rendering.
 */
@SuppressLint("SetJavaScriptEnabled")
@Composable
fun OpenFreeMapView(
    modifier: Modifier = Modifier,
    is3DMode: Boolean,
    userLocation: Location? = null,
    currentHeading: Float = 0f,
    selectedPlace: NominatimResult? = null,
    currentRoute: OsrmRoute? = null,
    routeOptions: List<RouteOption> = emptyList(),
    selectedRouteIndex: Int = -1,
    publicPlaces: List<PublicPlace> = emptyList(),
    roadReports: List<RoadReport> = emptyList(),
    liveVehicles: List<LiveVehicle> = emptyList(),
    userVehicleProfile: UserVehicleProfile? = null,
    isRouteActive: Boolean = false,
    centerOnUserTrigger: Long = 0L,
    onMapClick: (lat: Double, lon: Double) -> Unit = { _, _ -> },
    onPublicPlaceClick: (String) -> Unit = {},
    onRoadReportClick: (String) -> Unit = {},
    onVehicleClick: (String) -> Unit = {},
    onPerspectiveChangedByGesture: (Boolean) -> Unit = {},
    onMapBoundsChanged: (Double, Double, Double, Double) -> Unit = { _, _, _, _ -> },
    onUserReverse: (Double, Double) -> Unit = { _, _ -> }
) {
  val context = LocalContext.current
  val lifecycleOwner = LocalLifecycleOwner.current

  var isMapReady by remember { mutableStateOf(false) }

  val bridge = remember {
    OpenFreeMapBridge(
        onPerspectiveChangedListener = onPerspectiveChangedByGesture,
        onMapReadyListener = {
          Log.d("OpenFreeMapView", "MapLibre isMapReady signaled from JavaScript")
          isMapReady = true
        },
        onMapClickListener = onMapClick,
        onPublicPlaceClickListener = onPublicPlaceClick,
        onMapBoundsChangedListener = onMapBoundsChanged,
        onUserReverseListener = onUserReverse,
        onRoadReportClickListener = onRoadReportClick,
        onVehicleClickListener = onVehicleClick
    )
  }

  val webView = remember {
    WebView(context).apply {
      layoutParams = ViewGroup.LayoutParams(
          ViewGroup.LayoutParams.MATCH_PARENT,
          ViewGroup.LayoutParams.MATCH_PARENT
      )

      settings.apply {
        javaScriptEnabled = true
        domStorageEnabled = true
        databaseEnabled = true
        allowFileAccess = true
        allowContentAccess = true
        allowFileAccessFromFileURLs = true
        allowUniversalAccessFromFileURLs = true
        cacheMode = WebSettings.LOAD_DEFAULT
        useWideViewPort = true
        loadWithOverviewMode = true
        setSupportZoom(false)
        builtInZoomControls = false
        displayZoomControls = false
        offscreenPreRaster = true
        loadsImagesAutomatically = true
      }

      setLayerType(View.LAYER_TYPE_HARDWARE, null)
      setRendererPriorityPolicy(WebView.RENDERER_PRIORITY_IMPORTANT, true)
      isVerticalScrollBarEnabled = false
      isHorizontalScrollBarEnabled = false
      overScrollMode = WebView.OVER_SCROLL_NEVER

      webChromeClient = object : WebChromeClient() {
        override fun onConsoleMessage(consoleMessage: android.webkit.ConsoleMessage?): Boolean {
          Log.d("MapLibreJS", "${consoleMessage?.message()} -- line ${consoleMessage?.lineNumber()}")
          return true
        }
      }
      webViewClient = object : WebViewClient() {
        override fun onPageFinished(view: WebView?, url: String?) {
          super.onPageFinished(view, url)
          Log.d("OpenFreeMapView", "WebView onPageFinished: $url")
        }
      }

      addJavascriptInterface(bridge, "AndroidBridge")
      loadUrl("file:///android_asset/openfreemap.html")
    }
  }

  // Handle Android lifecycle for WebView
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      when (event) {
        Lifecycle.Event.ON_RESUME -> webView.onResume()
        Lifecycle.Event.ON_PAUSE -> webView.onPause()
        Lifecycle.Event.ON_DESTROY -> {
          webView.destroy()
        }
        else -> Unit
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  // Update 2D/3D camera perspective when is3DMode toggles
  LaunchedEffect(is3DMode, isMapReady) {
    if (isMapReady) {
      webView.evaluateJavascript("setPerspective($is3DMode);", null)
    }
  }

  // Synchronize route active state (transitions user marker between red dot and red arrow)
  LaunchedEffect(isRouteActive, isMapReady) {
    if (isMapReady) {
      webView.evaluateJavascript("setRouteActiveState($isRouteActive);", null)
    }
  }

  // Update user GPS location (Red Dot before route, Direction Arrow during route)
  LaunchedEffect(userLocation, isRouteActive, isMapReady) {
    if (isMapReady && userLocation != null) {
      val bearing = userLocation.bearing
      webView.evaluateJavascript(
          "updateUserLocation(${userLocation.latitude}, ${userLocation.longitude}, $isRouteActive, $bearing);",
          null
      )
    }
  }

  // Lightweight compass / GPS heading rotation during active navigation
  LaunchedEffect(currentHeading, isRouteActive, isMapReady) {
    if (isMapReady && isRouteActive) {
      webView.evaluateJavascript("updateUserHeading($currentHeading);", null)
    }
  }

  // Center camera on user when requested
  LaunchedEffect(centerOnUserTrigger, isMapReady) {
    if (isMapReady && centerOnUserTrigger > 0L && userLocation != null) {
      webView.evaluateJavascript(
          "centerOnUser(${userLocation.latitude}, ${userLocation.longitude});",
          null
      )
    }
  }

  // Destination Marker management (Checkered Racing Flag pinned immediately at destination coordinates)
  LaunchedEffect(selectedPlace, isMapReady) {
    if (isMapReady) {
      if (selectedPlace != null) {
        val quotedTitle = JSONObject.quote(selectedPlace.shortTitle)
        val shouldFly = !selectedPlace.isDirectMapTap
        webView.evaluateJavascript(
            "setDestinationMarker(${selectedPlace.latitude}, ${selectedPlace.longitude}, $quotedTitle, $shouldFly);",
            null
        )
      } else {
        webView.evaluateJavascript("clearDestinationMarker();", null)
      }
    }
  }

  // Route Drawing management (Up to 4 routes with distinct colors and live trimming)
  LaunchedEffect(routeOptions, selectedRouteIndex, currentRoute, isMapReady) {
    if (isMapReady) {
      if (routeOptions.isNotEmpty()) {
        val routesArray = JSONArray()
        for (option in routeOptions) {
          val coords = option.route.geometry?.coordinates ?: emptyList()
          val coordsArray = JSONArray()
          for (coord in coords) {
            val pt = JSONArray().apply {
              put(coord[0])
              put(coord[1])
            }
            coordsArray.put(pt)
          }
          val obj = JSONObject().apply {
            put("index", option.index)
            put("color", option.colorHex)
            put("coordinates", coordsArray)
          }
          routesArray.put(obj)
        }
        val quotedJson = JSONObject.quote(routesArray.toString())
        webView.evaluateJavascript("drawMultipleRoutes($quotedJson, $selectedRouteIndex);", null)
      } else if (currentRoute != null) {
        val coords = currentRoute.geometry?.coordinates
        if (!coords.isNullOrEmpty()) {
          val jsonArray = JSONArray()
          for (coord in coords) {
            val pt = JSONArray().apply {
              put(coord[0])
              put(coord[1])
            }
            jsonArray.put(pt)
          }
          val quotedJson = JSONObject.quote(jsonArray.toString())
          webView.evaluateJavascript("drawRoute($quotedJson);", null)
        } else {
          webView.evaluateJavascript("clearAllRoutes();", null)
        }
      } else {
        webView.evaluateJavascript("clearAllRoutes();", null)
      }
    }
  }

  // Render public community places on map
  LaunchedEffect(publicPlaces, isMapReady) {
    if (isMapReady) {
      if (publicPlaces.isNotEmpty()) {
        val placesArray = JSONArray()
        for (p in publicPlaces) {
          val icon = PlaceIconRegistry.getIconById(p.iconId)
          val colorHex = String.format("#%06X", (0xFFFFFF and icon.primaryColor.value.toInt()))
          val obj = JSONObject().apply {
            put("id", p.id)
            put("title", p.title)
            put("latitude", p.latitude)
            put("longitude", p.longitude)
            put("color", colorHex)
            put("iconId", p.iconId)
            put("category", p.category)
          }
          placesArray.put(obj)
        }
        val quoted = JSONObject.quote(placesArray.toString())
        webView.evaluateJavascript("setPublicPlaces($quoted);", null)
      } else {
        webView.evaluateJavascript("clearPublicPlaces();", null)
      }
    }
  }

  // Render community road reports on map (with matching soft glow and custom icons)
  LaunchedEffect(roadReports, isMapReady) {
    if (isMapReady) {
      if (roadReports.isNotEmpty()) {
        val reportsArray = JSONArray()
        for (r in roadReports) {
          if (!r.isCleared) {
            val obj = JSONObject().apply {
              put("id", r.id)
              put("type", r.type.id)
              put("latitude", r.latitude)
              put("longitude", r.longitude)
              put("description", r.description)
              put("color", r.type.colorHex)
              put("glowColor", r.type.glowColorHex)
            }
            reportsArray.put(obj)
          }
        }
        val quoted = JSONObject.quote(reportsArray.toString())
        webView.evaluateJavascript("setRoadReports($quoted);", null)
      } else {
        webView.evaluateJavascript("clearRoadReports();", null)
      }
    }
  }

  // Render live driver vehicles on map (pure Chibi 3D vehicle SVGs, no containers)
  LaunchedEffect(liveVehicles, isMapReady) {
    if (isMapReady) {
      if (liveVehicles.isNotEmpty()) {
        val vehiclesArray = JSONArray()
        for (v in liveVehicles) {
          val obj = JSONObject().apply {
            put("id", v.effectiveUserId)
            put("userId", v.effectiveUserId)
            put("driverName", v.driverName)
            put("vehicleModelId", v.vehicleModelId)
            put("colorHex", v.effectiveColorHex)
            put("latitude", v.latitude)
            put("longitude", v.longitude)
            put("bearing", v.bearing)
            put("speedKmh", v.effectiveSpeedKmh)
            put("isAvailableForOrders", v.effectiveIsAvailable)
            put("serviceCategory", v.effectiveServiceCategory)
            put("isTaxiOwner", v.isTaxiOwner)
            put("taxiStatus", v.taxiStatus)
            put("taxiColorHex", v.effectiveColorHex)
            put("isSharingLocation", v.isSharingLocation)
          }
          vehiclesArray.put(obj)
        }
        val quoted = JSONObject.quote(vehiclesArray.toString())
        webView.evaluateJavascript("setLiveVehicles($quoted);", null)
      } else {
        webView.evaluateJavascript("clearLiveVehicles();", null)
      }
    }
  }

  // Update user vehicle configuration for personal marker transformation
  LaunchedEffect(userVehicleProfile, isMapReady) {
    if (isMapReady) {
      // Taxi vehicles are discovered from the taxi list, not rendered as map markers.
      val isTaxi = false
      val isVehicleVisible = userVehicleProfile != null && (
          isTaxi ||
          userVehicleProfile.visibilityMode == com.example.data.model.LocationVisibilityMode.HIDDEN_FROM_OTHERS ||
          userVehicleProfile.visibilityMode == com.example.data.model.LocationVisibilityMode.PUBLIC_TO_ALL ||
          userVehicleProfile.isSharingLocation
      ) && userVehicleProfile.visibilityMode != com.example.data.model.LocationVisibilityMode.PEDESTRIAN_MODE

      val obj = JSONObject().apply {
        put("isSharing", isVehicleVisible)
        put("visibilityMode", userVehicleProfile?.visibilityMode?.id ?: "hidden")
        put("modelId", "none")
        put("colorHex", if (isTaxi) (userVehicleProfile?.taxiColorHex ?: "#F59E0B") else (userVehicleProfile?.colorHex ?: "#3B82F6"))
        put("isTaxiOwner", isTaxi)
        put("taxiColorHex", userVehicleProfile?.taxiColorHex ?: "#F59E0B")
      }
      val quoted = JSONObject.quote(obj.toString())
      webView.evaluateJavascript("setUserVehicleConfig($quoted);", null)
    }
  }

  AndroidView(
      factory = { webView },
      modifier = modifier
  )
}
