package com.example.data.model

/**
 * Public place created and published by DRAW community users.
 * Accessible to all users for exploration, navigation, interactive likes, and comments.
 */
data class PublicPlace(
    val id: String = "",
    val title: String = "",
    val address: String = "",
    val description: String = "",
    val category: String = "favorite",
    val iconId: String = "personal_favorite",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val images: List<String> = emptyList(), // Requires min 2, max 5 images
    val creatorId: String = "",
    val creatorName: String = "",
    val creatorPhotoUrl: String = "",
    val likesCount: Long = 0L,
    val commentsCount: Long = 0L,
    val averageRating: Double = 0.0,
    val ratingsCount: Long = 0L,
    val totalRatingScore: Double = 0.0,
    val starCounts: Map<String, Int> = emptyMap(),
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
) {
    val likesCountInt: Int get() = likesCount.toInt()
    val commentsCountInt: Int get() = commentsCount.toInt()
    val ratingsCountInt: Int get() = ratingsCount.toInt()
}
