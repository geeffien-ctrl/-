package com.example.data.repository

import android.Manifest
import android.annotation.SuppressLint
import android.content.Context
import android.content.pm.PackageManager
import android.location.Location
import android.os.Looper
import androidx.core.content.ContextCompat
import com.google.android.gms.location.FusedLocationProviderClient
import com.google.android.gms.location.LocationCallback
import com.google.android.gms.location.LocationRequest
import com.google.android.gms.location.LocationResult
import com.google.android.gms.location.LocationServices
import com.google.android.gms.location.Priority
import kotlinx.coroutines.channels.awaitClose
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.callbackFlow
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlinx.coroutines.withTimeoutOrNull
import kotlin.coroutines.resume

class LocationRepository(val context: Context) {
  private val fusedLocationClient: FusedLocationProviderClient =
      LocationServices.getFusedLocationProviderClient(context.applicationContext)

  fun hasLocationPermission(): Boolean {
    val fineGranted =
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_FINE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    val coarseGranted =
        ContextCompat.checkSelfPermission(
            context,
            Manifest.permission.ACCESS_COARSE_LOCATION
        ) == PackageManager.PERMISSION_GRANTED
    return fineGranted || coarseGranted
  }

  @SuppressLint("MissingPermission")
  suspend fun getCurrentLocation(): Location? {
    if (!hasLocationPermission()) return null
    return withTimeoutOrNull(6000L) {
      suspendCancellableCoroutine { continuation ->
        fusedLocationClient.getCurrentLocation(Priority.PRIORITY_HIGH_ACCURACY, null)
          .addOnSuccessListener { location -> if (continuation.isActive) continuation.resume(location) }
          .addOnFailureListener {
            fusedLocationClient.lastLocation
              .addOnSuccessListener { last -> if (continuation.isActive) continuation.resume(last) }
              .addOnFailureListener { if (continuation.isActive) continuation.resume(null) }
          }
      }
    }
  }
  @SuppressLint("MissingPermission")
  fun getLocationUpdates(intervalMs: Long = 1000L): Flow<Location> = callbackFlow {
    if (!hasLocationPermission()) {
      close()
      return@callbackFlow
    }

    // Immediately push last known location if available so map receives instant position
    fusedLocationClient.lastLocation
        .addOnSuccessListener { lastLoc ->
          if (lastLoc != null) {
            trySend(lastLoc)
          }
        }

    val locationRequest =
        LocationRequest.Builder(Priority.PRIORITY_HIGH_ACCURACY, intervalMs)
            .setMinUpdateIntervalMillis(intervalMs / 2)
            .setMinUpdateDistanceMeters(0.0f)
            .setWaitForAccurateLocation(false)
            .build()

    var bestLocation: Location? = null

    val callback = object : LocationCallback() {
      override fun onLocationResult(result: LocationResult) {
        val loc = result.lastLocation ?: return
        bestLocation = loc
        trySend(loc)
      }
    }

    fusedLocationClient.requestLocationUpdates(
        locationRequest,
        callback,
        Looper.getMainLooper()
    )

    awaitClose {
      fusedLocationClient.removeLocationUpdates(callback)
    }
  }
}
