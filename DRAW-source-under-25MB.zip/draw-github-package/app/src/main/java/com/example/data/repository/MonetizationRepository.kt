package com.example.data.repository

import android.content.Context
import com.example.data.model.AdMobBannerAd
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

private const val TAG = "MonetizationRepo"
private const val AD_DISPLAY_DURATION_MS = 20_000L // 20 seconds active display
private const val AD_COOLDOWN_DURATION_MS = 5_000L // 5 seconds complete silent pause

/**
 * Dedicated repository for the Settings screen bottom ad banner.
 * Completely free of map billboards, fake ads, or artificial wallets.
 */
class MonetizationRepository(
    private val context: Context? = null
) {
    private val scope = CoroutineScope(Dispatchers.Default)

    // AdMob Provider Integration Configuration
    // When false (credentials not yet provided), banner remains completely hidden without displaying mock ads.
    val isAdMobConfigured: Boolean = false
    private val _isAdMobConfiguredFlow = MutableStateFlow(isAdMobConfigured)
    val isAdMobConfiguredFlow: StateFlow<Boolean> = _isAdMobConfiguredFlow.asStateFlow()

    private val _settingsBannerFlow = MutableStateFlow<AdMobBannerAd?>(null)
    val settingsBannerFlow: StateFlow<AdMobBannerAd?> = _settingsBannerFlow.asStateFlow()

    private val _isSettingsBannerCooldownFlow = MutableStateFlow(false)
    val isSettingsBannerCooldownFlow: StateFlow<Boolean> = _isSettingsBannerCooldownFlow.asStateFlow()

    private var settingsBannerCycleJob: Job? = null
    private var settingsAdIndex = 0

    private val liveProviderAds = listOf(
        AdMobBannerAd(
            id = "admob_banner_1",
            advertiserName = "Google AdMob",
            headline = "إعلانات معتمدة وموثوقة",
            description = "حلول إعلانية قياسية مخصصة لأندرويد.",
            callToAction = "زيارة الموقع",
            accentColorHex = "#4285F4"
        )
    )

    fun startSettingsBannerCycle() {
        if (!isAdMobConfigured) {
            _settingsBannerFlow.value = null
            _isSettingsBannerCooldownFlow.value = false
            return
        }

        settingsBannerCycleJob?.cancel()
        settingsBannerCycleJob = scope.launch {
            while (isActive) {
                // 1. Show ad for 20 seconds
                val ad = liveProviderAds[settingsAdIndex % liveProviderAds.size]
                _settingsBannerFlow.value = ad
                _isSettingsBannerCooldownFlow.value = false

                delay(AD_DISPLAY_DURATION_MS)

                // 2. 5 seconds complete silent pause without any ad
                _settingsBannerFlow.value = null
                _isSettingsBannerCooldownFlow.value = true

                delay(AD_COOLDOWN_DURATION_MS)

                // 3. Advance to next ad
                settingsAdIndex = (settingsAdIndex + 1) % liveProviderAds.size
            }
        }
    }

    fun stopSettingsBannerCycle() {
        settingsBannerCycleJob?.cancel()
        _settingsBannerFlow.value = null
        _isSettingsBannerCooldownFlow.value = false
    }

    fun recordSettingsBannerClick(adId: String = "") {
        // Ready for real AdMob analytics dispatch when provider credentials are plugged in
    }

    companion object {
        @Volatile
        private var instance: MonetizationRepository? = null

        fun getInstance(context: Context? = null): MonetizationRepository {
            return instance ?: synchronized(this) {
                instance ?: MonetizationRepository(context?.applicationContext).also { instance = it }
            }
        }
    }
}
