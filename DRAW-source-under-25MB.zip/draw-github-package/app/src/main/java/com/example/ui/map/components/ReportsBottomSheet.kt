package com.example.ui.map.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CarRepair
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.Pool
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material.icons.filled.Work
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.RoadReportType
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * Bottom Sheet displaying the 9 Road Report Types for DRAW.
 * Item 10 is the green "Road is Clear" action in the report details.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ReportsBottomSheet(
    onDismissRequest: () -> Unit,
    onReportTypeSelected: (RoadReportType, String) -> Unit,
    modifier: Modifier = Modifier
) {
    var selectedType by remember { mutableStateOf<RoadReportType?>(null) }
    var noteText by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismissRequest,
        modifier = modifier.testTag("reports_bottom_sheet"),
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        containerColor = Color.White,
        dragHandle = {
            BottomSheetDefaults.DragHandle(
                color = Color(0xFFD1D1D6),
                width = 36.dp,
                height = 4.dp
            )
        }
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .navigationBarsPadding(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "إضافة بلاغ على الطريق",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = DrawTextNearBlack
                    )
                    Text(
                        text = "اختر نوع البلاغ لتنبيه السائقين الآخرين فوراً",
                        fontSize = 12.5.sp,
                        color = DrawTextSecondary
                    )
                }
                IconButton(
                    onClick = onDismissRequest,
                    modifier = Modifier.size(36.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color(0xFF8E8E93)
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            if (selectedType == null) {
                // Display the exactly 9 report types in a 3-column clean grid
                val reportTypes = RoadReportType.values().toList()

                LazyVerticalGrid(
                    columns = GridCells.Fixed(3),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(max = 420.dp),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    items(reportTypes) { type ->
                        ReportTypeItemCard(
                            type = type,
                            onClick = {
                                selectedType = type
                            }
                        )
                    }
                }
            } else {
                // Confirmation & Optional Note
                val currentType = selectedType!!
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Box(
                        modifier = Modifier.size(56.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        RoadReportUnifiedIcon(type = currentType, size = 50.dp)
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = currentType.titleArabic,
                        fontSize = 17.sp,
                        fontWeight = FontWeight.Bold,
                        color = DrawTextNearBlack
                    )
                    Text(
                        text = currentType.titleEnglish,
                        fontSize = 12.sp,
                        color = DrawTextSecondary
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    OutlinedTextField(
                        value = noteText,
                        onValueChange = { noteText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("report_note_input"),
                        placeholder = { Text("ملاحظة اختيارية (مثال: المسار الأيمن، بالقرب من الجسر)", fontSize = 13.sp) },
                        shape = RoundedCornerShape(14.dp),
                        maxLines = 2,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = currentType.composeColor,
                            unfocusedBorderColor = Color(0xFFE5E5EA)
                        )
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedButton(
                            onClick = { selectedType = null },
                            modifier = Modifier
                                .weight(1f)
                                .height(48.dp),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = DrawTextNearBlack)
                        ) {
                            Text("رجوع")
                        }

                        Button(
                            onClick = {
                                onReportTypeSelected(currentType, noteText.trim())
                            },
                            modifier = Modifier
                                .weight(1.5f)
                                .height(48.dp)
                                .testTag("submit_report_button"),
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = currentType.composeColor
                            )
                        ) {
                            Text("نشر البلاغ الآن", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
        }
    }
}

@Composable
private fun ReportTypeItemCard(
    type: RoadReportType,
    onClick: () -> Unit,
    modifier: Modifier = Modifier
) {
    Column(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(1.dp, Color(0xFFF2F2F7), RoundedCornerShape(16.dp))
            .background(Color(0xFFFAFAFA))
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 6.dp)
            .testTag("report_item_${type.id}"),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Unified Road Report Icon matching the map marker exactly (transparent background)
        Box(
            modifier = Modifier.size(44.dp),
            contentAlignment = Alignment.Center
        ) {
            RoadReportUnifiedIcon(type = type, size = 38.dp)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = type.titleArabic,
            fontSize = 11.5.sp,
            fontWeight = FontWeight.SemiBold,
            color = DrawTextNearBlack,
            textAlign = TextAlign.Center,
            maxLines = 2,
            lineHeight = 14.sp
        )

        Text(
            text = type.titleEnglish,
            fontSize = 9.5.sp,
            color = DrawTextSecondary,
            textAlign = TextAlign.Center,
            maxLines = 1
        )
    }
}
