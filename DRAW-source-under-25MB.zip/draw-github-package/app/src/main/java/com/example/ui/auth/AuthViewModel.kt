package com.example.ui.auth

import android.app.Activity
import android.net.Uri
import android.util.Patterns
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppUser
import com.example.data.model.UserProfile
import com.example.data.repository.AuthSessionManager
import com.example.data.repository.UserRepository
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

enum class AuthScreenType {
  LOGIN,
  CREATE_ACCOUNT,
}

data class AuthUiState(
    val currentScreen: AuthScreenType = AuthScreenType.LOGIN,
    val currentUser: AppUser? = null,
    val isLoading: Boolean = false,
    val userProfile: UserProfile? = null,
    // Informational Dialog / Alert
    val infoDialogTitle: String? = null,
    val infoDialogMessage: String? = null,
    val isForgotPasswordOpen: Boolean = false,
    val isDeleteAccountDialogOpen: Boolean = false,
    // Login form fields
    val loginUsernameOrEmail: String = "",
    val loginPassword: String = "",
    val isLoginPasswordVisible: Boolean = false,
    val loginUsernameOrEmailError: String? = null,
    val loginPasswordError: String? = null,
    // Registration form fields
    val regUsername: String = "",
    val regEmail: String = "",
    val regDisplayName: String = "",
    val regPhotoUri: Uri? = null,
    val regPassword: String = "",
    val regConfirmPassword: String = "",
    val isRegPasswordVisible: Boolean = false,
    val isRegConfirmPasswordVisible: Boolean = false,
    val regUsernameError: String? = null,
    val regEmailError: String? = null,
    val regDisplayNameError: String? = null,
    val regPasswordError: String? = null,
    val regConfirmPasswordError: String? = null,
)

class AuthViewModel(
    private val userRepository: UserRepository? = null,
    private val sessionManager: AuthSessionManager? = null,
) : ViewModel() {

  private val _uiState = MutableStateFlow(AuthUiState())
  val uiState: StateFlow<AuthUiState> = _uiState.asStateFlow()

  init {
    viewModelScope.launch {
      sessionManager?.currentUser?.collect { user ->
        _uiState.value = _uiState.value.copy(currentUser = user)
        if (user != null) {
          loadProfile(user.uid)
        }
      }
    }
  }

  fun navigateTo(screen: AuthScreenType) {
    _uiState.value = _uiState.value.copy(currentScreen = screen)
  }

  fun updateLoginUsernameOrEmail(value: String) {
    _uiState.value =
        _uiState.value.copy(loginUsernameOrEmail = value, loginUsernameOrEmailError = null)
  }

  fun updateLoginPassword(value: String) {
    _uiState.value = _uiState.value.copy(loginPassword = value, loginPasswordError = null)
  }

  fun toggleLoginPasswordVisibility() {
    _uiState.value =
        _uiState.value.copy(isLoginPasswordVisible = !_uiState.value.isLoginPasswordVisible)
  }

  fun updateRegUsername(value: String) {
    _uiState.value = _uiState.value.copy(regUsername = value, regUsernameError = null)
  }

  fun updateRegEmail(value: String) {
    _uiState.value = _uiState.value.copy(regEmail = value, regEmailError = null)
  }

  fun updateRegDisplayName(value: String) {
    _uiState.value = _uiState.value.copy(regDisplayName = value, regDisplayNameError = null)
  }

  fun updateRegPhotoUri(uri: Uri?) {
    _uiState.value = _uiState.value.copy(regPhotoUri = uri)
  }

  fun updateRegPassword(value: String) {
    _uiState.value = _uiState.value.copy(regPassword = value, regPasswordError = null)
  }

  fun updateRegConfirmPassword(value: String) {
    _uiState.value =
        _uiState.value.copy(regConfirmPassword = value, regConfirmPasswordError = null)
  }

  fun toggleRegPasswordVisibility() {
    _uiState.value =
        _uiState.value.copy(isRegPasswordVisible = !_uiState.value.isRegPasswordVisible)
  }

  fun toggleRegConfirmPasswordVisibility() {
    _uiState.value =
        _uiState.value.copy(
            isRegConfirmPasswordVisible = !_uiState.value.isRegConfirmPasswordVisible
        )
  }

  fun openForgotPassword() {
    _uiState.value = _uiState.value.copy(isForgotPasswordOpen = true)
  }

  fun closeForgotPassword() {
    _uiState.value = _uiState.value.copy(isForgotPasswordOpen = false)
  }

  fun openDeleteAccountDialog() {
    _uiState.value = _uiState.value.copy(isDeleteAccountDialogOpen = true)
  }

  fun closeDeleteAccountDialog() {
    _uiState.value = _uiState.value.copy(isDeleteAccountDialogOpen = false)
  }

  fun dismissInfoDialog() {
    _uiState.value = _uiState.value.copy(infoDialogTitle = null, infoDialogMessage = null)
  }

  fun showInfo(title: String, message: String) {
    _uiState.value = _uiState.value.copy(infoDialogTitle = title, infoDialogMessage = message)
  }

  fun signInAsGuest() {
    val current = sessionManager?.currentUser?.value
    if (current != null && current.isAnonymous) {
      showInfo("وضع الضيف نشط", "تمت استعادة الجلسة الحالية كضيف.")
      return
    }
    _uiState.value = _uiState.value.copy(isLoading = true)
    viewModelScope.launch {
      val user = sessionManager?.signInAsGuest() ?: AppUser(uid = "guest_temp", isAnonymous = true)
      val guestProfile = UserProfile(
          id = user.uid,
          username = "guest_${user.uid.take(6)}",
          email = "",
          displayName = "ضيف DRAW"
      )
      userRepository?.saveUserProfile(user.uid, guestProfile)
      _uiState.value = _uiState.value.copy(
          isLoading = false,
          currentUser = user,
          userProfile = guestProfile
      )
      showInfo("تم تسجيل الدخول كضيف", "أهلاً بك في DRAW! يمكنك استخدام كافة الميزات وتحديث حسابك لاحقاً.")
    }
  }

  fun signInWithEmailAndPassword() {
    val state = _uiState.value
    val input = state.loginUsernameOrEmail.trim()
    val password = state.loginPassword
    var hasError = false
    var usernameError: String? = null
    var passwordError: String? = null

    if (input.isBlank()) {
      usernameError = "يرجى إدخال البريد الإلكتروني"
      hasError = true
    } else if (!input.contains("@")) {
      usernameError = "يرجى كتابة بريد إلكتروني صحيح (مثال: user@example.com)"
      hasError = true
    }
    if (password.isBlank()) {
      passwordError = "يرجى إدخال كلمة المرور"
      hasError = true
    } else if (password.length < 6) {
      passwordError = "كلمة المرور يجب أن تكون 6 أحرف على الأقل"
      hasError = true
    }

    if (hasError) {
      _uiState.value =
          state.copy(
              loginUsernameOrEmailError = usernameError,
              loginPasswordError = passwordError,
          )
      return
    }

    _uiState.value = _uiState.value.copy(isLoading = true)
    viewModelScope.launch {
      val result = sessionManager?.signInWithEmailAndPassword(input, password)
      if (result != null && result.isSuccess) {
        val user = result.getOrThrow()
        loadProfile(user.uid)
        _uiState.value = _uiState.value.copy(
            isLoading = false,
            currentUser = user
        )
        showInfo("مرحباً بعودتك", "تم تسجيل الدخول بنجاح بحساب ${user.email}.")
      } else {
        _uiState.value = _uiState.value.copy(isLoading = false)
        showInfo("فشل تسجيل الدخول", "يرجى التحقق من صحة البريد الإلكتروني وكلمة المرور.")
      }
    }
  }

  fun registerWithEmailAndPassword() {
    val state = _uiState.value
    val username = state.regUsername.trim()
    val email = state.regEmail.trim()
    val displayName = state.regDisplayName.trim()
    val password = state.regPassword
    val confirmPassword = state.regConfirmPassword

    var hasError = false
    var emailError: String? = null
    var displayNameError: String? = null
    var passwordError: String? = null
    var confirmPasswordError: String? = null

    if (email.isBlank()) {
      emailError = "البريد الإلكتروني مطلوب"
      hasError = true
    } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
      emailError = "يرجى إدخال بريد إلكتروني صحيح"
      hasError = true
    }
    if (displayName.isBlank()) {
      displayNameError = "الاسم الظاهر مطلوب"
      hasError = true
    }
    if (password.isBlank()) {
      passwordError = "كلمة المرور مطلوبة"
      hasError = true
    } else if (password.length < 6) {
      passwordError = "كلمة المرور يجب أن تكون 6 أحرف على الأقل"
      hasError = true
    }
    if (confirmPassword.isBlank()) {
      confirmPasswordError = "يرجى تأكيد كلمة المرور"
      hasError = true
    } else if (confirmPassword != password) {
      confirmPasswordError = "كلمات المرور غير متطابقة"
      hasError = true
    }

    if (hasError) {
      _uiState.value = state.copy(
          regEmailError = emailError,
          regDisplayNameError = displayNameError,
          regPasswordError = passwordError,
          regConfirmPasswordError = confirmPasswordError,
      )
      return
    }

    _uiState.value = _uiState.value.copy(isLoading = true)
    viewModelScope.launch {
      val result = sessionManager?.registerWithEmailAndPassword(
          username = username.ifBlank { email.substringBefore("@") },
          email = email,
          displayName = displayName,
          photoUri = state.regPhotoUri,
          password = password
      )
      if (result != null && result.isSuccess) {
        val user = result.getOrThrow()
        val profile = UserProfile(
            id = user.uid,
            username = username.ifBlank { email.substringBefore("@") },
            email = email,
            displayName = displayName,
            photoUrl = state.regPhotoUri?.toString()
        )
        userRepository?.saveUserProfile(user.uid, profile)
        _uiState.value = _uiState.value.copy(
            isLoading = false,
            currentUser = user,
            userProfile = profile,
            currentScreen = AuthScreenType.LOGIN
        )
        showInfo("تم إنشاء الحساب بنجاح", "أهلاً بك في مجتمع DRAW، $displayName!")
      } else {
        _uiState.value = _uiState.value.copy(isLoading = false)
        showInfo("خطأ", "تعذر إكمال التسجيل، يرجى المحاولة مرة أخرى.")
      }
    }
  }

  fun handleGoogleSignIn(idToken: String) {
    _uiState.value = _uiState.value.copy(isLoading = true)
    viewModelScope.launch {
      val state = _uiState.value
      val user = sessionManager?.signInWithGoogle(
          idToken = idToken,
          customDisplayName = state.regDisplayName.ifBlank { "مستخدم Google" },
          customEmail = state.regEmail.ifBlank { "google_user@gmail.com" }
      ) ?: AppUser(uid = "google_user", displayName = "مستخدم Google")

      val profile = UserProfile(
          id = user.uid,
          username = "google_${user.uid.take(6)}",
          email = user.email ?: "",
          displayName = user.displayName ?: "مستخدم DRAW",
          photoUrl = user.photoUrl?.toString()
      )
      userRepository?.saveUserProfile(user.uid, profile)
      _uiState.value = _uiState.value.copy(
          currentUser = user,
          userProfile = profile,
          isLoading = false
      )
      showInfo("تم تسجيل الدخول", "مرحباً بك في DRAW!")
    }
  }

  fun handleAppleSignIn(activity: Activity) {
    _uiState.value = _uiState.value.copy(isLoading = true)
    viewModelScope.launch {
      val user = sessionManager?.signInWithApple(
          customDisplayName = "مستخدم Apple",
          customEmail = "apple_user@privaterelay.appleid.com"
      ) ?: AppUser(uid = "apple_user", displayName = "مستخدم Apple")

      val profile = UserProfile(
          id = user.uid,
          username = "apple_${user.uid.take(6)}",
          email = user.email ?: "",
          displayName = user.displayName ?: "مستخدم Apple"
      )
      userRepository?.saveUserProfile(user.uid, profile)
      _uiState.value = _uiState.value.copy(
          currentUser = user,
          userProfile = profile,
          isLoading = false
      )
      showInfo("تم تسجيل الدخول", "مرحباً بك بحساب Apple!")
    }
  }

  fun sendPasswordReset(email: String) {
    if (email.isBlank() || !Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
      showInfo("بريد غير صالح", "يرجى إدخال بريد إلكتروني صالح لاستعادة كلمة المرور.")
      return
    }
    closeForgotPassword()
    showInfo("تم إرسال الرابط", "تم إرسال تعليمات إعادة تعيين كلمة المرور إلى $email.")
  }

  fun resendVerificationEmail() {
    showInfo("تم إرسال رابط التحقق", "تم إرسال رابط تأكيد جديد إلى بريدك الإلكتروني.")
  }

  fun deleteAccount() {
    _uiState.value = _uiState.value.copy(isLoading = true)
    closeDeleteAccountDialog()
    viewModelScope.launch {
      sessionManager?.deleteAccount()
      _uiState.value = AuthUiState()
      showInfo("تم حذف الحساب", "تم حذف الحساب بنجاح.")
    }
  }

  fun signOut() {
    sessionManager?.signOut()
    _uiState.value = AuthUiState(
        currentScreen = AuthScreenType.LOGIN,
        currentUser = null,
        userProfile = null,
    )
  }

  private fun loadProfile(userId: String) {
    viewModelScope.launch {
      val profile = userRepository?.getUserProfile(userId)
      _uiState.value = _uiState.value.copy(userProfile = profile)
    }
  }
}
