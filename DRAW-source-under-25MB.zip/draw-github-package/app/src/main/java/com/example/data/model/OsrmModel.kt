package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class OsrmResponse(
    val code: String = "",
    val routes: List<OsrmRoute> = emptyList()
)

@JsonClass(generateAdapter = true)
data class OsrmRoute(
    val distance: Double = 0.0, // in meters
    val duration: Double = 0.0, // in seconds
    val weight: Double? = null,
    val geometry: OsrmGeometry? = null,
    val legs: List<OsrmLeg> = emptyList()
) {
  val formattedDistance: String
    get() {
      return if (distance < 1000) {
        "${distance.toInt()} m"
      } else {
        "%.1f km".format(distance / 1000.0)
      }
    }

  val formattedDuration: String
    get() {
      val totalMinutes = (duration / 60.0).toInt()
      return if (totalMinutes < 60) {
        "$totalMinutes min"
      } else {
        val hours = totalMinutes / 60
        val remainingMinutes = totalMinutes % 60
        "${hours}h ${remainingMinutes}m"
      }
    }
}

@JsonClass(generateAdapter = true)
data class OsrmGeometry(
    val type: String = "LineString",
    val coordinates: List<List<Double>> = emptyList() // [longitude, latitude]
)

@JsonClass(generateAdapter = true)
data class OsrmLeg(
    val distance: Double = 0.0,
    val duration: Double = 0.0,
    val summary: String? = null,
    val steps: List<OsrmStep> = emptyList()
)

@JsonClass(generateAdapter = true)
data class OsrmStep(
    val distance: Double = 0.0,
    val duration: Double = 0.0,
    val name: String = "",
    val maneuver: OsrmManeuver? = null
)

@JsonClass(generateAdapter = true)
data class OsrmManeuver(
    val type: String = "",
    val modifier: String? = null,
    val instruction: String? = null,
    val location: List<Double>? = null
)
