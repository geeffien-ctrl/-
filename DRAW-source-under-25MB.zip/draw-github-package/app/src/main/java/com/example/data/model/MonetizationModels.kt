package com.example.data.model

/**
 * AdMob Settings Banner item.
 * Strictly used inside the Settings screen bottom banner when configured.
 * 100% silent and will not interrupt voice guidance or navigation.
 */
data class AdMobBannerAd(
    val id: String = "",
    val advertiserName: String = "",
    val headline: String = "",
    val description: String = "",
    val callToAction: String = "معرفة المزيد",
    val accentColorHex: String = "#2563EB",
    val isSilent: Boolean = true
)
