package com.example.ui.settings

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.DirectionsBike
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.DirectionsWalk
import androidx.compose.material.icons.filled.Layers
import androidx.compose.material.icons.filled.Straighten
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material.icons.filled.ViewInAr
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@Composable
fun PreferencesSubScreen(
    uiState: SettingsUiState,
    onSetDefaultTo3D: (Boolean) -> Unit,
    onSetVoiceGuidance: (Boolean) -> Unit = {},
    onSetMasterVoice: (Boolean) -> Unit = {},
    onSetAiCompanionVoice: (Boolean) -> Unit = {},
    onSetShow3DBuildings: (Boolean) -> Unit,
    onSetTransportMode: (String) -> Unit,
    onSetDistanceUnit: (String) -> Unit,
    modifier: Modifier = Modifier,
) {
  val cardShape = RoundedCornerShape(22.dp)

  Column(
      modifier = modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 20.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Perspective Card
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, cardShape, spotColor = Color(0x18000000))
            .border(0.8.dp, Color(0x14000000), cardShape),
        shape = cardShape,
        color = Color.White,
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
        ) {
          Icon(
              imageVector = Icons.Default.ViewInAr,
              contentDescription = null,
              tint = DrawRed,
              modifier = Modifier.size(24.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "العرض الافتراضي للخريطة",
                fontSize = 15.5.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack,
            )
            Text(
                text = "اختر زاوية الكاميرا المبدئية عند فتح الخريطة",
                fontSize = 12.5.sp,
                color = DrawTextSecondary,
            )
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Segmented selector for 2D vs 3D
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
                .clip(RoundedCornerShape(14.dp))
                .background(Color(0xFFF2F2F7))
                .padding(3.dp),
        ) {
          Box(
              modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (!uiState.defaultTo3D) Color.White else Color.Transparent)
                  .clickable { onSetDefaultTo3D(false) }
                  .testTag("pref_mode_2d"),
              contentAlignment = Alignment.Center,
          ) {
            Text(
                text = "2D ثنائي الأبعاد",
                fontSize = 13.5.sp,
                fontWeight = if (!uiState.defaultTo3D) FontWeight.Bold else FontWeight.Normal,
                color = if (!uiState.defaultTo3D) DrawRed else DrawTextSecondary,
            )
          }

          Box(
              modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(12.dp))
                  .background(if (uiState.defaultTo3D) Color.White else Color.Transparent)
                  .clickable { onSetDefaultTo3D(true) }
                  .testTag("pref_mode_3d"),
              contentAlignment = Alignment.Center,
          ) {
            Text(
                text = "3D ثلاثي الأبعاد",
                fontSize = 13.5.sp,
                fontWeight = if (uiState.defaultTo3D) FontWeight.Bold else FontWeight.Normal,
                color = if (uiState.defaultTo3D) DrawRed else DrawTextSecondary,
            )
          }
        }
      }
    }

    // 2. Navigation Mode Card
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, cardShape, spotColor = Color(0x18000000))
            .border(0.8.dp, Color(0x14000000), cardShape),
        shape = cardShape,
        color = Color.White,
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Text(
            text = "وسيلة النقل الافتراضية للمسارات",
            fontSize = 15.5.sp,
            fontWeight = FontWeight.Bold,
            color = DrawTextNearBlack,
        )
        Text(
            text = "يتم حساب أسرع مسار تلقائياً بناءً على وسيلتك المفضلة",
            fontSize = 12.5.sp,
            color = DrawTextSecondary,
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          TransportOptionItem(
              title = "سيارة",
              icon = Icons.Default.DirectionsCar,
              isSelected = uiState.transportMode == "driving",
              onClick = { onSetTransportMode("driving") },
              modifier = Modifier.weight(1f),
              testTag = "pref_transport_driving",
          )
          TransportOptionItem(
              title = "مشي",
              icon = Icons.Default.DirectionsWalk,
              isSelected = uiState.transportMode == "walking",
              onClick = { onSetTransportMode("walking") },
              modifier = Modifier.weight(1f),
              testTag = "pref_transport_walking",
          )
          TransportOptionItem(
              title = "دراجة",
              icon = Icons.Default.DirectionsBike,
              isSelected = uiState.transportMode == "cycling",
              onClick = { onSetTransportMode("cycling") },
              modifier = Modifier.weight(1f),
              testTag = "pref_transport_cycling",
          )
        }
      }
    }

    // 3. Toggles Card (Voice & Buildings)
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, cardShape, spotColor = Color(0x18000000))
            .border(0.8.dp, Color(0x14000000), cardShape),
        shape = cardShape,
        color = Color.White,
    ) {
      Column(modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)) {
        // Voice Guidance Switch
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
        ) {
          Icon(
              imageVector = Icons.Default.VolumeUp,
              contentDescription = null,
              tint = DrawRed,
              modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "إرشادات الصوت للملاحة",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = DrawTextNearBlack,
            )
            Text(
                text = if (uiState.voiceGuidance && uiState.masterVoiceEnabled) "مفعّل (التنبيهات المهمة فقط)" else "صامت تماماً (يتوقف كل صوت)",
                fontSize = 12.sp,
                color = DrawTextSecondary,
            )
          }
          Switch(
              checked = uiState.voiceGuidance,
              onCheckedChange = onSetVoiceGuidance,
              colors = SwitchDefaults.colors(
                  checkedThumbColor = Color.White,
                  checkedTrackColor = DrawRed,
              ),
              modifier = Modifier.testTag("pref_voice_guidance_switch"),
          )
        }

        HorizontalDivider(color = Color(0x14000000), thickness = 0.8.dp)

        // Requirement 5.a: Master Voice for Navigation
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
        ) {
          Icon(
              imageVector = Icons.Default.VolumeUp,
              contentDescription = null,
              tint = if (uiState.masterVoiceEnabled) DrawRed else Color(0xFF8E8E93),
              modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "الصوت الأساسي للملاحة",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = DrawTextNearBlack,
            )
            Text(
                text = if (uiState.masterVoiceEnabled) "تنبيهات الانعطافات والمخاطر والمطبات والكاميرات فقط" else "مكتوم تماماً (يتوقف كل صوت في الخريطة والملاحة)",
                fontSize = 12.sp,
                color = DrawTextSecondary,
            )
          }
          Switch(
              checked = uiState.masterVoiceEnabled,
              onCheckedChange = onSetMasterVoice,
              colors = SwitchDefaults.colors(
                  checkedThumbColor = Color.White,
                  checkedTrackColor = DrawRed,
              ),
              modifier = Modifier.testTag("pref_master_voice_switch"),
          )
        }

        HorizontalDivider(color = Color(0x14000000), thickness = 0.8.dp)

        // Requirement 5.b: Talking AI Companion (Periodic 10s driving tips)
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
        ) {
          Icon(
              imageVector = Icons.Default.ViewInAr,
              contentDescription = null,
              tint = if (uiState.aiCompanionVoiceEnabled && uiState.masterVoiceEnabled) DrawRed else Color(0xFF8E8E93),
              modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "الذكاء الاصطناعي المتكلم",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = DrawTextNearBlack,
            )
            Text(
                text = if (!uiState.masterVoiceEnabled) "معطّل (لأن الصوت الأساسي مكتوم)" else if (uiState.aiCompanionVoiceEnabled) "معلومات قصيرة كل 10 ثوانٍ (الطقس، المرور، والقيادة الآمنة)" else "متوقف (تنبيهات الملاحة المهمة فقط)",
                fontSize = 12.sp,
                color = DrawTextSecondary,
            )
          }
          Switch(
              checked = uiState.aiCompanionVoiceEnabled && uiState.masterVoiceEnabled,
              enabled = uiState.masterVoiceEnabled,
              onCheckedChange = onSetAiCompanionVoice,
              colors = SwitchDefaults.colors(
                  checkedThumbColor = Color.White,
                  checkedTrackColor = DrawRed,
              ),
              modifier = Modifier.testTag("pref_ai_companion_voice_switch"),
          )
        }

        HorizontalDivider(color = Color(0x14000000), thickness = 0.8.dp)

        // 3D Buildings Switch
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp),
        ) {
          Icon(
              imageVector = Icons.Default.Layers,
              contentDescription = null,
              tint = DrawRed,
              modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "عرض المباني ثلاثية الأبعاد",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = DrawTextNearBlack,
            )
            Text(
                text = "إظهار كتل المباني ثلاثية الأبعاد في وضع 3D",
                fontSize = 12.sp,
                color = DrawTextSecondary,
            )
          }
          Switch(
              checked = uiState.show3DBuildings,
              onCheckedChange = onSetShow3DBuildings,
              colors = SwitchDefaults.colors(
                  checkedThumbColor = Color.White,
                  checkedTrackColor = DrawRed,
              ),
              modifier = Modifier.testTag("pref_buildings_switch"),
          )
        }
      }
    }

    // 4. Units Card
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .shadow(4.dp, cardShape, spotColor = Color(0x18000000))
            .border(0.8.dp, Color(0x14000000), cardShape),
        shape = cardShape,
        color = Color.White,
    ) {
      Column(modifier = Modifier.padding(18.dp)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(
              imageVector = Icons.Default.Straighten,
              contentDescription = null,
              tint = DrawRed,
              modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
              text = "وحدة قياس المسافة",
              fontSize = 15.5.sp,
              fontWeight = FontWeight.Bold,
              color = DrawTextNearBlack,
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .height(42.dp)
                .clip(RoundedCornerShape(12.dp))
                .background(Color(0xFFF2F2F7))
                .padding(3.dp),
        ) {
          Box(
              modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (uiState.distanceUnit == "km") Color.White else Color.Transparent)
                  .clickable { onSetDistanceUnit("km") }
                  .testTag("pref_unit_km"),
              contentAlignment = Alignment.Center,
          ) {
            Text(
                text = "كيلومتر (كم)",
                fontSize = 13.5.sp,
                fontWeight = if (uiState.distanceUnit == "km") FontWeight.Bold else FontWeight.Normal,
                color = if (uiState.distanceUnit == "km") DrawRed else DrawTextSecondary,
            )
          }

          Box(
              modifier = Modifier
                  .weight(1f)
                  .clip(RoundedCornerShape(10.dp))
                  .background(if (uiState.distanceUnit == "mi") Color.White else Color.Transparent)
                  .clickable { onSetDistanceUnit("mi") }
                  .testTag("pref_unit_mi"),
              contentAlignment = Alignment.Center,
          ) {
            Text(
                text = "ميل (mi)",
                fontSize = 13.5.sp,
                fontWeight = if (uiState.distanceUnit == "mi") FontWeight.Bold else FontWeight.Normal,
                color = if (uiState.distanceUnit == "mi") DrawRed else DrawTextSecondary,
            )
          }
        }
      }
    }
  }
}

@Composable
private fun TransportOptionItem(
    title: String,
    icon: ImageVector,
    isSelected: Boolean,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    testTag: String = "",
) {
  val shape = RoundedCornerShape(16.dp)
  Box(
      modifier = modifier
          .clip(shape)
          .background(if (isSelected) Color(0xFFFFECEB) else Color(0xFFF8F8F9))
          .border(
              width = if (isSelected) 1.5.dp else 0.8.dp,
              color = if (isSelected) DrawRed else Color(0x16000000),
              shape = shape,
          )
          .clickable(onClick = onClick)
          .padding(vertical = 12.dp)
          .testTag(testTag),
      contentAlignment = Alignment.Center,
  ) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
      Icon(
          imageVector = icon,
          contentDescription = null,
          tint = if (isSelected) DrawRed else Color(0xFF636366),
          modifier = Modifier.size(24.dp),
      )
      Spacer(modifier = Modifier.height(4.dp))
      Text(
          text = title,
          fontSize = 13.sp,
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
          color = if (isSelected) DrawRed else DrawTextNearBlack,
      )
    }
  }
}
