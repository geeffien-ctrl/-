package com.example.ui.map

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.speech.RecognizerIntent
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AddLocationAlt
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Explore
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MyLocation
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.data.model.NominatimResult
import com.example.data.network.OpenRouterService
import com.example.data.repository.AiAssistantRepository
import com.example.data.repository.AiConversationRepository
import com.example.data.repository.LocationRepository
import com.example.data.repository.NavigationRepository
import com.example.data.repository.NearbyPlacesSearchService
import com.example.data.repository.OrientationSensorRepository
import com.example.data.repository.PlaceInteractionsRepository
import com.example.data.repository.PublicPlacesRepository
import com.example.data.repository.UserRepository
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.TextButton
import com.example.ui.auth.AuthScreenType
import com.example.ui.map.components.AddCustomPlaceDialog
import com.example.ui.map.components.ArrivalCelebrationCard
import com.example.ui.map.components.CommentsBottomSheet
import com.example.ui.map.components.DiscoveredPlaceCard
import com.example.ui.map.components.DrawAiAssistantSheet
import com.example.ui.map.components.ExploreCategoriesSheet
import com.example.ui.map.components.HazardDetourAlertBanner
import com.example.ui.map.components.MapSearchBar
import com.example.ui.map.components.NavigationTurnBanner
import com.example.ui.map.components.NotificationsSheet
import com.example.ui.map.components.PlaceDetailsCard
import com.example.ui.map.components.PublicPlaceDetailsCard
import com.example.ui.map.components.RouteSummaryCard
import com.example.ui.map.components.SavedPlacesSheet
import com.example.ui.map.components.ActiveOrderTrackingCard
import com.example.ui.map.components.DriverProfileBottomSheet
import com.example.ui.map.components.TaxiListBottomSheet
import com.example.ui.map.components.IncomingOrderBanner
import com.example.ui.map.components.ReportsBottomSheet
import com.example.ui.map.components.ReportDetailsBottomSheet
import com.example.ui.map.navigation.NavigationVoiceSpeaker
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import com.example.data.repository.AuthSessionManager

/**
 * DRAW Main Interactive Map Screen.
 *
 * Implements:
 * 1. Full-screen OpenFreeMap with Positron light style and MapLibre engine.
 * 2. Top search bar with live Nominatim geocoding and dropdown results.
 * 3. 2D / 3D capsule toggle button and 60-Categories Explore button directly below search bar.
 * 4. Voice search button with real Android SpeechRecognizer.
 * 5. Add Place button, Saved Places button, and My Location button.
 * 6. Red user location dot before route, and direction arrow start marker during route.
 * 7. Real OSRM route calculation, Blue GeoJSON polyline rendering, and turn-by-turn guidance.
 * 8. Realtime community places on map, with 2-5 photos, publisher details, and 5-star rating system.
 * 9. iOS-inspired soft rounded styling with smooth animations.
 */
@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun MapScreen(
    modifier: Modifier = Modifier,
    onOpenSettings: () -> Unit = {},
    onSignOutRequested: () -> Unit = {},
    onNavigateToAuth: (AuthScreenType) -> Unit = {}
) {
  val context = LocalContext.current
  val locationRepository = remember { LocationRepository(context) }
  val navigationRepository = remember { NavigationRepository(context) }
  val userRepository = remember { UserRepository(context) }
  val openRouterService = remember { OpenRouterService(context) }
  val aiAssistantRepository = remember { AiAssistantRepository(openRouterService) }
  val aiConversationRepository = remember { AiConversationRepository(context) }
  val publicPlacesRepository = remember { PublicPlacesRepository(context.applicationContext) }
  val placeInteractionsRepository = remember { PlaceInteractionsRepository(context.applicationContext) }
  val nearbyPlacesSearchService = remember { NearbyPlacesSearchService(publicPlacesRepository) }
  val navigationVoiceSpeaker = remember { NavigationVoiceSpeaker(context) }
  val orientationSensorRepository = remember { OrientationSensorRepository(context) }

  val mapViewModel: MapViewModel = viewModel {
    MapViewModel(
        locationRepository = locationRepository,
        navigationRepository = navigationRepository,
        publicPlacesRepository = publicPlacesRepository,
        nearbyPlacesSearchService = nearbyPlacesSearchService,
        aiAssistantRepository = aiAssistantRepository,
        aiConversationRepository = aiConversationRepository,
        openRouterService = openRouterService,
        placeInteractionsRepository = placeInteractionsRepository,
        navigationVoiceSpeaker = navigationVoiceSpeaker,
        orientationSensorRepository = orientationSensorRepository
    )
  }
  val uiState by mapViewModel.uiState.collectAsStateWithLifecycle()
  val sessionManager = remember { AuthSessionManager.getInstance(context) }
  val currentUser by sessionManager.currentUser.collectAsStateWithLifecycle()
  val user = currentUser
  val sortedTaxiVehicles = remember(uiState.liveVehicles, uiState.userLocation) {
    uiState.liveVehicles.filter { it.effectiveIsAvailable }.map { vehicle ->
      val meters = if (uiState.userLocation != null && vehicle.latitude != 0.0 && vehicle.longitude != 0.0) {
        val result = FloatArray(1)
        android.location.Location.distanceBetween(
            uiState.userLocation!!.latitude, uiState.userLocation!!.longitude,
            vehicle.latitude, vehicle.longitude, result
        )
        result[0]
      } else vehicle.distanceToUserMeters
      vehicle.copy(distanceToUserMeters = meters)
    }.sortedBy { it.distanceToUserMeters }
  }

  // Load favorites & AI conversation history & notifications for logged-in user
  LaunchedEffect(user?.uid) {
    user?.uid?.let { uid ->
      mapViewModel.loadFavorites(uid)
      mapViewModel.loadAiConversations(uid)
    }
    mapViewModel.syncCurrentUser(user)
  }

  // Location Permission Launcher
  val locationPermissionLauncher = rememberLauncherForActivityResult(
      contract = ActivityResultContracts.RequestMultiplePermissions()
  ) { permissions: Map<String, Boolean> ->
    val fineGranted = permissions[Manifest.permission.ACCESS_FINE_LOCATION] == true
    val coarseGranted = permissions[Manifest.permission.ACCESS_COARSE_LOCATION] == true
    if (fineGranted || coarseGranted) {
      mapViewModel.checkPermissionAndFetchLocation(autoCenter = true)
      mapViewModel.centerOnUser()
    }
  }

  // Request location permissions on startup if not already granted, or fetch immediately
  val lifecycleOwner = LocalLifecycleOwner.current
  DisposableEffect(lifecycleOwner) {
    val observer = LifecycleEventObserver { _, event ->
      if (event == Lifecycle.Event.ON_RESUME) {
        mapViewModel.refreshVehicleProfile()
      }
    }
    lifecycleOwner.lifecycle.addObserver(observer)
    onDispose {
      lifecycleOwner.lifecycle.removeObserver(observer)
    }
  }

  LaunchedEffect(Unit) {
    mapViewModel.refreshVehicleProfile()
    if (locationRepository.hasLocationPermission()) {
      mapViewModel.checkPermissionAndFetchLocation(autoCenter = true)
    } else {
      locationPermissionLauncher.launch(
          arrayOf(
              Manifest.permission.ACCESS_FINE_LOCATION,
              Manifest.permission.ACCESS_COARSE_LOCATION
          )
      )
    }
  }

  // Speech Recognition Activity Launcher
  val speechRecognitionLauncher = rememberLauncherForActivityResult(
      contract = ActivityResultContracts.StartActivityForResult()
  ) { result ->
    mapViewModel.setVoiceListening(false)
    if (result.resultCode == Activity.RESULT_OK) {
      val spoken = result.data
          ?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)
          ?.firstOrNull()
      if (!spoken.isNullOrBlank()) {
        mapViewModel.openAiAssistant()
        mapViewModel.sendAiAssistantPrompt(spoken)
      }
    }
  }

  // Audio Permission Launcher
  val audioPermissionLauncher = rememberLauncherForActivityResult(
      contract = ActivityResultContracts.RequestPermission()
  ) { isGranted ->
    if (isGranted) {
      mapViewModel.openAiAssistant()
      mapViewModel.setVoiceListening(true)
      val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث إلى مساعد DRAW الذكي...")
      }
      try {
        speechRecognitionLauncher.launch(intent)
      } catch (e: Exception) {
        mapViewModel.setVoiceListening(false)
        Toast.makeText(context, "التعرف الصوتي غير متوفر على هذا الجهاز", Toast.LENGTH_SHORT).show()
      }
    } else {
      mapViewModel.setVoiceListening(false)
      Toast.makeText(context, "يرجى منح إذن الميكروفون للتحدث إلى مساعد DRAW", Toast.LENGTH_SHORT).show()
    }
  }

  fun startVoiceAssistant() {
    mapViewModel.openAiAssistant()
    val hasAudio = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED
    if (hasAudio) {
      mapViewModel.setVoiceListening(true)
      val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
        putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
        putExtra(RecognizerIntent.EXTRA_PROMPT, "تحدث إلى مساعد DRAW الذكي...")
      }
      try {
        speechRecognitionLauncher.launch(intent)
      } catch (e: Exception) {
        mapViewModel.setVoiceListening(false)
        Toast.makeText(context, "التعرف الصوتي غير متوفر على هذا الجهاز", Toast.LENGTH_SHORT).show()
      }
    } else {
      audioPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
    }
  }

  Box(
      modifier = modifier
          .fillMaxSize()
          .background(Color(0xFFF6F6F4))
  ) {
    // 1. Full-Screen OpenFreeMap with MapLibre engine
    OpenFreeMapView(
        modifier = Modifier
            .fillMaxSize()
            .testTag("openfreemap_view"),
        is3DMode = uiState.is3DMode,
        userLocation = uiState.userLocation,
        currentHeading = uiState.currentHeading,
        selectedPlace = uiState.selectedPlace,
        currentRoute = uiState.currentRoute,
        routeOptions = uiState.routeOptions,
        selectedRouteIndex = uiState.selectedRouteIndex,
        publicPlaces = uiState.allMapPlaces,
        roadReports = uiState.roadReports,
        liveVehicles = emptyList(),
        userVehicleProfile = uiState.userVehicleProfile,
        isRouteActive = uiState.isNavigating,
        centerOnUserTrigger = uiState.centerOnUserTrigger,
        onMapClick = { lat, lon ->
          mapViewModel.selectLocationFromCoordinates(lat, lon)
        },
        onPublicPlaceClick = { placeId ->
          mapViewModel.selectPublicPlace(placeId, currentUser?.uid ?: "")
        },
        onRoadReportClick = { reportId ->
          mapViewModel.selectRoadReport(reportId)
        },
        onVehicleClick = {},
        onPerspectiveChangedByGesture = { detected3D ->
          mapViewModel.set3DMode(detected3D)
        },
        onMapBoundsChanged = { minLat, maxLat, minLng, maxLng ->
          mapViewModel.onMapBoundsChanged(minLat, maxLat, minLng, maxLng)
        },
        onUserReverse = { lat, lng ->
          mapViewModel.triggerReroute(lat, lng)
        }
    )

    // 2. Top Bar Section: Navigation Turn Banner OR Search Bar + 2D/3D & Categories Buttons
    val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()
    Column(
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = statusBarPadding + 10.dp)
            .fillMaxWidth(),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
      // Detour proposal alert banner when hazard detected on route
      if (uiState.activeHazardProposal != null) {
        HazardDetourAlertBanner(
            proposal = uiState.activeHazardProposal,
            onAcceptDetour = { mapViewModel.acceptDetourProposal() },
            onDismissDetour = { mapViewModel.dismissDetourProposal() },
            modifier = Modifier
                .padding(horizontal = 14.dp)
                .fillMaxWidth()
        )
        Spacer(modifier = Modifier.height(8.dp))
      }

      if (uiState.isNavigating && uiState.currentRoute != null) {
        NavigationTurnBanner(
            route = uiState.currentRoute!!,
            currentStepIndex = uiState.currentStepIndex,
            isVoiceMuted = uiState.isVoiceGuidanceMuted,
            onToggleMute = { mapViewModel.toggleVoiceGuidanceMute() },
            onNextStep = { mapViewModel.nextNavigationStep() },
            onStopNavigation = { mapViewModel.stopNavigation() }
        )
      } else {
        // Search Bar with Real Geocoding & Dropdown
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 14.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
          MapSearchBar(
              query = uiState.searchQuery,
              onQueryChange = { mapViewModel.onSearchQueryChanged(it) },
              searchResults = uiState.searchResults,
              isSearching = uiState.isSearching,
              onPlaceSelected = { place ->
                mapViewModel.selectPlace(place, calculateRouteImmediately = false)
              },
              onVoiceClick = { startVoiceAssistant() },
              onProfileClick = onOpenSettings,
              onRefreshClick = { mapViewModel.refreshAppData() },
              isRefreshing = uiState.isRefreshingAppData,
              modifier = Modifier.fillMaxWidth()
          )
        }

        Spacer(modifier = Modifier.height(10.dp))

        // Row directly below search bar: 2D/3D Toggle + Categories Explore Button + Taxi Status Pill
        Row(
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
          PerspectiveToggleButton(
              is3D = uiState.is3DMode,
              onToggle = { enable3D ->
                mapViewModel.set3DMode(enable3D)
              }
          )

          ExplorePillButton(
              onClick = { mapViewModel.openExploreSheet() }
          )

          val isTaxiOwner = uiState.userVehicleProfile?.isTaxiOwner == true
          val isTaxiAvailable = uiState.userVehicleProfile?.taxiStatus == com.example.data.model.TaxiDriverStatus.AVAILABLE
          Surface(
              shape = RoundedCornerShape(20.dp),
              color = if (isTaxiOwner && isTaxiAvailable) Color(0xFF0F766E) else Color.White,
              shadowElevation = 3.dp,
              modifier = Modifier
                  .clip(RoundedCornerShape(20.dp))
                  .clickable { if (isTaxiOwner) mapViewModel.toggleTaxiAvailability() else mapViewModel.openTaxiList() }
                  .testTag("taxi_main_button")
          ) {
            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(5.dp), modifier = Modifier.padding(horizontal = 10.dp, vertical = 7.dp)) {
              Icon(Icons.Default.LocalTaxi, contentDescription = "التاكسي", tint = if (isTaxiOwner && isTaxiAvailable) Color.White else DrawRed, modifier = Modifier.size(18.dp))
              Text(
                  text = if (isTaxiOwner) (if (isTaxiAvailable) "متاح" else "مشغول") else "تاكسي",
                  fontSize = 11.5.sp,
                  fontWeight = FontWeight.Bold,
                  color = if (isTaxiOwner && isTaxiAvailable) Color.White else DrawTextNearBlack
              )
            }
          }
        }
      }
    }

    // 3. Bottom Floating Action Buttons (iOS style rounded controls)
    if (!uiState.isNavigating) {
      // Corner 1: Voice Search Floating Button (Bottom-Start)
      Box(
          modifier = Modifier
              .align(Alignment.BottomStart)
              .padding(start = 20.dp, bottom = 32.dp)
      ) {
        FloatingRoundButton(
            icon = Icons.Default.Mic,
            contentDescription = "Voice Search",
            tint = DrawRed,
            size = 54.dp,
            testTag = "bottom_voice_button",
            onClick = { startVoiceAssistant() }
        )
      }

      // Corner 2: Favorites, Notifications & My Location Buttons (Bottom-End)
      Column(
          modifier = Modifier
              .align(Alignment.BottomEnd)
              .padding(end = 20.dp, bottom = 32.dp),
          horizontalAlignment = Alignment.CenterHorizontally,
          verticalArrangement = Arrangement.spacedBy(12.dp)
      ) {
        // 1. Favorites Floating Button (Directly above Notifications Bell)
        FloatingRoundButton(
            icon = Icons.Default.Bookmark,
            contentDescription = "المفضلة والأماكن المحفوظة",
            tint = DrawRed,
            size = 50.dp,
            testTag = "favorites_floating_button",
            onClick = {
              mapViewModel.openSavedPlacesSheet()
            }
        )

        // 2. Notifications Bell Button with Unread Badge
        Box {
          FloatingRoundButton(
              icon = Icons.Default.Notifications,
              contentDescription = "الإشعارات",
              tint = if (uiState.unreadNotificationsCount > 0) DrawRed else Color(0xFF3A3A3C),
              size = 50.dp,
              testTag = "notifications_bell_button",
              onClick = { mapViewModel.openNotificationsSheet() }
          )
          if (uiState.unreadNotificationsCount > 0) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .size(19.dp)
                    .clip(CircleShape)
                    .background(DrawRed)
                    .border(1.5.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
              Text(
                  text = if (uiState.unreadNotificationsCount > 99) "99+" else "${uiState.unreadNotificationsCount}",
                  color = Color.White,
                  fontSize = 9.5.sp,
                  fontWeight = FontWeight.Bold
              )
            }
          }
        }



        // My Location Button
        FloatingRoundButton(
            icon = Icons.Default.MyLocation,
            contentDescription = "My Location",
            tint = Color(0xFF007AFF),
            size = 50.dp,
            testTag = "bottom_my_location_button",
            onClick = {
              if (locationRepository.hasLocationPermission()) {
                mapViewModel.checkPermissionAndFetchLocation(autoCenter = true)
                mapViewModel.requestCenterOnUser()
              } else {
                locationPermissionLauncher.launch(
                    arrayOf(
                        Manifest.permission.ACCESS_FINE_LOCATION,
                        Manifest.permission.ACCESS_COARSE_LOCATION
                    )
                )
              }
            }
        )
      }

      // Reports / بلاغات Floating Action Button
      // Positioned vertically near the current GPS and My Location controls.
      // Not placed beside or inside the existing three map controls; preserving their exact positions.
      Surface(
          onClick = { mapViewModel.openReportsSheet() },
          shape = RoundedCornerShape(22.dp),
          color = Color.White,
          shadowElevation = 5.dp,
          modifier = Modifier
              .align(Alignment.BottomEnd)
              .padding(end = 20.dp, bottom = 226.dp)
              .height(44.dp)
              .testTag("reports_button")
      ) {
        Row(
            modifier = Modifier.padding(horizontal = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Icon(
              imageVector = Icons.Default.Warning,
              contentDescription = "Reports / بلاغات",
              tint = Color(0xFFDC2626),
              modifier = Modifier.size(19.dp)
          )
          Text(
              text = "Reports / بلاغات",
              fontSize = 12.5.sp,
              fontWeight = FontWeight.Bold,
              color = Color(0xFF1C1C1E)
          )
        }
      }
    }

    // 4. Bottom Cards: Route Summary OR Public Place Card OR Discovered POI OR Place Details Card
    Box(
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 16.dp)
    ) {
      if (uiState.currentRoute != null && !uiState.isNavigating) {
        RouteSummaryCard(
            routeOptions = uiState.routeOptions,
            selectedRouteIndex = uiState.selectedRouteIndex,
            destinationName = uiState.selectedPublicPlace?.title
                ?: uiState.discoveredCandidate?.title
                ?: uiState.selectedPlace?.shortTitle
                ?: "الوجهة المحددة",
            onSelectRoute = { index -> mapViewModel.selectRouteOption(index) },
            onStartNavigation = { mapViewModel.startNavigation() },
            onDismissRoute = { mapViewModel.clearSelection() }
        )
      } else if (uiState.selectedPublicPlace != null && !uiState.isNavigating) {
        PublicPlaceDetailsCard(
            place = uiState.selectedPublicPlace!!,
            currentUserId = user?.uid ?: "",
            isLiked = uiState.isCurrentPlaceLiked,
            likesCount = uiState.currentPlaceLikesCount,
            commentsCount = uiState.currentPlaceCommentsCount,
            isCalculatingRoute = uiState.isCalculatingRoute,
            isSavingPlace = uiState.isSavingPlace,
            onToggleLike = {
              if (user == null || user.isAnonymous) {
                mapViewModel.showGuestRestrictionDialog("لتتمكن من الإعجاب بالأماكن")
              } else {
                mapViewModel.togglePlaceLike(user)
              }
            },
            onOpenComments = {
              mapViewModel.openCommentsSheet(currentUserId = user?.uid ?: "")
            },
            onDirectionsClick = {
              val p = uiState.selectedPublicPlace!!
              mapViewModel.calculateRouteToPlace(
                  NominatimResult.fromCoordinates(
                      lat = p.latitude,
                      lon = p.longitude,
                      title = p.title
                  )
              )
            },
            onSavePlace = {
              if (user == null || user.isAnonymous) {
                mapViewModel.showGuestRestrictionDialog("لحفظ الأماكن في المفضلة")
              } else {
                mapViewModel.savePublicPlaceToFavorites(user.uid)
              }
            },
            onDeletePlace = {
              mapViewModel.deletePublicPlace(uiState.selectedPublicPlace!!.id, user?.uid ?: "")
            },
            onCloseClick = { mapViewModel.dismissPublicPlace() }
        )
      } else if (uiState.discoveredCandidate != null && !uiState.isNavigating) {
        DiscoveredPlaceCard(
            candidate = uiState.discoveredCandidate!!,
            isCalculatingRoute = uiState.isCalculatingRoute,
            onCalculateRoute = {
              val cand = uiState.discoveredCandidate!!
              mapViewModel.calculateRouteToPlace(
                  NominatimResult.fromCoordinates(
                      lat = cand.latitude,
                      lon = cand.longitude,
                      title = cand.title
                  )
              )
            },
            onDismiss = { mapViewModel.dismissDiscoveredPlace() }
        )
      } else if (uiState.selectedPlace != null && !uiState.isNavigating) {
        PlaceDetailsCard(
            place = uiState.selectedPlace!!,
            userLocation = uiState.userLocation,
            isCalculatingRoute = uiState.isCalculatingRoute,
            isSavingPlace = uiState.isSavingPlace,
            onDirectionsClick = {
              mapViewModel.calculateRouteToPlace(uiState.selectedPlace!!)
            },
            onSaveFavoriteClick = {
              if (user == null || user.isAnonymous) {
                mapViewModel.showGuestRestrictionDialog("لحفظ الأماكن في المفضلة")
              } else {
                mapViewModel.saveCurrentPlaceToFavorites(user.uid)
              }
            },
            onAddCustomPlaceClick = {
              if (user == null || user.isAnonymous) {
                mapViewModel.showGuestRestrictionDialog("لتتمكن من إضافة ونشر أماكن جديدة")
              } else {
                mapViewModel.openAddCustomPlaceDialog(
                    tappedLat = uiState.selectedPlace?.latitude,
                    tappedLng = uiState.selectedPlace?.longitude
                )
              }
            },
            onCloseClick = {
              mapViewModel.clearSelection()
            }
        )
      }

    }

    // Arrival Celebration Card with Smooth Animations
    AnimatedVisibility(
        visible = uiState.hasArrived,
        enter = fadeIn(tween(400)) + slideInVertically(tween(400)),
        exit = fadeOut(tween(400)) + slideOutVertically(tween(400)),
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 20.dp)
    ) {
      ArrivalCelebrationCard(
          destinationName = uiState.arrivedDestinationName,
          onDismiss = { mapViewModel.dismissArrival() }
      )
    }

    // 5. Explore 60 Categories Modal Sheet
    if (uiState.isExploreSheetOpen) {
      ExploreCategoriesSheet(
          userLocation = uiState.userLocation,
          publicPlaces = uiState.publicPlaces,
          onPlaceSelected = { place ->
            mapViewModel.flyToPlace(place.latitude, place.longitude, place.title)
          },
          onCategorySelected = { iconItem ->
            mapViewModel.onExploreCategorySelected(iconItem)
          },
          onDismiss = { mapViewModel.closeExploreSheet() }
      )
    }

    if (uiState.isTaxiListOpen) {
      TaxiListBottomSheet(
          vehicles = sortedTaxiVehicles,
          onVehicleSelected = { vehicle ->
            mapViewModel.closeTaxiList()
            mapViewModel.onVehicleClick(vehicle.effectiveUserId)
          },
          onDismiss = { mapViewModel.closeTaxiList() }
      )
    }

    // 6. Saved Places Modal Sheet
    if (uiState.isSavedPlacesSheetOpen) {
      val myPlaces = remember(uiState.publicPlaces, user?.uid) {
        val uid = user?.uid ?: ""
        if (uid.isBlank()) emptyList() else uiState.publicPlaces.filter { it.creatorId == uid }
      }
      SavedPlacesSheet(
          favorites = uiState.savedFavorites,
          myPlaces = myPlaces,
          onPlaceSelected = { saved ->
            mapViewModel.closeSavedPlacesSheet()
            mapViewModel.selectLocationFromCoordinates(
                lat = saved.latitude,
                lon = saved.longitude,
                title = saved.title
            )
          },
          onMyPlaceSelected = { place ->
            mapViewModel.closeSavedPlacesSheet()
            mapViewModel.selectLocationFromCoordinates(
                lat = place.latitude,
                lon = place.longitude,
                title = place.title
            )
            mapViewModel.selectPublicPlace(place.id, user?.uid ?: "")
          },
          onAddNewPlaceClick = {
            if (user == null || user.isAnonymous) {
              mapViewModel.showGuestRestrictionDialog()
            } else {
              mapViewModel.openAddCustomPlaceDialog(
                  tappedLat = uiState.userLocation?.latitude,
                  tappedLng = uiState.userLocation?.longitude
              )
            }
          },
          onDeletePlace = { placeId ->
            mapViewModel.removeFavorite(user?.uid ?: "", placeId)
          },
          onDismiss = { mapViewModel.closeSavedPlacesSheet() }
      )
    }

    // 7. Add Place Dialog (Mandatory 2 to 5 photos)
    if (uiState.isAddCustomPlaceDialogOpen) {
      AddCustomPlaceDialog(
          placeName = uiState.customPlaceName,
          address = uiState.customPlaceAddress,
          description = uiState.customPlaceDescription,
          category = uiState.customPlaceCategory,
          selectedIconId = uiState.customPlaceIconId,
          latitude = uiState.customPlaceLat,
          longitude = uiState.customPlaceLng,
          selectedImageUris = uiState.customPlaceImageUris,
          isPublishing = uiState.isPublishingPlace,
          onNameChange = { mapViewModel.onCustomPlaceNameChanged(it) },
          onAddressChange = { mapViewModel.onCustomPlaceAddressChanged(it) },
          onDescriptionChange = { mapViewModel.onCustomPlaceDescriptionChanged(it) },
          onCategoryChange = { mapViewModel.onCustomPlaceCategoryChanged(it) },
          onIconSelected = { mapViewModel.onCustomPlaceIconChanged(it) },
          onImagesPicked = { mapViewModel.onAddPlaceImagesPicked(it) },
          onImageRemoved = { mapViewModel.onAddPlaceImageRemoved(it) },
          onPublish = {
            mapViewModel.publishCommunityPlace(context, user)
          },
          onDismiss = { mapViewModel.closeAddCustomPlaceDialog() }
      )
    }

    // 8. Comments Bottom Sheet (75% height, dimmed background, real-time comments & likes)
    val activeCommentsPlace = uiState.selectedPublicPlace
    if (uiState.isCommentsSheetOpen && activeCommentsPlace != null) {
      CommentsBottomSheet(
          placeTitle = activeCommentsPlace.title,
          comments = uiState.placeComments,
          userLikedCommentIds = uiState.userLikedCommentIds,
          isGuest = (user == null || user.isAnonymous),
          isSubmitting = uiState.isSubmittingComment,
          currentUserId = user?.uid ?: "",
          onAddComment = { text ->
            if (user == null || user.isAnonymous) {
              mapViewModel.showGuestRestrictionDialog("لتتمكن من كتابة تعليق")
            } else {
              mapViewModel.addComment(text, user)
            }
          },
          onToggleCommentLike = { comment ->
            if (user == null || user.isAnonymous) {
              mapViewModel.showGuestRestrictionDialog("لتتمكن من الإعجاب بالتعليقات")
            } else {
              mapViewModel.toggleCommentLike(comment, user)
            }
          },
          onDeleteComment = { comment ->
            user?.uid?.let { uid ->
              mapViewModel.deleteComment(comment, uid)
            }
          },
          onRequireLogin = {
            mapViewModel.showGuestRestrictionDialog("لتتمكن من كتابة التعليقات والتفاعل")
          },
          onDismiss = { mapViewModel.closeCommentsSheet() }
      )
    }

    // Guest Restriction Dialog for Protected Operations
    if (uiState.isGuestPublishRestricted) {
      AlertDialog(
          onDismissRequest = { mapViewModel.closeGuestRestrictionDialog() },
          icon = {
            Box(
                modifier = Modifier
                    .size(54.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFFFECEB)),
                contentAlignment = Alignment.Center
            ) {
              Icon(
                  imageVector = Icons.Default.Lock,
                  contentDescription = null,
                  tint = DrawRed,
                  modifier = Modifier.size(28.dp)
              )
            }
          },
          title = {
            Text(
                text = "تنبيه الحساب",
                fontWeight = FontWeight.Bold,
                fontSize = 18.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
          },
          text = {
            Text(
                text = uiState.guestRestrictionMessage,
                fontSize = 14.5.sp,
                color = DrawTextSecondary,
                lineHeight = 22.sp,
                textAlign = TextAlign.Center,
                modifier = Modifier.fillMaxWidth()
            )
          },
          confirmButton = {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Button(
                  onClick = {
                    mapViewModel.closeGuestRestrictionDialog()
                    onNavigateToAuth(AuthScreenType.LOGIN)
                  },
                  colors = ButtonDefaults.buttonColors(
                      containerColor = DrawRed,
                      contentColor = Color.White
                  ),
                  shape = RoundedCornerShape(12.dp),
                  modifier = Modifier.weight(1f).testTag("guest_dialog_login_button")
              ) {
                Text("تسجيل الدخول", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 12.5.sp)
              }

              OutlinedButton(
                  onClick = {
                    mapViewModel.closeGuestRestrictionDialog()
                    onNavigateToAuth(AuthScreenType.CREATE_ACCOUNT)
                  },
                  shape = RoundedCornerShape(12.dp),
                  colors = ButtonDefaults.outlinedButtonColors(contentColor = DrawTextNearBlack),
                  modifier = Modifier.weight(1f).testTag("guest_dialog_create_account_button")
              ) {
                Text("إنشاء حساب", fontWeight = FontWeight.Bold, color = DrawTextNearBlack, fontSize = 12.5.sp)
              }
            }
          },
          dismissButton = {
            TextButton(
                onClick = { mapViewModel.closeGuestRestrictionDialog() },
                modifier = Modifier.fillMaxWidth()
            ) {
              Text("إلغاء", color = DrawTextSecondary, fontSize = 13.sp)
            }
          },
          shape = RoundedCornerShape(24.dp)
      )
    }

    // 9. Notifications Center Sheet
    if (uiState.isNotificationsSheetOpen) {
      NotificationsSheet(
          notifications = uiState.userNotifications,
          unreadCount = uiState.unreadNotificationsCount,
          onNotificationClick = { notification ->
            mapViewModel.onNotificationClicked(notification, currentUser?.uid ?: "")
          },
          onMarkAllAsRead = {
            mapViewModel.markAllNotificationsAsRead(currentUser?.uid ?: "")
          },
          onDismiss = { mapViewModel.closeNotificationsSheet() }
      )
    }

    // 10. DRAW Intelligent Voice & AI Assistant Modal Sheet
    if (uiState.isAiAssistantOpen) {
      DrawAiAssistantSheet(
          messages = uiState.aiAssistantMessages,
          isLoading = uiState.isAiAssistantLoading,
          isListening = uiState.isVoiceListening,
          conversationSessions = uiState.aiConversationSessions,
          isGuest = (user == null || user.isAnonymous),
          isAiSpeaking = uiState.isAiSpeaking,
          currentlySpeakingMessageId = uiState.currentlySpeakingAiMessageId,
          isAutoPlayEnabled = uiState.isAiTtsAutoPlayEnabled,
          onSendMessage = { prompt ->
            mapViewModel.sendAiAssistantPrompt(prompt, user?.uid ?: "")
          },
          onStartVoiceInput = {
            startVoiceAssistant()
          },
          onSelectSuggestion = { suggestion, startNav ->
            mapViewModel.selectAiPlaceSuggestion(suggestion, startNav)
          },
          onSelectSession = { convId ->
            user?.uid?.let { uid ->
              mapViewModel.selectAiConversation(uid, convId)
            }
          },
          onNewChat = {
            mapViewModel.startNewAiConversation()
          },
          onToggleSpeech = { messageId, text ->
            mapViewModel.toggleAiSpeech(messageId, text)
          },
          onToggleAutoPlay = {
            mapViewModel.toggleAiTtsAutoPlay()
          },
          onDismiss = {
            mapViewModel.closeAiAssistant()
          }
      )
    }

    // 9. Profile & Account Dialog
    if (uiState.isProfileMenuOpen) {
      ProfileMenuDialog(
          userEmail = user?.email ?: user?.displayName ?: "مستخدم زائر",
          onSignOut = {
            mapViewModel.toggleProfileMenu()
            sessionManager.signOut()
            onSignOutRequested()
          },
          onDismiss = { mapViewModel.toggleProfileMenu() }
      )
    }

    // Road Reports Bottom Sheet (9 report types)
    if (uiState.isReportsSheetOpen) {
      ReportsBottomSheet(
          onDismissRequest = { mapViewModel.closeReportsSheet() },
          onReportTypeSelected = { type, note ->
            mapViewModel.submitRoadReport(type, note, currentUser)
          }
      )
    }

    // Road Report Details Bottom Sheet (Owner Delete & GPS "Road is Clear" Verification)
    val activeReport = uiState.selectedRoadReport
    if (activeReport != null) {
      ReportDetailsBottomSheet(
          report = activeReport,
          currentUserId = user?.uid ?: "",
          verificationSession = uiState.verificationSession,
          onDismissRequest = { mapViewModel.closeReportDetails() },
          onStartResolution = { mapViewModel.startRoadReportResolution(activeReport) },
          onCancelResolution = { mapViewModel.cancelRoadReportResolution() },
          onDeleteReport = { reportId ->
            mapViewModel.deleteRoadReport(reportId, user?.uid ?: "")
          }
      )
    }

    // 9. Status / Error Notification Pill Banner
    val statusText = uiState.statusMessage ?: uiState.errorMessage
    AnimatedVisibility(
        visible = statusText != null,
        enter = fadeIn() + slideInVertically(initialOffsetY = { -it }),
        exit = fadeOut() + slideOutVertically(targetOffsetY = { -it }),
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = statusBarPadding + 70.dp, start = 20.dp, end = 20.dp)
    ) {
      if (statusText != null) {
        val isError = uiState.errorMessage != null
        Surface(
            shape = RoundedCornerShape(16.dp),
            color = if (isError) Color(0xFFD32F2F) else Color(0xFF323232),
            shadowElevation = 8.dp,
            modifier = Modifier.clickable {
              mapViewModel.clearStatus()
              mapViewModel.clearError()
            }
        ) {
          Text(
              text = statusText,
              color = Color.White,
              fontSize = 13.5.sp,
              fontWeight = FontWeight.Medium,
              textAlign = TextAlign.Center,
              modifier = Modifier.padding(horizontal = 18.dp, vertical = 10.dp)
          )
        }
      }
    }

    // 10. Incoming Order Notification Banner for Driver (Top Dropdown with Tone Cue)
    IncomingOrderBanner(
        incomingOrder = uiState.incomingOrder,
        onAccept = { order -> mapViewModel.acceptIncomingOrder(order) },
        onReject = { order -> mapViewModel.rejectIncomingOrder(order) },
        modifier = Modifier
            .align(Alignment.TopCenter)
            .padding(top = statusBarPadding + 6.dp)
    )

    // 11. Active Order Tracking Card (Mutual Live Ride Tracking)
    ActiveOrderTrackingCard(
        order = uiState.activeOrder,
        currentUserId = currentUser?.uid ?: "",
        onAdvanceStatus = { order, newStatus -> mapViewModel.advanceOrderStatus(order, newStatus) },
        onCancelOrder = { order -> mapViewModel.cancelOrder(order) },
        onDismissCard = { mapViewModel.dismissActiveOrderCard() },
        onSubmitReview = { order, liked, comment -> mapViewModel.submitTripReview(order, liked, comment) },
        modifier = Modifier
            .align(Alignment.BottomCenter)
            .padding(bottom = 16.dp)
    )

    // 12. Driver Profile & Vehicle Details Bottom Sheet
    val selectedDriver = uiState.selectedDriverVehicle
    if (uiState.isDriverProfileOpen && selectedDriver != null) {
      val distMeters = remember(uiState.userLocation, selectedDriver) {
        val loc = uiState.userLocation
        if (loc != null) {
          val res = FloatArray(1)
          android.location.Location.distanceBetween(
              loc.latitude, loc.longitude,
              selectedDriver.latitude, selectedDriver.longitude,
              res
          )
          res[0].toDouble()
        } else null
      }
      val isSelf = selectedDriver.userId == (currentUser?.uid ?: "")

      DriverProfileBottomSheet(
          vehicle = selectedDriver,
          distanceMeters = distMeters,
          isSelf = isSelf,
          onRequestOrder = { v -> mapViewModel.requestOrderFromDriver(v) },
          onLikeDriver = { v ->
            if (currentUser == null || currentUser!!.isAnonymous) mapViewModel.showGuestRestrictionDialog("لتتمكن من الإعجاب بالسائق")
            else mapViewModel.toggleDriverLike(v)
          },
          onCommentDriver = { v, text ->
            if (currentUser == null || currentUser!!.isAnonymous) mapViewModel.showGuestRestrictionDialog("لتتمكن من التعليق على السائق")
            else mapViewModel.addDriverComment(v, text)
          },
          onOpenComments = { v -> mapViewModel.openTaxiComments(v) },
          onDismiss = { mapViewModel.dismissDriverProfile() },
          onReportDriver = { driverId, reason -> mapViewModel.submitReportDriver(driverId, reason) }
      )
    }
    if (uiState.isTaxiCommentsSheetOpen) {
      val taxi = uiState.liveVehicles.firstOrNull { it.effectiveUserId == uiState.taxiCommentsDriverId }
      CommentsBottomSheet(
          placeTitle = taxi?.driverName?.ifBlank { "سائق تاكسي" } ?: "تعليقات التاكسي",
          comments = uiState.taxiComments,
          userLikedCommentIds = uiState.taxiUserLikedCommentIds,
          isGuest = currentUser == null || currentUser!!.isAnonymous,
          isSubmitting = false,
          currentUserId = currentUser?.uid ?: "",
          onAddComment = { text -> mapViewModel.addTaxiComment(uiState.taxiCommentsDriverId, text, currentUser) },
          onToggleCommentLike = { comment -> mapViewModel.toggleTaxiCommentLike(uiState.taxiCommentsDriverId, comment, currentUser) },
          onDeleteComment = { comment -> mapViewModel.deleteTaxiComment(uiState.taxiCommentsDriverId, comment, currentUser) },
          onRequireLogin = { mapViewModel.showGuestRestrictionDialog("لتتمكن من التعليق على التاكسي") },
          onDismiss = { mapViewModel.closeTaxiComments() }
      )
    }
  }
}

/**
 * iOS-styled circular floating action button with soft drop shadow.
 */
@Composable
private fun FloatingRoundButton(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    contentDescription: String,
    tint: Color,
    size: androidx.compose.ui.unit.Dp,
    testTag: String,
    onClick: () -> Unit
) {
  val shape = CircleShape
  Surface(
      onClick = onClick,
      shape = shape,
      color = Color.White,
      shadowElevation = 8.dp,
      modifier = Modifier
          .size(size)
          .border(width = 0.8.dp, color = Color(0x18000000), shape = shape)
          .testTag(testTag)
  ) {
    Box(
        contentAlignment = Alignment.Center,
        modifier = Modifier.fillMaxSize()
    ) {
      Icon(
          imageVector = icon,
          contentDescription = contentDescription,
          tint = tint,
          modifier = Modifier.size(size * 0.48f)
      )
    }
  }
}

/**
 * Pill button for opening 60-Categories exploration sheet.
 */
@Composable
private fun ExplorePillButton(
    onClick: () -> Unit
) {
  val shape = RoundedCornerShape(24.dp)
  Surface(
      onClick = onClick,
      modifier = Modifier
          .shadow(elevation = 6.dp, shape = shape, spotColor = Color(0x28000000))
          .border(width = 0.8.dp, color = Color(0x18000000), shape = shape)
          .testTag("explore_categories_button"),
      shape = shape,
      color = Color.White
  ) {
    Row(
        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
      Icon(
          imageVector = Icons.Default.Explore,
          contentDescription = "استكشاف الأقسام",
          tint = DrawRed,
          modifier = Modifier.size(18.dp)
      )
      Spacer(modifier = Modifier.width(6.dp))
      Text(
          text = "الأقسام (60)",
          color = DrawTextNearBlack,
          fontWeight = FontWeight.Bold,
          fontSize = 12.5.sp
      )
    }
  }
}

/**
 * iOS-styled 2D / 3D segmented capsule toggle button.
 */
@Composable
private fun PerspectiveToggleButton(
    is3D: Boolean,
    onToggle: (Boolean) -> Unit
) {
  val shape = RoundedCornerShape(24.dp)

  Surface(
      modifier = Modifier
          .shadow(elevation = 6.dp, shape = shape, spotColor = Color(0x28000000))
          .border(width = 0.8.dp, color = Color(0x18000000), shape = shape)
          .testTag("perspective_toggle_button"),
      shape = shape,
      color = Color.White
  ) {
    Row(
        modifier = Modifier.padding(3.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
      PerspectiveSegment(
          label = "2D",
          isSelected = !is3D,
          onClick = { onToggle(false) },
          testTag = "perspective_segment_2d"
      )
      PerspectiveSegment(
          label = "3D",
          isSelected = is3D,
          onClick = { onToggle(true) },
          testTag = "perspective_segment_3d"
      )
    }
  }
}

@Composable
private fun PerspectiveSegment(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    testTag: String
) {
  val segmentShape = RoundedCornerShape(20.dp)
  val backgroundColor by animateColorAsState(
      targetValue = if (isSelected) DrawRed else Color.Transparent,
      animationSpec = tween(durationMillis = 200),
      label = "segment_bg"
  )
  val contentColor by animateColorAsState(
      targetValue = if (isSelected) Color.White else Color(0xFF666666),
      animationSpec = tween(durationMillis = 200),
      label = "segment_color"
  )

  Box(
      modifier = Modifier
          .clip(segmentShape)
          .background(backgroundColor)
          .clickable(
              interactionSource = remember { MutableInteractionSource() },
              indication = null,
              onClick = onClick
          )
          .padding(horizontal = 18.dp, vertical = 6.dp)
          .testTag(testTag),
      contentAlignment = Alignment.Center
  ) {
    Text(
        text = label,
        color = contentColor,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        fontSize = 13.sp
    )
  }
}

/**
 * Profile & Settings Dialog.
 */
@Composable
private fun ProfileMenuDialog(
    userEmail: String,
    onSignOut: () -> Unit,
    onDismiss: () -> Unit
) {
  Dialog(onDismissRequest = onDismiss) {
    val shape = RoundedCornerShape(26.dp)
    Surface(
        shape = shape,
        color = Color.White,
        modifier = Modifier
            .fillMaxWidth()
            .padding(16.dp)
            .testTag("profile_dialog")
    ) {
      Column(
          modifier = Modifier
              .fillMaxWidth()
              .padding(22.dp),
          horizontalAlignment = Alignment.CenterHorizontally
      ) {
        Box(
            modifier = Modifier
                .size(56.dp)
                .clip(CircleShape)
                .background(Color(0xFFFFECEB)),
            contentAlignment = Alignment.Center
        ) {
          Icon(
              imageVector = Icons.Default.AccountCircle,
              contentDescription = null,
              tint = DrawRed,
              modifier = Modifier.size(36.dp)
          )
        }

        Spacer(modifier = Modifier.height(12.dp))

        Text(
            text = "حساب DRAW",
            fontSize = 17.sp,
            fontWeight = FontWeight.Bold,
            color = DrawTextNearBlack
        )

        Spacer(modifier = Modifier.height(4.dp))

        Text(
            text = userEmail,
            fontSize = 13.sp,
            color = DrawTextSecondary,
            textAlign = TextAlign.Center
        )

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onSignOut,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = DrawRed, contentColor = Color.White),
            modifier = Modifier
                .fillMaxWidth()
                .height(46.dp)
                .testTag("profile_sign_out_button")
        ) {
          Text(text = "تسجيل الخروج", color = Color.White, fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(8.dp))

        Button(
            onClick = onDismiss,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFF2F2F7)),
            modifier = Modifier
                .fillMaxWidth()
                .height(44.dp)
        ) {
          Text(text = "إغلاق", color = DrawTextNearBlack, fontWeight = FontWeight.Medium)
        }
      }
    }
  }
}
