package com.example.ui.map.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.HorizontalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import coil.compose.AsyncImage
import com.example.data.model.PublicPlace
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/**
 * Interactive post-style card for a published place in DRAW,
 * featuring photo carousel, publisher badge, Likes, Comments, Save, and Directions routing.
 * (Star ratings have been completely removed as per instructions).
 */
@Composable
fun PublicPlaceDetailsCard(
    place: PublicPlace,
    currentUserId: String,
    isLiked: Boolean,
    likesCount: Long,
    commentsCount: Long,
    isCalculatingRoute: Boolean,
    isSavingPlace: Boolean = false,
    onToggleLike: () -> Unit,
    onOpenComments: () -> Unit,
    onDirectionsClick: () -> Unit,
    onSavePlace: () -> Unit = {},
    onDeletePlace: () -> Unit,
    onCloseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
  val iconItem = PlaceIconRegistry.getIconById(place.iconId)
  val isOwner = currentUserId.isNotBlank() && currentUserId == place.creatorId
  val shape = RoundedCornerShape(26.dp)
  var enlargedImageIndex by remember { mutableStateOf<Int?>(null) }

  val heartColor by animateColorAsState(
      targetValue = if (isLiked) DrawRed else Color(0xFF636366),
      label = "place_heart_color"
  )

  Surface(
      modifier = modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp)
          .shadow(elevation = 16.dp, shape = shape, spotColor = Color(0x38000000))
          .border(width = 0.8.dp, color = Color(0x18000000), shape = shape)
          .testTag("public_place_details_card"),
      shape = shape,
      color = Color(0xFDFDFDFF)
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp)
    ) {
      // 1. Header with DRAW Category Icon, Title, and Close Button
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
          Box(
              modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .background(iconItem.primaryColor),
              contentAlignment = Alignment.Center
          ) {
            Icon(
                imageVector = iconItem.iconVector,
                contentDescription = iconItem.nameArabic,
                tint = Color.White,
                modifier = Modifier.size(22.dp)
            )
          }
          Spacer(modifier = Modifier.width(12.dp))
          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = place.title,
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            if (place.address.isNotBlank()) {
              Text(
                  text = place.address,
                  fontSize = 12.sp,
                  color = Color(0xFF636366),
                  maxLines = 1,
                  overflow = TextOverflow.Ellipsis
              )
            }
            Text(
                text = "${iconItem.nameArabic} • ${iconItem.categoryArabic}",
                fontSize = 11.5.sp,
                fontWeight = FontWeight.SemiBold,
                color = iconItem.primaryColor
            )
          }
        }

        IconButton(
            onClick = onCloseClick,
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(Color(0xFFE5E5EA))
                .testTag("close_public_place_details")
        ) {
          Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = Color(0xFF3A3A3C),
              modifier = Modifier.size(16.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 2. Photo Carousel / Slider with Tap-to-Enlarge
      if (place.images.isNotEmpty()) {
        val pagerState = rememberPagerState(pageCount = { place.images.size })
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(155.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(Color(0xFFF2F2F7))
        ) {
          HorizontalPager(
              state = pagerState,
              modifier = Modifier.fillMaxWidth()
          ) { pageIndex ->
            AsyncImage(
                model = place.images[pageIndex],
                contentDescription = "Photo ${pageIndex + 1}",
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .fillMaxWidth()
                    .height(155.dp)
                    .clickable { enlargedImageIndex = pageIndex }
            )
          }

          if (place.images.size > 1) {
            Row(
                modifier = Modifier
                    .align(Alignment.BottomCenter)
                    .padding(bottom = 8.dp)
                    .background(Color(0x99000000), RoundedCornerShape(12.dp))
                .padding(horizontal = 8.dp, vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
              repeat(place.images.size) { i ->
                val isCurrent = pagerState.currentPage == i
                Box(
                    modifier = Modifier
                        .size(if (isCurrent) 7.dp else 5.dp)
                        .clip(CircleShape)
                        .background(if (isCurrent) Color.White else Color(0x88FFFFFF))
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))
      }

      // 3. Description
      if (place.description.isNotBlank()) {
        Text(
            text = place.description,
            fontSize = 13.5.sp,
            color = Color(0xFF3A3A3C),
            lineHeight = 19.sp,
            maxLines = 3,
            overflow = TextOverflow.Ellipsis
        )
        Spacer(modifier = Modifier.height(10.dp))
      }

      // 4. Publisher Info & Avatar & Date
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          if (place.creatorPhotoUrl.isNotBlank()) {
            AsyncImage(
                model = place.creatorPhotoUrl,
                contentDescription = place.creatorName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(24.dp)
                    .clip(CircleShape)
                    .border(0.8.dp, Color(0x22000000), CircleShape)
            )
          } else {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = Color(0xFF8E8E93),
                modifier = Modifier.size(16.dp)
            )
          }
          Spacer(modifier = Modifier.width(6.dp))
          Text(
              text = "نشر بواسطة: ${place.creatorName.ifBlank { "مستخدم DRAW" }}",
              fontSize = 12.sp,
              color = DrawTextSecondary,
              fontWeight = FontWeight.Medium
          )
        }

        if (place.createdAt > 0L) {
          val dateStr = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
              .format(Date(place.createdAt))
          Text(
              text = dateStr,
              fontSize = 11.5.sp,
              color = Color(0xFFAAAAAA)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))
      HorizontalDivider(color = Color(0x12000000), thickness = 0.8.dp)
      Spacer(modifier = Modifier.height(10.dp))

      // 5. Interactive Post Reactions Bar: Likes & Comments
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .background(Color(0xFFF8F8FA), RoundedCornerShape(16.dp))
              .padding(horizontal = 14.dp, vertical = 8.dp),
          horizontalArrangement = Arrangement.SpaceAround,
          verticalAlignment = Alignment.CenterVertically
      ) {
        // Like Button
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { onToggleLike() }
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .testTag("toggle_place_like_button")
        ) {
          Icon(
              imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
              contentDescription = "إعجاب",
              tint = heartColor,
              modifier = Modifier.size(22.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
              text = "$likesCount إعجاب",
              fontSize = 13.5.sp,
              fontWeight = if (isLiked) FontWeight.Bold else FontWeight.Medium,
              color = if (isLiked) DrawRed else DrawTextNearBlack
          )
        }

        Box(
            modifier = Modifier
                .width(1.dp)
                .height(20.dp)
                .background(Color(0x20000000))
        )

        // Comment Button
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier
                .clip(RoundedCornerShape(12.dp))
                .clickable { onOpenComments() }
                .padding(horizontal = 12.dp, vertical = 6.dp)
                .testTag("open_place_comments_button")
        ) {
          Icon(
              imageVector = Icons.Default.ChatBubbleOutline,
              contentDescription = "تعليقات",
              tint = Color(0xFF007AFF),
              modifier = Modifier.size(21.dp)
          )
          Spacer(modifier = Modifier.width(6.dp))
          Text(
              text = "$commentsCount تعليق",
              fontSize = 13.5.sp,
              fontWeight = FontWeight.Medium,
              color = DrawTextNearBlack
          )
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 6. Action Buttons: Directions, Save, and Delete (if owner)
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(8.dp),
          verticalAlignment = Alignment.CenterVertically
      ) {
        if (isOwner) {
          OutlinedButton(
              onClick = onDeletePlace,
              shape = RoundedCornerShape(16.dp),
              colors = ButtonDefaults.outlinedButtonColors(contentColor = DrawRed),
              modifier = Modifier
                  .height(46.dp)
                  .testTag("delete_public_place_button")
          ) {
            Icon(
                imageVector = Icons.Default.DeleteOutline,
                contentDescription = "Delete",
                tint = DrawRed,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("حذف", fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
        }

        // Save to Private List Button
        OutlinedButton(
            onClick = onSavePlace,
            enabled = !isSavingPlace,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.outlinedButtonColors(contentColor = DrawDarkRed),
            modifier = Modifier
                .height(46.dp)
                .testTag("public_place_save_button")
        ) {
          if (isSavingPlace) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = DrawRed
            )
          } else {
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                tint = DrawDarkRed,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text("حفظ", fontSize = 13.sp, fontWeight = FontWeight.Bold)
          }
        }

        Button(
            onClick = onDirectionsClick,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF007AFF)),
            modifier = Modifier
                .weight(1f)
                .height(46.dp)
                .testTag("public_place_directions_button")
        ) {
          if (isCalculatingRoute) {
            CircularProgressIndicator(
                color = Color.White,
                strokeWidth = 2.dp,
                modifier = Modifier.size(20.dp)
            )
          } else {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                  imageVector = Icons.Default.Directions,
                  contentDescription = null,
                  modifier = Modifier.size(19.dp)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                  text = "تحديد المسار",
                  fontSize = 14.5.sp,
                  fontWeight = FontWeight.Bold
              )
            }
          }
        }
      }
    }
  }

  // Full-screen / enlarged photo viewer dialog when tapping a photo
  if (enlargedImageIndex != null && place.images.isNotEmpty()) {
    val initialIdx = enlargedImageIndex!!.coerceIn(0, place.images.size - 1)
    val dialogPagerState = rememberPagerState(initialPage = initialIdx, pageCount = { place.images.size })
    Dialog(
        onDismissRequest = { enlargedImageIndex = null },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
      Box(
          modifier = Modifier
              .fillMaxSize()
              .background(Color(0xF0000000))
      ) {
        HorizontalPager(
            state = dialogPagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
          Box(
              modifier = Modifier.fillMaxSize(),
              contentAlignment = Alignment.Center
          ) {
            AsyncImage(
                model = place.images[page],
                contentDescription = "Enlarged photo ${page + 1}",
                contentScale = ContentScale.Fit,
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp)
            )
          }
        }

        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 44.dp, start = 20.dp, end = 20.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
              text = "${dialogPagerState.currentPage + 1} / ${place.images.size}",
              color = Color.White,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold
          )

          IconButton(
              onClick = { enlargedImageIndex = null },
              modifier = Modifier
                  .size(38.dp)
                  .background(Color(0x66FFFFFF), CircleShape)
          ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "إغلاق",
                tint = Color.White,
                modifier = Modifier.size(20.dp)
            )
          }
        }
      }
    }
  }
}
