package com.example.data.network

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

private const val TAG = "OpenRouterService"
private const val PREFS_NAME = "draw_openrouter_secure_prefs"
private const val KEY_API_KEY = "openrouter_api_key"
private const val KEY_MODEL = "openrouter_model"
private const val KEY_STATUS = "openrouter_status"
private const val KEY_LAST_ERROR = "openrouter_last_error"

enum class OpenRouterStatus(val labelArabic: String) {
  NOT_CONFIGURED("غير مهيأ"),
  CHECKING("جارٍ التحقق..."),
  CONNECTED("متصل"),
  FAILED("فشل الاتصال")
}

data class OpenRouterConfig(
    val apiKey: String = "",
    val model: String = "liquid/lfm-2.5-2.6b:free",
    val status: OpenRouterStatus = OpenRouterStatus.NOT_CONFIGURED,
    val lastError: String? = null
) {
  val isConnected: Boolean get() = status == OpenRouterStatus.CONNECTED && apiKey.isNotBlank()
  val isConfigured: Boolean get() = apiKey.isNotBlank()

  val maskedKey: String
    get() {
      if (apiKey.isBlank()) return ""
      return if (apiKey.length > 8) {
        apiKey.take(7) + "..." + apiKey.takeLast(4)
      } else {
        "••••••••"
      }
    }
}

class OpenRouterService(context: Context) {

  private val prefs: SharedPreferences =
      context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)

  private val client = OkHttpClient.Builder()
      .connectTimeout(15, TimeUnit.SECONDS)
      .readTimeout(30, TimeUnit.SECONDS)
      .writeTimeout(15, TimeUnit.SECONDS)
      .build()

  companion object {
    const val DEFAULT_MAP_API_KEY = "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"
    const val DEFAULT_CHAT_API_KEY = "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"
    const val DEFAULT_FREE_MODEL = "liquid/lfm-2.5-2.6b:free"

    val FREE_FALLBACK_MODELS = listOf(
        "liquid/lfm-2.5-2.6b:free",
        "nvidia/nemotron-3.5-lightning:free",
        "google/gemma-2-9b-it:free",
        "mistralai/mistral-7b-instruct:free",
        "meta-llama/llama-3.2-3b-instruct:free"
    )
  }

  fun getMapApiKey(): String {
    val key = prefs.getString("openrouter_map_api_key", "") ?: ""
    return if (key.isNotBlank()) key else DEFAULT_MAP_API_KEY
  }

  fun getChatApiKey(): String {
    val key = prefs.getString(KEY_API_KEY, "") ?: ""
    return if (key.isNotBlank()) key else DEFAULT_CHAT_API_KEY
  }

  fun getConfig(): OpenRouterConfig {
    val key = getChatApiKey()
    val rawModel = prefs.getString(KEY_MODEL, DEFAULT_FREE_MODEL) ?: DEFAULT_FREE_MODEL
    val model = if (rawModel.contains("gemini-2.5-flash")) DEFAULT_FREE_MODEL else rawModel
    val statusStr = prefs.getString(KEY_STATUS, null)
    val status = if (statusStr != null) {
      try { OpenRouterStatus.valueOf(statusStr) } catch (_: Exception) { OpenRouterStatus.CONNECTED }
    } else {
      OpenRouterStatus.CONNECTED
    }
    val error = prefs.getString(KEY_LAST_ERROR, null)
    return OpenRouterConfig(apiKey = key, model = model, status = status, lastError = error)
  }

  fun getMapConfig(): OpenRouterConfig {
    val key = getMapApiKey()
    val model = DEFAULT_FREE_MODEL
    return OpenRouterConfig(apiKey = key, model = model, status = OpenRouterStatus.CONNECTED, lastError = null)
  }

  fun saveConfig(config: OpenRouterConfig) {
    prefs.edit()
        .putString(KEY_API_KEY, config.apiKey)
        .putString(KEY_MODEL, config.model)
        .putString(KEY_STATUS, config.status.name)
        .putString(KEY_LAST_ERROR, config.lastError)
        .apply()
  }

  fun clearConfig() {
    prefs.edit().clear().apply()
  }

  /**
   * Performs an actual live verification check against OpenRouter's official auth endpoint.
   */
  suspend fun verifyApiKey(apiKey: String): Result<Boolean> = withContext(Dispatchers.IO) {
    val cleanKey = apiKey.trim()
    if (cleanKey.isBlank()) {
      return@withContext Result.failure(IllegalArgumentException("يرجى إدخال مفتاح OpenRouter صالح."))
    }

    try {
      val request = Request.Builder()
          .url("https://openrouter.ai/api/v1/auth/key")
          .header("Authorization", "Bearer $cleanKey")
          .header("HTTP-Referer", "https://draw.navigation.app")
          .header("X-Title", "DRAW Navigation")
          .get()
          .build()

      val response = client.newCall(request).execute()
      val responseBody = response.body?.string() ?: ""

      if (response.isSuccessful) {
        // OpenRouter /auth/key returns JSON with key metadata (data: { label, usage, limit, ... })
        Log.i(TAG, "OpenRouter API Key verification succeeded: HTTP ${response.code}")
        Result.success(true)
      } else {
        val errorMsg = try {
          val json = JSONObject(responseBody)
          json.optJSONObject("error")?.optString("message") ?: "رمز الاستجابة: ${response.code}"
        } catch (_: Exception) {
          "رمز الخطأ: ${response.code}"
        }
        Log.w(TAG, "OpenRouter verification failed: HTTP ${response.code} - $errorMsg")
        Result.failure(Exception("فشل التحقق من المفتاح: $errorMsg"))
      }
    } catch (e: Exception) {
      Log.e(TAG, "Network exception verifying OpenRouter key", e)
      Result.failure(Exception("تعذر الاتصال بخوادم OpenRouter: ${e.localizedMessage ?: "تحقق من اتصال الإنترنت"}"))
    }
  }

  /**
   * Generates a chat completion via OpenRouter official API with system and contextual prompts.
   * Automatically falls back across verified free-tier models if the primary model fails.
   */
  suspend fun generateChatCompletion(
      apiKey: String,
      model: String,
      systemInstruction: String,
      messages: List<Pair<String, String>>
  ): Result<String> = withContext(Dispatchers.IO) {
    val cleanKey = apiKey.trim()
    if (cleanKey.isBlank()) {
      return@withContext Result.failure(IllegalStateException("مفتاح OpenRouter غير مهيأ."))
    }

    val preferredModel = if (model.isBlank() || model.contains("gemini-2.5-flash")) {
      DEFAULT_FREE_MODEL
    } else {
      model
    }

    // Build candidate list starting with preferredModel followed by remaining free fallbacks
    val candidateModels = linkedSetOf(preferredModel).apply {
      addAll(FREE_FALLBACK_MODELS)
    }.toList()

    var lastErrorMessage = "لم تنجح محاولة توليد الإجابة"

    for (candidateModel in candidateModels) {
      try {
        val jsonBody = JSONObject().apply {
          put("model", candidateModel)
          val messagesArray = JSONArray()

          if (systemInstruction.isNotBlank()) {
            messagesArray.put(JSONObject().apply {
              put("role", "system")
              put("content", systemInstruction)
            })
          }

          for ((role, content) in messages) {
            messagesArray.put(JSONObject().apply {
              put("role", if (role == "user") "user" else "assistant")
              put("content", content)
            })
          }

          put("messages", messagesArray)
          put("temperature", 0.7)
          put("max_tokens", 800)
        }

        val body = jsonBody.toString().toRequestBody("application/json; charset=utf-8".toMediaType())
        val request = Request.Builder()
            .url("https://openrouter.ai/api/v1/chat/completions")
            .header("Authorization", "Bearer $cleanKey")
            .header("HTTP-Referer", "https://draw.navigation.app")
            .header("X-Title", "DRAW Navigation")
            .post(body)
            .build()

        val response = client.newCall(request).execute()
        val responseText = response.body?.string() ?: ""

        if (response.isSuccessful) {
          val json = JSONObject(responseText)
          val choices = json.optJSONArray("choices")
          if (choices != null && choices.length() > 0) {
            val messageObj = choices.getJSONObject(0).optJSONObject("message")
            var reply = if (messageObj != null && !messageObj.isNull("content")) {
              messageObj.optString("content").trim()
            } else ""

            // Clean out reasoning / thinking tags if returned by reasoning models
            reply = reply.replace(Regex("""(?s)<think>.*?</think>"""), "").trim()

            if (reply.equals("null", ignoreCase = true) || reply.equals("none", ignoreCase = true)) {
              reply = ""
            }

            if (reply.isNotEmpty()) {
              Log.i(TAG, "OpenRouter generated reply successfully using model: $candidateModel")
              return@withContext Result.success(reply)
            }
          }
        } else {
          val errorMsg = try {
            val json = JSONObject(responseText)
            json.optJSONObject("error")?.optString("message") ?: "HTTP ${response.code}"
          } catch (_: Exception) {
            "HTTP ${response.code}"
          }
          lastErrorMessage = errorMsg
          Log.w(TAG, "Model $candidateModel returned HTTP ${response.code}: $errorMsg. Trying next fallback...")
        }
      } catch (e: Exception) {
        lastErrorMessage = e.localizedMessage ?: "خطأ في الشبكة"
        Log.w(TAG, "Exception calling OpenRouter with model $candidateModel: ${e.message}")
      }
    }

    Result.failure(Exception("فشل الاتصال بالنماذج المجانية في OpenRouter: $lastErrorMessage"))
  }
}
