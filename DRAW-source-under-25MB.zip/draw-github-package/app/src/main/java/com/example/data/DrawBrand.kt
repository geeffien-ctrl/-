package com.example.data

/** Fixed in-app identity used for every user avatar; it never points to a user-uploaded image. */
object DrawBrand {
    const val AVATAR_URI = "android.resource://com.aistudio.draw.navapp/drawable/draw_symbol"
}
