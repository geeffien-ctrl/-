package com.example.data.repository

import android.content.Context
import android.net.Uri
import com.example.data.model.AppUser
import com.example.data.DrawBrand
import com.example.data.model.AudioTrack
import com.example.data.model.Story
import com.example.data.util.ImageCompressUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.UUID

class StoriesRepository(
    private val context: Context
) {
    companion object {
        private val sampleStories = listOf(
            Story(
                id = "story_seed_1",
                creatorId = "user_1",
                creatorName = "علي السعدون",
                imageUrl = "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800",
                audioTitle = "أصوات الطبيعة",
                audioDuration = 60000L,
                createdAt = System.currentTimeMillis() - 3600000L,
                expiresAt = System.currentTimeMillis() + 82800000L
            ),
            Story(
                id = "story_seed_2",
                creatorId = "user_2",
                creatorName = "مريم الأحمد",
                imageUrl = "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800",
                audioTitle = "هدوء الصباح",
                audioDuration = 45000L,
                createdAt = System.currentTimeMillis() - 7200000L,
                expiresAt = System.currentTimeMillis() + 79200000L
            )
        )

        private val allStoriesList = mutableListOf<Story>().apply { addAll(sampleStories) }
        private val storiesFlow = MutableStateFlow<List<Story>>(allStoriesList.toList())
    }

    fun getActiveStoriesFlow(followingUserIds: Set<String>, currentUserId: String): Flow<List<Story>> {
        return storiesFlow.asStateFlow()
    }

    suspend fun createSingleStory(
        currentUser: AppUser,
        imageUri: Uri,
        audioTrack: AudioTrack?,
        context: Context
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            val storyId = "story_" + UUID.randomUUID().toString().take(10)
            val imageUrl = ImageCompressUtil.compressUriToBase64(context, imageUri, 800) ?: imageUri.toString()
            val audioUrl = audioTrack?.uri?.toString() ?: ""

            val now = System.currentTimeMillis()
            val story = Story(
                id = storyId,
                creatorId = currentUser.uid,
                creatorName = currentUser.displayName ?: currentUser.email?.substringBefore("@") ?: "مستخدم DRAW",
                creatorPhotoUrl = DrawBrand.AVATAR_URI,
                imageUrl = imageUrl,
                audioUrl = audioUrl,
                audioTitle = audioTrack?.title ?: "",
                audioDuration = audioTrack?.durationMs ?: 0L,
                createdAt = now,
                expiresAt = now + (24L * 3600L * 1000L)
            )
            allStoriesList.add(0, story)
            storiesFlow.value = allStoriesList.toList()
            Result.success(storyId)
        } catch (e: Exception) {
            Result.failure(e)
        }
    }

    suspend fun createMultipleStories(
        currentUser: AppUser,
        imageUris: List<Uri>,
        audioTrack: AudioTrack?,
        context: Context
    ): Result<Int> = withContext(Dispatchers.IO) {
        var count = 0
        for (uri in imageUris) {
            val res = createSingleStory(currentUser, uri, audioTrack, context)
            if (res.isSuccess) count++
        }
        if (count > 0) Result.success(count) else Result.failure(Exception("فشل نشر القصص"))
    }
}
