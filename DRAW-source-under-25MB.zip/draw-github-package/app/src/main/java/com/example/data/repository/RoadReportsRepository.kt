package com.example.data.repository

import android.content.Context
import android.location.Location
import android.util.Log
import com.example.R
import com.example.data.model.RoadReport
import com.example.data.model.RoadReportType
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private const val TAG = "RoadReportsRepo"
private const val PREFS_NAME = "draw_road_reports"
private const val KEY_SAVED_REPORTS = "saved_reports_json"

class RoadReportsRepository(
    private val context: Context? = null
) {
    private val prefs = context?.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
    private val _reportsFlow = MutableStateFlow<List<RoadReport>>(loadSavedReports())
    private var snapshotListenerRegistration: ListenerRegistration? = null

    private val db: FirebaseFirestore? by lazy {
        try {
            context?.let { ctx ->
                val dbId = ctx.getString(R.string.firestore_database_id)
                FirebaseFirestore.getInstance(dbId)
            } ?: FirebaseFirestore.getInstance()
        } catch (_: Exception) {
            try {
                FirebaseFirestore.getInstance()
            } catch (_: Exception) {
                null
            }
        }
    }

    init {
        startFirestoreRealtimeListener()
    }

    fun getActiveReportsFlow(): Flow<List<RoadReport>> = _reportsFlow.asStateFlow()

    fun getActiveReports(): List<RoadReport> = _reportsFlow.value.filter { !it.isCleared }

    private fun startFirestoreRealtimeListener() {
        try {
            val firestore = db ?: return
            snapshotListenerRegistration?.remove()
            snapshotListenerRegistration = firestore.collection("road_reports")
                .addSnapshotListener { snapshot, error ->
                    if (error != null) {
                        Log.w(TAG, "Road reports snapshot warning: ${error.message}")
                        return@addSnapshotListener
                    }
                    if (snapshot != null) {
                        val fetchedReports = mutableListOf<RoadReport>()
                        for (doc in snapshot.documents) {
                            try {
                                val typeStr = doc.getString("type") ?: RoadReportType.ROAD_HAZARD.id
                                val report = RoadReport(
                                    id = doc.id,
                                    type = RoadReportType.fromId(typeStr),
                                    description = doc.getString("description") ?: "",
                                    latitude = doc.getDouble("latitude") ?: 0.0,
                                    longitude = doc.getDouble("longitude") ?: 0.0,
                                    creatorId = doc.getString("creatorId") ?: "",
                                    creatorName = doc.getString("creatorName") ?: "",
                                    createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                                    isCleared = doc.getBoolean("isCleared") ?: false,
                                    clearedAt = doc.getLong("clearedAt"),
                                    clearedByUserId = doc.getString("clearedByUserId"),
                                    clearedByName = doc.getString("clearedByName"),
                                    clearAuditLat = doc.getDouble("clearAuditLat"),
                                    clearAuditLng = doc.getDouble("clearAuditLng"),
                                    clearAuditAccuracy = doc.getDouble("clearAuditAccuracy")?.toFloat(),
                                    isConfirmed = doc.getBoolean("isConfirmed") ?: false,
                                    confirmationsCount = (doc.getLong("confirmationsCount") ?: 1L).toInt()
                                )
                                fetchedReports.add(report)
                            } catch (e: Exception) {
                                Log.e(TAG, "Error parsing road report ${doc.id}", e)
                            }
                        }
                        // Update state with active reports only
                        val active = fetchedReports.filter { !it.isCleared }
                        _reportsFlow.value = active
                        saveReportsLocally(active)
                    }
                }
        } catch (e: Exception) {
            Log.e(TAG, "Failed to start road reports listener", e)
        }
    }

    suspend fun createReport(report: RoadReport): Result<RoadReport> = withContext(Dispatchers.IO) {
        try {
            val reportId = if (report.id.isNotBlank()) report.id else UUID.randomUUID().toString()
            val finalReport = report.copy(id = reportId)

            val reportData = hashMapOf(
                "type" to finalReport.type.id,
                "description" to finalReport.description,
                "latitude" to finalReport.latitude,
                "longitude" to finalReport.longitude,
                "creatorId" to finalReport.creatorId,
                "creatorName" to finalReport.creatorName,
                "createdAt" to finalReport.createdAt,
                "isCleared" to false
            )

            val firestore = db
            if (firestore != null) {
                firestore.collection("road_reports").document(reportId)
                    .set(reportData, SetOptions.merge())
                    .await()
            }

            // Immediately reflect in local state
            val currentList = _reportsFlow.value.toMutableList()
            currentList.removeAll { it.id == reportId }
            currentList.add(0, finalReport)
            _reportsFlow.value = currentList
            saveReportsLocally(currentList)

            Result.success(finalReport)
        } catch (e: Exception) {
            Log.e(TAG, "Error creating road report", e)
            Result.failure(e)
        }
    }

    suspend fun resolveReport(
        reportId: String,
        userId: String,
        userName: String,
        auditLocation: Location
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val updateData = hashMapOf<String, Any>(
                "isCleared" to true,
                "clearedAt" to System.currentTimeMillis(),
                "clearedByUserId" to userId,
                "clearedByName" to userName,
                "clearAuditLat" to auditLocation.latitude,
                "clearAuditLng" to auditLocation.longitude,
                "clearAuditAccuracy" to (if (auditLocation.hasAccuracy()) auditLocation.accuracy else 0.0f)
            )

            val firestore = db
            if (firestore != null) {
                firestore.collection("road_reports").document(reportId)
                    .update(updateData)
                    .await()
            }

            // Remove from active reports list locally
            val updatedList = _reportsFlow.value.filter { it.id != reportId }
            _reportsFlow.value = updatedList
            saveReportsLocally(updatedList)

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error resolving road report $reportId", e)
            Result.failure(e)
        }
    }

    suspend fun deleteReport(
        reportId: String,
        userId: String
    ): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            val firestore = db
            if (firestore != null) {
                val docRef = firestore.collection("road_reports").document(reportId)
                val snapshot = docRef.get().await()
                val creatorId = snapshot.getString("creatorId") ?: ""
                if (creatorId.isNotBlank() && creatorId != userId) {
                    return@withContext Result.failure(IllegalAccessException("لا تملك صلاحية حذف هذا البلاغ"))
                }
                docRef.delete().await()
            }

            val updatedList = _reportsFlow.value.filter { it.id != reportId }
            _reportsFlow.value = updatedList
            saveReportsLocally(updatedList)

            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error deleting road report $reportId", e)
            Result.failure(e)
        }
    }

    private fun saveReportsLocally(reports: List<RoadReport>) {
        try {
            val jsonArray = JSONArray()
            for (r in reports) {
                val obj = JSONObject().apply {
                    put("id", r.id)
                    put("type", r.type.id)
                    put("description", r.description)
                    put("latitude", r.latitude)
                    put("longitude", r.longitude)
                    put("creatorId", r.creatorId)
                    put("creatorName", r.creatorName)
                    put("createdAt", r.createdAt)
                    put("isCleared", r.isCleared)
                    put("isConfirmed", r.isConfirmed)
                    put("confirmationsCount", r.confirmationsCount)
                }
                jsonArray.put(obj)
            }
            prefs?.edit()?.putString(KEY_SAVED_REPORTS, jsonArray.toString())?.apply()
        } catch (e: Exception) {
            Log.e(TAG, "Error caching road reports locally", e)
        }
    }

    private fun loadSavedReports(): List<RoadReport> {
        val saved = prefs?.getString(KEY_SAVED_REPORTS, null) ?: return emptyList()
        val list = mutableListOf<RoadReport>()
        try {
            val jsonArray = JSONArray(saved)
            for (i in 0 until jsonArray.length()) {
                val obj = jsonArray.getJSONObject(i)
                val typeStr = obj.optString("type", RoadReportType.ROAD_HAZARD.id)
                list.add(
                    RoadReport(
                        id = obj.optString("id"),
                        type = RoadReportType.fromId(typeStr),
                        description = obj.optString("description"),
                        latitude = obj.optDouble("latitude"),
                        longitude = obj.optDouble("longitude"),
                        creatorId = obj.optString("creatorId"),
                        creatorName = obj.optString("creatorName"),
                        createdAt = obj.optLong("createdAt"),
                        isCleared = obj.optBoolean("isCleared", false),
                        isConfirmed = obj.optBoolean("isConfirmed", false),
                        confirmationsCount = obj.optInt("confirmationsCount", 1)
                    )
                )
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error parsing cached road reports", e)
        }
        return list.filter { !it.isCleared }
    }

    suspend fun purgeAllReportsFromFirestoreAndLocal(): Result<Unit> = withContext(Dispatchers.IO) {
        try {
            prefs?.edit()?.clear()?.apply()
            _reportsFlow.value = emptyList()

            val firestore = db ?: return@withContext Result.success(Unit)
            val snapshot = firestore.collection("road_reports").get().await()
            val batch = firestore.batch()
            for (doc in snapshot.documents) {
                batch.delete(doc.reference)
            }
            batch.commit().await()
            Result.success(Unit)
        } catch (e: Exception) {
            Log.e(TAG, "Error purging road reports", e)
            Result.failure(e)
        }
    }
}
