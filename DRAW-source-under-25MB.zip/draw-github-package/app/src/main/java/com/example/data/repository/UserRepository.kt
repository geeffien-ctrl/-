package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import com.example.R
import com.example.data.model.UserProfile
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONObject

class UserRepository(private val context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("draw_user_profiles", Context.MODE_PRIVATE)

    private val db: FirebaseFirestore? by lazy {
        try {
            val dbId = context.applicationContext.getString(R.string.firestore_database_id)
            FirebaseFirestore.getInstance(dbId)
        } catch (_: Exception) {
            null
        }
    }

    suspend fun getUserProfile(userId: String): UserProfile? = withContext(Dispatchers.IO) {
        if (userId.isBlank()) return@withContext null
        try {
            val doc = db?.collection("users")?.document(userId)?.get()?.await()
            if (doc != null && doc.exists()) {
                val profile = UserProfile(
                    id = doc.id,
                    username = doc.getString("username") ?: "",
                    email = doc.getString("email") ?: "",
                    displayName = doc.getString("displayName") ?: "",
                    photoUrl = doc.getString("photoUrl"),
                    createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis(),
                    updatedAt = doc.getLong("updatedAt") ?: System.currentTimeMillis()
                )
                saveToLocal(userId, profile)
                return@withContext profile
            }
        } catch (_: Exception) {}

        loadFromLocal(userId)
    }

    suspend fun saveUserProfile(userId: String, profile: UserProfile) = withContext(Dispatchers.IO) {
        if (userId.isBlank()) return@withContext
        saveToLocal(userId, profile)
        try {
            val data = mapOf(
                "username" to profile.username,
                "email" to profile.email,
                "displayName" to profile.displayName,
                "photoUrl" to (profile.photoUrl ?: ""),
                "updatedAt" to System.currentTimeMillis()
            )
            db?.collection("users")?.document(userId)?.set(data, SetOptions.merge())?.await()
        } catch (_: Exception) {}
    }

    private fun loadFromLocal(userId: String): UserProfile? {
        val jsonStr = prefs.getString("profile_$userId", null) ?: return null
        return try {
            val json = JSONObject(jsonStr)
            UserProfile(
                id = json.optString("id", userId),
                username = json.optString("username", ""),
                email = json.optString("email", ""),
                displayName = json.optString("displayName", ""),
                photoUrl = json.optString("photoUrl").takeIf { it.isNotBlank() },
                createdAt = json.optLong("createdAt", System.currentTimeMillis()),
                updatedAt = json.optLong("updatedAt", System.currentTimeMillis())
            )
        } catch (_: Exception) {
            null
        }
    }

    private fun saveToLocal(userId: String, profile: UserProfile) {
        val json = JSONObject().apply {
            put("id", profile.id.ifBlank { userId })
            put("username", profile.username)
            put("email", profile.email)
            put("displayName", profile.displayName)
            put("photoUrl", profile.photoUrl ?: "")
            put("createdAt", profile.createdAt)
            put("updatedAt", profile.updatedAt)
        }
        prefs.edit().putString("profile_$userId", json.toString()).apply()
    }
}
