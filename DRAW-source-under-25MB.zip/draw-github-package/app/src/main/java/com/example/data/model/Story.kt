package com.example.data.model

/**
 * 24-hour Daily Story model with single photo and optional audio.
 */
data class Story(
    val id: String = "",
    val creatorId: String = "",
    val creatorName: String = "",
    val creatorPhotoUrl: String = "",
    val imageUrl: String = "",
    val audioUrl: String = "",
    val audioTitle: String = "",
    val audioDuration: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + (24L * 3600L * 1000L)
) {
    val isExpired: Boolean
        get() = System.currentTimeMillis() > expiresAt
}
