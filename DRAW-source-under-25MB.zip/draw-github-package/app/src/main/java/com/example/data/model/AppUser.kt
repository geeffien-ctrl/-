package com.example.data.model

import android.net.Uri

data class AppUserInfo(
    val providerId: String = "password",
    val uid: String = "",
    val displayName: String? = null,
    val email: String? = null,
    val photoUrl: Uri? = null
)

data class AppUser(
    val uid: String = "",
    val email: String? = null,
    val displayName: String? = null,
    val photoUrl: Uri? = null,
    val isAnonymous: Boolean = false,
    val isEmailVerified: Boolean = true,
    val providerData: List<AppUserInfo> = listOf(
        AppUserInfo(
            providerId = if (isAnonymous) "anonymous" else "password",
            uid = uid,
            displayName = displayName,
            email = email,
            photoUrl = photoUrl
        )
    )
)
