package com.example.ui.components

import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Audiotrack
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.AudioTrack
import com.example.data.repository.PostsRepository
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AudioPickerSheet(
    currentAudio: AudioTrack?,
    onAudioSelected: (AudioTrack?) -> Unit,
    onDismiss: () -> Unit
) {
    val context = LocalContext.current
    val postsRepository = remember { PostsRepository(context) }
    var selectedTrack by remember { mutableStateOf<AudioTrack?>(currentAudio) }
    var isPreviewPlaying by remember { mutableStateOf(false) }
    var mediaPlayer by remember { mutableStateOf<MediaPlayer?>(null) }

    DisposableEffect(Unit) {
        onDispose {
            try {
                mediaPlayer?.stop()
                mediaPlayer?.release()
            } catch (_: Exception) {}
            mediaPlayer = null
        }
    }

    fun startPreview(uri: Uri) {
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
            val player = MediaPlayer.create(context, uri)
            if (player != null) {
                player.setOnCompletionListener {
                    isPreviewPlaying = false
                }
                player.start()
                mediaPlayer = player
                isPreviewPlaying = true
            }
        } catch (_: Exception) {
            isPreviewPlaying = false
        }
    }

    fun stopPreview() {
        try {
            mediaPlayer?.pause()
            mediaPlayer?.seekTo(0)
        } catch (_: Exception) {}
        isPreviewPlaying = false
    }

    val audioFilePickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri: Uri? ->
        if (uri != null) {
            val track = postsRepository.extractAudioMetadata(context, uri)
            selectedTrack = track
            startPreview(uri)
        }
    }

    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

    ModalBottomSheet(
        onDismissRequest = {
            stopPreview()
            onDismiss()
        },
        sheetState = sheetState,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        modifier = Modifier.testTag("audio_picker_sheet")
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 12.dp)
                .padding(bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFFFECEB)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.MusicNote,
                            contentDescription = null,
                            tint = DrawRed,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Text(
                        text = "إضافة صوت للمنشور",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = DrawTextNearBlack
                    )
                }

                IconButton(
                    onClick = {
                        stopPreview()
                        onDismiss()
                    },
                    modifier = Modifier
                        .size(30.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE5E5EA))
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "Close",
                        tint = Color(0xFF3A3A3C),
                        modifier = Modifier.size(16.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            if (selectedTrack == null) {
                // Empty state: Choose audio button
                Surface(
                    onClick = { audioFilePickerLauncher.launch("audio/*") },
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFF9F9FB),
                    border = androidx.compose.foundation.BorderStroke(1.5.dp, Color(0x18000000)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 12.dp)
                        .testTag("select_device_audio_button")
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally
                    ) {
                        Box(
                            modifier = Modifier
                                .size(64.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFFECEB)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.Audiotrack,
                                contentDescription = null,
                                tint = DrawRed,
                                modifier = Modifier.size(34.dp)
                            )
                        }
                        Spacer(modifier = Modifier.height(14.dp))
                        Text(
                            text = "اختيار ملف صوتي من الجهاز",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = DrawTextNearBlack
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "يدعم ملفات MP3 و WAV و M4A من هاتفك",
                            fontSize = 12.5.sp,
                            color = DrawTextSecondary
                        )
                    }
                }
            } else {
                // Selected Audio Track Preview Card
                val track = selectedTrack!!
                Surface(
                    shape = RoundedCornerShape(20.dp),
                    color = Color(0xFFF8F9FA),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x18000000)),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 10.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Play / Pause preview button
                        IconButton(
                            onClick = {
                                if (isPreviewPlaying) stopPreview()
                                else track.uri?.let { startPreview(it) }
                            },
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(DrawRed)
                                .testTag("preview_audio_play_button")
                        ) {
                            Icon(
                                imageVector = if (isPreviewPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                contentDescription = if (isPreviewPlaying) "Pause" else "Play",
                                tint = Color.White,
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(14.dp))

                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = track.title.ifBlank { "مقطع صوتي" },
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = DrawTextNearBlack,
                                maxLines = 1,
                                overflow = TextOverflow.Ellipsis
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = null,
                                    tint = DrawRed,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (track.durationMs > 0) track.formattedDuration else "جاهز للمعاينة",
                                    fontSize = 12.sp,
                                    color = DrawTextSecondary
                                )
                            }
                        }

                        // Remove Audio button
                        IconButton(
                            onClick = {
                                stopPreview()
                                selectedTrack = null
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.Delete,
                                contentDescription = "حذف الصوت",
                                tint = Color(0xFF8E8E93),
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }

                // Change Audio button
                Text(
                    text = "تغيير الملف الصوتي",
                    fontSize = 13.sp,
                    color = Color(0xFF007AFF),
                    fontWeight = FontWeight.SemiBold,
                    modifier = Modifier
                        .clickable { audioFilePickerLauncher.launch("audio/*") }
                        .padding(vertical = 8.dp)
                )
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                OutlinedButton(
                    onClick = {
                        stopPreview()
                        selectedTrack = null
                        onAudioSelected(null)
                        onDismiss()
                    },
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier
                        .weight(1f)
                        .height(48.dp)
                ) {
                    Text("بدون صوت", color = Color(0xFF8E8E93), fontWeight = FontWeight.SemiBold)
                }

                Button(
                    onClick = {
                        stopPreview()
                        onAudioSelected(selectedTrack)
                        onDismiss()
                    },
                    shape = RoundedCornerShape(16.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
                    modifier = Modifier
                        .weight(1.3f)
                        .height(48.dp)
                        .testTag("confirm_audio_button")
                ) {
                    Text("تأكيد الصوت", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 14.5.sp)
                }
            }
        }
    }
}
