package com.example.ui.map.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Comment
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Handshake
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.NearMe
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.WarningAmber
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LiveVehicle
import com.example.ui.theme.DrawGreen
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * DRAW Taxi Inspection & Request Bottom Sheet.
 * Shown when passenger taps on a Taxi marker on the map.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DriverProfileBottomSheet(
    vehicle: LiveVehicle,
    distanceMeters: Double?,
    isSelf: Boolean,
    onRequestOrder: (LiveVehicle) -> Unit,
    onLikeDriver: (LiveVehicle) -> Unit = {},
    onCommentDriver: (LiveVehicle, String) -> Unit = { _, _ -> },
    onOpenComments: (LiveVehicle) -> Unit = {},
    onDismiss: () -> Unit,
    onReportDriver: ((driverId: String, reason: String) -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    var showReportDialog by remember { mutableStateOf(false) }
    var reportReason by remember { mutableStateOf("") }

    val isAvailable = vehicle.effectiveIsAvailable
    val speedKmh = vehicle.effectiveSpeedKmh.toInt()
    val farePerKm = vehicle.farePerKm

    // Estimated fare calculation: distance (km) * farePerKm, with 1500 IQD base fare floor
    val distanceKm = (distanceMeters ?: 1000.0) / 1000.0
    val estimatedFare = if (farePerKm > 0.0) distanceKm * farePerKm else 0.0

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color.White,
        shape = RoundedCornerShape(topStart = 24.dp, topEnd = 24.dp),
        modifier = modifier.testTag("driver_profile_bottom_sheet"),
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
        ) {
            // Header Bar
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(if (isAvailable) DrawGreen else Color(0xFFEF4444))
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isAvailable) "تاكسي متاح للطلب" else "السائق مشغول حاليًا",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (isAvailable) DrawGreen else Color(0xFFEF4444),
                    )
                }

                IconButton(
                    onClick = onDismiss,
                    modifier = Modifier.size(32.dp).testTag("close_driver_sheet_button"),
                ) {
                    Icon(
                        imageVector = Icons.Default.Close,
                        contentDescription = "إغلاق",
                        tint = Color(0xFF8E8E93),
                        modifier = Modifier.size(20.dp),
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Taxi Driver & Vehicle Card
            Surface(
                shape = RoundedCornerShape(18.dp),
                color = Color(0xFFF9FAFB),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x14000000)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    // Cartoon Top-Down Taxi Preview with live color and roof sign
                    Box(
                        modifier = Modifier
                            .size(62.dp)
                            .clip(RoundedCornerShape(14.dp))
                            .background(Color.White)
                            .border(1.dp, Color(0xFFE5E7EB), RoundedCornerShape(14.dp)),
                        contentAlignment = Alignment.Center,
                    ) {
                        TopDownVehicleIcon(
                            modelId = "taxi_city",
                            size = 50.dp,
                            customColorHex = vehicle.effectiveColorHex
                        )
                    }

                    Spacer(modifier = Modifier.width(14.dp))

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (vehicle.driverName.isNotBlank()) vehicle.driverName else "سائق تاكسي DRAW",
                            fontSize = 16.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = DrawTextNearBlack,
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = vehicle.effectiveCarModel,
                            fontSize = 13.sp,
                            color = DrawTextSecondary,
                        )
                        Spacer(modifier = Modifier.height(3.dp))
                        Text(
                            text = if (farePerKm > 0.0) "سعر المسافة: ${farePerKm.toInt()} لكل كم" else "السعر غير محدد من السائق",
                            fontSize = 12.5.sp,
                            color = DrawRed,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }

            // Warning if driver is currently busy
            if (!isAvailable) {
                Spacer(modifier = Modifier.height(10.dp))
                Surface(
                    shape = RoundedCornerShape(12.dp),
                    color = Color(0xFFFEF2F2),
                    border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFFFCA5A5)),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Default.WarningAmber,
                            contentDescription = null,
                            tint = Color(0xFFDC2626),
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "السائق مشغول حاليًا، ابحث عن تاكسي آخر",
                            fontSize = 12.5.sp,
                            fontWeight = FontWeight.Bold,
                            color = Color(0xFF991B1B),
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Trip Estimate & Telemetry Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp),
            ) {
                // Distance to user
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFF4F4F6),
                    modifier = Modifier.weight(1f),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Default.NearMe,
                            contentDescription = null,
                            tint = DrawRed,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("المسافة عنك", fontSize = 11.sp, color = DrawTextSecondary)
                            Text(
                                text = if (distanceMeters != null) {
                                    if (distanceMeters < 1000) "${distanceMeters.toInt()} م"
                                    else String.format("%.1f كم", distanceMeters / 1000.0)
                                } else "قريب منك",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = DrawTextNearBlack,
                            )
                        }
                    }
                }

                // Estimated Fare based on km
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFECFDF5),
                    border = androidx.compose.foundation.BorderStroke(0.8.dp, Color(0xFFA7F3D0)),
                    modifier = Modifier.weight(1f),
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                    ) {
                        Icon(
                            imageVector = Icons.Default.Payments,
                            contentDescription = null,
                            tint = DrawGreen,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text("الأجرة التقديرية", fontSize = 11.sp, color = Color(0xFF065F46))
                            Text(
                                text = if (estimatedFare > 0.0) "${estimatedFare.toInt()}" else "غير محدد",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF047857),
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Likes and Comments Count (Locked until trip completion note)
            Surface(
                shape = RoundedCornerShape(14.dp),
                color = Color(0xFFF8FAFC),
                border = androidx.compose.foundation.BorderStroke(0.8.dp, Color(0xFFE2E8F0)),
                modifier = Modifier.fillMaxWidth(),
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceAround,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onLikeDriver(vehicle) }) {
                            Icon(Icons.Default.ThumbUp, contentDescription = "إعجاب", tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${vehicle.likesCount} إعجاب",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = DrawTextNearBlack
                            )
                        }

                        Box(modifier = Modifier.width(1.dp).height(18.dp).background(Color(0x20000000)))

                        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { onOpenComments(vehicle) }) {
                            Icon(Icons.Default.Comment, contentDescription = "تعليقات", tint = Color(0xFF059669), modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "${vehicle.commentsCount} تعليق",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Bold,
                                color = DrawTextNearBlack
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "اضغط إعجاباً أو اكتب تعليقك عن السائق",
                        fontSize = 11.sp,
                        color = DrawTextSecondary,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Action: Request Taxi or Self note
            if (isSelf) {
                Surface(
                    shape = RoundedCornerShape(14.dp),
                    color = Color(0xFFECEFF1),
                    modifier = Modifier.fillMaxWidth(),
                ) {
                    Text(
                        text = "هذا التاكسي الخاص بك وهو نشط حالياً على الخريطة",
                        fontSize = 13.5.sp,
                        fontWeight = FontWeight.SemiBold,
                        color = DrawTextSecondary,
                        modifier = Modifier.padding(14.dp),
                        textAlign = TextAlign.Center,
                    )
                }
            } else {
                Button(
                    onClick = { onRequestOrder(vehicle) },
                    enabled = isAvailable,
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("request_order_button"),
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DrawRed,
                        contentColor = Color.White,
                        disabledContainerColor = Color(0xFFE5E7EB),
                        disabledContentColor = Color(0xFF9CA3AF)
                    ),
                    shape = RoundedCornerShape(14.dp),
                ) {
                    Icon(
                        imageVector = Icons.Default.LocalTaxi,
                        contentDescription = null,
                        modifier = Modifier.size(20.dp)
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = if (isAvailable) "اطلب التاكسي" else "السائق مشغول حاليًا",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                    )
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Report button
                TextButton(
                    onClick = { showReportDialog = true },
                    modifier = Modifier
                        .align(Alignment.CenterHorizontally)
                        .testTag("report_driver_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Flag,
                        contentDescription = null,
                        tint = Color(0xFFDC2626),
                        modifier = Modifier.size(15.dp)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "إبلاغ عن مشكلة أو سلوك غير مناسب",
                        fontSize = 12.sp,
                        color = Color(0xFFDC2626)
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))
        }
    }

    // Report Driver Dialog
    if (showReportDialog) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = {
                Text(
                    text = "إبلاغ عن السائق",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
            },
            text = {
                Column {
                    Text(
                        text = "يرجى تحديد سبب الإبلاغ لمراجعة الحساب وحماية أمان الركاب:",
                        fontSize = 13.sp,
                        color = DrawTextSecondary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    listOf(
                        "سلوك غير لائق أو غير محترم",
                        "سيارة غير مطابقة للبيانات",
                        "مطالبة بأجرة أعلى من المتفق عليها",
                        "حساب وهمي أو عدم الحضور"
                    ).forEach { preset ->
                        Surface(
                            onClick = { reportReason = preset },
                            shape = RoundedCornerShape(8.dp),
                            color = if (reportReason == preset) DrawRed.copy(alpha = 0.1f) else Color(0xFFF3F4F6),
                            border = if (reportReason == preset) androidx.compose.foundation.BorderStroke(1.dp, DrawRed) else null,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Text(
                                text = preset,
                                fontSize = 12.sp,
                                fontWeight = if (reportReason == preset) FontWeight.Bold else FontWeight.Normal,
                                color = if (reportReason == preset) DrawRed else DrawTextNearBlack,
                                modifier = Modifier.padding(10.dp)
                            )
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        onReportDriver?.invoke(vehicle.effectiveUserId, reportReason.ifBlank { "بلاغ عام" })
                        showReportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
                    shape = RoundedCornerShape(10.dp)
                ) {
                    Text("إرسال البلاغ")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) {
                    Text("إلغاء")
                }
            }
        )
    }


}
