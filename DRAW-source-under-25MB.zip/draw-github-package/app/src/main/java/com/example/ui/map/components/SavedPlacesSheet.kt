package com.example.ui.map.components

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Star
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Post
import com.example.data.model.PublicPlace
import com.example.data.model.SavedPlace
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

enum class FavoritesSheetTab {
  SAVED_PLACES,
  MY_ADDED_PLACES
}

/**
 * Modal bottom sheet presenting user favorites divided into two distinct sections:
 * 1. الأماكن المحفوظة (Places saved by the user)
 * 2. الأماكن والمنشورات التي أضفتها (Places and content created & published by the user)
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SavedPlacesSheet(
    favorites: List<SavedPlace>,
    myPlaces: List<PublicPlace> = emptyList(),
    myPosts: List<Post> = emptyList(),
    onPlaceSelected: (SavedPlace) -> Unit,
    onMyPlaceSelected: (PublicPlace) -> Unit = {},
    onMyPostSelected: (Post) -> Unit = {},
    onAddNewPlaceClick: () -> Unit = {},
    onDeletePlace: (String) -> Unit,
    onDismiss: () -> Unit
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
  var selectedTab by remember { mutableStateOf(FavoritesSheetTab.SAVED_PLACES) }

  ModalBottomSheet(
      onDismissRequest = onDismiss,
      sheetState = sheetState,
      shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
      containerColor = Color(0xFDFDFDFF),
      dragHandle = {
        Box(
            modifier = Modifier
                .padding(top = 10.dp, bottom = 6.dp)
                .size(width = 36.dp, height = 4.dp)
                .clip(CircleShape)
                .background(Color(0xFFD1D1D6))
        )
      }
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(horizontal = 20.dp)
            .padding(bottom = 32.dp)
            .testTag("saved_places_sheet")
    ) {
      // 1. Sheet Header
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 10.dp),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
              modifier = Modifier
                  .size(36.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFFECEB)),
              contentAlignment = Alignment.Center
          ) {
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                tint = DrawRed,
                modifier = Modifier.size(20.dp)
            )
          }
          Spacer(modifier = Modifier.width(10.dp))
          Column {
            Text(
                text = "المفضلة والأماكن",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack
            )
            val subtext = if (selectedTab == FavoritesSheetTab.SAVED_PLACES) {
              "${favorites.size} مكان مسجل في المفضلة"
            } else {
              "${myPlaces.size} مكان و${myPosts.size} منشور أضفته"
            }
            Text(
                text = subtext,
                fontSize = 12.sp,
                color = DrawTextSecondary
            )
          }
        }

        IconButton(
            onClick = onDismiss,
            modifier = Modifier
                .size(30.dp)
                .clip(CircleShape)
                .background(Color(0xFFE5E5EA))
        ) {
          Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close sheet",
              tint = Color(0xFF3A3A3C),
              modifier = Modifier.size(16.dp)
          )
        }
      }

      // 2. Clear Segmented Tabs for the Two Sections
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .padding(vertical = 8.dp)
              .clip(RoundedCornerShape(14.dp))
              .background(Color(0xFFF2F2F7))
              .padding(4.dp),
          horizontalArrangement = Arrangement.spacedBy(6.dp)
      ) {
        // Tab 1: الأماكن المحفوظة
        val isTab1Active = selectedTab == FavoritesSheetTab.SAVED_PLACES
        Surface(
            modifier = Modifier
                .weight(1f)
                .height(42.dp)
                .clickable { selectedTab = FavoritesSheetTab.SAVED_PLACES }
                .testTag("tab_saved_places"),
            shape = RoundedCornerShape(10.dp),
            color = if (isTab1Active) DrawRed else Color.Transparent,
            shadowElevation = if (isTab1Active) 2.dp else 0.dp
        ) {
          Row(
              modifier = Modifier.fillMaxSize(),
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                tint = if (isTab1Active) Color.White else Color(0xFF48484A),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "الأماكن المحفوظة",
                fontSize = 13.sp,
                fontWeight = if (isTab1Active) FontWeight.Bold else FontWeight.Medium,
                color = if (isTab1Active) Color.White else Color(0xFF48484A)
            )
            if (favorites.isNotEmpty()) {
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                  modifier = Modifier
                      .clip(CircleShape)
                      .background(if (isTab1Active) Color.White.copy(alpha = 0.28f) else Color(0xFFE5E5EA))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                    text = "${favorites.size}",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isTab1Active) Color.White else Color(0xFF333333)
                )
              }
            }
          }
        }

        // Tab 2: الأماكن والمنشورات التي أضفتها
        val isTab2Active = selectedTab == FavoritesSheetTab.MY_ADDED_PLACES
        Surface(
            modifier = Modifier
                .weight(1f)
                .height(42.dp)
                .clickable { selectedTab = FavoritesSheetTab.MY_ADDED_PLACES }
                .testTag("tab_my_added_places"),
            shape = RoundedCornerShape(10.dp),
            color = if (isTab2Active) DrawRed else Color.Transparent,
            shadowElevation = if (isTab2Active) 2.dp else 0.dp
        ) {
          Row(
              modifier = Modifier.fillMaxSize(),
              horizontalArrangement = Arrangement.Center,
              verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
                imageVector = Icons.Default.Place,
                contentDescription = null,
                tint = if (isTab2Active) Color.White else Color(0xFF48484A),
                modifier = Modifier.size(16.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "التي أضفتها",
                fontSize = 13.sp,
                fontWeight = if (isTab2Active) FontWeight.Bold else FontWeight.Medium,
                color = if (isTab2Active) Color.White else Color(0xFF48484A)
            )
            val myTotalCount = myPlaces.size + myPosts.size
            if (myTotalCount > 0) {
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                  modifier = Modifier
                      .clip(CircleShape)
                      .background(if (isTab2Active) Color.White.copy(alpha = 0.28f) else Color(0xFFE5E5EA))
                      .padding(horizontal = 6.dp, vertical = 2.dp)
              ) {
                Text(
                    text = "$myTotalCount",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isTab2Active) Color.White else Color(0xFF333333)
                )
              }
            }
          }
        }
      }

      HorizontalDivider(color = Color(0x12000000), thickness = 0.8.dp)

      Spacer(modifier = Modifier.height(8.dp))

      // 3. Tab Contents
      when (selectedTab) {
        FavoritesSheetTab.SAVED_PLACES -> {
          // SECTION 1: الأماكن المحفوظة
          if (favorites.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 36.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Box(
                  modifier = Modifier
                      .size(64.dp)
                      .clip(CircleShape)
                      .background(Color(0xFFF2F2F7)),
                  contentAlignment = Alignment.Center
              ) {
                Icon(
                    imageVector = Icons.Default.BookmarkBorder,
                    contentDescription = null,
                    tint = Color(0xFF8E8E93),
                    modifier = Modifier.size(32.dp)
                )
              }
              Spacer(modifier = Modifier.height(14.dp))
              Text(
                  text = "لا توجد أماكن محفوظة بعد",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = DrawTextNearBlack
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                  text = "ابحث عن أي مكان أو اضغط على الخريطة ثم اختر حفظ لإضافته إلى مفضلتك السريعة.",
                  fontSize = 13.sp,
                  color = DrawTextSecondary,
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(horizontal = 24.dp)
              )
            }
          } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp)
            ) {
              items(favorites, key = { it.id.ifBlank { it.title + it.latitude } }) { place ->
                SavedPlaceRow(
                    place = place,
                    onClick = { onPlaceSelected(place) },
                    onDelete = { onDeletePlace(place.id) }
                )
                HorizontalDivider(color = Color(0x0C000000), thickness = 0.5.dp)
              }
            }
          }
        }

        FavoritesSheetTab.MY_ADDED_PLACES -> {
          // SECTION 2: الأماكن والمنشورات التي أضفتها
          val hasAddedContent = myPlaces.isNotEmpty() || myPosts.isNotEmpty()
          if (!hasAddedContent) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 36.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
              Box(
                  modifier = Modifier
                      .size(64.dp)
                      .clip(CircleShape)
                      .background(Color(0xFFFFECEB)),
                  contentAlignment = Alignment.Center
              ) {
                Icon(
                    imageVector = Icons.Default.Place,
                    contentDescription = null,
                    tint = DrawRed,
                    modifier = Modifier.size(32.dp)
                )
              }
              Spacer(modifier = Modifier.height(14.dp))
              Text(
                  text = "لم تقم بإضافة أماكن أو منشورات بعد",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = DrawTextNearBlack
              )
              Spacer(modifier = Modifier.height(6.dp))
              Text(
                  text = "يمكنك توثيق الأماكن والمعالم وإضافتها على الخريطة ومشاركتها مع مجتمع درو DRAW.",
                  fontSize = 13.sp,
                  color = DrawTextSecondary,
                  textAlign = TextAlign.Center,
                  modifier = Modifier.padding(horizontal = 24.dp)
              )
            }
          } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .heightIn(max = 380.dp)
            ) {
              // 1. My Published Places
              items(myPlaces, key = { "my_place_${it.id}" }) { place ->
                MyAddedPlaceRow(
                    place = place,
                    onClick = { onMyPlaceSelected(place) }
                )
                HorizontalDivider(color = Color(0x0C000000), thickness = 0.5.dp)
              }

              // 2. My Posts (if any)
              items(myPosts, key = { "my_post_${it.id}" }) { post ->
                MyAddedPostRow(
                    post = post,
                    onClick = { onMyPostSelected(post) }
                )
                HorizontalDivider(color = Color(0x0C000000), thickness = 0.5.dp)
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun SavedPlaceRow(
    place: SavedPlace,
    onClick: () -> Unit,
    onDelete: () -> Unit
) {
  Row(
      modifier = Modifier
          .fillMaxWidth()
          .clickable(onClick = onClick)
          .padding(vertical = 12.dp, horizontal = 4.dp)
          .testTag("saved_place_row_${place.title}"),
      verticalAlignment = Alignment.CenterVertically
  ) {
    val iconItem = PlaceIconRegistry.getIconById(place.iconId.ifBlank { place.category })

    Box(
        modifier = Modifier
            .size(40.dp)
            .clip(CircleShape)
            .background(iconItem.primaryColor),
        contentAlignment = Alignment.Center
    ) {
      Icon(
          imageVector = iconItem.iconVector,
          contentDescription = iconItem.nameArabic,
          tint = Color.White,
          modifier = Modifier.size(20.dp)
      )
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = place.title,
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.5.sp,
            color = DrawTextNearBlack,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Text(
            text = "• ${iconItem.nameArabic}",
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = iconItem.primaryColor
        )
      }
      Spacer(modifier = Modifier.height(2.dp))
      Text(
          text = place.address.ifBlank { "موقع محفوظ على الخريطة" },
          fontWeight = FontWeight.Normal,
          fontSize = 12.sp,
          color = DrawTextSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
      )
    }

    IconButton(
        onClick = onDelete,
        modifier = Modifier
            .size(36.dp)
            .testTag("delete_place_button_${place.id}")
    ) {
      Icon(
          imageVector = Icons.Default.DeleteOutline,
          contentDescription = "Delete place",
          tint = Color(0xFF8E8E93),
          modifier = Modifier.size(19.dp)
      )
    }
  }
}

@Composable
private fun MyAddedPlaceRow(
    place: PublicPlace,
    onClick: () -> Unit
) {
  Row(
      modifier = Modifier
          .fillMaxWidth()
          .clickable(onClick = onClick)
          .padding(vertical = 12.dp, horizontal = 4.dp)
          .testTag("my_added_place_row_${place.id}"),
      verticalAlignment = Alignment.CenterVertically
  ) {
    if (place.images.isNotEmpty()) {
      AsyncImage(
          model = place.images.first(),
          contentDescription = place.title,
          contentScale = ContentScale.Crop,
          modifier = Modifier
              .size(46.dp)
              .clip(RoundedCornerShape(10.dp))
      )
    } else {
      val iconItem = PlaceIconRegistry.getIconById(place.iconId.ifBlank { place.category })
      Box(
          modifier = Modifier
              .size(46.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(iconItem.primaryColor.copy(alpha = 0.15f)),
          contentAlignment = Alignment.Center
      ) {
        Icon(
            imageVector = iconItem.iconVector,
            contentDescription = null,
            tint = iconItem.primaryColor,
            modifier = Modifier.size(24.dp)
        )
      }
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = place.title,
            fontWeight = FontWeight.Bold,
            fontSize = 14.5.sp,
            color = DrawTextNearBlack,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFE8F5E9))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
              text = "منشور بواسطتك",
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF2E7D32)
          )
        }
      }

      Spacer(modifier = Modifier.height(2.dp))

      Text(
          text = place.address.ifBlank { place.description },
          fontWeight = FontWeight.Normal,
          fontSize = 12.sp,
          color = DrawTextSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(4.dp))

      Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        if (place.averageRating > 0.0) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(Icons.Default.Star, contentDescription = null, tint = Color(0xFFFFB300), modifier = Modifier.size(13.dp))
            Spacer(modifier = Modifier.width(3.dp))
            Text(text = "${place.averageRating}", fontSize = 11.5.sp, fontWeight = FontWeight.Bold, color = DrawTextNearBlack)
          }
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Favorite, contentDescription = null, tint = DrawRed, modifier = Modifier.size(13.dp))
          Spacer(modifier = Modifier.width(3.dp))
          Text(text = "${place.likesCount}", fontSize = 11.5.sp, color = DrawTextSecondary)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = Color(0xFF007AFF), modifier = Modifier.size(13.dp))
          Spacer(modifier = Modifier.width(3.dp))
          Text(text = "${place.commentsCount}", fontSize = 11.5.sp, color = DrawTextSecondary)
        }
      }
    }

    Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
        contentDescription = "الانتقال إلى الموقع على الخريطة",
        tint = Color(0xFFC7C7CC),
        modifier = Modifier.size(14.dp)
    )
  }
}

@Composable
private fun MyAddedPostRow(
    post: Post,
    onClick: () -> Unit
) {
  Row(
      modifier = Modifier
          .fillMaxWidth()
          .clickable(onClick = onClick)
          .padding(vertical = 12.dp, horizontal = 4.dp)
          .testTag("my_added_post_row_${post.id}"),
      verticalAlignment = Alignment.CenterVertically
  ) {
    if (post.images.isNotEmpty()) {
      AsyncImage(
          model = post.images.first(),
          contentDescription = post.caption,
          contentScale = ContentScale.Crop,
          modifier = Modifier
              .size(46.dp)
              .clip(RoundedCornerShape(10.dp))
      )
    } else {
      Box(
          modifier = Modifier
              .size(46.dp)
              .clip(RoundedCornerShape(10.dp))
              .background(Color(0xFFEEEEEE)),
          contentAlignment = Alignment.Center
      ) {
        Icon(
            imageVector = Icons.Default.Place,
            contentDescription = null,
            tint = Color(0xFF888888),
            modifier = Modifier.size(24.dp)
        )
      }
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Text(
            text = post.caption.ifBlank { "منشور اجتماعي" },
            fontWeight = FontWeight.SemiBold,
            fontSize = 14.sp,
            color = DrawTextNearBlack,
            maxLines = 1,
            overflow = TextOverflow.Ellipsis,
            modifier = Modifier.weight(1f, fill = false)
        )
        Spacer(modifier = Modifier.width(6.dp))
        Box(
            modifier = Modifier
                .clip(RoundedCornerShape(6.dp))
                .background(Color(0xFFE3F2FD))
                .padding(horizontal = 6.dp, vertical = 2.dp)
        ) {
          Text(
              text = "منشورك",
              fontSize = 10.sp,
              fontWeight = FontWeight.SemiBold,
              color = Color(0xFF1976D2)
          )
        }
      }

      Spacer(modifier = Modifier.height(4.dp))

      Row(
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.spacedBy(10.dp)
      ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.Favorite, contentDescription = null, tint = DrawRed, modifier = Modifier.size(13.dp))
          Spacer(modifier = Modifier.width(3.dp))
          Text(text = "${post.likesCount}", fontSize = 11.5.sp, color = DrawTextSecondary)
        }
        Row(verticalAlignment = Alignment.CenterVertically) {
          Icon(Icons.Default.ChatBubbleOutline, contentDescription = null, tint = Color(0xFF007AFF), modifier = Modifier.size(13.dp))
          Spacer(modifier = Modifier.width(3.dp))
          Text(text = "${post.commentsCount}", fontSize = 11.5.sp, color = DrawTextSecondary)
        }
      }
    }

    Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
        contentDescription = "عرض المنشور",
        tint = Color(0xFFC7C7CC),
        modifier = Modifier.size(14.dp)
    )
  }
}
