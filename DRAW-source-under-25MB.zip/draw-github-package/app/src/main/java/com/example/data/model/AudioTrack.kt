package com.example.data.model

import android.net.Uri

/**
 * Model representing an audio track selected from device files or loaded from storage.
 */
data class AudioTrack(
    val uri: Uri? = null,
    val title: String = "",
    val durationMs: Long = 0L,
    val remoteUrl: String = ""
) {
    val formattedDuration: String
        get() {
            val totalSec = durationMs / 1000
            val min = totalSec / 60
            val sec = totalSec % 60
            return "%d:%02d".format(min, sec)
        }
}
