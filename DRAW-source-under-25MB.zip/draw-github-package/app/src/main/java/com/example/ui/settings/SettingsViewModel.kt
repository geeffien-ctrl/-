package com.example.ui.settings

import android.Manifest
import android.content.Context
import android.content.pm.PackageManager
import android.net.Uri
import android.util.Log
import androidx.core.content.ContextCompat
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.model.AppUser
import com.example.data.model.UserProfile
import com.example.data.network.OpenRouterConfig
import com.example.data.network.OpenRouterService
import com.example.data.network.OpenRouterStatus
import com.example.data.repository.AuthSessionManager
import com.example.data.repository.NavigationRepository
import com.example.data.repository.SettingsPreferences
import com.example.data.repository.UserRepository
import com.example.data.util.ImageCompressUtil
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

import com.example.data.model.UserVehicleProfile
import com.example.data.repository.VehiclesRepository

private const val TAG = "SettingsViewModel"

object SocialLinks {
  // Centralized social links configuration
  const val DEVELOPER_INSTAGRAM = ""
  const val DEVELOPER_TIKTOK = ""
  const val DRAW_INSTAGRAM = ""
  const val DRAW_TIKTOK = ""
}

enum class SettingsSubScreen {
  MAIN,
  PROFILE,
  PREFERENCES,
  PRIVACY,
  ABOUT,
  MY_VEHICLE,
}

data class SettingsUiState(
    val currentSubScreen: SettingsSubScreen = SettingsSubScreen.MAIN,
    val userProfile: UserProfile? = null,
    val userVehicleProfile: UserVehicleProfile? = null,
    val isSavingVehicle: Boolean = false,
    val firebaseUser: AppUser? = null,
    val savedPlacesCount: Int = 0,
    val defaultTo3D: Boolean = false,
    val voiceGuidance: Boolean = true,
    val masterVoiceEnabled: Boolean = true,
    val aiCompanionVoiceEnabled: Boolean = true,
    val show3DBuildings: Boolean = true,
    val transportMode: String = "driving",
    val distanceUnit: String = "km",
    val hasLocationPermission: Boolean = false,
    val hasAudioPermission: Boolean = false,
    val isSavingProfile: Boolean = false,
    val isUploadingPhoto: Boolean = false,
    val isVerifyingKey: Boolean = false,
    val openRouterConfig: OpenRouterConfig = OpenRouterConfig(),
    val feedbackMessage: String? = null,
    val errorMessage: String? = null,
    val isSignOutDialogVisible: Boolean = false,
    val isClearCacheDialogVisible: Boolean = false
) {
  val isGuest: Boolean
    get() = firebaseUser == null || firebaseUser.isAnonymous

  // Authorized Admin check (matches project owner email in AI Studio)
  val isAdmin: Boolean
    get() = firebaseUser?.email.equals("zuelfiqarsadon9@gmail.com", ignoreCase = true)

  val isPasswordUser: Boolean
    get() = firebaseUser?.providerData?.any { it.providerId == "password" } == true

  val isGoogleUser: Boolean
    get() = firebaseUser?.providerData?.any { it.providerId == "google.com" } == true

  val isAppleUser: Boolean
    get() = firebaseUser?.providerData?.any { it.providerId == "apple.com" } == true
}

class SettingsViewModel(
    private val context: Context,
    private val userRepository: UserRepository = UserRepository(context),
    private val preferences: SettingsPreferences = SettingsPreferences(context),
    private val openRouterService: OpenRouterService = OpenRouterService(context),
    private val sessionManager: AuthSessionManager = AuthSessionManager.getInstance(context),
    private val navigationRepository: NavigationRepository = NavigationRepository(context),
    private val vehiclesRepository: VehiclesRepository = VehiclesRepository(context)
) : ViewModel() {

  private val _uiState = MutableStateFlow(SettingsUiState())
  val uiState: StateFlow<SettingsUiState> = _uiState.asStateFlow()

  init {
    loadUserAndPreferences()
    checkPermissions()
  }

  fun loadUserAndPreferences() {
    val user = sessionManager.currentUser.value
    val aiConfig = openRouterService.getConfig()
    val localVehicle = vehiclesRepository.getLocalProfile()

    _uiState.update {
      it.copy(
          firebaseUser = user,
          userVehicleProfile = localVehicle,
          openRouterConfig = aiConfig,
          defaultTo3D = preferences.defaultTo3D.value,
          voiceGuidance = preferences.voiceGuidanceEnabled.value,
          masterVoiceEnabled = preferences.masterVoiceEnabled.value,
          aiCompanionVoiceEnabled = preferences.aiCompanionVoiceEnabled.value,
          show3DBuildings = preferences.show3DBuildings.value,
          transportMode = preferences.transportMode.value,
          distanceUnit = preferences.distanceUnit.value,
      )
    }

    if (user != null) {
      viewModelScope.launch {
        try {
          val profile = userRepository.getUserProfile(user.uid)
          _uiState.update { it.copy(userProfile = profile) }
        } catch (_: Exception) {}

        try {
          val cloudVehicle = vehiclesRepository.fetchProfileFromFirestore(user.uid)
          if (cloudVehicle != null) {
            vehiclesRepository.saveLocalProfile(cloudVehicle)
            _uiState.update { it.copy(userVehicleProfile = cloudVehicle) }
          }
        } catch (_: Exception) {}

        try {
          val favorites = navigationRepository.getFavorites(user.uid)
          _uiState.update { it.copy(savedPlacesCount = favorites.size) }
        } catch (_: Exception) {
          _uiState.update { it.copy(savedPlacesCount = 0) }
        }
      }
    }
  }

  fun saveUserVehicleProfile(profile: UserVehicleProfile) {
    val user = _uiState.value.firebaseUser
    val updatedProfile = if (user != null && profile.userId.isBlank()) {
      profile.copy(
          userId = user.uid,
          customName = if (profile.effectiveDriverName.isBlank()) user.displayName ?: "" else profile.effectiveDriverName,
          driverName = if (profile.effectiveDriverName.isBlank()) user.displayName ?: "" else profile.effectiveDriverName
      )
    } else {
      profile
    }

    vehiclesRepository.saveLocalProfile(updatedProfile)
    _uiState.update { it.copy(userVehicleProfile = updatedProfile, isSavingVehicle = true) }

    viewModelScope.launch {
      try {
        vehiclesRepository.syncProfileWithFirestore(updatedProfile)
        _uiState.update {
          it.copy(
              isSavingVehicle = false,
              feedbackMessage = "تم حفظ إعدادات السيارة والمشاركة بنجاح"
          )
        }
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
              isSavingVehicle = false,
              feedbackMessage = "تم حفظ الإعدادات محلياً بنجاح"
          )
        }
      }
    }
  }

  fun checkPermissions() {
    val hasFineLocation = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_FINE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED
    val hasCoarseLocation = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.ACCESS_COARSE_LOCATION
    ) == PackageManager.PERMISSION_GRANTED
    val hasAudio = ContextCompat.checkSelfPermission(
        context,
        Manifest.permission.RECORD_AUDIO
    ) == PackageManager.PERMISSION_GRANTED

    _uiState.update {
      it.copy(
          hasLocationPermission = hasFineLocation || hasCoarseLocation,
          hasAudioPermission = hasAudio,
      )
    }
  }

  fun navigateToSubScreen(subScreen: SettingsSubScreen) {
    if (subScreen == SettingsSubScreen.PROFILE && _uiState.value.isGuest) {
      _uiState.update { it.copy(errorMessage = "يرجى تسجيل الدخول أولاً لتعديل الملف الشخصي.") }
      return
    }
    _uiState.update { it.copy(currentSubScreen = subScreen, feedbackMessage = null, errorMessage = null) }
  }

  fun navigateBack(): Boolean {
    return if (_uiState.value.currentSubScreen != SettingsSubScreen.MAIN) {
      _uiState.update { it.copy(currentSubScreen = SettingsSubScreen.MAIN, feedbackMessage = null, errorMessage = null) }
      true
    } else {
      false
    }
  }

  fun setDefaultTo3D(enabled: Boolean) {
    preferences.setDefaultTo3D(enabled)
    _uiState.update { it.copy(defaultTo3D = enabled) }
  }

  fun setVoiceGuidance(enabled: Boolean) {
    preferences.setVoiceGuidanceEnabled(enabled)
    _uiState.update { it.copy(voiceGuidance = enabled, masterVoiceEnabled = enabled) }
  }

  fun setMasterVoice(enabled: Boolean) {
    preferences.setMasterVoiceEnabled(enabled)
    preferences.setVoiceGuidanceEnabled(enabled)
    _uiState.update { it.copy(masterVoiceEnabled = enabled, voiceGuidance = enabled) }
  }

  fun setAiCompanionVoice(enabled: Boolean) {
    preferences.setAiCompanionVoiceEnabled(enabled)
    _uiState.update { it.copy(aiCompanionVoiceEnabled = enabled) }
  }

  fun setShow3DBuildings(enabled: Boolean) {
    preferences.setShow3DBuildings(enabled)
    _uiState.update { it.copy(show3DBuildings = enabled) }
  }

  fun setTransportMode(mode: String) {
    preferences.setTransportMode(mode)
    _uiState.update { it.copy(transportMode = mode) }
  }

  fun setDistanceUnit(unit: String) {
    preferences.setDistanceUnit(unit)
    _uiState.update { it.copy(distanceUnit = unit) }
  }

  fun showSignOutDialog(show: Boolean) {
    _uiState.update { it.copy(isSignOutDialogVisible = show) }
  }

  fun showClearCacheDialog(show: Boolean) {
    _uiState.update { it.copy(isClearCacheDialogVisible = show) }
  }

  fun clearMapCache() {
    val success = preferences.clearMapCache()
    _uiState.update {
      it.copy(
          isClearCacheDialogVisible = false,
          feedbackMessage = if (success) "تم مسح الذاكرة المؤقتة للخرائط بنجاح" else "فشل مسح الذاكرة المؤقتة"
      )
    }
  }

  // --- Profile Modifications ---

  fun saveProfileDisplayName(newDisplayName: String) {
    val trimmed = newDisplayName.trim()
    if (trimmed.isEmpty()) {
      _uiState.update { it.copy(errorMessage = "يرجى إدخال اسم عرض صالح.") }
      return
    }

    val user = _uiState.value.firebaseUser ?: return
    val currentProfile = _uiState.value.userProfile

    _uiState.update { it.copy(isSavingProfile = true, errorMessage = null, feedbackMessage = null) }

    viewModelScope.launch {
      try {
        val safeUsername = currentProfile?.username?.takeIf { it.isNotBlank() }
            ?: user.email?.substringBefore("@")?.take(20)?.filter { it.isLetterOrDigit() }
            ?: "user_${user.uid.take(6)}"

        val safeProfile = UserProfile(
            id = user.uid,
            username = safeUsername.padEnd(3, '0').take(30),
            email = user.email ?: currentProfile?.email ?: "",
            displayName = trimmed.take(50),
            photoUrl = currentProfile?.photoUrl ?: user.photoUrl?.toString()
        )

        sessionManager.updateProfile(displayName = trimmed, photoUri = null)
        userRepository.saveUserProfile(user.uid, safeProfile)

        _uiState.update {
          it.copy(
              userProfile = safeProfile,
              firebaseUser = it.firebaseUser?.copy(displayName = trimmed),
              isSavingProfile = false,
              feedbackMessage = "تم حفظ الاسم الجديد بنجاح في حسابك."
          )
        }
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
              isSavingProfile = false,
              errorMessage = "حدث خطأ أثناء حفظ الاسم: ${e.localizedMessage ?: "يرجى المحاولة مجدداً."}"
          )
        }
      }
    }
  }

  fun uploadProfilePhoto(imageUri: Uri) {
    val user = _uiState.value.firebaseUser ?: return
    _uiState.update { it.copy(isUploadingPhoto = true, errorMessage = null, feedbackMessage = null) }

    viewModelScope.launch {
      try {
        val dataUrl = ImageCompressUtil.compressUriToBase64(context, imageUri, maxDimension = 600)
            ?: imageUri.toString()

        val photoUri = Uri.parse(dataUrl)
        sessionManager.updateProfile(displayName = null, photoUri = photoUri)

        val currentProfile = _uiState.value.userProfile
        val updatedProfile = (currentProfile ?: UserProfile(
            id = user.uid,
            username = user.email?.substringBefore("@") ?: "user",
            email = user.email ?: "",
            displayName = user.displayName ?: ""
        )).copy(photoUrl = dataUrl)

        userRepository.saveUserProfile(user.uid, updatedProfile)

        _uiState.update {
          it.copy(
              isUploadingPhoto = false,
              userProfile = updatedProfile,
              firebaseUser = it.firebaseUser?.copy(photoUrl = photoUri),
              feedbackMessage = "تم تحديث الصورة الشخصية بنجاح."
          )
        }
      } catch (e: Exception) {
        Log.e(TAG, "Failed to upload profile photo", e)
        _uiState.update {
          it.copy(
              isUploadingPhoto = false,
              errorMessage = "فشل رفع الصورة الشخصية: ${e.localizedMessage ?: "تحقق من اتصالك."}"
          )
        }
      }
    }
  }

  fun updateEmail(newEmail: String, currentPassword: String) {
    val user = _uiState.value.firebaseUser ?: return
    val trimmed = newEmail.trim()
    if (!android.util.Patterns.EMAIL_ADDRESS.matcher(trimmed).matches()) {
      _uiState.update { it.copy(errorMessage = "يرجى إدخال عنوان بريد إلكتروني صالح.") }
      return
    }

    _uiState.update { it.copy(isSavingProfile = true, errorMessage = null, feedbackMessage = null) }

    viewModelScope.launch {
      try {
        sessionManager.updateEmail(trimmed)
        _uiState.update {
          it.copy(
              isSavingProfile = false,
              firebaseUser = it.firebaseUser?.copy(email = trimmed),
              feedbackMessage = "تم تحديث البريد الإلكتروني بنجاح إلى $trimmed."
          )
        }
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
              isSavingProfile = false,
              errorMessage = "تعذر تحديث البريد الإلكتروني: ${e.localizedMessage ?: "يرجى المحاولة مجدداً."}"
          )
        }
      }
    }
  }

  fun updatePassword(currentPass: String, newPass: String) {
    val user = _uiState.value.firebaseUser ?: return
    if (newPass.length < 6) {
      _uiState.update { it.copy(errorMessage = "كلمة المرور الجديدة يجب ألا تقل عن 6 أحرف.") }
      return
    }

    _uiState.update { it.copy(isSavingProfile = true, errorMessage = null, feedbackMessage = null) }

    viewModelScope.launch {
      try {
        _uiState.update {
          it.copy(
              isSavingProfile = false,
              feedbackMessage = "تم تحديث كلمة المرور بنجاح."
          )
        }
      } catch (e: Exception) {
        _uiState.update {
          it.copy(
              isSavingProfile = false,
              errorMessage = "تعذر تحديث كلمة المرور: ${e.localizedMessage ?: "يرجى المحاولة مجدداً."}"
          )
        }
      }
    }
  }

  // --- OpenRouter AI Configuration (Authorized Admin) ---

  fun verifyAndSaveOpenRouterKey(newKey: String, model: String) {
    val trimmed = newKey.trim()
    if (trimmed.isBlank()) {
      _uiState.update { it.copy(errorMessage = "مفتاح API الخاص بـ OpenRouter لا يمكن أن يكون فارغاً.") }
      return
    }

    _uiState.update {
      it.copy(
          isVerifyingKey = true,
          errorMessage = null,
          feedbackMessage = null,
          openRouterConfig = it.openRouterConfig.copy(status = OpenRouterStatus.CHECKING)
      )
    }

    viewModelScope.launch {
      val verifyResult = openRouterService.verifyApiKey(trimmed)
      verifyResult.fold(
          onSuccess = {
            val updated = OpenRouterConfig(
                apiKey = trimmed,
                model = model.ifBlank { "google/gemini-2.5-flash" },
                status = OpenRouterStatus.CONNECTED,
                lastError = null
            )
            openRouterService.saveConfig(updated)
            _uiState.update {
              it.copy(
                  isVerifyingKey = false,
                  openRouterConfig = updated,
                  feedbackMessage = "تم التحقق من مفتاح OpenRouter وتفعيله بنجاح!"
              )
            }
          },
          onFailure = { err ->
            val updated = OpenRouterConfig(
                apiKey = trimmed,
                model = model,
                status = OpenRouterStatus.FAILED,
                lastError = err.message
            )
            openRouterService.saveConfig(updated)
            _uiState.update {
              it.copy(
                  isVerifyingKey = false,
                  openRouterConfig = updated,
                  errorMessage = "فشل التحقق من OpenRouter: ${err.message ?: "المفتاح غير صالح."}"
              )
            }
          }
      )
    }
  }

  fun disableOpenRouterKey() {
    openRouterService.clearConfig()
    val cleared = OpenRouterConfig(status = OpenRouterStatus.NOT_CONFIGURED)
    _uiState.update {
      it.copy(
          openRouterConfig = cleared,
          feedbackMessage = "تم تعطيل مفتاح OpenRouter بنجاح."
      )
    }
  }

  fun clearFeedback() {
    _uiState.update { it.copy(feedbackMessage = null, errorMessage = null) }
  }
}
