package com.example.data.repository

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.UUID

data class AiConversationSession(
    val id: String = "",
    val userId: String = "",
    val title: String = "",
    val lastSnippet: String = "",
    val messageCount: Int = 0,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis()
)

data class AiConversationMessage(
    val id: String = "",
    val role: String = "user", // "user" or "model"
    val content: String = "",
    val timestamp: Long = System.currentTimeMillis(),
    val suggestedPlaces: List<AiPlaceSuggestion> = emptyList()
)

class AiConversationRepository(private val context: Context) {

    companion object {
        private val sessionsByUser = mutableMapOf<String, MutableList<AiConversationSession>>()
        private val messagesBySession = mutableMapOf<String, MutableList<AiConversationMessage>>()
    }

    suspend fun getUserConversations(userId: String): Result<List<AiConversationSession>> = withContext(Dispatchers.IO) {
        if (userId.isBlank()) return@withContext Result.success(emptyList())
        val list = sessionsByUser[userId] ?: emptyList()
        Result.success(list.sortedByDescending { it.updatedAt })
    }

    suspend fun getConversationMessages(
        userId: String,
        conversationId: String
    ): Result<List<AiConversationMessage>> = withContext(Dispatchers.IO) {
        if (userId.isBlank() || conversationId.isBlank()) return@withContext Result.success(emptyList())
        val list = messagesBySession[conversationId] ?: emptyList()
        Result.success(list.sortedBy { it.timestamp })
    }

    suspend fun appendExchange(
        userId: String,
        conversationId: String,
        userMessageText: String,
        modelResponseText: String,
        suggestedPlaces: List<AiPlaceSuggestion> = emptyList()
    ): Result<String> = withContext(Dispatchers.IO) {
        val convId = conversationId.ifBlank { UUID.randomUUID().toString() }
        val now = System.currentTimeMillis()

        val msgs = messagesBySession.getOrPut(convId) { mutableListOf() }
        msgs.add(
            AiConversationMessage(
                id = "msg_${now}_user",
                role = "user",
                content = userMessageText,
                timestamp = now
            )
        )
        msgs.add(
            AiConversationMessage(
                id = "msg_${now + 10}_model",
                role = "model",
                content = modelResponseText,
                timestamp = now + 10,
                suggestedPlaces = suggestedPlaces
            )
        )

        val userSessions = sessionsByUser.getOrPut(userId) { mutableListOf() }
        val idx = userSessions.indexOfFirst { it.id == convId }
        val titleSnippet = userMessageText.take(45).let { if (userMessageText.length > 45) "$it..." else it }
        val session = AiConversationSession(
            id = convId,
            userId = userId,
            title = titleSnippet,
            lastSnippet = modelResponseText.take(60),
            messageCount = msgs.size,
            updatedAt = System.currentTimeMillis()
        )
        if (idx >= 0) {
            userSessions[idx] = session
        } else {
            userSessions.add(0, session)
        }

        Result.success(convId)
    }
}
