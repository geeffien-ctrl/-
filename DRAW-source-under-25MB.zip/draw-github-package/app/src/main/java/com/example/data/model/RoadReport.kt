package com.example.data.model

import androidx.compose.ui.graphics.Color

/**
 * 9 Road Report Types defined for DRAW application.
 * Item 10 is the green "Road is Clear" resolution action inside report details.
 */
enum class RoadReportType(
    val id: String,
    val titleArabic: String,
    val titleEnglish: String,
    val colorHex: String,
    val glowColorHex: String
) {
    TRAFFIC_ACCIDENT(
        id = "traffic_accident",
        titleArabic = "حادث مروري",
        titleEnglish = "Traffic Accident",
        colorHex = "#6B7280", // Gray
        glowColorHex = "#9CA3AF"
    ),
    TRAFFIC_JAM(
        id = "traffic_jam",
        titleArabic = "ازدحام مروري",
        titleEnglish = "Traffic Jam",
        colorHex = "#F97316", // Orange
        glowColorHex = "#FB923C"
    ),
    POTHOLE(
        id = "pothole",
        titleArabic = "حفرة في الطريق",
        titleEnglish = "Pothole",
        colorHex = "#111827", // Black
        glowColorHex = "#374151"
    ),
    ROAD_HAZARD(
        id = "road_hazard",
        titleArabic = "خطر على الطريق",
        titleEnglish = "Road Hazard",
        colorHex = "#991B1B", // Dark Red
        glowColorHex = "#DC2626"
    ),
    TRAFFIC_CHECKPOINT(
        id = "traffic_checkpoint",
        titleArabic = "نقطة تفتيش",
        titleEnglish = "Traffic Checkpoint",
        colorHex = "#9333EA", // Purple
        glowColorHex = "#A855F7"
    ),
    ROADWORKS(
        id = "roadworks",
        titleArabic = "أعمال صيانة",
        titleEnglish = "Roadworks",
        colorHex = "#EAB308", // Yellow
        glowColorHex = "#FACC15"
    ),
    ROAD_CLOSED(
        id = "road_closed",
        titleArabic = "طريق مغلق",
        titleEnglish = "Road Closed",
        colorHex = "#CA8A04", // Dark Yellow
        glowColorHex = "#EAB308"
    ),
    FLOOD_WATER(
        id = "flood_water",
        titleArabic = "تجمع مياه",
        titleEnglish = "Flood / Water",
        colorHex = "#2563EB", // Blue
        glowColorHex = "#60A5FA"
    ),
    STOPPED_VEHICLE(
        id = "stopped_vehicle",
        titleArabic = "مركبة معطلة",
        titleEnglish = "Stopped Vehicle",
        colorHex = "#DC2626", // Crimson
        glowColorHex = "#EF4444"
    ),
    SPEED_CAMERA(
        id = "speed_camera",
        titleArabic = "كاميرا مراقبة",
        titleEnglish = "Speed Camera",
        colorHex = "#0D233A", // Dark Navy
        glowColorHex = "#38BDF8" // Glowing Blue/Cyan
    ),
    SPEED_BUMP(
        id = "speed_bump",
        titleArabic = "مطب",
        titleEnglish = "Speed Bump",
        colorHex = "#D97706", // Amber / Gold
        glowColorHex = "#F59E0B"
    ),
    SLIPPERY_ROAD(
        id = "slippery_road",
        titleArabic = "طريق زلق",
        titleEnglish = "Slippery Road",
        colorHex = "#0284C7", // Cyan / Cerulean
        glowColorHex = "#38BDF8"
    );

    val composeColor: Color
        get() = Color(android.graphics.Color.parseColor(colorHex))

    val composeGlowColor: Color
        get() = Color(android.graphics.Color.parseColor(glowColorHex))

    val legalSafetyNotice: String
        get() = when (this) {
            SPEED_CAMERA -> "تنبيه نظامي: التزم بالسرعة القانونية المقررة حفاظاً على سلامتك وسلامة الجميع على الطريق."
            ROAD_CLOSED -> "تحذير أمان: هذا الطريق مغلق تماماً، يُرجى تجنب المسار نهائياً."
            TRAFFIC_ACCIDENT -> "تنبيه: حادث مروري في الطريق، توخ الحذر وخفف السرعة."
            SPEED_BUMP -> "تنبيه: انتبه لوجود مطب صناعي في الطريق وخفف السرعة."
            SLIPPERY_ROAD -> "تحذير: الطريق قد يكون زلقاً، تجنب الفرملة المفاجئة وحافظ على مسافة الأمان."
            else -> "تنبيه قيادة: احرص على مسافة أمان كافية والقيادة بهدوء."
        }

    companion object {
        fun fromId(id: String): RoadReportType {
            return values().firstOrNull { it.id.equals(id, ignoreCase = true) } ?: ROAD_HAZARD
        }
    }
}

/**
 * Data model for a community Road Report in DRAW.
 */
data class RoadReport(
    val id: String = "",
    val type: RoadReportType = RoadReportType.ROAD_HAZARD,
    val description: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val creatorId: String = "",
    val creatorName: String = "",
    val createdAt: Long = System.currentTimeMillis(),
    val isCleared: Boolean = false,
    val clearedAt: Long? = null,
    val clearedByUserId: String? = null,
    val clearedByName: String? = null,
    val clearAuditLat: Double? = null,
    val clearAuditLng: Double? = null,
    val clearAuditAccuracy: Float? = null,
    val isConfirmed: Boolean = false,
    val confirmationsCount: Int = 1
)
