package com.example.data.model

data class SavedPlace(
    val id: String = "",
    val title: String = "",
    val address: String = "",
    val latitude: Double = 0.0,
    val longitude: Double = 0.0,
    val category: String = "favorite", // "favorite", "home", "work", "history"
    val iconId: String = "personal_favorite",
    val placeRefId: String = "",
    val source: String = "custom", // "draw", "osm", "search", "custom"
    val imageUrl: String = "",
    val createdAt: Long = System.currentTimeMillis()
)
