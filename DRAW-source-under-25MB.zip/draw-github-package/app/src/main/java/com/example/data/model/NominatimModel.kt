package com.example.data.model

import com.squareup.moshi.Json
import com.squareup.moshi.JsonClass

@JsonClass(generateAdapter = true)
data class NominatimResult(
    @Json(name = "place_id") val placeId: Long = 0L,
    @Json(name = "osm_id") val osmId: Long? = null,
    @Json(name = "osm_type") val osmType: String? = null,
    @Json(name = "lat") val latStr: String = "0.0",
    @Json(name = "lon") val lonStr: String = "0.0",
    @Json(name = "display_name") val displayName: String = "",
    @Json(name = "name") val name: String? = null,
    @Json(name = "type") val type: String? = null,
    @Json(name = "class") val placeClass: String? = null,
    @Json(name = "importance") val importance: Double? = null,
    @Json(name = "address") val address: NominatimAddress? = null,
    val isDirectMapTap: Boolean = false
) {
  val latitude: Double
    get() = latStr.toDoubleOrNull() ?: 0.0

  val longitude: Double
    get() = lonStr.toDoubleOrNull() ?: 0.0

  val shortTitle: String
    get() {
      if (!name.isNullOrBlank()) return name
      val parts = displayName.split(",")
      return parts.firstOrNull()?.trim() ?: displayName
    }

  val subtitle: String
    get() {
      val parts = displayName.split(",")
      return if (parts.size > 1) {
        parts.drop(1).take(3).joinToString(",").trim()
      } else {
        displayName
      }
    }

  companion object {
    fun fromCoordinates(
        lat: Double,
        lon: Double,
        title: String,
        id: Long = 0L,
        isDirectMapTap: Boolean = false
    ): NominatimResult {
      return NominatimResult(
          placeId = id,
          latStr = lat.toString(),
          lonStr = lon.toString(),
          displayName = title,
          name = title,
          isDirectMapTap = isDirectMapTap
      )
    }
  }
}

@JsonClass(generateAdapter = true)
data class NominatimAddress(
    val road: String? = null,
    val suburb: String? = null,
    val city: String? = null,
    val town: String? = null,
    val village: String? = null,
    val state: String? = null,
    val country: String? = null,
    val postcode: String? = null
)
