package com.example.ui.map.components

import android.media.AudioManager
import android.media.ToneGenerator
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ServiceOrder
import com.example.ui.theme.DrawGreen
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@Composable
fun IncomingOrderBanner(
    incomingOrder: ServiceOrder?,
    onAccept: (ServiceOrder) -> Unit,
    onReject: (ServiceOrder) -> Unit,
    modifier: Modifier = Modifier
) {
  // Play subtle audible chime when a new order arrives
  LaunchedEffect(incomingOrder?.id) {
    if (incomingOrder != null) {
      try {
        val toneGen = ToneGenerator(AudioManager.STREAM_NOTIFICATION, 90)
        toneGen.startTone(ToneGenerator.TONE_PROP_BEEP2, 400)
      } catch (_: Throwable) {}
    }
  }

  AnimatedVisibility(
      visible = incomingOrder != null,
      enter = slideInVertically(initialOffsetY = { -it }) + fadeIn(),
      exit = slideOutVertically(targetOffsetY = { -it }) + fadeOut(),
      modifier = modifier,
  ) {
    if (incomingOrder != null) {
      Surface(
          modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp, vertical = 8.dp)
              .shadow(8.dp, RoundedCornerShape(20.dp), spotColor = Color(0x33000000))
              .border(1.2.dp, DrawGreen, RoundedCornerShape(20.dp))
              .testTag("incoming_order_banner"),
          shape = RoundedCornerShape(20.dp),
          color = Color(0xFF1C1C1E), // Matte dark high-contrast driver banner
      ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
        ) {
          // Banner Top row with pulsing notification bell
          Row(
              modifier = Modifier.fillMaxWidth(),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Box(
                  modifier = Modifier
                      .size(34.dp)
                      .clip(CircleShape)
                  .background(DrawGreen.copy(alpha = 0.2f)),
                  contentAlignment = Alignment.Center,
              ) {
                Icon(
                    imageVector = Icons.Default.NotificationsActive,
                    contentDescription = null,
                    tint = DrawGreen,
                    modifier = Modifier.size(20.dp),
                )
              }
              Spacer(modifier = Modifier.width(10.dp))
              Column {
                Text(
                    text = "طلب مشوار جديد وارد!",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White,
                )
                Text(
                    text = "من: ${incomingOrder.effectiveCustomerName.ifBlank { "راكب بالقرب منك" }}",
                    fontSize = 12.sp,
                    color = Color(0xFFB0B0B8),
                )
              }
            }

            // Green status chip
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = DrawGreen,
            ) {
              Text(
                  text = "بانتظار ردك",
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                  color = Color.White,
                  modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }

          Spacer(modifier = Modifier.height(10.dp))

          Text(
              text = "نوع الخدمة: ${incomingOrder.effectiveServiceTitle}",
              fontSize = 13.sp,
              color = Color.White,
              fontWeight = FontWeight.Medium,
          )

          Spacer(modifier = Modifier.height(14.dp))

          // Decision Actions Row
          Row(
              modifier = Modifier.fillMaxWidth(),
              horizontalArrangement = Arrangement.spacedBy(10.dp),
          ) {
            Button(
                onClick = { onAccept(incomingOrder) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = DrawGreen,
                    contentColor = Color.White,
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1.3f)
                    .height(46.dp)
                    .testTag("accept_order_button"),
            ) {
              Icon(
                  imageVector = Icons.Default.Check,
                  contentDescription = null,
                  modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                  text = "قبول المشوار",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
              )
            }

            OutlinedButton(
                onClick = { onReject(incomingOrder) },
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFE0E0E0)),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x40FFFFFF)),
                modifier = Modifier
                    .weight(0.9f)
                    .height(46.dp)
                    .testTag("reject_order_button"),
            ) {
              Icon(
                  imageVector = Icons.Default.Close,
                  contentDescription = null,
                  tint = Color(0xFFFF6B6B),
                  modifier = Modifier.size(18.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                  text = "رفض",
                  fontSize = 13.sp,
                  color = Color(0xFFFF6B6B),
              )
            }
          }
        }
      }
    }
  }
}
