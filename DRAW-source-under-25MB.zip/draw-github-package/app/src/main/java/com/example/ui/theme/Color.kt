package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// DRAW Official Brand Colors
val DrawRed = Color(0xFFFF0000)
val DrawDarkRed = Color(0xFFD50000)
val DrawWhite = Color(0xFFFFFFFF)
val DrawGreen = Color(0xFF34C759)

// Phase 2 Authentication Design System Colors
val DrawTextNearBlack = Color(0xFF171717)
val DrawTextSecondary = Color(0xFF737373)
val DrawGrayText = Color(0xFF737373)
val DrawTextMuted = Color(0xFF9E9E9E)
val DrawLinkBlue = Color(0xFF1685FF)
val DrawSurfaceLight = Color(0xFFF7F7F9)
val DrawBorderLight = Color(0xFFE5E5EA)
val DrawCardShadow = Color(0x1F000000)

// Legacy fallbacks
val DrawBlack = Color(0xFF000000)
val DrawGraphiteGray = Color(0xFF666666)

val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
