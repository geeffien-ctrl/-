package com.example.ui.map.components

import android.location.Location
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInVertically
import androidx.compose.animation.slideOutVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddLocation
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Directions
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.NominatimResult
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * iOS-styled bottom card displaying place information, directions action, and save to favorites.
 */
@Composable
fun PlaceDetailsCard(
    place: NominatimResult,
    userLocation: Location?,
    isCalculatingRoute: Boolean,
    isSavingPlace: Boolean,
    onDirectionsClick: () -> Unit,
    onSaveFavoriteClick: () -> Unit,
    onAddCustomPlaceClick: () -> Unit,
    onCloseClick: () -> Unit,
    modifier: Modifier = Modifier
) {
  val shape = RoundedCornerShape(26.dp)

  Surface(
      modifier = modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp)
          .shadow(elevation = 14.dp, shape = shape, spotColor = Color(0x38000000))
          .border(width = 0.8.dp, color = Color(0x18000000), shape = shape)
          .testTag("place_details_card"),
      shape = shape,
      color = Color(0xFDFDFDFF)
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(18.dp)
    ) {
      // Top Drag Indicator / Header Row
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        // Place category tag or pin badge
        Row(verticalAlignment = Alignment.CenterVertically) {
          Box(
              modifier = Modifier
                  .size(30.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFFECEB)),
              contentAlignment = Alignment.Center
          ) {
            Icon(
                imageVector = Icons.Default.Place,
                contentDescription = null,
                tint = DrawRed,
                modifier = Modifier.size(17.dp)
            )
          }
          Spacer(modifier = Modifier.width(8.dp))
          Text(
              text = "مكان محدد على الخريطة",
              fontSize = 12.sp,
              fontWeight = FontWeight.Medium,
              color = DrawDarkRed
          )
        }

        // Close Button
        IconButton(
            onClick = onCloseClick,
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(Color(0xFFE5E5EA))
                .testTag("close_place_details_button")
        ) {
          Icon(
              imageVector = Icons.Default.Close,
              contentDescription = "Close",
              tint = Color(0xFF3A3A3C),
              modifier = Modifier.size(16.dp)
          )
        }
      }

      Spacer(modifier = Modifier.height(10.dp))

      // Place Title
      Text(
          text = place.shortTitle,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = DrawTextNearBlack,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
      )

      Spacer(modifier = Modifier.height(4.dp))

      // Full Address
      Text(
          text = place.displayName,
          fontSize = 13.sp,
          fontWeight = FontWeight.Normal,
          color = DrawTextSecondary,
          maxLines = 2,
          overflow = TextOverflow.Ellipsis,
          lineHeight = 18.sp
      )

      // Distance from current location if available
      if (userLocation != null) {
        val distanceMeters = calculateDistance(
            userLocation.latitude, userLocation.longitude,
            place.latitude, place.longitude
        )
        val formattedDist = if (distanceMeters < 1000) {
          "${distanceMeters.toInt()} متر"
        } else {
          "%.1f كم".format(distanceMeters / 1000.0)
        }

        Spacer(modifier = Modifier.height(6.dp))
        Text(
            text = "المسافة التقريبية: $formattedDist",
            fontSize = 12.sp,
            color = Color(0xFF34C759),
            fontWeight = FontWeight.SemiBold
        )
      }

      Spacer(modifier = Modifier.height(16.dp))

      // Action Buttons Row (iOS style rounded pill buttons)
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
          verticalAlignment = Alignment.CenterVertically
      ) {
        // Directions / Route Button (Primary DRAW Red)
        Button(
            onClick = onDirectionsClick,
            enabled = !isCalculatingRoute,
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = DrawRed,
                contentColor = Color.White
            ),
            modifier = Modifier
                .weight(1.3f)
                .height(48.dp)
                .testTag("place_directions_button")
        ) {
          if (isCalculatingRoute) {
            CircularProgressIndicator(
                modifier = Modifier.size(20.dp),
                strokeWidth = 2.dp,
                color = Color.White
            )
          } else {
            Icon(
                imageVector = Icons.Default.Directions,
                contentDescription = null,
                modifier = Modifier.size(19.dp)
            )
            Spacer(modifier = Modifier.width(6.dp))
            Text(
                text = "الاتجاهات",
                fontWeight = FontWeight.Bold,
                fontSize = 14.5.sp
            )
          }
        }

        // Save Favorite Button
        OutlinedButton(
            onClick = onSaveFavoriteClick,
            enabled = !isSavingPlace,
            shape = RoundedCornerShape(18.dp),
            colors = ButtonDefaults.outlinedButtonColors(
                contentColor = DrawDarkRed
            ),
            modifier = Modifier
                .weight(1f)
                .height(48.dp)
                .testTag("place_save_favorite_button")
        ) {
          if (isSavingPlace) {
            CircularProgressIndicator(
                modifier = Modifier.size(18.dp),
                strokeWidth = 2.dp,
                color = DrawRed
            )
          } else {
            Icon(
                imageVector = Icons.Default.Bookmark,
                contentDescription = null,
                modifier = Modifier.size(18.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "حفظ",
                fontWeight = FontWeight.SemiBold,
                fontSize = 14.sp
            )
          }
        }

        // Add to DRAW Public Directory Button
        Surface(
            onClick = onAddCustomPlaceClick,
            shape = RoundedCornerShape(18.dp),
            color = Color(0xFFF2F2F7),
            modifier = Modifier
                .height(48.dp)
                .testTag("place_add_custom_button")
        ) {
          Row(
              modifier = Modifier.padding(horizontal = 12.dp),
              verticalAlignment = Alignment.CenterVertically
          ) {
            Icon(
                imageVector = Icons.Default.AddLocation,
                contentDescription = "إضافة إلى دليل DRAW",
                tint = Color(0xFF1C1C1E),
                modifier = Modifier.size(19.dp)
            )
            Spacer(modifier = Modifier.width(4.dp))
            Text(
                text = "نشر في DRAW",
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF1C1C1E)
            )
          }
        }
      }
    }
  }
}

/**
 * Calculates straight line distance between two coordinates in meters.
 */
private fun calculateDistance(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Float {
  val results = FloatArray(1)
  Location.distanceBetween(lat1, lon1, lat2, lon2, results)
  return results[0]
}
