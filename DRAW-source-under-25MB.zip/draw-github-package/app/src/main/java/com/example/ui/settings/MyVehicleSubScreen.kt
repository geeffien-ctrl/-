package com.example.ui.settings

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.Payments
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.ThumbUp
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.LocationVisibilityMode
import com.example.data.model.TaxiColorOption
import com.example.data.model.TaxiColorPresets
import com.example.data.model.TaxiDriverStatus
import com.example.data.model.UserVehicleProfile
import com.example.ui.map.components.TopDownVehicleIcon
import com.example.ui.theme.DrawGreen
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * Dedicated Taxi SubScreen for DRAW.
 * "أنا صاحب تاكسي" toggle & complete taxi configuration.
 */
@Composable
fun MyVehicleSubScreen(
    currentProfile: UserVehicleProfile?,
    isSaving: Boolean,
    onSaveProfile: (UserVehicleProfile) -> Unit,
    modifier: Modifier = Modifier
) {
    val initial: UserVehicleProfile = currentProfile ?: UserVehicleProfile()

    var isTaxiOwner by remember(currentProfile) { mutableStateOf(initial.isTaxiOwner) }
    var driverName by remember(currentProfile) { mutableStateOf(initial.effectiveDriverName) }
    var carModel by remember(currentProfile) { mutableStateOf(initial.effectiveMakeModel) }
    var farePerKmStr by remember(currentProfile) {
        mutableStateOf(if (initial.taxiFarePerKm > 0) initial.taxiFarePerKm.toInt().toString() else "")
    }
    var isAvailableForOrders by remember(currentProfile) {
        mutableStateOf(initial.taxiStatus == TaxiDriverStatus.AVAILABLE)
    }

    val cardShape = RoundedCornerShape(20.dp)

    Column(
        modifier = modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 16.dp, vertical = 16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        // 1. Primary Toggle Card: "أنا صاحب تاكسي"
        Surface(
            modifier = Modifier
                .fillMaxWidth()
                .shadow(4.dp, cardShape, spotColor = Color(0x22000000))
                .border(
                    width = if (isTaxiOwner) 1.5.dp else 1.dp,
                    color = if (isTaxiOwner) DrawGreen else Color(0x18000000),
                    shape = cardShape
                )
                .testTag("taxi_owner_toggle_card"),
            shape = cardShape,
            color = Color.White,
        ) {
            Column(modifier = Modifier.padding(18.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween,
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(if (isTaxiOwner) Color(0xFFFEF3C7) else Color(0xFFF3F4F6)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.LocalTaxi,
                                contentDescription = null,
                                tint = if (isTaxiOwner) Color(0xFFD97706) else Color(0xFF6B7280),
                                modifier = Modifier.size(26.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Column {
                            Text(
                                text = "أنا صاحب تاكسي",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = DrawTextNearBlack,
                            )
                            Text(
                                text = if (isTaxiOwner) "التاكسي نشط ويستقبل الطلبات" else "متوقف (غير ظاهر على الخريطة)",
                                fontSize = 12.5.sp,
                                fontWeight = FontWeight.Medium,
                                color = if (isTaxiOwner) DrawGreen else DrawTextSecondary,
                            )
                        }
                    }

                    Switch(
                        checked = isTaxiOwner,
                        onCheckedChange = { checked ->
                            isTaxiOwner = checked
                            // Auto save toggle change to keep driver synced
                            val fareNum = Regex("[0-9]+(?:\\.[0-9]+)?").find(farePerKmStr)?.value?.toDoubleOrNull() ?: 0.0
                            val updated = initial.copy(
                                isTaxiOwner = checked,
                                isSharingLocation = checked,
                                visibilityMode = if (checked) LocationVisibilityMode.PUBLIC_TO_ALL else LocationVisibilityMode.HIDDEN_FROM_OTHERS,
                                taxiDriverName = driverName,
                                taxiCarModel = carModel,
                                taxiFarePerKm = fareNum,
                                taxiColorHex = initial.taxiColorHex,
                                taxiStatus = if (checked) (if (isAvailableForOrders) TaxiDriverStatus.AVAILABLE else TaxiDriverStatus.UNAVAILABLE) else TaxiDriverStatus.UNAVAILABLE,
                                isAcceptingOrders = checked && isAvailableForOrders,
                                lastUpdatedAt = System.currentTimeMillis()
                            )
                            onSaveProfile(updated)
                        },
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = DrawGreen,
                            uncheckedThumbColor = Color.White,
                            uncheckedTrackColor = Color(0xFFD1D5DB)
                        ),
                        modifier = Modifier.testTag("taxi_owner_switch")
                    )
                }

                if (!isTaxiOwner) {
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "عند إيقاف الميزة، يتم إخفاء التاكسي عن الخريطة وإيقاف استقبال الطلبات مع الاحتفاظ بكافة بياناتك لتفعيلها لاحقاً في أي وقت.",
                        fontSize = 12.sp,
                        color = DrawTextSecondary,
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // 2. Taxi Settings Container (Appears when enabled)
        AnimatedVisibility(
            visible = isTaxiOwner,
            enter = fadeIn() + expandVertically(),
            exit = fadeOut() + shrinkVertically()
        ) {
            Column(
                verticalArrangement = Arrangement.spacedBy(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                // Driver Details & Vehicle Info
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(3.dp, cardShape, spotColor = Color(0x18000000))
                        .border(1.dp, Color(0x14000000), cardShape)
                        .testTag("taxi_fields_card"),
                    shape = cardShape,
                    color = Color.White,
                ) {
                    Column(
                        modifier = Modifier.padding(18.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            text = "بيانات السائق والسيارة",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = DrawTextNearBlack,
                        )

                        // Driver Name
                        OutlinedTextField(
                            value = driverName,
                            onValueChange = { driverName = it },
                            label = { Text("اسم السائق الظاهر للركاب") },
                            placeholder = { Text("مثال: علي كريم") },
                            leadingIcon = {
                                Icon(Icons.Default.Person, contentDescription = null, tint = DrawRed)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("taxi_driver_name_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.Black,
                                unfocusedTextColor = Color.Black,
                                focusedPlaceholderColor = Color.Black,
                                unfocusedPlaceholderColor = Color.Black,
                                focusedLabelColor = Color.Black,
                                unfocusedLabelColor = Color.Black,
                                focusedBorderColor = DrawRed,
                                unfocusedBorderColor = Color(0x22000000),
                            )
                        )

                        // Car Make, Name & Model
                        OutlinedTextField(
                            value = carModel,
                            onValueChange = { carModel = it },
                            label = { Text("نوع السيارة واسمها وموديلها") },
                            placeholder = { Text("مثال: هيونداي النترا 2023") },
                            leadingIcon = {
                                Icon(Icons.Default.LocalTaxi, contentDescription = null, tint = DrawRed)
                            },
                            singleLine = true,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("taxi_car_model_input"),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedTextColor = Color.Black,
                                unfocusedTextColor = Color.Black,
                                focusedPlaceholderColor = Color.Black,
                                unfocusedPlaceholderColor = Color.Black,
                                focusedLabelColor = Color.Black,
                                unfocusedLabelColor = Color.Black,
                                focusedBorderColor = DrawRed,
                                unfocusedBorderColor = Color(0x22000000),
                            )
                        )

                        // Fare per Km
                        Column {
                            OutlinedTextField(
                                value = farePerKmStr,
                                onValueChange = { input ->
                                    if (input.length <= 40) {
                                        farePerKmStr = input
                                    }
                                },
                                label = { Text("سعر المسافة (اكتب العملة والوحدة)") },
                                placeholder = { Text("مثال: 5000 دينار عراقي / كم") },
                                trailingIcon = {
                                    Text(
                                        text = "لكل كم",
                                        fontWeight = FontWeight.Bold,
                                        color = DrawTextSecondary,
                                        fontSize = 12.sp,
                                        modifier = Modifier.padding(end = 12.dp)
                                    )
                                },
                                leadingIcon = {
                                    Icon(Icons.Default.Payments, contentDescription = null, tint = DrawGreen)
                                },
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .testTag("taxi_fare_per_km_input"),
                                colors = OutlinedTextFieldDefaults.colors(
                                    focusedTextColor = Color.Black,
                                    unfocusedTextColor = Color.Black,
                                    focusedPlaceholderColor = Color.Black,
                                    unfocusedPlaceholderColor = Color.Black,
                                    focusedLabelColor = Color.Black,
                                    unfocusedLabelColor = Color.Black,
                                    focusedBorderColor = DrawRed,
                                    unfocusedBorderColor = Color(0x22000000),
                                )
                            )

                        }

                        HorizontalDivider(color = Color(0x14000000))

                    }
                }

                // Driver Reputation & Stats (Likes & Comments from verified rides)
                Surface(
                    modifier = Modifier
                        .fillMaxWidth()
                        .shadow(2.dp, cardShape, spotColor = Color(0x14000000))
                        .border(1.dp, Color(0x14000000), cardShape),
                    shape = cardShape,
                    color = Color(0xFFFBFBFC),
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceEvenly,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${initial.totalCompletedTrips}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = DrawTextNearBlack
                            )
                            Text(
                                text = "رحلات مكتملة",
                                fontSize = 11.5.sp,
                                color = DrawTextSecondary
                            )
                        }

                        Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0x20000000)))

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.ThumbUp, contentDescription = null, tint = Color(0xFF2563EB), modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = "${initial.totalLikes}",
                                    fontSize = 18.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = DrawTextNearBlack
                                )
                            }
                            Text(
                                text = "إعجابات الركاب",
                                fontSize = 11.5.sp,
                                color = DrawTextSecondary
                            )
                        }

                        Box(modifier = Modifier.width(1.dp).height(24.dp).background(Color(0x20000000)))

                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${initial.totalComments}",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = DrawTextNearBlack
                            )
                            Text(
                                text = "تعليقات موثقة",
                                fontSize = 11.5.sp,
                                color = DrawTextSecondary
                            )
                        }
                    }
                }

                // Save & Apply Button
                Button(
                    onClick = {
                        val fareNum = Regex("[0-9]+(?:\\.[0-9]+)?").find(farePerKmStr)?.value?.toDoubleOrNull() ?: 0.0
                        val updated = initial.copy(
                            isTaxiOwner = true,
                            isSharingLocation = true,
                            visibilityMode = LocationVisibilityMode.PUBLIC_TO_ALL,
                            taxiDriverName = driverName,
                            taxiCarModel = carModel,
                            taxiFarePerKm = fareNum,
                            taxiColorHex = initial.taxiColorHex,
                            taxiStatus = if (isAvailableForOrders) TaxiDriverStatus.AVAILABLE else TaxiDriverStatus.UNAVAILABLE,
                            isAcceptingOrders = isAvailableForOrders,
                            lastUpdatedAt = System.currentTimeMillis()
                        )
                        onSaveProfile(updated)
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("save_taxi_settings_button"),
                    enabled = !isSaving,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = DrawRed,
                        contentColor = Color.White,
                    ),
                    shape = RoundedCornerShape(14.dp),
                ) {
                    if (isSaving) {
                        CircularProgressIndicator(
                            color = Color.White,
                            modifier = Modifier.size(22.dp),
                            strokeWidth = 2.dp,
                        )
                    } else {
                        Icon(
                            imageVector = Icons.Default.CheckCircle,
                            contentDescription = null,
                            modifier = Modifier.size(20.dp),
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "حفظ وتفعيل التاكسي على الخريطة",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                        )
                    }
                }
            }
        }
    }
}

/**
 * 3-Choice Taxi Color Item with Instant Top-Down Visual Preview.
 */
@Composable
private fun TaxiColorItem(
    colorOption: TaxiColorOption,
    isSelected: Boolean,
    onSelect: () -> Unit,
    modifier: Modifier = Modifier
) {
    Surface(
        onClick = onSelect,
        shape = RoundedCornerShape(14.dp),
        color = if (isSelected) colorOption.primaryColor.copy(alpha = 0.10f) else Color(0xFFF9FAFB),
        border = androidx.compose.foundation.BorderStroke(
            width = if (isSelected) 2.dp else 1.dp,
            color = if (isSelected) colorOption.primaryColor else Color(0x18000000)
        ),
        modifier = modifier.testTag("taxi_color_${colorOption.id}")
    ) {
        Column(
            modifier = Modifier.padding(10.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            // Color sample swatch with black accent trim
            Box(
                modifier = Modifier
                    .size(36.dp)
                    .clip(CircleShape)
                    .background(colorOption.primaryColor)
                    .border(2.5.dp, Color(0xFF111827), CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (isSelected) {
                    Icon(
                        imageVector = Icons.Default.Check,
                        contentDescription = null,
                        tint = Color.White,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = colorOption.nameArabic,
                fontSize = 11.5.sp,
                fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                color = if (isSelected) DrawTextNearBlack else DrawTextSecondary,
                textAlign = TextAlign.Center
            )
        }
    }
}
