package com.example.ui.auth

import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.tween
import androidx.compose.animation.fadeIn
import androidx.compose.animation.slideInVertically
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.layout.widthIn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AddAPhoto
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.outlined.Badge
import androidx.compose.material.icons.outlined.Email
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.Person
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import coil.compose.AsyncImage
import com.example.R
import com.example.ui.components.BalloonButton
import com.example.ui.components.BalloonTextField
import com.example.ui.components.DrawBrandHeader
import com.example.ui.components.ProviderSignInCard
import com.example.ui.theme.DrawBorderLight
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawLinkBlue
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawSurfaceLight
import com.example.ui.theme.DrawTextMuted
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import com.example.ui.theme.DrawWhite

/**
 * DRAW Phase 2: Create Account Screen
 *
 * Includes strictly the requested 7 account fields in exact order:
 * 1. Username
 * 2. Email address
 * 3. Display name
 * 4. Profile picture selection from device gallery
 * 5. Password
 * 6. Confirm password
 * 7. Create account button
 */
@Composable
fun CreateAccountScreen(
    uiState: AuthUiState,
    onUsernameChange: (String) -> Unit = {},
    onEmailChange: (String) -> Unit,
    onDisplayNameChange: (String) -> Unit,
    onPhotoUriChange: (Uri?) -> Unit,
    onPasswordChange: (String) -> Unit,
    onConfirmPasswordChange: (String) -> Unit,
    onTogglePasswordVisibility: () -> Unit,
    onToggleConfirmPasswordVisibility: () -> Unit,
    onCreateAccountSubmit: () -> Unit,
    onBackToLogin: () -> Unit,
    onGoogleSignIn: () -> Unit = {},
    onAppleSignIn: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
  BackHandler { onBackToLogin() }

  var isVisible by remember { mutableStateOf(false) }
  LaunchedEffect(Unit) { isVisible = true }

  val photoPickerLauncher =
      rememberLauncherForActivityResult(
          contract = ActivityResultContracts.PickVisualMedia(),
          onResult = { uri: Uri? -> onPhotoUriChange(uri) },
      )

  val scrollState = rememberScrollState()

  Box(
      modifier =
          modifier
              .fillMaxSize()
              .background(DrawRed)
              .imePadding(),
  ) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier =
            Modifier
                .fillMaxSize()
                .verticalScroll(scrollState)
                .padding(horizontal = 20.dp, vertical = 20.dp),
    ) {
      // Top Navigation Row
      Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier.fillMaxWidth().padding(bottom = 8.dp),
      ) {
        IconButton(
            onClick = onBackToLogin,
            modifier =
                Modifier
                    .shadow(elevation = 4.dp, shape = CircleShape)
                    .clip(CircleShape)
                    .background(DrawWhite)
                    .testTag("create_account_back_button"),
        ) {
          Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowBack,
              contentDescription = "Back to Login",
              tint = DrawTextNearBlack,
              modifier = Modifier.size(22.dp),
          )
        }
      }

      // Main White Card Surface
      AnimatedVisibility(
          visible = isVisible,
          enter =
              fadeIn(animationSpec = tween(500)) +
                  slideInVertically(
                      initialOffsetY = { 60 },
                      animationSpec = tween(500),
                  ),
      ) {
        Card(
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = DrawWhite),
            elevation = CardDefaults.cardElevation(defaultElevation = 12.dp),
            modifier =
                Modifier
                    .fillMaxWidth()
                    .widthIn(max = 480.dp)
                    .shadow(elevation = 16.dp, shape = RoundedCornerShape(32.dp), clip = false)
                    .testTag("create_account_card_surface"),
        ) {
          Column(
              horizontalAlignment = Alignment.CenterHorizontally,
              modifier =
                  Modifier
                      .fillMaxWidth()
                      .padding(horizontal = 24.dp, vertical = 28.dp),
          ) {
            DrawBrandHeader(
                title = "Create Account",
                subtitle = "Join the DRAW navigation community",
                logoSize = 72.dp,
            )

            Spacer(modifier = Modifier.height(20.dp))

            // 2. Email Address
            BalloonTextField(
                value = uiState.regEmail,
                onValueChange = onEmailChange,
                label = "Email Address",
                placeholder = "name@example.com",
                leadingIcon = Icons.Outlined.Email,
                errorMessage = uiState.regEmailError,
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Email,
                        imeAction = ImeAction.Next,
                    ),
                testTag = "reg_email_input",
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 3. Display Name
            BalloonTextField(
                value = uiState.regDisplayName,
                onValueChange = onDisplayNameChange,
                label = "Display Name",
                placeholder = "Your full name or callsign",
                leadingIcon = Icons.Outlined.Badge,
                errorMessage = uiState.regDisplayNameError,
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Text,
                        imeAction = ImeAction.Next,
                    ),
                testTag = "reg_display_name_input",
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 4. Password
            BalloonTextField(
                value = uiState.regPassword,
                onValueChange = onPasswordChange,
                label = "Password",
                placeholder = "Create a password (min. 6 characters)",
                leadingIcon = Icons.Outlined.Lock,
                errorMessage = uiState.regPasswordError,
                visualTransformation =
                    if (uiState.isRegPasswordVisible) VisualTransformation.None
                    else PasswordVisualTransformation(),
                trailingIcon = {
                  IconButton(
                      onClick = onTogglePasswordVisibility,
                      modifier = Modifier.testTag("reg_password_visibility_toggle"),
                  ) {
                    Icon(
                        imageVector =
                            if (uiState.isRegPasswordVisible) Icons.Filled.VisibilityOff
                            else Icons.Filled.Visibility,
                        contentDescription =
                            if (uiState.isRegPasswordVisible) "Hide password"
                            else "Show password",
                        tint = DrawTextSecondary,
                        modifier = Modifier.size(20.dp),
                    )
                  }
                },
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Next,
                    ),
                testTag = "reg_password_input",
            )

            Spacer(modifier = Modifier.height(16.dp))

            // 6. Confirm Password
            BalloonTextField(
                value = uiState.regConfirmPassword,
                onValueChange = onConfirmPasswordChange,
                label = "Confirm Password",
                placeholder = "Re-enter your password",
                leadingIcon = Icons.Outlined.Lock,
                errorMessage = uiState.regConfirmPasswordError,
                visualTransformation =
                    if (uiState.isRegConfirmPasswordVisible) VisualTransformation.None
                    else PasswordVisualTransformation(),
                trailingIcon = {
                  IconButton(
                      onClick = onToggleConfirmPasswordVisibility,
                      modifier = Modifier.testTag("reg_confirm_password_visibility_toggle"),
                  ) {
                    Icon(
                        imageVector =
                            if (uiState.isRegConfirmPasswordVisible) Icons.Filled.VisibilityOff
                            else Icons.Filled.Visibility,
                        contentDescription =
                            if (uiState.isRegConfirmPasswordVisible) "Hide password"
                            else "Show password",
                        tint = DrawTextSecondary,
                        modifier = Modifier.size(20.dp),
                    )
                  }
                },
                keyboardOptions =
                    KeyboardOptions(
                        keyboardType = KeyboardType.Password,
                        imeAction = ImeAction.Done,
                    ),
                keyboardActions = KeyboardActions(onDone = { onCreateAccountSubmit() }),
                testTag = "reg_confirm_password_input",
            )

            Spacer(modifier = Modifier.height(28.dp))

            // Create Account Button (Red background with clean pure white text)
            BalloonButton(
                text = "Create Account",
                onClick = onCreateAccountSubmit,
                isLoading = uiState.isLoading,
                backgroundColor = DrawRed,
                contentColor = DrawWhite,
                testTag = "create_account_submit_button",
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Divider with text
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
            ) {
              Box(modifier = Modifier.weight(1f).height(1.dp).background(DrawBorderLight))
              Text(
                  text = "or register with",
                  fontSize = 12.sp,
                  color = DrawTextMuted,
                  modifier = Modifier.padding(horizontal = 12.dp),
              )
              Box(modifier = Modifier.weight(1f).height(1.dp).background(DrawBorderLight))
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Google and Apple quick registration buttons intentionally removed.

            Spacer(modifier = Modifier.height(24.dp))

            // Back to Login link
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center,
                modifier = Modifier.fillMaxWidth(),
            ) {
              Text(
                  text = "Already have an account? ",
                  fontSize = 14.sp,
                  color = DrawTextSecondary,
              )
              Text(
                  text = "Sign in",
                  fontSize = 14.sp,
                  fontWeight = FontWeight.Bold,
                  color = DrawLinkBlue,
                  modifier =
                      Modifier
                          .clickable(onClick = onBackToLogin)
                          .padding(vertical = 4.dp)
                          .testTag("back_to_login_link"),
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(24.dp))
    }
  }
}
