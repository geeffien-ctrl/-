package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.util.Log
import com.example.R
import com.example.data.model.NominatimResult
import com.example.data.model.OsrmResponse
import com.example.data.model.SavedPlace
import com.example.data.network.OsmApiClient
import com.example.data.network.OsmApiService
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

private const val TAG = "NavigationRepository"

sealed class SaveFavoriteResult {
  object Success : SaveFavoriteResult()
  object AlreadySaved : SaveFavoriteResult()
  data class Error(val message: String) : SaveFavoriteResult()
}

class NavigationRepository(
    private val api: OsmApiService = OsmApiClient.apiService,
    private val context: Context? = null
) {
  constructor(context: Context) : this(
      api = OsmApiClient.apiService,
      context = context.applicationContext
  )

  private val prefs: SharedPreferences? =
      context?.getSharedPreferences("draw_saved_favorites", Context.MODE_PRIVATE)

  private val db: FirebaseFirestore? by lazy {
    try {
      context?.let { ctx ->
        val dbId = ctx.getString(R.string.firestore_database_id)
        FirebaseFirestore.getInstance(dbId)
      }
    } catch (_: Exception) {
      null
    }
  }

  suspend fun searchPlaces(query: String): List<NominatimResult> = withContext(Dispatchers.IO) {
    if (query.trim().length < 2) return@withContext emptyList()
    try {
      api.searchPlaces(query = query.trim())
    } catch (e: Exception) {
      Log.e(TAG, "Search places failed for query: $query", e)
      emptyList()
    }
  }

  suspend fun reverseGeocode(lat: Double, lon: Double): NominatimResult? = withContext(Dispatchers.IO) {
    try {
      api.reverseGeocode(lat = lat, lon = lon)
    } catch (e: Exception) {
      Log.e(TAG, "Reverse geocode failed for ($lat, $lon)", e)
      null
    }
  }

  suspend fun getRoute(
      startLat: Double,
      startLon: Double,
      endLat: Double,
      endLon: Double
  ): OsrmResponse? = withContext(Dispatchers.IO) {
    try {
      val coordinatesParam = "$startLon,$startLat;$endLon,$endLat"
      api.getRoute(coordinates = coordinatesParam)
    } catch (e: Exception) {
      Log.e(TAG, "Routing failed for $startLat,$startLon -> $endLat,$endLon", e)
      null
    }
  }

  suspend fun getFavorites(userId: String): List<SavedPlace> = withContext(Dispatchers.IO) {
    if (userId.isBlank()) return@withContext emptyList()
    try {
      val snapshot = db?.collection("users")?.document(userId)?.collection("favorites")?.get()?.await()
      if (snapshot != null && !snapshot.isEmpty) {
        val cloudList = snapshot.documents.mapNotNull { doc ->
          try {
            SavedPlace(
                id = doc.id,
                title = doc.getString("title") ?: "",
                address = doc.getString("address") ?: "",
                latitude = doc.getDouble("latitude") ?: 0.0,
                longitude = doc.getDouble("longitude") ?: 0.0,
                category = doc.getString("category") ?: "favorite",
                iconId = doc.getString("iconId") ?: "personal_favorite",
                placeRefId = doc.getString("placeRefId") ?: "",
                source = doc.getString("source") ?: "custom",
                imageUrl = doc.getString("imageUrl") ?: "",
                createdAt = doc.getLong("createdAt") ?: System.currentTimeMillis()
            )
          } catch (_: Exception) { null }
        }
        if (cloudList.isNotEmpty()) {
          saveToLocal(userId, cloudList)
          return@withContext cloudList.sortedByDescending { it.createdAt }
        }
      }
    } catch (_: Exception) {}

    loadFromLocal(userId)
  }

  suspend fun saveFavorite(userId: String, place: SavedPlace): SaveFavoriteResult = withContext(Dispatchers.IO) {
    if (userId.isBlank() || userId.startsWith("guest_")) return@withContext SaveFavoriteResult.Error("يرجى تسجيل الدخول بحساب مسجل لحفظ الأماكن")
    try {
      val current = getFavorites(userId).toMutableList()

      if (place.placeRefId.isNotBlank() && current.any { it.placeRefId == place.placeRefId }) {
        return@withContext SaveFavoriteResult.AlreadySaved
      }

      val duplicate = current.any {
        it.title == place.title &&
            Math.abs(it.latitude - place.latitude) < 0.0002 &&
            Math.abs(it.longitude - place.longitude) < 0.0002
      }
      if (duplicate) {
        return@withContext SaveFavoriteResult.AlreadySaved
      }

      val newId = place.id.ifBlank { UUID.randomUUID().toString() }
      val placeToSave = place.copy(id = newId)
      current.add(0, placeToSave)

      saveToLocal(userId, current)

      try {
        val map = mapOf(
            "title" to placeToSave.title,
            "address" to placeToSave.address,
            "latitude" to placeToSave.latitude,
            "longitude" to placeToSave.longitude,
            "category" to placeToSave.category,
            "iconId" to placeToSave.iconId,
            "placeRefId" to placeToSave.placeRefId,
            "source" to placeToSave.source,
            "imageUrl" to placeToSave.imageUrl,
            "createdAt" to placeToSave.createdAt
        )
        db?.collection("users")?.document(userId)?.collection("favorites")?.document(newId)?.set(map, SetOptions.merge())?.await()
      } catch (_: Exception) {}

      SaveFavoriteResult.Success
    } catch (e: Exception) {
      Log.e(TAG, "Failed to save favorite for user $userId", e)
      SaveFavoriteResult.Error(e.message ?: "خطأ أثناء حفظ المكان")
    }
  }

  suspend fun deleteFavorite(userId: String, favoriteId: String): Boolean = withContext(Dispatchers.IO) {
    if (userId.isBlank() || favoriteId.isBlank()) return@withContext false
    try {
      val current = getFavorites(userId).filter { it.id != favoriteId }
      saveToLocal(userId, current)

      try {
        db?.collection("users")?.document(userId)?.collection("favorites")?.document(favoriteId)?.delete()?.await()
      } catch (_: Exception) {}

      true
    } catch (e: Exception) {
      Log.e(TAG, "Failed to delete favorite $favoriteId", e)
      false
    }
  }

  private fun loadFromLocal(userId: String): List<SavedPlace> {
    if (prefs == null || userId.isBlank()) return emptyList()
    val raw = prefs.getString("favs_$userId", null) ?: return emptyList()
    return try {
      val arr = JSONArray(raw)
      val list = mutableListOf<SavedPlace>()
      for (i in 0 until arr.length()) {
        val obj = arr.getJSONObject(i)
        list.add(
            SavedPlace(
                id = obj.optString("id"),
                title = obj.optString("title"),
                address = obj.optString("address"),
                latitude = obj.optDouble("latitude"),
                longitude = obj.optDouble("longitude"),
                category = obj.optString("category", "favorite"),
                iconId = obj.optString("iconId", "personal_favorite"),
                placeRefId = obj.optString("placeRefId"),
                source = obj.optString("source", "custom"),
                imageUrl = obj.optString("imageUrl"),
                createdAt = obj.optLong("createdAt", System.currentTimeMillis())
            )
        )
      }
      list.sortedByDescending { it.createdAt }
    } catch (_: Exception) {
      emptyList()
    }
  }

  private fun saveToLocal(userId: String, list: List<SavedPlace>) {
    if (prefs == null || userId.isBlank()) return
    val arr = JSONArray()
    for (item in list) {
      arr.put(
          JSONObject().apply {
            put("id", item.id)
            put("title", item.title)
            put("address", item.address)
            put("latitude", item.latitude)
            put("longitude", item.longitude)
            put("category", item.category)
            put("iconId", item.iconId)
            put("placeRefId", item.placeRefId)
            put("source", item.source)
            put("imageUrl", item.imageUrl)
            put("createdAt", item.createdAt)
          }
      )
    }
    prefs.edit().putString("favs_$userId", arr.toString()).apply()
  }
}
