package com.example.ui.reels

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.pager.VerticalPager
import androidx.compose.foundation.pager.rememberPagerState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.ErrorOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.Post
import com.example.data.repository.PostsRepository
import com.example.ui.feed.PostCommentsBottomSheet
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.data.repository.AuthSessionManager
import kotlinx.coroutines.launch

@OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)
@Composable
fun ReelsScreen(
    initialPostId: String? = null,
    onBack: (() -> Unit)? = null,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val postsRepository = remember { PostsRepository(context) }
    val scope = rememberCoroutineScope()
    val sessionManager = remember { AuthSessionManager.getInstance(context) }
    val currentUser by sessionManager.currentUser.collectAsStateWithLifecycle()

    // All posts for Reels discovery flow
    val allPosts by postsRepository.getFeedPostsFlow(emptySet(), currentUser?.uid ?: "")
        .collectAsStateWithLifecycle(initialValue = emptyList())
    val videoPosts = remember(allPosts) { allPosts.filter { it.isVideo } }

    val initialIndex = remember(videoPosts, initialPostId) {
        if (!initialPostId.isNullOrBlank()) {
            val idx = videoPosts.indexOfFirst { it.id == initialPostId }
            if (idx >= 0) idx else 0
        } else {
            0
        }
    }

    if (videoPosts.isEmpty()) {
        Box(
            modifier = modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text(
                    text = "قسم الريلز (Reels)",
                    color = Color.White,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    text = "لم يتم نشر فيديوهات قصيرة بعد.\nكن أول من ينشر فيديو عبر زر الإنشاء (+)",
                    color = Color.White.copy(alpha = 0.7f),
                    fontSize = 13.5.sp,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.padding(horizontal = 32.dp)
                )
            }
        }
        return
    }

    val pagerState = rememberPagerState(
        initialPage = initialIndex.coerceIn(0, videoPosts.size - 1),
        pageCount = { videoPosts.size }
    )

    var activeCommentPostId by remember { mutableStateOf<String?>(null) }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("reels_screen")
    ) {
        VerticalPager(
            state = pagerState,
            modifier = Modifier.fillMaxSize()
        ) { page ->
            val post = videoPosts[page]
            val isCurrentPage = pagerState.currentPage == page

            ReelItemPage(
                post = post,
                isCurrentPage = isCurrentPage,
                postsRepository = postsRepository,
                currentUserId = currentUser?.uid ?: "",
                onOpenComments = { activeCommentPostId = post.id }
            )
        }

        // Top Header Overlay (Back button if opened from feed, and "Reels" Title)
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(top = 48.dp, start = 16.dp, end = 16.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (onBack != null) {
                IconButton(
                    onClick = onBack,
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(Color.Black.copy(alpha = 0.5f))
                        .testTag("reels_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = Color.White,
                        modifier = Modifier.size(22.dp)
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
            }
            Text(
                text = "Reels",
                fontSize = 20.sp,
                fontWeight = FontWeight.ExtraBold,
                color = Color.White
            )
        }

        if (activeCommentPostId != null) {
            PostCommentsBottomSheet(
                postId = activeCommentPostId!!,
                onDismiss = { activeCommentPostId = null }
            )
        }
    }
}

@Composable
private fun ReelItemPage(
    post: Post,
    isCurrentPage: Boolean,
    postsRepository: PostsRepository,
    currentUserId: String,
    onOpenComments: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val sessionManager = remember { AuthSessionManager.getInstance(context) }
    val currentUser by sessionManager.currentUser.collectAsStateWithLifecycle()

    val isLiked by postsRepository.isPostLikedFlow(post.id, currentUserId)
        .collectAsStateWithLifecycle(initialValue = false)
    val isSaved by postsRepository.isPostSavedFlow(currentUserId, post.id)
        .collectAsStateWithLifecycle(initialValue = false)

    var hasVideoError by remember { mutableStateOf(false) }
    var isPlaying by remember { mutableStateOf(true) }
    var videoViewRef by remember { mutableStateOf<VideoView?>(null) }

    val heartColor by animateColorAsState(
        targetValue = if (isLiked) DrawRed else Color.White,
        label = "reel_heart"
    )

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable {
                videoViewRef?.let { vv ->
                    if (vv.isPlaying) {
                        vv.pause()
                        isPlaying = false
                    } else {
                        vv.start()
                        isPlaying = true
                    }
                }
            }
    ) {
        // Video View or Error State
        if (hasVideoError || post.videoUrl.isBlank()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .background(Color(0xFF141416)),
                contentAlignment = Alignment.Center
            ) {
                Column(
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ErrorOutline,
                        contentDescription = null,
                        tint = DrawRed,
                        modifier = Modifier.size(48.dp)
                    )
                    Text(
                        text = "تعذر تحميل الفيديو",
                        color = Color.White,
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Text(
                        text = "يرجى التحقق من اتصالك بالإنترنت",
                        color = Color.White.copy(alpha = 0.6f),
                        fontSize = 12.sp
                    )
                }
            }
        } else {
            AndroidView(
                factory = { ctx ->
                    VideoView(ctx).apply {
                        setVideoURI(Uri.parse(post.videoUrl))
                        setOnPreparedListener { mp ->
                            mp.isLooping = true
                            if (isCurrentPage) {
                                start()
                                isPlaying = true
                            }
                        }
                        setOnErrorListener { _, _, _ ->
                            hasVideoError = true
                            true
                        }
                        videoViewRef = this
                    }
                },
                update = { vv ->
                    if (isCurrentPage) {
                        if (!vv.isPlaying && isPlaying) vv.start()
                    } else {
                        if (vv.isPlaying) vv.pause()
                    }
                },
                modifier = Modifier.fillMaxSize()
            )
        }

        // Pause overlay badge
        if (!isPlaying && !hasVideoError) {
            Box(
                modifier = Modifier
                    .size(64.dp)
                    .clip(CircleShape)
                    .background(Color.Black.copy(alpha = 0.5f))
                    .align(Alignment.Center),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.PlayArrow,
                    contentDescription = "Paused",
                    tint = Color.White,
                    modifier = Modifier.size(42.dp)
                )
            }
        }

        // Bottom Shadow Gradient for text legibility
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(260.dp)
                .align(Alignment.BottomCenter)
                .background(
                    Brush.verticalGradient(
                        listOf(Color.Transparent, Color.Black.copy(alpha = 0.85f))
                    )
                )
        )

        // Bottom Left: Creator Info & Caption
        Column(
            modifier = Modifier
                .align(Alignment.BottomStart)
                .padding(start = 16.dp, bottom = 32.dp, end = 90.dp)
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                if (post.creatorPhotoUrl.isNotBlank()) {
                    AsyncImage(
                        model = post.creatorPhotoUrl,
                        contentDescription = post.creatorName,
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .border(1.5.dp, Color.White, CircleShape)
                    )
                } else {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(Color.White.copy(alpha = 0.25f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Person,
                            contentDescription = null,
                            tint = Color.White,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.width(10.dp))

                Text(
                    text = post.creatorName.ifBlank { "مستخدم ZOLAVOR" },
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }

            if (post.caption.isNotBlank()) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = post.caption,
                    fontSize = 13.5.sp,
                    color = Color.White,
                    lineHeight = 18.sp,
                    maxLines = 3,
                    overflow = TextOverflow.Ellipsis
                )
            }

            // Audio track label (uses original video audio)
            Spacer(modifier = Modifier.height(8.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                Icon(
                    imageVector = Icons.Default.GraphicEq,
                    contentDescription = null,
                    tint = DrawRed,
                    modifier = Modifier.size(15.dp)
                )
                Spacer(modifier = Modifier.width(6.dp))
                Text(
                    text = if (post.audioTitle.isNotBlank()) post.audioTitle else "الصوت الأصلي للفيديو",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.9f)
                )
            }
        }

        // Bottom Right: Actions (Like, Comment, Share, Save)
        Column(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(end = 16.dp, bottom = 32.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Like
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = {
                        val user = currentUser
                        if (user != null) {
                            scope.launch { postsRepository.togglePostLike(post.id, user) }
                        }
                    },
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                        contentDescription = "Like",
                        tint = heartColor,
                        modifier = Modifier.size(28.dp)
                    )
                }
                Text(
                    text = "${post.likesCount}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Comment
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                IconButton(
                    onClick = onOpenComments,
                    modifier = Modifier.size(40.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.ChatBubbleOutline,
                        contentDescription = "Comment",
                        tint = Color.White,
                        modifier = Modifier.size(26.dp)
                    )
                }
                Text(
                    text = "${post.commentsCount}",
                    color = Color.White,
                    fontSize = 12.sp,
                    fontWeight = FontWeight.Bold
                )
            }

            // Share
            IconButton(
                onClick = {
                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                        type = "text/plain"
                        putExtra(Intent.EXTRA_TEXT, "شاهد فيديو ${post.creatorName} عبر تطبيق ZOLAVOR")
                    }
                    context.startActivity(Intent.createChooser(shareIntent, "مشاركة الفيديو"))
                },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Share,
                    contentDescription = "Share",
                    tint = Color.White,
                    modifier = Modifier.size(24.dp)
                )
            }

            // Save / Bookmark
            IconButton(
                onClick = {
                    val user = currentUser
                    if (user != null) {
                        scope.launch { postsRepository.toggleSavePost(user.uid, post.id) }
                    }
                },
                modifier = Modifier.size(40.dp)
            ) {
                Icon(
                    imageVector = if (isSaved) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                    contentDescription = "Save",
                    tint = if (isSaved) DrawRed else Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }
        }
    }
}
