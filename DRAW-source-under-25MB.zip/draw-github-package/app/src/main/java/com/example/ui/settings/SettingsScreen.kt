package com.example.ui.settings

import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.slideInHorizontally
import androidx.compose.animation.slideOutHorizontally
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.asPaddingValues
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBars
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.CleaningServices
import androidx.compose.material.icons.filled.Code
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.DirectionsCar
import androidx.compose.material.icons.filled.LocalTaxi
import androidx.compose.material.icons.filled.Error
import androidx.compose.material.icons.filled.ExpandMore
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Key
import androidx.compose.material.icons.filled.Login
import androidx.compose.material.icons.filled.Logout
import androidx.compose.material.icons.filled.Map
import androidx.compose.material.icons.filled.Navigation
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.Schedule
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.SmartToy
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.runtime.DisposableEffect
import com.example.data.repository.MonetizationRepository
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.example.R
import com.example.data.DrawBrand
import com.example.data.model.LocationVisibilityMode
import com.example.data.model.VehicleLibrary
import com.example.data.network.OpenRouterStatus
import com.example.ui.map.components.TopDownVehicleIcon
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawGreen
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * DRAW Full-Screen Independent Settings Screen.
 *
 * Implements:
 * 1. Distinction between Guest ("ضيف") and Logged-in profile without dummy UIDs.
 * 2. Removed "الأماكن والمفضلة المحفوظة" from the Settings UI (keeping Firebase data intact).
 * 3. In-place expandable Accordion for "حول التطبيق" and "المطور" (Zuelfiqar Sadon, Iraq, centralized SocialLinks).
 * 4. Authorized Admin AI Assistant (OpenRouter) setup section for zuelfiqarsadon9@gmail.com with live verification.
 * 5. Full profile avatar updates, email/password re-auth for password accounts, and provider badges.
 */
@Composable
fun SettingsScreen(
    onBack: () -> Unit,
    onSignOut: () -> Unit,
    onOpenSavedPlaces: () -> Unit = {},
    modifier: Modifier = Modifier,
) {
  val context = LocalContext.current
  val viewModel: SettingsViewModel = viewModel { SettingsViewModel(context) }
  val uiState by viewModel.uiState.collectAsStateWithLifecycle()

  // Handle hardware / system back gesture
  BackHandler {
    if (!viewModel.navigateBack()) {
      onBack()
    }
  }

  val statusBarPadding = WindowInsets.statusBars.asPaddingValues().calculateTopPadding()

  Box(
      modifier = modifier
          .fillMaxSize()
          .background(Color(0xFFF2F2F7))
          .testTag("settings_screen_container"),
  ) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(top = statusBarPadding),
    ) {
      // 1. Top Navigation Bar with Single Back Button
      SettingsTopBar(
          title = when (uiState.currentSubScreen) {
            SettingsSubScreen.MAIN -> "الإعدادات"
            SettingsSubScreen.PROFILE -> "الملف الشخصي"
            SettingsSubScreen.MY_VEHICLE -> "أنا صاحب تاكسي"
            SettingsSubScreen.PREFERENCES -> "تفضيلات الخريطة والملاحة"
            SettingsSubScreen.PRIVACY -> "الخصوصية والأذونات"
            SettingsSubScreen.ABOUT -> "عن تطبيق DRAW"
          },
          onBackClick = {
            if (!viewModel.navigateBack()) {
              onBack()
            }
          },
      )

      // 2. Feedback / Error Notification Pill
      val feedback = uiState.feedbackMessage ?: uiState.errorMessage
      AnimatedVisibility(
          visible = feedback != null,
          modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 20.dp, vertical = 6.dp),
      ) {
        if (feedback != null) {
          val isError = uiState.errorMessage != null
          Surface(
              shape = RoundedCornerShape(14.dp),
              color = if (isError) Color(0xFFD32F2F) else Color(0xFF2E7D32),
              modifier = Modifier
                  .fillMaxWidth()
                  .clickable { viewModel.clearFeedback() },
          ) {
            Text(
                text = feedback,
                color = Color.White,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Medium,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp),
            )
          }
        }
      }

      // 3. Screen Animated Switcher
      AnimatedContent(
          targetState = uiState.currentSubScreen,
          transitionSpec = {
            if (targetState == SettingsSubScreen.MAIN) {
              (slideInHorizontally { -it } + fadeIn()) togetherWith
                  (slideOutHorizontally { it } + fadeOut())
            } else {
              (slideInHorizontally { it } + fadeIn()) togetherWith
                  (slideOutHorizontally { -it } + fadeOut())
            }
          },
          label = "settings_navigation_transition",
          modifier = Modifier.fillMaxSize(),
      ) { subScreen ->
        when (subScreen) {
          SettingsSubScreen.MAIN -> {
            MainSettingsContent(
                uiState = uiState,
                onNavigate = { viewModel.navigateToSubScreen(it) },
                onToggleDefault3D = { viewModel.setDefaultTo3D(it) },
                onToggleVoice = { viewModel.setVoiceGuidance(it) },
                onPromptClearCache = { viewModel.showClearCacheDialog(true) },
                onPromptSignOut = { viewModel.showSignOutDialog(true) },
                onDirectSignIn = onSignOut,
                onVerifyAiKey = { key, model -> viewModel.verifyAndSaveOpenRouterKey(key, model) },
                onDisableAiKey = { viewModel.disableOpenRouterKey() },
            )
          }
          SettingsSubScreen.PROFILE -> {
            ProfileSubScreen(
                uiState = uiState,
                onSaveDisplayName = { viewModel.saveProfileDisplayName(it) },
                onUploadPhoto = { viewModel.uploadProfilePhoto(it) },
                onUpdateEmail = { email, pass -> viewModel.updateEmail(email, pass) },
                onUpdatePassword = { oldPass, newPass -> viewModel.updatePassword(oldPass, newPass) },
            )
          }
          SettingsSubScreen.PREFERENCES -> {
            PreferencesSubScreen(
                uiState = uiState,
                onSetDefaultTo3D = { viewModel.setDefaultTo3D(it) },
                onSetVoiceGuidance = { viewModel.setVoiceGuidance(it) },
                onSetMasterVoice = { viewModel.setMasterVoice(it) },
                onSetAiCompanionVoice = { viewModel.setAiCompanionVoice(it) },
                onSetShow3DBuildings = { viewModel.setShow3DBuildings(it) },
                onSetTransportMode = { viewModel.setTransportMode(it) },
                onSetDistanceUnit = { viewModel.setDistanceUnit(it) },
            )
          }
          SettingsSubScreen.PRIVACY -> {
            PrivacySubScreen(
                uiState = uiState,
                onRefreshPermissions = { viewModel.checkPermissions() },
            )
          }
          SettingsSubScreen.MY_VEHICLE -> {
            MyVehicleSubScreen(
                currentProfile = uiState.userVehicleProfile,
                isSaving = uiState.isSavingVehicle,
                onSaveProfile = { viewModel.saveUserVehicleProfile(it) },
            )
          }
          SettingsSubScreen.ABOUT -> {
            AboutSubScreen()
          }
        }
      }
    }

    // 4. Sign Out Confirmation Dialog
    if (uiState.isSignOutDialogVisible) {
      AlertDialog(
          onDismissRequest = { viewModel.showSignOutDialog(false) },
          title = {
            Text(
                text = "تسجيل الخروج",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
            )
          },
          text = {
            Text(
                text = "هل أنت متأكد من رغبتك في تسجيل الخروج من حساب DRAW؟ ستبقى بياناتك وأماكنك محفوظة في السحابة.",
                fontSize = 14.sp,
                color = DrawTextSecondary,
                lineHeight = 20.sp,
            )
          },
          confirmButton = {
            Button(
                onClick = {
                  viewModel.showSignOutDialog(false)
                  onSignOut()
                },
                colors = ButtonDefaults.buttonColors(containerColor = DrawRed, contentColor = Color.White),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("confirm_sign_out_button"),
            ) {
              Text("نعم، تسجيل الخروج", color = Color.White, fontWeight = FontWeight.Bold)
            }
          },
          dismissButton = {
            TextButton(
                onClick = { viewModel.showSignOutDialog(false) },
            ) {
              Text("إلغاء", color = DrawTextNearBlack)
            }
          },
          shape = RoundedCornerShape(20.dp),
      )
    }

    // 5. Clear Cache Confirmation Dialog
    if (uiState.isClearCacheDialogVisible) {
      AlertDialog(
          onDismissRequest = { viewModel.showClearCacheDialog(false) },
          title = {
            Text(
                text = "مسح الذاكرة المؤقتة للخريطة",
                fontWeight = FontWeight.Bold,
                fontSize = 17.sp,
            )
          },
          text = {
            Text(
                text = "سيتم تفريغ بلاطات الخرائط المؤقتة والبيانات المخزنة محلياً لتحديث العرض وتوفير المساحة. هل ترغب بالمتابعة؟",
                fontSize = 14.sp,
                color = DrawTextSecondary,
                lineHeight = 20.sp,
            )
          },
          confirmButton = {
            Button(
                onClick = { viewModel.clearMapCache() },
                colors = ButtonDefaults.buttonColors(
                    containerColor = DrawRed,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier.testTag("confirm_clear_cache_button"),
            ) {
              Text("مسح", fontWeight = FontWeight.Bold, color = Color.White)
            }
          },
          dismissButton = {
            Button(
                onClick = { viewModel.showClearCacheDialog(false) },
                colors = ButtonDefaults.buttonColors(
                    containerColor = Color.Black,
                    contentColor = Color.White
                ),
                shape = RoundedCornerShape(12.dp),
            ) {
              Text("إلغاء", fontWeight = FontWeight.Bold, color = Color.White)
            }
          },
          shape = RoundedCornerShape(20.dp),
      )
    }
  }
}

/**
 * Clean Top Bar featuring single back button and screen title.
 */
@Composable
private fun SettingsTopBar(
    title: String,
    onBackClick: () -> Unit,
) {
  Surface(
      color = Color.White,
      shadowElevation = 2.dp,
      modifier = Modifier.fillMaxWidth(),
  ) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .height(56.dp)
            .padding(horizontal = 12.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
      IconButton(
          onClick = onBackClick,
          modifier = Modifier
              .size(42.dp)
              .testTag("settings_back_button"),
      ) {
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "رجوع",
            tint = DrawTextNearBlack,
            modifier = Modifier.size(24.dp),
        )
      }

      Spacer(modifier = Modifier.width(8.dp))

      Text(
          text = title,
          fontSize = 18.sp,
          fontWeight = FontWeight.Bold,
          color = DrawTextNearBlack,
          modifier = Modifier.weight(1f),
      )
    }
  }
}

/**
 * Main Settings overview with structured iOS grouped cards.
 */
@Composable
private fun MainSettingsContent(
    uiState: SettingsUiState,
    onNavigate: (SettingsSubScreen) -> Unit,
    onToggleDefault3D: (Boolean) -> Unit,
    onToggleVoice: (Boolean) -> Unit,
    onPromptClearCache: () -> Unit,
    onPromptSignOut: () -> Unit,
    onDirectSignIn: () -> Unit,
    onVerifyAiKey: (String, String) -> Unit,
    onDisableAiKey: () -> Unit,
) {
  val cardShape = RoundedCornerShape(20.dp)

  Column(
      modifier = Modifier
          .fillMaxSize()
          .verticalScroll(rememberScrollState())
          .padding(horizontal = 16.dp, vertical = 16.dp),
      verticalArrangement = Arrangement.spacedBy(16.dp),
  ) {
    // 1. Account Section Card (Guest vs. Logged-in Profile)
    if (uiState.isGuest) {
      // Guest User Card: shows "ضيف", not clickable to edit profile, no dummy UID
      Surface(
          modifier = Modifier
              .fillMaxWidth()
              .shadow(2.dp, cardShape, spotColor = Color(0x14000000))
              .border(0.8.dp, Color(0x12000000), cardShape)
              .testTag("settings_account_row_guest"),
          shape = cardShape,
          color = Color.White,
      ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
          Box(
              modifier = Modifier
                  .size(54.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFEBEBEF)),
              contentAlignment = Alignment.Center,
          ) {
            Icon(
                imageVector = Icons.Default.AccountCircle,
                contentDescription = null,
                tint = Color(0xFF8E8E93),
                modifier = Modifier.size(34.dp),
            )
          }

          Spacer(modifier = Modifier.width(14.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "ضيف",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = "تصفح الخريطة دون حساب",
                fontSize = 13.sp,
                color = DrawTextSecondary,
            )
          }

          // Sign In Action Button
          Button(
              onClick = onDirectSignIn,
              colors = ButtonDefaults.buttonColors(
                  containerColor = DrawRed,
                  contentColor = Color.White
              ),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier.testTag("guest_sign_in_button"),
          ) {
            Text(
                text = "تسجيل الدخول",
                color = Color.White,
                fontSize = 12.5.sp,
                fontWeight = FontWeight.Bold,
            )
          }
        }
      }
    } else {
      // Logged-in User Card
      val displayName = uiState.userProfile?.displayName
          ?: uiState.firebaseUser?.displayName
          ?: uiState.firebaseUser?.email?.substringBefore("@")
          ?: "مستخدم DRAW"

      val avatarUrl = DrawBrand.AVATAR_URI

      Surface(
          modifier = Modifier
              .fillMaxWidth()
              .shadow(2.dp, cardShape, spotColor = Color(0x14000000))
              .border(0.8.dp, Color(0x12000000), cardShape)
              .clickable { onNavigate(SettingsSubScreen.PROFILE) }
              .testTag("settings_account_row"),
          shape = cardShape,
          color = Color.White,
      ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
          // Avatar circle
          Box(
              modifier = Modifier
                  .size(54.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFFECEB)),
              contentAlignment = Alignment.Center,
          ) {
            if (!avatarUrl.isNullOrBlank()) {
              AsyncImage(
                  model = avatarUrl,
                  contentDescription = "الصورة الشخصية",
                  contentScale = ContentScale.Crop,
                  modifier = Modifier.fillMaxSize(),
              )
            } else {
              val firstLetter = displayName.firstOrNull()?.uppercaseChar()?.toString()
              if (!firstLetter.isNullOrBlank()) {
                Text(
                    text = firstLetter,
                    fontSize = 22.sp,
                    fontWeight = FontWeight.Bold,
                    color = DrawRed,
                )
              } else {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = DrawRed,
                    modifier = Modifier.size(32.dp),
                )
              }
            }
          }

          Spacer(modifier = Modifier.width(14.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = displayName,
                fontSize = 16.5.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = uiState.firebaseUser?.email ?: "",
                fontSize = 13.sp,
                color = DrawTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
          }

          Icon(
              imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
              contentDescription = null,
              tint = Color(0xFFC7C7CC),
              modifier = Modifier.size(16.dp),
          )
        }
      }
    }

    // 2. Navigation & Map Settings Group
    SettingsGroupCard(title = "الخريطة والملاحة") {
      Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
      ) {
        Icon(
            imageVector = Icons.Default.Map,
            contentDescription = null,
            tint = DrawRed,
            modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
              text = "العرض الافتراضي للخريطة",
              fontSize = 14.5.sp,
              fontWeight = FontWeight.SemiBold,
              color = DrawTextNearBlack,
          )
          Text(
              text = if (uiState.defaultTo3D) "ثلاثي الأبعاد (3D)" else "ثنائي الأبعاد (2D)",
              fontSize = 12.sp,
              color = DrawTextSecondary,
          )
        }
        Switch(
            checked = uiState.defaultTo3D,
            onCheckedChange = onToggleDefault3D,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = DrawRed,
            ),
            modifier = Modifier.testTag("settings_toggle_3d"),
        )
      }

      HorizontalDivider(color = Color(0x14000000), thickness = 0.8.dp)

      Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 16.dp, vertical = 12.dp),
      ) {
        Icon(
            imageVector = Icons.Default.VolumeUp,
            contentDescription = null,
            tint = DrawRed,
            modifier = Modifier.size(22.dp),
        )
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Text(
              text = "الصوت الأساسي للملاحة",
              fontSize = 14.5.sp,
              fontWeight = FontWeight.SemiBold,
              color = DrawTextNearBlack,
          )
          Text(
              text = if (uiState.voiceGuidance && uiState.masterVoiceEnabled) "مفعّل (التنبيهات المهمة فقط)" else "صامت تماماً (يتوقف كل صوت)",
              fontSize = 12.sp,
              color = DrawTextSecondary,
          )
        }
        Switch(
            checked = uiState.voiceGuidance,
            onCheckedChange = onToggleVoice,
            colors = SwitchDefaults.colors(
                checkedThumbColor = Color.White,
                checkedTrackColor = DrawRed,
            ),
            modifier = Modifier.testTag("settings_toggle_voice"),
        )
      }

      HorizontalDivider(color = Color(0x14000000), thickness = 0.8.dp)

      SettingsRowLink(
          icon = Icons.Default.Navigation,
          title = "تفضيلات المسارات والنقل",
          subtitle = "وسيلة النقل، وحدات القياس، والمباني 3D",
          testTag = "settings_preferences_row",
          onClick = { onNavigate(SettingsSubScreen.PREFERENCES) },
      )

      HorizontalDivider(color = Color(0x14000000), thickness = 0.8.dp)

      val vehicleProfile = uiState.userVehicleProfile
      val isTaxi = vehicleProfile?.isTaxiOwner == true
      val vehicleSubtitle = if (isTaxi) {
        "التاكسي نشط على الخريطة • ${vehicleProfile.effectiveFarePerKmFormatted}"
      } else {
        "متوقف (اضغط لفتح إعدادات التاكسي والتفعيل)"
      }

      Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
              .fillMaxWidth()
              .clickable { onNavigate(SettingsSubScreen.MY_VEHICLE) }
              .padding(horizontal = 16.dp, vertical = 12.dp)
              .testTag("settings_my_vehicle_row"),
      ) {
        if (vehicleProfile != null && isTaxi) {
          TopDownVehicleIcon(
              modelId = "taxi_city",
              size = 32.dp,
              customColorHex = vehicleProfile.taxiColorHex
          )
        } else {
          Box(
              modifier = Modifier
                  .size(34.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFFEF3C7)),
              contentAlignment = Alignment.Center
          ) {
            Icon(
                imageVector = Icons.Default.LocalTaxi,
                contentDescription = null,
                tint = Color(0xFFD97706),
                modifier = Modifier.size(20.dp),
            )
          }
        }
        Spacer(modifier = Modifier.width(12.dp))
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
                text = "أنا صاحب تاكسي",
                fontSize = 14.5.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack,
            )
            if (isTaxi) {
              Spacer(modifier = Modifier.width(6.dp))
              Box(
                  modifier = Modifier
                      .size(7.dp)
                      .clip(CircleShape)
                      .background(DrawGreen)
              )
            }
          }
          Text(
              text = vehicleSubtitle,
              fontSize = 12.sp,
              color = if (isTaxi) DrawGreen else DrawTextSecondary,
              maxLines = 1,
              overflow = TextOverflow.Ellipsis,
          )
        }
        Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
            contentDescription = null,
            tint = Color(0xFFC7C7CC),
            modifier = Modifier.size(16.dp),
        )
      }
    }

    // 3. Data & Storage Group (Saved places link removed from UI as requested)
    SettingsGroupCard(title = "البيانات والتخزين") {
      SettingsRowLink(
          icon = Icons.Default.CleaningServices,
          title = "مسح الذاكرة المؤقتة للخريطة",
          subtitle = "تفريغ بلاطات OpenFreeMap المؤقتة",
          testTag = "settings_clear_cache_row",
          onClick = onPromptClearCache,
      )
    }

    // 4. Privacy & Permissions Group
    SettingsGroupCard(title = "الخصوصية والأمان") {
      SettingsRowLink(
          icon = Icons.Default.Security,
          title = "الأذونات وحماية البيانات",
          subtitle = "حالة الموقع الجغرافي، الميكروفون، والشبكة",
          testTag = "settings_privacy_row",
          onClick = { onNavigate(SettingsSubScreen.PRIVACY) },
      )
    }

    // 5. Admin AI Assistant Configuration (Visible ONLY for zuelfiqarsadon9@gmail.com)
    if (uiState.isAdmin) {
      AdminAiAssistantSection(
          uiState = uiState,
          onVerifyKey = onVerifyAiKey,
          onDisableKey = onDisableAiKey,
      )
    }

    // Clean Developer & Version row
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 8.dp)
            .testTag("settings_developer_version_row"),
        horizontalArrangement = Arrangement.Center,
        verticalAlignment = Alignment.CenterVertically
    ) {
      Text(
          text = "المطور: ذوالفقار سعدون",
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium,
          color = DrawTextSecondary
      )
      Text(
          text = "  •  ",
          fontSize = 13.sp,
          color = DrawTextSecondary
      )
      Text(
          text = "الإصدار: ${com.example.BuildConfig.VERSION_NAME}",
          fontSize = 13.sp,
          fontWeight = FontWeight.Medium,
          color = DrawTextSecondary
      )
    }

    // 7. Sign Out Button (Prominent red button with white text and confirmation dialog)
    if (!uiState.isGuest) {
      Surface(
          modifier = Modifier
              .fillMaxWidth()
              .shadow(4.dp, cardShape, spotColor = Color(0x33D32F2F))
              .clickable(onClick = onPromptSignOut)
              .testTag("settings_sign_out_button"),
          shape = cardShape,
          color = DrawRed,
      ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp, vertical = 14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.Center,
        ) {
          Icon(
              imageVector = Icons.Default.Logout,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
              text = "تسجيل الخروج",
              color = Color.White,
              fontSize = 15.sp,
              fontWeight = FontWeight.Bold,
          )
        }
      }
    }

    // 8. Bottom AdMob Banner for Settings ONLY (20s active / 5s pause cycle, 100% silent, stops on leaving Settings)
    AdMobSettingsBottomBanner()

    Spacer(modifier = Modifier.height(20.dp))
  }
}

/**
 * Dedicated AdMob Banner situated strictly at the bottom of the Settings Screen.
 * Conforms to:
 * 1. 20 seconds active ad display, followed by 5 seconds complete pause without ad.
 * 2. 100% silent audio (all ads and videos auto-muted, zero sound playback).
 * 3. Cycle runs only while inside the Settings screen and stops immediately when leaving Settings.
 * 4. Distinct independent cycle from the map billboards.
 */
@Composable
private fun AdMobSettingsBottomBanner(
    modifier: Modifier = Modifier
) {
  val context = LocalContext.current
  val repo = remember { MonetizationRepository.getInstance(context) }
  val currentAd by repo.settingsBannerFlow.collectAsStateWithLifecycle()
  val isCooldown by repo.isSettingsBannerCooldownFlow.collectAsStateWithLifecycle()
  val isAdConfigured by repo.isAdMobConfiguredFlow.collectAsStateWithLifecycle()

  // Lifecycle control: strictly starts when entering Settings, stops when leaving Settings
  DisposableEffect(Unit) {
    repo.startSettingsBannerCycle()
    onDispose {
      repo.stopSettingsBannerCycle()
    }
  }

  // If AdMob is not configured or no ad is ready, completely hide the banner as requested
  if (!isAdConfigured || currentAd == null) {
    return
  }

  val bannerShape = RoundedCornerShape(16.dp)

  Surface(
      shape = bannerShape,
      color = Color.White,
      shadowElevation = 2.dp,
      border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x1F000000)),
      modifier = modifier
          .fillMaxWidth()
          .testTag("settings_admob_banner_container")
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
      // Top Ad Header: AdMob badge + Muted Audio indicator
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
          Surface(
              shape = RoundedCornerShape(6.dp),
              color = Color(0xFFF1F5F9),
              border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0xFFCBD5E1))
          ) {
            Text(
                text = "AdMob إعلان",
                fontSize = 10.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF475569),
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
            )
          }

          Text(
              text = "إعلان تجاري",
              fontSize = 11.5.sp,
              fontWeight = FontWeight.SemiBold,
              color = DrawTextSecondary
          )
        }

        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          Icon(
              imageVector = Icons.Default.VolumeOff,
              contentDescription = "صامت",
              tint = Color(0xFF94A3B8),
              modifier = Modifier.size(14.dp)
          )
          Text(
              text = "صامت تماماً",
              fontSize = 10.5.sp,
              color = Color(0xFF94A3B8)
          )
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      if (!isCooldown && currentAd != null) {
        val ad = currentAd!!
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { repo.recordSettingsBannerClick() }
                .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
          Box(
              modifier = Modifier
                  .size(46.dp)
                  .clip(RoundedCornerShape(10.dp))
                  .background(Color(0xFFFFECEB)),
              contentAlignment = Alignment.Center
          ) {
            Icon(
                imageVector = Icons.Default.Campaign,
                contentDescription = null,
                tint = DrawRed,
                modifier = Modifier.size(26.dp)
            )
          }

          Spacer(modifier = Modifier.width(12.dp))

          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = ad.headline,
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = ad.description,
                fontSize = 11.5.sp,
                color = DrawTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = "بواسطة ${ad.advertiserName}",
                fontSize = 10.sp,
                color = DrawRed
            )
          }

          Spacer(modifier = Modifier.width(8.dp))

          Surface(
              shape = RoundedCornerShape(10.dp),
              color = DrawRed,
              modifier = Modifier.clickable { repo.recordSettingsBannerClick() }
          ) {
            Text(
                text = ad.callToAction,
                fontSize = 11.5.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
            )
          }
        }
      } else {
        // 5-second complete cooldown state
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 12.dp),
            horizontalArrangement = Arrangement.Center,
            verticalAlignment = Alignment.CenterVertically
        ) {
          Text(
              text = "فترة هدوء 5 ثوانٍ • جاري تجهيز إعلان AdMob التالي...",
              fontSize = 11.5.sp,
              color = Color(0xFF94A3B8)
          )
        }
      }
    }
  }
}

/**
 * Authorized Admin Section: Configure OpenRouter AI with real key verification and status badge.
 */
@Composable
private fun AdminAiAssistantSection(
    uiState: SettingsUiState,
    onVerifyKey: (String, String) -> Unit,
    onDisableKey: () -> Unit,
) {
  val shape = RoundedCornerShape(20.dp)
  var keyInput by remember(uiState.openRouterConfig.apiKey) {
    mutableStateOf(uiState.openRouterConfig.apiKey)
  }
  var selectedModel by remember(uiState.openRouterConfig.model) {
    mutableStateOf(uiState.openRouterConfig.model)
  }

  Column {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier.padding(start = 12.dp, bottom = 6.dp),
    ) {
      Text(
          text = "إعداد المساعد الذكي (OpenRouter)",
          fontSize = 13.sp,
          fontWeight = FontWeight.SemiBold,
          color = DrawTextSecondary,
      )
      Spacer(modifier = Modifier.width(8.dp))
      Surface(
          shape = RoundedCornerShape(6.dp),
          color = Color(0xFFFFECEB),
      ) {
        Text(
            text = "خاص بالمشرف",
            color = DrawRed,
            fontSize = 10.5.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
        )
      }
    }

    Surface(
        shape = shape,
        color = Color.White,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, shape, spotColor = Color(0x14000000))
            .border(0.8.dp, Color(0x12000000), shape)
            .testTag("admin_ai_section"),
    ) {
      Column(modifier = Modifier.padding(16.dp)) {
        // Status Row
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.fillMaxWidth(),
        ) {
          Icon(
              imageVector = Icons.Default.SmartToy,
              contentDescription = null,
              tint = DrawRed,
              modifier = Modifier.size(22.dp),
          )
          Spacer(modifier = Modifier.width(10.dp))
          Text(
              text = "حالة الاتصال",
              fontSize = 14.5.sp,
              fontWeight = FontWeight.SemiBold,
              color = DrawTextNearBlack,
              modifier = Modifier.weight(1f),
          )

          // Status Badge Pill
          val statusColor = when (uiState.openRouterConfig.status) {
            OpenRouterStatus.CONNECTED -> Color(0xFF2E7D32)
            OpenRouterStatus.CHECKING -> Color(0xFFED6C02)
            OpenRouterStatus.FAILED -> Color(0xFFD32F2F)
            OpenRouterStatus.NOT_CONFIGURED -> Color(0xFF757575)
          }
          val statusText = when (uiState.openRouterConfig.status) {
            OpenRouterStatus.CONNECTED -> "متصل بنجاح"
            OpenRouterStatus.CHECKING -> "جاري التحقق..."
            OpenRouterStatus.FAILED -> "فشل التحقق"
            OpenRouterStatus.NOT_CONFIGURED -> "غير مهيأ"
          }

          Surface(
              shape = RoundedCornerShape(12.dp),
              color = statusColor.copy(alpha = 0.12f),
          ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
            ) {
              Box(
                  modifier = Modifier
                      .size(8.dp)
                      .clip(CircleShape)
                      .background(statusColor)
              )
              Spacer(modifier = Modifier.width(6.dp))
              Text(
                  text = statusText,
                  color = statusColor,
                  fontSize = 12.sp,
                  fontWeight = FontWeight.Bold,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        // Masked key display if connected
        if (uiState.openRouterConfig.isConfigured) {
          Surface(
              shape = RoundedCornerShape(10.dp),
              color = Color(0xFFF7F7F9),
              modifier = Modifier.fillMaxWidth(),
          ) {
            Row(
                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                  imageVector = Icons.Default.Key,
                  contentDescription = null,
                  tint = DrawTextSecondary,
                  modifier = Modifier.size(16.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                  text = "المفتاح النشط: ${uiState.openRouterConfig.maskedKey}",
                  fontSize = 12.5.sp,
                  color = DrawTextNearBlack,
                  fontWeight = FontWeight.Medium,
                  modifier = Modifier.weight(1f),
              )
            }
          }
          Spacer(modifier = Modifier.height(12.dp))
        }

        // Key Input Field
        OutlinedTextField(
            value = keyInput,
            onValueChange = { keyInput = it },
            label = { Text("مفتاح API لـ OpenRouter") },
            placeholder = { Text("sk-or-v1-...") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("openrouter_key_input"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = DrawRed,
                unfocusedBorderColor = Color(0x22000000),
            ),
        )

        Spacer(modifier = Modifier.height(8.dp))

        // Model Input Field
        OutlinedTextField(
            value = selectedModel,
            onValueChange = { selectedModel = it },
            label = { Text("النموذج الذكي (Model)") },
            placeholder = { Text("google/gemini-2.5-flash") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth()
                .testTag("openrouter_model_input"),
            shape = RoundedCornerShape(12.dp),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = DrawRed,
                unfocusedBorderColor = Color(0x22000000),
            ),
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Buttons
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
          Button(
              onClick = { onVerifyKey(keyInput, selectedModel) },
              enabled = !uiState.isVerifyingKey && keyInput.isNotBlank(),
              colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
              shape = RoundedCornerShape(12.dp),
              modifier = Modifier
                  .weight(1f)
                  .testTag("openrouter_verify_button"),
          ) {
            if (uiState.isVerifyingKey) {
              CircularProgressIndicator(
                  color = Color.White,
                  modifier = Modifier.size(18.dp),
                  strokeWidth = 2.dp,
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text("جاري الفحص...")
            } else {
              Text("تحقق وحفظ المفتاح", fontWeight = FontWeight.Bold)
            }
          }

          if (uiState.openRouterConfig.isConfigured) {
            OutlinedButton(
                onClick = onDisableKey,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFD32F2F)),
                modifier = Modifier.testTag("openrouter_disable_button"),
            ) {
              Icon(imageVector = Icons.Default.Delete, contentDescription = null, modifier = Modifier.size(16.dp))
              Spacer(modifier = Modifier.width(4.dp))
              Text("تعطيل")
            }
          }
        }
      }
    }
  }
}



@Composable
private fun SettingsGroupCard(
    title: String,
    content: @Composable () -> Unit,
) {
  val shape = RoundedCornerShape(20.dp)
  Column {
    Text(
        text = title,
        fontSize = 13.sp,
        fontWeight = FontWeight.SemiBold,
        color = DrawTextSecondary,
        modifier = Modifier.padding(start = 12.dp, bottom = 6.dp),
    )
    Surface(
        shape = shape,
        color = Color.White,
        modifier = Modifier
            .fillMaxWidth()
            .shadow(2.dp, shape, spotColor = Color(0x14000000))
            .border(0.8.dp, Color(0x12000000), shape),
    ) {
      Column {
        content()
      }
    }
  }
}

@Composable
private fun SettingsRowLink(
    icon: ImageVector,
    title: String,
    subtitle: String,
    testTag: String,
    onClick: () -> Unit,
) {
  Row(
      verticalAlignment = Alignment.CenterVertically,
      modifier = Modifier
          .fillMaxWidth()
          .clickable(onClick = onClick)
          .padding(horizontal = 16.dp, vertical = 12.dp)
          .testTag(testTag),
  ) {
    Icon(
        imageVector = icon,
        contentDescription = null,
        tint = DrawRed,
        modifier = Modifier.size(22.dp),
    )
    Spacer(modifier = Modifier.width(12.dp))
    Column(modifier = Modifier.weight(1f)) {
      Text(
          text = title,
          fontSize = 14.5.sp,
          fontWeight = FontWeight.SemiBold,
          color = DrawTextNearBlack,
      )
      Text(
          text = subtitle,
          fontSize = 12.sp,
          color = DrawTextSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis,
      )
    }
    Icon(
        imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
        contentDescription = null,
        tint = Color(0xFFC7C7CC),
        modifier = Modifier.size(16.dp),
    )
  }
}
