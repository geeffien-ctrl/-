package com.example.ui.map.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.tween
import androidx.compose.animation.expandVertically
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.shrinkVertically
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.heightIn
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.launch
import com.example.data.model.NominatimResult
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

/**
 * iOS-styled floating search bar with search results dropdown.
 */
@Composable
fun MapSearchBar(
    query: String,
    onQueryChange: (String) -> Unit,
    searchResults: List<NominatimResult>,
    isSearching: Boolean,
    onPlaceSelected: (NominatimResult) -> Unit,
    onVoiceClick: () -> Unit,
    onProfileClick: () -> Unit,
    onRefreshClick: () -> Unit,
    isRefreshing: Boolean = false,
    modifier: Modifier = Modifier
) {
  val focusManager = LocalFocusManager.current
  val refreshRotation = remember { Animatable(0f) }
  val refreshScope = rememberCoroutineScope()
  val barShape = RoundedCornerShape(22.dp)

  Column(
      modifier = modifier.fillMaxWidth()
  ) {
    // Floating iOS search capsule
    Surface(
        modifier = Modifier
            .fillMaxWidth()
            .height(52.dp)
            .shadow(elevation = 8.dp, shape = barShape, spotColor = Color(0x2E000000))
            .border(width = 0.8.dp, color = Color(0x18000000), shape = barShape)
            .testTag("search_bar_surface"),
        shape = barShape,
        color = Color(0xFAFFFFFF)
    ) {
      Row(
          modifier = Modifier
              .fillMaxWidth()
              .padding(horizontal = 14.dp),
          verticalAlignment = Alignment.CenterVertically
      ) {
        // Leading Search Icon
        Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search",
            tint = Color(0xFF8E8E93),
            modifier = Modifier.size(20.dp)
        )

        Spacer(modifier = Modifier.width(10.dp))

        // Search Text Input
        Box(
            modifier = Modifier
                .weight(1f),
            contentAlignment = Alignment.CenterStart
        ) {
          if (query.isEmpty()) {
            Text(
                text = "ابحث عن مكان، معلم، أو شارع...",
                color = Color(0xFF8E8E93),
                fontSize = 14.5.sp,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
          }

          BasicTextField(
              value = query,
              onValueChange = onQueryChange,
              singleLine = true,
              textStyle = TextStyle(
                  color = DrawTextNearBlack,
                  fontSize = 15.sp,
                  fontWeight = FontWeight.Normal
              ),
              keyboardOptions = KeyboardOptions(imeAction = ImeAction.Search),
              keyboardActions = KeyboardActions(onSearch = { focusManager.clearFocus() }),
              modifier = Modifier
                  .fillMaxWidth()
                  .testTag("search_text_input")
          )
        }

        // Searching loader or Clear button
        if (isSearching) {
          CircularProgressIndicator(
              modifier = Modifier.size(18.dp),
              strokeWidth = 2.dp,
              color = DrawRed
          )
          Spacer(modifier = Modifier.width(6.dp))
        } else if (query.isNotEmpty()) {
          IconButton(
              onClick = {
                onQueryChange("")
                focusManager.clearFocus()
              },
              modifier = Modifier.size(28.dp)
          ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "Clear search",
                tint = Color(0xFF8E8E93),
                modifier = Modifier.size(16.dp)
            )
          }
        }

        // Voice Search Action
        IconButton(
            onClick = onVoiceClick,
            modifier = Modifier
                .size(32.dp)
                .testTag("search_voice_button")
        ) {
          Icon(
              imageVector = Icons.Default.Mic,
              contentDescription = "Voice Search",
              tint = DrawRed,
              modifier = Modifier.size(20.dp)
          )
        }

        IconButton(
            onClick = {
              onRefreshClick()
              refreshScope.launch {
                refreshRotation.stop()
                refreshRotation.animateTo(refreshRotation.value + 720f, tween(durationMillis = 1000))
              }
            },
            modifier = Modifier.size(32.dp).testTag("search_refresh_button")
        ) {
          Icon(Icons.Default.Refresh, contentDescription = "تحديث البيانات", tint = DrawRed,
              modifier = Modifier.size(20.dp).rotate(refreshRotation.value))
        }

        // Settings / Menu Action
        IconButton(
            onClick = onProfileClick,
            modifier = Modifier
                .size(32.dp)
                .testTag("search_settings_button")
        ) {
          Icon(
              imageVector = Icons.Default.Settings,
              contentDescription = "الإعدادات",
              tint = Color(0xFF3C3C43),
              modifier = Modifier.size(22.dp)
          )
        }
      }
    }

    // Search Results Dropdown Overlay
    AnimatedVisibility(
        visible = searchResults.isNotEmpty(),
        enter = fadeIn() + expandVertically(),
        exit = fadeOut() + shrinkVertically()
    ) {
      val dropdownShape = RoundedCornerShape(18.dp)
      Surface(
          modifier = Modifier
              .fillMaxWidth()
              .padding(top = 8.dp)
              .shadow(elevation = 12.dp, shape = dropdownShape, spotColor = Color(0x33000000))
              .border(width = 0.8.dp, color = Color(0x18000000), shape = dropdownShape)
              .testTag("search_results_container"),
          shape = dropdownShape,
          color = Color(0xFDFDFDFF)
      ) {
        LazyColumn(
            modifier = Modifier
                .fillMaxWidth()
                .heightIn(max = 260.dp)
        ) {
          items(searchResults) { result ->
            SearchResultRow(
                result = result,
                onClick = {
                  focusManager.clearFocus()
                  onPlaceSelected(result)
                }
            )
            HorizontalDivider(
                color = Color(0x0F000000),
                thickness = 0.5.dp,
                modifier = Modifier.padding(horizontal = 14.dp)
            )
          }
        }
      }
    }
  }
}

@Composable
private fun SearchResultRow(
    result: NominatimResult,
    onClick: () -> Unit
) {
  Row(
      modifier = Modifier
          .fillMaxWidth()
          .clickable(onClick = onClick)
          .padding(horizontal = 14.dp, vertical = 11.dp)
          .testTag("search_result_item_${result.shortTitle}"),
      verticalAlignment = Alignment.CenterVertically
  ) {
    Box(
        modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Color(0xFFF2F2F7)),
        contentAlignment = Alignment.Center
    ) {
      Icon(
          imageVector = Icons.Default.Place,
          contentDescription = null,
          tint = DrawRed,
          modifier = Modifier.size(18.dp)
      )
    }

    Spacer(modifier = Modifier.width(12.dp))

    Column(modifier = Modifier.weight(1f)) {
      Text(
          text = result.shortTitle,
          fontWeight = FontWeight.SemiBold,
          fontSize = 14.sp,
          color = DrawTextNearBlack,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
      )
      Spacer(modifier = Modifier.height(2.dp))
      Text(
          text = result.displayName,
          fontWeight = FontWeight.Normal,
          fontSize = 12.sp,
          color = DrawTextSecondary,
          maxLines = 1,
          overflow = TextOverflow.Ellipsis
      )
    }
  }
}
