package com.example.ui.map.components

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountBalance
import androidx.compose.material.icons.filled.Attractions
import androidx.compose.material.icons.filled.AutoStories
import androidx.compose.material.icons.filled.BakeryDining
import androidx.compose.material.icons.filled.BeachAccess
import androidx.compose.material.icons.filled.Biotech
import androidx.compose.material.icons.filled.CarRental
import androidx.compose.material.icons.filled.CarRepair
import androidx.compose.material.icons.filled.CardGiftcard
import androidx.compose.material.icons.filled.Checkroom
import androidx.compose.material.icons.filled.ChildCare
import androidx.compose.material.icons.filled.ContentCut
import androidx.compose.material.icons.filled.Devices
import androidx.compose.material.icons.filled.DinnerDining
import androidx.compose.material.icons.filled.DirectionsBus
import androidx.compose.material.icons.filled.DirectionsSubway
import androidx.compose.material.icons.filled.Emergency
import androidx.compose.material.icons.filled.EvStation
import androidx.compose.material.icons.filled.Fastfood
import androidx.compose.material.icons.filled.FitnessCenter
import androidx.compose.material.icons.filled.Flight
import androidx.compose.material.icons.filled.Gavel
import androidx.compose.material.icons.filled.HealthAndSafety
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Hotel
import androidx.compose.material.icons.filled.Icecream
import androidx.compose.material.icons.filled.Landscape
import androidx.compose.material.icons.filled.LocalAtm
import androidx.compose.material.icons.filled.LocalBar
import androidx.compose.material.icons.filled.LocalCafe
import androidx.compose.material.icons.filled.LocalFireDepartment
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.material.icons.filled.LocalGroceryStore
import androidx.compose.material.icons.filled.LocalHospital
import androidx.compose.material.icons.filled.LocalLaundryService
import androidx.compose.material.icons.filled.LocalMall
import androidx.compose.material.icons.filled.LocalParking
import androidx.compose.material.icons.filled.LocalPharmacy
import androidx.compose.material.icons.filled.LocalPizza
import androidx.compose.material.icons.filled.LocalPolice
import androidx.compose.material.icons.filled.LocalPostOffice
import androidx.compose.material.icons.filled.MedicalServices
import androidx.compose.material.icons.filled.MenuBook
import androidx.compose.material.icons.filled.Mosque
import androidx.compose.material.icons.filled.Movie
import androidx.compose.material.icons.filled.Museum
import androidx.compose.material.icons.filled.Park
import androidx.compose.material.icons.filled.Place
import androidx.compose.material.icons.filled.Pool
import androidx.compose.material.icons.filled.Psychology
import androidx.compose.material.icons.filled.Restaurant
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.SportsSoccer
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TheaterComedy
import androidx.compose.material.icons.filled.Tour
import androidx.compose.material.icons.filled.Villa
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.Work
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector

/**
 * Model representing a single place icon with iOS circular styling and consistent category metadata.
 */
data class PlaceIconItem(
    val id: String,
    val nameArabic: String,
    val categoryKey: String,
    val categoryArabic: String,
    val iconVector: ImageVector,
    val primaryColor: Color,
    val softBgColor: Color,
    val osmKeyword: String = ""
)

data class PlaceCategoryItem(
    val key: String,
    val nameArabic: String,
    val color: Color
)

object PlaceIconRegistry {

  // Distinct category palette inspired by iOS system colors
  val COLOR_PERSONAL = Color(0xFF5B7F95)       // Slate Calm Blue
  val BG_PERSONAL = Color(0xFFEAF1F6)

  val COLOR_FOOD = Color(0xFFFF9500)           // Warm Orange
  val BG_FOOD = Color(0xFFFFF4E5)

  val COLOR_SHOPPING = Color(0xFF30B0C7)       // Ocean Teal
  val BG_SHOPPING = Color(0xFFE5F7FA)

  val COLOR_HEALTH = Color(0xFFFF2D55)         // Crimson Rose
  val BG_HEALTH = Color(0xFFFFE8EC)

  val COLOR_TRANSPORT = Color(0xFF007AFF)      // Navigation Blue
  val BG_TRANSPORT = Color(0xFFE5F1FF)

  val COLOR_RECREATION = Color(0xFF34C759)     // Emerald Green
  val BG_RECREATION = Color(0xFFE8F9EE)

  val COLOR_SERVICES = Color(0xFF5856D6)       // Indigo Violet
  val BG_SERVICES = Color(0xFFEEEEFC)

  val COLOR_EDUCATION = Color(0xFFA2845E)      // Deep Amber / Bronze
  val BG_EDUCATION = Color(0xFFF7F3EE)

  val COLOR_TOURS_WORSHIP = Color(0xFFFF9F0A)  // Golden Ochre
  val BG_TOURS_WORSHIP = Color(0xFFFFF7EA)

  val categories: List<PlaceCategoryItem> = listOf(
      PlaceCategoryItem("all", "الكل", Color(0xFF8E8E93)),
      PlaceCategoryItem("personal", "الأماكن الشخصية", COLOR_PERSONAL),
      PlaceCategoryItem("food", "الأطعمة والمشروبات", COLOR_FOOD),
      PlaceCategoryItem("shopping", "التسوق والمتاجر", COLOR_SHOPPING),
      PlaceCategoryItem("health", "الصحة والطب", COLOR_HEALTH),
      PlaceCategoryItem("transport", "النقل والمواصلات", COLOR_TRANSPORT),
      PlaceCategoryItem("recreation", "الترفيه والرياضة", COLOR_RECREATION),
      PlaceCategoryItem("services", "الخدمات والمالية", COLOR_SERVICES),
      PlaceCategoryItem("education", "التعليم والمعرفة", COLOR_EDUCATION),
      PlaceCategoryItem("tourism", "السياحة والعبادة", COLOR_TOURS_WORSHIP)
  )

  /**
   * The complete set of 60 unique place icons with stable identifiers and Arabic labels.
   */
  val allIcons: List<PlaceIconItem> = listOf(
      // --- 1. الأماكن الشخصية (3 أيقونات) ---
      PlaceIconItem("personal_home", "المنزل", "personal", "الأماكن الشخصية", Icons.Default.Home, COLOR_PERSONAL, BG_PERSONAL, "home"),
      PlaceIconItem("personal_work", "مكان العمل", "personal", "الأماكن الشخصية", Icons.Default.Work, COLOR_PERSONAL, BG_PERSONAL, "work"),
      PlaceIconItem("personal_favorite", "الأماكن المفضلة", "personal", "الأماكن الشخصية", Icons.Default.Star, COLOR_PERSONAL, BG_PERSONAL, "favorite"),

      // --- 2. الأطعمة والمشروبات (8 أيقونات) ---
      PlaceIconItem("food_restaurant", "مطعم", "food", "الأطعمة والمشروبات", Icons.Default.Restaurant, COLOR_FOOD, BG_FOOD, "restaurant"),
      PlaceIconItem("food_cafe", "مقهى", "food", "الأطعمة والمشروبات", Icons.Default.LocalCafe, COLOR_FOOD, BG_FOOD, "cafe"),
      PlaceIconItem("food_fastfood", "وجبات سريعة", "food", "الأطعمة والمشروبات", Icons.Default.Fastfood, COLOR_FOOD, BG_FOOD, "fast_food"),
      PlaceIconItem("food_bakery", "مخبز ومعجنات", "food", "الأطعمة والمشروبات", Icons.Default.BakeryDining, COLOR_FOOD, BG_FOOD, "bakery"),
      PlaceIconItem("food_icecream", "حلويات ومثلجات", "food", "الأطعمة والمشروبات", Icons.Default.Icecream, COLOR_FOOD, BG_FOOD, "ice_cream"),
      PlaceIconItem("food_drinks", "عصائر ومشروبات", "food", "الأطعمة والمشروبات", Icons.Default.LocalBar, COLOR_FOOD, BG_FOOD, "juice"),
      PlaceIconItem("food_pizza", "بيتزا", "food", "الأطعمة والمشروبات", Icons.Default.LocalPizza, COLOR_FOOD, BG_FOOD, "pizza"),
      PlaceIconItem("food_grill", "مشويات ومأكولات", "food", "الأطعمة والمشروبات", Icons.Default.DinnerDining, COLOR_FOOD, BG_FOOD, "grill"),

      // --- 3. التسوق والمتاجر (8 أيقونات) ---
      PlaceIconItem("shop_supermarket", "سوبرماركت وبقالة", "shopping", "التسوق والمتاجر", Icons.Default.LocalGroceryStore, COLOR_SHOPPING, BG_SHOPPING, "supermarket"),
      PlaceIconItem("shop_mall", "مركز تسوق (مول)", "shopping", "التسوق والمتاجر", Icons.Default.LocalMall, COLOR_SHOPPING, BG_SHOPPING, "mall"),
      PlaceIconItem("shop_clothing", "متجر ملابس", "shopping", "التسوق والمتاجر", Icons.Default.Checkroom, COLOR_SHOPPING, BG_SHOPPING, "clothes"),
      PlaceIconItem("shop_pharmacy", "صيدلية", "shopping", "التسوق والمتاجر", Icons.Default.LocalPharmacy, COLOR_SHOPPING, BG_SHOPPING, "pharmacy"),
      PlaceIconItem("shop_electronics", "إلكترونيات وأجهزة", "shopping", "التسوق والمتاجر", Icons.Default.Devices, COLOR_SHOPPING, BG_SHOPPING, "electronics"),
      PlaceIconItem("shop_gifts", "هدايا وزهور", "shopping", "التسوق والمتاجر", Icons.Default.CardGiftcard, COLOR_SHOPPING, BG_SHOPPING, "gift"),
      PlaceIconItem("shop_bookstore", "مكتبة وقرطاسية", "shopping", "التسوق والمتاجر", Icons.Default.MenuBook, COLOR_SHOPPING, BG_SHOPPING, "books"),
      PlaceIconItem("shop_furniture", "أثاث ومنزل", "shopping", "التسوق والمتاجر", Icons.Default.Place, COLOR_SHOPPING, BG_SHOPPING, "furniture"),

      // --- 4. الصحة والطب (6 أيقونات) ---
      PlaceIconItem("health_hospital", "مستشفى", "health", "الصحة والطب", Icons.Default.LocalHospital, COLOR_HEALTH, BG_HEALTH, "hospital"),
      PlaceIconItem("health_clinic", "عيادة طبية", "health", "الصحة والطب", Icons.Default.MedicalServices, COLOR_HEALTH, BG_HEALTH, "clinic"),
      PlaceIconItem("health_emergency", "طوارئ وإسعاف", "health", "الصحة والطب", Icons.Default.Emergency, COLOR_HEALTH, BG_HEALTH, "emergency"),
      PlaceIconItem("health_dentist", "طب أسنان", "health", "الصحة والطب", Icons.Default.HealthAndSafety, COLOR_HEALTH, BG_HEALTH, "dentist"),
      PlaceIconItem("health_lab", "مختبر تحاليل", "health", "الصحة والطب", Icons.Default.Biotech, COLOR_HEALTH, BG_HEALTH, "laboratory"),
      PlaceIconItem("health_optics", "بصريات ونظارات", "health", "الصحة والطب", Icons.Default.Visibility, COLOR_HEALTH, BG_HEALTH, "optician"),

      // --- 5. النقل والمواصلات (8 أيقونات) ---
      PlaceIconItem("trans_gas_station", "محطة وقود", "transport", "النقل والمواصلات", Icons.Default.LocalGasStation, COLOR_TRANSPORT, BG_TRANSPORT, "fuel"),
      PlaceIconItem("trans_ev_charging", "شحن سيارات كهربائية", "transport", "النقل والمواصلات", Icons.Default.EvStation, COLOR_TRANSPORT, BG_TRANSPORT, "charging_station"),
      PlaceIconItem("trans_parking", "موقف سيارات", "transport", "النقل والمواصلات", Icons.Default.LocalParking, COLOR_TRANSPORT, BG_TRANSPORT, "parking"),
      PlaceIconItem("trans_bus_station", "محطة حافلات", "transport", "النقل والمواصلات", Icons.Default.DirectionsBus, COLOR_TRANSPORT, BG_TRANSPORT, "bus_station"),
      PlaceIconItem("trans_metro_train", "محطة قطار ومترو", "transport", "النقل والمواصلات", Icons.Default.DirectionsSubway, COLOR_TRANSPORT, BG_TRANSPORT, "subway"),
      PlaceIconItem("trans_airport", "مطار", "transport", "النقل والمواصلات", Icons.Default.Flight, COLOR_TRANSPORT, BG_TRANSPORT, "aerodrome"),
      PlaceIconItem("trans_car_rental", "تأجير سيارات", "transport", "النقل والمواصلات", Icons.Default.CarRental, COLOR_TRANSPORT, BG_TRANSPORT, "car_rental"),
      PlaceIconItem("trans_car_repair", "غسيل وصيانة سيارات", "transport", "النقل والمواصلات", Icons.Default.CarRepair, COLOR_TRANSPORT, BG_TRANSPORT, "car_repair"),

      // --- 6. الترفيه والرياضة (8 أيقونات) ---
      PlaceIconItem("rec_park", "حديقة عامة ومنتزه", "recreation", "الترفيه والرياضة", Icons.Default.Park, COLOR_RECREATION, BG_RECREATION, "park"),
      PlaceIconItem("rec_gym", "نادي رياضي ولياقة", "recreation", "الترفيه والرياضة", Icons.Default.FitnessCenter, COLOR_RECREATION, BG_RECREATION, "fitness_centre"),
      PlaceIconItem("rec_pool", "مسبح", "recreation", "الترفيه والرياضة", Icons.Default.Pool, COLOR_RECREATION, BG_RECREATION, "swimming_pool"),
      PlaceIconItem("rec_stadium", "ملعب وساحة رياضية", "recreation", "الترفيه والرياضة", Icons.Default.SportsSoccer, COLOR_RECREATION, BG_RECREATION, "stadium"),
      PlaceIconItem("rec_cinema", "سينما", "recreation", "الترفيه والرياضة", Icons.Default.Movie, COLOR_RECREATION, BG_RECREATION, "cinema"),
      PlaceIconItem("rec_amusement", "مدينة ملاهي وألعاب", "recreation", "الترفيه والرياضة", Icons.Default.Attractions, COLOR_RECREATION, BG_RECREATION, "theme_park"),
      PlaceIconItem("rec_museum", "متحف ومعرض فني", "recreation", "الترفيه والرياضة", Icons.Default.Museum, COLOR_RECREATION, BG_RECREATION, "museum"),
      PlaceIconItem("rec_theatre", "مسرح وعروض", "recreation", "الترفيه والرياضة", Icons.Default.TheaterComedy, COLOR_RECREATION, BG_RECREATION, "theatre"),

      // --- 7. الخدمات والمالية (8 أيقونات) ---
      PlaceIconItem("serv_bank", "بنك ومصرف", "services", "الخدمات والمالية", Icons.Default.AccountBalance, COLOR_SERVICES, BG_SERVICES, "bank"),
      PlaceIconItem("serv_atm", "صراف آلي ATM", "services", "الخدمات والمالية", Icons.Default.LocalAtm, COLOR_SERVICES, BG_SERVICES, "atm"),
      PlaceIconItem("serv_post", "بريد وشحن", "services", "الخدمات والمالية", Icons.Default.LocalPostOffice, COLOR_SERVICES, BG_SERVICES, "post_office"),
      PlaceIconItem("serv_police", "مركز شرطة", "services", "الخدمات والمالية", Icons.Default.LocalPolice, COLOR_SERVICES, BG_SERVICES, "police"),
      PlaceIconItem("serv_fire_station", "محطة إطفاء", "services", "الخدمات والمالية", Icons.Default.LocalFireDepartment, COLOR_SERVICES, BG_SERVICES, "fire_station"),
      PlaceIconItem("serv_salon", "صالون حلاقة وتجميل", "services", "الخدمات والمالية", Icons.Default.ContentCut, COLOR_SERVICES, BG_SERVICES, "hairdresser"),
      PlaceIconItem("serv_laundry", "مغسلة ملابس", "services", "الخدمات والمالية", Icons.Default.LocalLaundryService, COLOR_SERVICES, BG_SERVICES, "laundry"),
      PlaceIconItem("serv_government", "دوائر حكومية", "services", "الخدمات والمالية", Icons.Default.Gavel, COLOR_SERVICES, BG_SERVICES, "townhall"),

      // --- 8. التعليم والمعرفة (5 أيقونات) ---
      PlaceIconItem("edu_school", "مدرسة", "education", "التعليم والمعرفة", Icons.Default.School, COLOR_EDUCATION, BG_EDUCATION, "school"),
      PlaceIconItem("edu_university", "جامعة وكلية", "education", "التعليم والمعرفة", Icons.Default.AccountBalance, COLOR_EDUCATION, BG_EDUCATION, "university"),
      PlaceIconItem("edu_kindergarten", "روضة أطفال", "education", "التعليم والمعرفة", Icons.Default.ChildCare, COLOR_EDUCATION, BG_EDUCATION, "kindergarten"),
      PlaceIconItem("edu_institute", "معهد تدريب", "education", "التعليم والمعرفة", Icons.Default.Psychology, COLOR_EDUCATION, BG_EDUCATION, "college"),
      PlaceIconItem("edu_library", "مكتبة عامة", "education", "التعليم والمعرفة", Icons.Default.AutoStories, COLOR_EDUCATION, BG_EDUCATION, "library"),

      // --- 9. السياحة والعبادة (6 أيقونات) ---
      PlaceIconItem("tour_hotel", "فندق", "tourism", "السياحة والعبادة", Icons.Default.Hotel, COLOR_TOURS_WORSHIP, BG_TOURS_WORSHIP, "hotel"),
      PlaceIconItem("tour_resort", "منتجع وشاليه", "tourism", "السياحة والعبادة", Icons.Default.Villa, COLOR_TOURS_WORSHIP, BG_TOURS_WORSHIP, "resort"),
      PlaceIconItem("tour_beach", "شاطئ وبحر", "tourism", "السياحة والعبادة", Icons.Default.BeachAccess, COLOR_TOURS_WORSHIP, BG_TOURS_WORSHIP, "beach"),
      PlaceIconItem("tour_attraction", "معلم سياحي", "tourism", "السياحة والعبادة", Icons.Default.Tour, COLOR_TOURS_WORSHIP, BG_TOURS_WORSHIP, "attraction"),
      PlaceIconItem("tour_mosque", "مسجد ومصلى", "tourism", "السياحة والعبادة", Icons.Default.Mosque, COLOR_TOURS_WORSHIP, BG_TOURS_WORSHIP, "mosque"),
      PlaceIconItem("tour_viewpoint", "مطل ومنظر طبيعي", "tourism", "السياحة والعبادة", Icons.Default.Landscape, COLOR_TOURS_WORSHIP, BG_TOURS_WORSHIP, "viewpoint")
  )

  /**
   * Safe lookup by icon identifier with a fallback to personal_favorite or default pin.
   */
  fun getIconById(id: String?): PlaceIconItem {
    if (id.isNullOrBlank()) return allIcons[2] // personal_favorite
    return allIcons.find { it.id == id }
        ?: when (id) {
          "home" -> allIcons[0]
          "work" -> allIcons[1]
          "favorite" -> allIcons[2]
          "cafe" -> allIcons[4]
          else -> allIcons[2]
        }
  }

  fun getIconsByCategory(categoryKey: String): List<PlaceIconItem> {
    if (categoryKey == "all") return allIcons
    return allIcons.filter { it.categoryKey == categoryKey }
  }
}
