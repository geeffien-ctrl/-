package com.example.ui.map.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DeleteOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.PlaceComment
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CommentsBottomSheet(
    placeTitle: String,
    comments: List<PlaceComment>,
    userLikedCommentIds: Set<String>,
    isGuest: Boolean,
    isSubmitting: Boolean,
    currentUserId: String = "",
    onAddComment: (String) -> Unit,
    onToggleCommentLike: (PlaceComment) -> Unit,
    onDeleteComment: (PlaceComment) -> Unit = {},
    onRequireLogin: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
  var commentText by remember { mutableStateOf("") }

  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFFFAFAFC),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = null,
        modifier = modifier
            .fillMaxWidth()
            .testTag("comments_bottom_sheet")
    ) {
      Column(
          modifier = Modifier
              .fillMaxWidth()
              .fillMaxHeight(0.75f)
              .imePadding()
      ) {
        // Drag Pill & Top Header
        Box(
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 10.dp, bottom = 6.dp)
                .width(42.dp)
                .height(4.5.dp)
                .clip(CircleShape)
                .background(Color(0xFFD1D1D6))
        )

        // Header: Place title & Comment count & Close button
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 10.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
          Column(modifier = Modifier.weight(1f)) {
            Text(
                text = "التعليقات",
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack
            )
            Text(
                text = "$placeTitle • ${comments.size} تعليق",
                fontSize = 12.5.sp,
                color = DrawTextSecondary,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
          }

          IconButton(
              onClick = onDismiss,
              modifier = Modifier
                  .size(32.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFE5E5EA))
                  .testTag("close_comments_sheet")
          ) {
            Icon(
                imageVector = Icons.Default.Close,
                contentDescription = "إغلاق",
                tint = Color(0xFF3A3A3C),
                modifier = Modifier.size(16.dp)
            )
          }
        }

        HorizontalDivider(color = Color(0x18000000), thickness = 0.8.dp)

        // Comments List / Empty State
        if (comments.isEmpty()) {
          Box(
              modifier = Modifier
                  .weight(1f)
                  .fillMaxWidth()
                  .padding(32.dp),
              contentAlignment = Alignment.Center
          ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Box(
                  modifier = Modifier
                      .size(64.dp)
                      .clip(CircleShape)
                      .background(Color(0xFFFFEEEE)),
                  contentAlignment = Alignment.Center
              ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = DrawRed,
                    modifier = Modifier.size(32.dp)
                )
              }
              Text(
                  text = "لا توجد تعليقات بعد",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = DrawTextNearBlack
              )
              Text(
                  text = "كن أول من يشارك برأيه أو تجربته في هذا المكان!",
                  fontSize = 13.sp,
                  color = DrawTextSecondary,
                  textAlign = TextAlign.Center
              )
            }
          }
        } else {
          LazyColumn(
              modifier = Modifier
                  .weight(1f)
                  .fillMaxWidth()
                  .padding(horizontal = 16.dp),
              verticalArrangement = Arrangement.spacedBy(12.dp)
          ) {
            item { Spacer(modifier = Modifier.height(6.dp)) }
            itemsIndexed(
                items = comments,
                key = { index, comment ->
                  if (comment.id.isNotBlank()) comment.id else "comment_${index}_${comment.userId}_${comment.text.hashCode()}"
                }
            ) { _, comment ->
              val isLiked = userLikedCommentIds.contains(comment.id)
              val isAuthor = currentUserId.isNotBlank() && comment.userId.isNotBlank() && comment.userId == currentUserId
              CommentItem(
                  comment = comment,
                  isLiked = isLiked,
                  isAuthor = isAuthor,
                  onToggleLike = {
                    if (isGuest) {
                      onRequireLogin()
                    } else {
                      onToggleCommentLike(comment)
                    }
                  },
                  onDelete = {
                    onDeleteComment(comment)
                  }
              )
            }
            item { Spacer(modifier = Modifier.height(10.dp)) }
          }
        }

        HorizontalDivider(color = Color(0x18000000), thickness = 0.8.dp)

        // Bottom Input Row or Guest Lock Banner
        if (isGuest) {
          Surface(
              modifier = Modifier
                  .fillMaxWidth()
                  .padding(14.dp)
                  .clickable { onRequireLogin() }
                  .testTag("guest_login_prompt_banner"),
              shape = RoundedCornerShape(16.dp),
              color = Color(0xFFFFEEEE),
              border = androidx.compose.foundation.BorderStroke(1.dp, DrawRed.copy(alpha = 0.3f))
          ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 16.dp, vertical = 12.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
              Icon(
                  imageVector = Icons.Default.Lock,
                  contentDescription = null,
                  tint = DrawRed,
                  modifier = Modifier.size(18.dp)
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                  text = "سجّل الدخول لتتمكن من كتابة تعليق والإعجاب",
                  color = DrawDarkRed,
                  fontSize = 13.5.sp,
                  fontWeight = FontWeight.SemiBold
              )
            }
          }
        } else {
          Row(
              modifier = Modifier
                  .fillMaxWidth()
                  .background(Color.White)
                  .padding(horizontal = 12.dp, vertical = 10.dp),
              verticalAlignment = Alignment.CenterVertically,
              horizontalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            OutlinedTextField(
                value = commentText,
                onValueChange = { commentText = it },
                placeholder = {
                  Text(
                      text = "أضف تعليقاً على هذا المكان...",
                      fontSize = 13.sp,
                      color = Color(0xFF8E8E93)
                  )
                },
                modifier = Modifier
                    .weight(1f)
                    .testTag("comment_input_field"),
                shape = RoundedCornerShape(24.dp),
                maxLines = 3,
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = DrawRed,
                    unfocusedBorderColor = Color(0xFFD1D1D6),
                    focusedContainerColor = Color(0xFFF9F9FB),
                    unfocusedContainerColor = Color(0xFFF9F9FB)
                )
            )

            val canSubmit = commentText.trim().isNotEmpty() && !isSubmitting
            IconButton(
                onClick = {
                  val text = commentText.trim()
                  if (text.isNotEmpty() && !isSubmitting) {
                    onAddComment(text)
                    commentText = ""
                  }
                },
                enabled = canSubmit,
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (canSubmit) DrawRed else Color(0xFFE5E5EA))
                    .testTag("send_comment_button")
            ) {
              if (isSubmitting) {
                CircularProgressIndicator(
                    modifier = Modifier.size(18.dp),
                    strokeWidth = 2.dp,
                    color = Color.White
                )
              } else {
                Icon(
                    imageVector = Icons.AutoMirrored.Filled.Send,
                    contentDescription = "إرسال",
                    tint = if (canSubmit) Color.White else Color(0xFF8E8E93),
                    modifier = Modifier.size(18.dp)
                )
              }
            }
          }
        }
      }
    }
  }
}

@Composable
private fun CommentItem(
    comment: PlaceComment,
    isLiked: Boolean,
    isAuthor: Boolean = false,
    onToggleLike: () -> Unit,
    onDelete: () -> Unit = {}
) {
  var showDeleteDialog by remember { mutableStateOf(false) }

  if (showDeleteDialog) {
    AlertDialog(
        onDismissRequest = { showDeleteDialog = false },
        title = {
          Text(text = "حذف التعليق", fontWeight = FontWeight.Bold, color = DrawRed)
        },
        text = {
          Text(text = "هل أنت متأكد من رغبتك في حذف تعليقك؟", fontSize = 14.sp)
        },
        confirmButton = {
          Button(
              onClick = {
                showDeleteDialog = false
                onDelete()
              },
              colors = ButtonDefaults.buttonColors(containerColor = DrawRed),
              shape = RoundedCornerShape(10.dp)
          ) {
            Text("حذف", color = Color.White, fontWeight = FontWeight.Bold)
          }
        },
        dismissButton = {
          TextButton(onClick = { showDeleteDialog = false }) {
            Text("إلغاء", color = Color(0xFF6B7280))
          }
        },
        containerColor = Color.White,
        shape = RoundedCornerShape(18.dp)
    )
  }

  val heartColor by animateColorAsState(
      targetValue = if (isLiked) DrawRed else Color(0xFF8E8E93),
      label = "comment_heart_color"
  )

  Surface(
      shape = RoundedCornerShape(16.dp),
      color = Color.White,
      border = androidx.compose.foundation.BorderStroke(0.6.dp, Color(0x18000000)),
      modifier = Modifier
          .fillMaxWidth()
          .testTag("comment_item_${comment.id}")
  ) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp)
    ) {
      Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically
      ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            modifier = Modifier.weight(1f)
        ) {
          // User Avatar
          if (comment.userPhotoUrl.isNotBlank()) {
            AsyncImage(
                model = comment.userPhotoUrl,
                contentDescription = comment.userName,
                contentScale = ContentScale.Crop,
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .border(1.dp, Color(0x22000000), CircleShape)
            )
          } else {
            Box(
                modifier = Modifier
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFEEEEF2)),
                contentAlignment = Alignment.Center
            ) {
              Icon(
                  imageVector = Icons.Default.Person,
                  contentDescription = null,
                  tint = Color(0xFF8E8E93),
                  modifier = Modifier.size(18.dp)
              )
            }
          }

          Spacer(modifier = Modifier.width(10.dp))

          Column {
            Text(
                text = comment.userName.ifBlank { "مستخدم DRAW" },
                fontSize = 13.5.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis
            )
            Text(
                text = formatRelativeTimeArabic(comment.createdAt),
                fontSize = 11.sp,
                color = DrawTextSecondary
            )
          }
        }

        // Action Buttons: Delete (Author only) + Like
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(4.dp)
        ) {
          if (isAuthor) {
            IconButton(
                onClick = { showDeleteDialog = true },
                modifier = Modifier
                    .size(30.dp)
                    .testTag("delete_comment_${comment.id}")
            ) {
              Icon(
                  imageVector = Icons.Default.DeleteOutline,
                  contentDescription = "حذف تعليقي",
                  tint = Color(0xFFDC2626),
                  modifier = Modifier.size(17.dp)
              )
            }
          }

          // Like Comment Button
          Row(
              verticalAlignment = Alignment.CenterVertically,
              modifier = Modifier
                  .clip(RoundedCornerShape(14.dp))
                  .clickable { onToggleLike() }
                  .padding(horizontal = 6.dp, vertical = 4.dp)
                  .testTag("like_comment_${comment.id}")
          ) {
            Icon(
                imageVector = if (isLiked) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                contentDescription = "إعجاب بالتعليق",
                tint = heartColor,
                modifier = Modifier.size(16.dp)
            )
            if (comment.likesCount > 0) {
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                  text = "${comment.likesCount}",
                  fontSize = 12.sp,
                  fontWeight = FontWeight.SemiBold,
                  color = if (isLiked) DrawRed else DrawTextSecondary
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(8.dp))

      Text(
          text = comment.text,
          fontSize = 13.5.sp,
          color = Color(0xFF2C2C2E),
          lineHeight = 19.sp,
          modifier = Modifier.padding(start = 44.dp)
      )
    }
  }
}

/**
 * Returns human-readable relative time in Arabic (e.g. "الآن", "منذ 5 دقائق", "منذ ساعتين", "منذ يومين", or dd/MM/yyyy).
 */
fun formatRelativeTimeArabic(timestamp: Long?): String {
  if (timestamp == null || timestamp <= 0L) return "الآن"
  val diffMillis = System.currentTimeMillis() - timestamp
  if (diffMillis < 0) return "الآن"

  val seconds = diffMillis / 1000
  val minutes = seconds / 60
  val hours = minutes / 60
  val days = hours / 24

  return when {
    seconds < 60 -> "الآن"
    minutes == 1L -> "منذ دقيقة"
    minutes == 2L -> "منذ دقيقتين"
    minutes in 3..10 -> "منذ $minutes دقائق"
    minutes < 60 -> "منذ $minutes دقيقة"
    hours == 1L -> "منذ ساعة"
    hours == 2L -> "منذ ساعتين"
    hours in 3..10 -> "منذ $hours ساعات"
    hours < 24 -> "منذ $hours ساعة"
    days == 1L -> "منذ يوم"
    days == 2L -> "منذ يومين"
    days in 3..10 -> "منذ $days أيام"
    days < 30 -> "منذ $days يوماً"
    else -> {
      val sdf = SimpleDateFormat("dd/MM/yyyy", Locale.getDefault())
      sdf.format(Date(timestamp))
    }
  }
}
