package com.example.ui.map.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.DoneAll
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.ModeComment
import androidx.compose.material.icons.filled.Notifications
import androidx.compose.material.icons.filled.NotificationsNone
import androidx.compose.material.icons.filled.Person
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.SheetState
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.UserNotification
import com.example.ui.theme.DrawDarkRed
import com.example.ui.theme.DrawRed
import com.example.ui.theme.DrawTextNearBlack
import com.example.ui.theme.DrawTextSecondary

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun NotificationsSheet(
    notifications: List<UserNotification>,
    unreadCount: Int,
    onNotificationClick: (UserNotification) -> Unit,
    onMarkAllAsRead: () -> Unit,
    onDismiss: () -> Unit,
    modifier: Modifier = Modifier,
    sheetState: SheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
) {
  CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = Color(0xFFFAFAFC),
        shape = RoundedCornerShape(topStart = 28.dp, topEnd = 28.dp),
        dragHandle = null,
        modifier = modifier
            .fillMaxWidth()
            .testTag("notifications_sheet")
    ) {
      Column(
          modifier = Modifier
              .fillMaxWidth()
              .fillMaxHeight(0.70f)
      ) {
        // Drag Pill
        Box(
            modifier = Modifier
                .align(Alignment.CenterHorizontally)
                .padding(top = 10.dp, bottom = 6.dp)
                .width(42.dp)
                .height(4.5.dp)
                .clip(CircleShape)
                .background(Color(0xFFD1D1D6))
        )

        // Header
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
                imageVector = Icons.Default.Notifications,
                contentDescription = null,
                tint = DrawRed,
                modifier = Modifier.size(22.dp)
            )
            Spacer(modifier = Modifier.width(8.dp))
            Text(
                text = "الإشعارات",
                fontSize = 19.sp,
                fontWeight = FontWeight.Bold,
                color = DrawTextNearBlack
            )
            if (unreadCount > 0) {
              Spacer(modifier = Modifier.width(8.dp))
              Box(
                  modifier = Modifier
                      .clip(CircleShape)
                      .background(DrawRed)
                      .padding(horizontal = 7.dp, vertical = 2.dp)
              ) {
                Text(
                    text = "$unreadCount جديد",
                    fontSize = 11.sp,
                    color = Color.White,
                    fontWeight = FontWeight.Bold
                )
              }
            }
          }

          Row(verticalAlignment = Alignment.CenterVertically) {
            if (unreadCount > 0) {
              TextButton(
                  onClick = onMarkAllAsRead,
                  modifier = Modifier.testTag("mark_all_read_button")
              ) {
                Icon(
                    imageVector = Icons.Default.DoneAll,
                    contentDescription = null,
                    tint = DrawDarkRed,
                    modifier = Modifier.size(16.dp)
                )
                Spacer(modifier = Modifier.width(4.dp))
                Text(
                    text = "تحديد الكل كمقروء",
                    fontSize = 12.sp,
                    color = DrawDarkRed,
                    fontWeight = FontWeight.SemiBold
                )
              }
            }

            IconButton(
                onClick = onDismiss,
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFE5E5EA))
                    .testTag("close_notifications_sheet")
            ) {
              Icon(
                  imageVector = Icons.Default.Close,
                  contentDescription = "إغلاق",
                  tint = Color(0xFF3A3A3C),
                  modifier = Modifier.size(16.dp)
              )
            }
          }
        }

        HorizontalDivider(color = Color(0x18000000), thickness = 0.8.dp)

        if (notifications.isEmpty()) {
          Box(
              modifier = Modifier
                  .weight(1f)
                  .fillMaxWidth()
                  .padding(32.dp),
              contentAlignment = Alignment.Center
          ) {
            Column(
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
              Box(
                  modifier = Modifier
                      .size(64.dp)
                      .clip(CircleShape)
                      .background(Color(0xFFFFEEEE)),
                  contentAlignment = Alignment.Center
              ) {
                Icon(
                    imageVector = Icons.Default.NotificationsNone,
                    contentDescription = null,
                    tint = DrawRed,
                    modifier = Modifier.size(32.dp)
                )
              }
              Text(
                  text = "لا توجد إشعارات حتى الآن",
                  fontSize = 16.sp,
                  fontWeight = FontWeight.Bold,
                  color = DrawTextNearBlack
              )
              Text(
                  text = "ستصلك هنا إشعارات عند تفاعل المستخدمين مع أماكنك أو تعليقاتك.",
                  fontSize = 13.sp,
                  color = DrawTextSecondary,
                  textAlign = TextAlign.Center
              )
            }
          }
        } else {
          LazyColumn(
              modifier = Modifier
                  .weight(1f)
                  .fillMaxWidth()
                  .padding(horizontal = 14.dp),
              verticalArrangement = Arrangement.spacedBy(8.dp)
          ) {
            item { Spacer(modifier = Modifier.height(4.dp)) }
            itemsIndexed(
                items = notifications,
                key = { index, item ->
                  if (item.id.isNotBlank()) item.id else "notif_${index}_${item.actorId}_${item.createdAt}"
                }
            ) { _, item ->
              NotificationListItem(
                  notification = item,
                  onClick = { onNotificationClick(item) }
              )
            }
            item { Spacer(modifier = Modifier.height(10.dp)) }
          }
        }
      }
    }
  }
}

@Composable
private fun NotificationListItem(
    notification: UserNotification,
    onClick: () -> Unit
) {
  val isUnread = !notification.read
  val surfaceBg = if (isUnread) Color(0xFFFFF7F7) else Color.White
  val borderStroke = if (isUnread) DrawRed.copy(alpha = 0.35f) else Color(0x15000000)

  Surface(
      shape = RoundedCornerShape(16.dp),
      color = surfaceBg,
      border = androidx.compose.foundation.BorderStroke(1.dp, borderStroke),
      modifier = Modifier
          .fillMaxWidth()
          .clickable { onClick() }
          .testTag("notification_item_${notification.id}")
  ) {
    Row(
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
      // Type Icon Badge over Avatar
      Box(modifier = Modifier.size(44.dp)) {
        if (notification.actorPhotoUrl.isNotBlank()) {
          AsyncImage(
              model = notification.actorPhotoUrl,
              contentDescription = notification.actorName,
              contentScale = ContentScale.Crop,
              modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .border(1.dp, Color(0x22000000), CircleShape)
          )
        } else {
          Box(
              modifier = Modifier
                  .size(40.dp)
                  .clip(CircleShape)
                  .background(Color(0xFFEEEEF2)),
              contentAlignment = Alignment.Center
          ) {
            Icon(
                imageVector = Icons.Default.Person,
                contentDescription = null,
                tint = Color(0xFF8E8E93),
                modifier = Modifier.size(22.dp)
            )
          }
        }

        // Sub-badge for type
        val (badgeIcon, badgeColor) = when (notification.type) {
          "PLACE_LIKE", "COMMENT_LIKE" -> Pair(Icons.Default.Favorite, DrawRed)
          else -> Pair(Icons.Default.ModeComment, Color(0xFF007AFF))
        }

        Box(
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .size(18.dp)
                .clip(CircleShape)
                .background(badgeColor)
                .border(1.5.dp, Color.White, CircleShape),
            contentAlignment = Alignment.Center
        ) {
          Icon(
              imageVector = badgeIcon,
              contentDescription = null,
              tint = Color.White,
              modifier = Modifier.size(10.dp)
          )
        }
      }

      Spacer(modifier = Modifier.width(12.dp))

      Column(modifier = Modifier.weight(1f)) {
        val titleText = when (notification.type) {
          "PLACE_LIKE" -> "أعجب ${notification.actorName} بمكانك «${notification.placeTitle}»"
          "PLACE_COMMENT" -> "علق ${notification.actorName} على مكانك «${notification.placeTitle}»"
          "COMMENT_LIKE" -> "أعجب ${notification.actorName} بتعليقك على «${notification.placeTitle}»"
          else -> "تفاعل جديد من ${notification.actorName}"
        }

        Text(
            text = titleText,
            fontSize = 13.5.sp,
            fontWeight = if (isUnread) FontWeight.Bold else FontWeight.Medium,
            color = DrawTextNearBlack,
            maxLines = 2,
            overflow = TextOverflow.Ellipsis
        )

        if (!notification.commentTextSnippet.isNullOrBlank()) {
          Text(
              text = "«${notification.commentTextSnippet}»",
              fontSize = 12.sp,
              color = Color(0xFF555555),
              maxLines = 1,
              overflow = TextOverflow.Ellipsis
          )
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
            text = formatRelativeTimeArabic(notification.createdAt),
            fontSize = 11.sp,
            color = DrawTextSecondary
        )
      }

      if (isUnread) {
        Spacer(modifier = Modifier.width(8.dp))
        Box(
            modifier = Modifier
                .size(9.dp)
                .clip(CircleShape)
                .background(DrawRed)
        )
      }
    }
  }
}
