package com.example.data.repository

import android.content.Context
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.util.Log
import com.example.data.model.AppUser
import com.example.data.DrawBrand
import com.example.data.model.AudioTrack
import com.example.data.model.PlaceComment
import com.example.data.model.Post
import com.example.data.util.ImageCompressUtil
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.UUID

private const val TAG = "PostsRepository"

class PostsRepository(
    private val context: Context
) {
    companion object {
        private val samplePosts = listOf(
            Post(
                id = "post_seed_1",
                creatorId = "user_1",
                creatorName = "علي السعدون",
                caption = "رحلة استكشافية ممتعة عبر طريق الجبل، الأجواء رائعة والخرائط دقيقة جداً! #DRAW #سفر",
                type = "image",
                images = listOf(
                    "https://images.unsplash.com/photo-1506744038136-46273834b3fb?w=800",
                    "https://images.unsplash.com/photo-1469854523086-cc02fe5d8800?w=800"
                ),
                audioTitle = "أصوات الطبيعة والهدوء",
                audioDuration = 180000L,
                likesCount = 34L,
                commentsCount = 5L,
                createdAt = System.currentTimeMillis() - 14400000L
            ),
            Post(
                id = "post_seed_2",
                creatorId = "user_2",
                creatorName = "مريم الأحمد",
                caption = "أفضل قهوة في المدينة مع إطلالة خلابة ☕️ جربوا هذا المكان عبر ميزة الاستكشاف.",
                type = "image",
                images = listOf(
                    "https://images.unsplash.com/photo-1495474472287-4d71bcdd2085?w=800"
                ),
                likesCount = 56L,
                commentsCount = 8L,
                createdAt = System.currentTimeMillis() - 28800000L
            )
        )

        private val allPostsList = mutableListOf<Post>().apply { addAll(samplePosts) }
        private val postsFlow = MutableStateFlow<List<Post>>(allPostsList.toList())
        private val followingMap = mutableMapOf<String, MutableSet<String>>()
        private val followingFlowMap = mutableMapOf<String, MutableStateFlow<Set<String>>>()
        private val likedPostsMap = mutableMapOf<String, MutableSet<String>>() // userId -> Set<postId>
        private val likedFlowMap = mutableMapOf<String, MutableStateFlow<Boolean>>()
        private val savedPostsMap = mutableMapOf<String, MutableSet<String>>() // userId -> Set<postId>
        private val savedFlowMap = mutableMapOf<String, MutableStateFlow<Boolean>>()
        private val postCommentsMap = mutableMapOf<String, MutableList<PlaceComment>>()
        private val postCommentsFlowMap = mutableMapOf<String, MutableStateFlow<List<PlaceComment>>>()
    }

    fun getFeedPostsFlow(followingUserIds: Set<String>, currentUserId: String): Flow<List<Post>> {
        return postsFlow.asStateFlow()
    }

    fun getFollowingUserIdsFlow(userId: String): Flow<Set<String>> {
        val flow = followingFlowMap.getOrPut(userId) {
            val set = followingMap.getOrPut(userId) { mutableSetOf() }
            MutableStateFlow(set.toSet())
        }
        return flow.asStateFlow()
    }

    suspend fun toggleFollow(currentUserId: String, targetUserId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        if (currentUserId.isBlank() || targetUserId.isBlank() || currentUserId == targetUserId) {
            return@withContext Result.failure(IllegalArgumentException("Invalid user IDs for follow"))
        }
        val set = followingMap.getOrPut(currentUserId) { mutableSetOf() }
        val isFollowing = set.contains(targetUserId)
        val newFollow = !isFollowing
        if (newFollow) set.add(targetUserId) else set.remove(targetUserId)
        followingFlowMap[currentUserId]?.value = set.toSet()
        Result.success(newFollow)
    }

    suspend fun createPost(
        currentUser: AppUser,
        caption: String,
        type: String,
        imageUris: List<Uri>,
        videoUri: Uri?,
        audioTrack: AudioTrack?,
        context: Context
    ): Result<String> = withContext(Dispatchers.IO) {
        try {
            if (currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
                return@withContext Result.failure(IllegalAccessException("Guest users cannot create posts"))
            }
            val postId = "post_" + UUID.randomUUID().toString().take(10)
            val imageUrls = imageUris.mapIndexedNotNull { index, uri ->
                ImageCompressUtil.compressUriToBase64(context, uri, 800) ?: uri.toString()
            }
            val videoUrl = videoUri?.toString() ?: ""
            val audioUrl = audioTrack?.uri?.toString() ?: ""

            val newPost = Post(
                id = postId,
                creatorId = currentUser.uid,
                creatorName = currentUser.displayName ?: currentUser.email?.substringBefore("@") ?: "مستخدم DRAW",
                creatorPhotoUrl = DrawBrand.AVATAR_URI,
                caption = caption.trim(),
                type = type,
                images = imageUrls,
                videoUrl = videoUrl,
                audioUrl = audioUrl,
                audioTitle = audioTrack?.title ?: "",
                audioDuration = audioTrack?.durationMs ?: 0L,
                likesCount = 0L,
                commentsCount = 0L,
                createdAt = System.currentTimeMillis(),
                updatedAt = System.currentTimeMillis()
            )
            allPostsList.add(0, newPost)
            postsFlow.value = allPostsList.toList()
            Result.success(postId)
        } catch (e: Exception) {
            Log.e(TAG, "Failed creating post", e)
            Result.failure(e)
        }
    }

    suspend fun togglePostLike(
        postId: String,
        currentUser: AppUser
    ): Result<Boolean> = withContext(Dispatchers.IO) {
        if (currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
            return@withContext Result.failure(IllegalAccessException("Guest users cannot like posts"))
        }
        val userId = currentUser.uid
        val userLikes = likedPostsMap.getOrPut(userId) { mutableSetOf() }
        val isLiked = userLikes.contains(postId)
        val newLiked = !isLiked
        if (newLiked) userLikes.add(postId) else userLikes.remove(postId)

        val key = "${userId}_$postId"
        likedFlowMap[key]?.value = newLiked

        val idx = allPostsList.indexOfFirst { it.id == postId }
        if (idx >= 0) {
            val p = allPostsList[idx]
            val newLikes = (p.likesCount + if (newLiked) 1L else -1L).coerceAtLeast(0L)
            allPostsList[idx] = p.copy(likesCount = newLikes)
            postsFlow.value = allPostsList.toList()
        }
        Result.success(newLiked)
    }

    fun isPostLikedFlow(postId: String, userId: String): Flow<Boolean> {
        val key = "${userId}_$postId"
        val flow = likedFlowMap.getOrPut(key) {
            val isLiked = likedPostsMap[userId]?.contains(postId) ?: false
            MutableStateFlow(isLiked)
        }
        return flow.asStateFlow()
    }

    suspend fun toggleSavePost(userId: String, postId: String): Result<Boolean> = withContext(Dispatchers.IO) {
        val userSaved = savedPostsMap.getOrPut(userId) { mutableSetOf() }
        val isSaved = userSaved.contains(postId)
        val newSaved = !isSaved
        if (newSaved) userSaved.add(postId) else userSaved.remove(postId)
        val key = "${userId}_$postId"
        savedFlowMap[key]?.value = newSaved
        Result.success(newSaved)
    }

    fun isPostSavedFlow(userId: String, postId: String): Flow<Boolean> {
        val key = "${userId}_$postId"
        val flow = savedFlowMap.getOrPut(key) {
            val isSaved = savedPostsMap[userId]?.contains(postId) ?: false
            MutableStateFlow(isSaved)
        }
        return flow.asStateFlow()
    }

    fun getPostCommentsFlow(postId: String): Flow<List<PlaceComment>> {
        val flow = postCommentsFlowMap.getOrPut(postId) {
            val list = postCommentsMap.getOrPut(postId) { mutableListOf() }
            MutableStateFlow(list.toList())
        }
        return flow.asStateFlow()
    }

    suspend fun addPostComment(
        postId: String,
        currentUser: AppUser,
        text: String
    ): Result<PlaceComment> = withContext(Dispatchers.IO) {
        if (currentUser.isAnonymous || currentUser.uid.startsWith("guest_")) {
            return@withContext Result.failure(IllegalAccessException("Guest users cannot comment on posts"))
        }
        val comment = PlaceComment(
            id = "c_" + UUID.randomUUID().toString().take(8),
            placeId = postId,
            userId = currentUser.uid,
            userName = currentUser.displayName ?: currentUser.email?.substringBefore("@") ?: "مستخدم DRAW",
            userPhotoUrl = DrawBrand.AVATAR_URI,
            text = text.trim(),
            likesCount = 0L,
            createdAt = System.currentTimeMillis()
        )
        val list = postCommentsMap.getOrPut(postId) { mutableListOf() }
        list.add(comment)
        postCommentsFlowMap[postId]?.value = list.toList()

        val idx = allPostsList.indexOfFirst { it.id == postId }
        if (idx >= 0) {
            val p = allPostsList[idx]
            allPostsList[idx] = p.copy(commentsCount = p.commentsCount + 1L)
            postsFlow.value = allPostsList.toList()
        }
        Result.success(comment)
    }

    fun extractAudioMetadata(context: Context, uri: Uri): AudioTrack {
        return try {
            val retriever = MediaMetadataRetriever()
            retriever.setDataSource(context, uri)
            val title = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_TITLE)
                ?: retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_ARTIST)
                ?: uri.lastPathSegment?.substringAfterLast("/")?.substringBeforeLast(".")
                ?: "مقطع صوتي"
            val durationStr = retriever.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)
            val durationMs = durationStr?.toLongOrNull() ?: 0L
            retriever.release()
            AudioTrack(uri = uri, title = title, durationMs = durationMs)
        } catch (e: Exception) {
            val title = uri.lastPathSegment?.substringAfterLast("/") ?: "مقطع صوتي"
            AudioTrack(uri = uri, title = title, durationMs = 0L)
        }
    }
}
