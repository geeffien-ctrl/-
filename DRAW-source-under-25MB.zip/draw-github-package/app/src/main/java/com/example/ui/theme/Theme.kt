package com.example.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import java.util.Locale

private val DrawDarkColorScheme = darkColorScheme(
    primary = DrawWhite,
    onPrimary = DrawRed,
    secondary = DrawWhite,
    onSecondary = DrawRed,
    background = DrawRed,
    onBackground = DrawWhite,
    surface = DrawRed,
    onSurface = DrawWhite,
)

@Composable
fun DrawTheme(
    content: @Composable () -> Unit
) {
    // Maintain LTR when English is explicitly chosen, otherwise enforce true RTL for Arabic
    val currentLang = Locale.getDefault().language
    val layoutDirection = if (currentLang.equals("en", ignoreCase = true)) {
        LayoutDirection.Ltr
    } else {
        LayoutDirection.Rtl
    }

    CompositionLocalProvider(
        LocalLayoutDirection provides layoutDirection
    ) {
        MaterialTheme(
            colorScheme = DrawDarkColorScheme,
            typography = Typography,
            content = content
        )
    }
}

@Composable
fun MyApplicationTheme(
    darkTheme: Boolean = true,
    dynamicColor: Boolean = false,
    content: @Composable () -> Unit
) {
    DrawTheme(content = content)
}
