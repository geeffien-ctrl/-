package com.example.data.util

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Matrix
import android.net.Uri
import android.util.Base64
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.ByteArrayOutputStream
import java.io.InputStream

object ImageCompressUtil {

  /**
   * Reads an image Uri, downsamples to maxDimension (640px), compresses to JPEG,
   * and returns a compact Base64 Data URL string ready for persistent cloud storage.
   */
  suspend fun compressUriToBase64(context: Context, uri: Uri, maxDimension: Int = 640): String? =
      withContext(Dispatchers.IO) {
        try {
          var input: InputStream? = context.contentResolver.openInputStream(uri) ?: return@withContext null

          // Decode bounds only
          val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
          BitmapFactory.decodeStream(input, null, options)
          input?.close()

          val rawWidth = options.outWidth
          val rawHeight = options.outHeight
          if (rawWidth <= 0 || rawHeight <= 0) return@withContext null

          var sampleSize = 1
          while (rawWidth / sampleSize > maxDimension * 2 || rawHeight / sampleSize > maxDimension * 2) {
            sampleSize *= 2
          }

          input = context.contentResolver.openInputStream(uri) ?: return@withContext null
          val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
          val sampledBitmap = BitmapFactory.decodeStream(input, null, decodeOptions)
          input?.close()

          if (sampledBitmap == null) return@withContext null

          // Scale down to exact maxDimension
          val width = sampledBitmap.width
          val height = sampledBitmap.height
          val scale = Math.min(maxDimension.toFloat() / width, maxDimension.toFloat() / height)

          val finalBitmap = if (scale < 1.0f) {
            val matrix = Matrix().apply { postScale(scale, scale) }
            Bitmap.createBitmap(sampledBitmap, 0, 0, width, height, matrix, true)
          } else {
            sampledBitmap
          }

          val outputStream = ByteArrayOutputStream()
          finalBitmap.compress(Bitmap.CompressFormat.JPEG, 75, outputStream)
          val bytes = outputStream.toByteArray()

          "data:image/jpeg;base64," + Base64.encodeToString(bytes, Base64.NO_WRAP)
        } catch (e: Exception) {
          null
        }
      }

  suspend fun compressUriToByteArray(context: Context, uri: Uri, maxDimension: Int = 1024): ByteArray? =
      withContext(Dispatchers.IO) {
        try {
          var input: InputStream? = context.contentResolver.openInputStream(uri) ?: return@withContext null

          val options = BitmapFactory.Options().apply { inJustDecodeBounds = true }
          BitmapFactory.decodeStream(input, null, options)
          input?.close()

          val rawWidth = options.outWidth
          val rawHeight = options.outHeight
          if (rawWidth <= 0 || rawHeight <= 0) return@withContext null

          var sampleSize = 1
          while (rawWidth / sampleSize > maxDimension * 2 || rawHeight / sampleSize > maxDimension * 2) {
            sampleSize *= 2
          }

          input = context.contentResolver.openInputStream(uri) ?: return@withContext null
          val decodeOptions = BitmapFactory.Options().apply { inSampleSize = sampleSize }
          val sampledBitmap = BitmapFactory.decodeStream(input, null, decodeOptions)
          input?.close()

          if (sampledBitmap == null) return@withContext null

          val width = sampledBitmap.width
          val height = sampledBitmap.height
          val scale = Math.min(maxDimension.toFloat() / width, maxDimension.toFloat() / height)

          val finalBitmap = if (scale < 1.0f) {
            val matrix = Matrix().apply { postScale(scale, scale) }
            Bitmap.createBitmap(sampledBitmap, 0, 0, width, height, matrix, true)
          } else {
            sampledBitmap
          }

          val outputStream = ByteArrayOutputStream()
          finalBitmap.compress(Bitmap.CompressFormat.JPEG, 80, outputStream)
          outputStream.toByteArray()
        } catch (e: Exception) {
          null
        }
      }
}
