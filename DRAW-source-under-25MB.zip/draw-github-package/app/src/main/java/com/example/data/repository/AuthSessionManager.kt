package com.example.data.repository

import android.content.Context
import android.content.SharedPreferences
import android.net.Uri
import android.util.Log
import com.example.data.model.AppUser
import com.example.data.model.AppUserInfo
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.GoogleAuthProvider
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.tasks.await
import kotlinx.coroutines.withContext
import java.util.UUID

private const val TAG = "AuthSessionManager"

class AuthSessionManager private constructor(context: Context) {

    private val prefs: SharedPreferences =
        context.applicationContext.getSharedPreferences("draw_auth_session", Context.MODE_PRIVATE)

    private val _currentUser = MutableStateFlow<AppUser?>(null)
    val currentUser: StateFlow<AppUser?> = _currentUser.asStateFlow()

    init {
        loadSavedSession()
    }

    private fun loadSavedSession() {
        try {
            val fbUser = FirebaseAuth.getInstance().currentUser
            if (fbUser != null) {
                val user = AppUser(
                    uid = fbUser.uid,
                    email = fbUser.email,
                    displayName = fbUser.displayName,
                    photoUrl = fbUser.photoUrl,
                    isAnonymous = fbUser.isAnonymous,
                    isEmailVerified = fbUser.isEmailVerified,
                    providerData = fbUser.providerData.map {
                        AppUserInfo(
                            providerId = it.providerId,
                            uid = it.uid,
                            displayName = it.displayName,
                            email = it.email,
                            photoUrl = it.photoUrl
                        )
                    }
                )
                saveSession(user, fbUser.providerData.firstOrNull()?.providerId ?: "google.com")
                return
            }
        } catch (_: Exception) {}

        val uid = prefs.getString("user_uid", null)
        if (!uid.isNullOrBlank()) {
            val email = prefs.getString("user_email", null)
            val displayName = prefs.getString("user_display_name", null)
            val photoUrlStr = prefs.getString("user_photo_url", null)
            val isAnonymous = prefs.getBoolean("user_is_anonymous", false)
            val providerId = prefs.getString("user_provider_id", if (isAnonymous) "anonymous" else "password") ?: "password"

            val photoUri = if (!photoUrlStr.isNullOrBlank()) Uri.parse(photoUrlStr) else null
            val user = AppUser(
                uid = uid,
                email = email,
                displayName = displayName,
                photoUrl = photoUri,
                isAnonymous = isAnonymous,
                isEmailVerified = true,
                providerData = listOf(
                    AppUserInfo(
                        providerId = providerId,
                        uid = uid,
                        displayName = displayName,
                        email = email,
                        photoUrl = photoUri
                    )
                )
            )
            _currentUser.value = user
        }
    }

    private fun saveSession(user: AppUser, providerId: String = "password") {
        prefs.edit()
            .putString("user_uid", user.uid)
            .putString("user_email", user.email)
            .putString("user_display_name", user.displayName)
            .putString("user_photo_url", user.photoUrl?.toString())
            .putBoolean("user_is_anonymous", user.isAnonymous)
            .putString("user_provider_id", providerId)
            .apply()
        _currentUser.value = user
    }

    fun signInAsGuest(): AppUser {
        val existing = _currentUser.value
        if (existing != null && existing.isAnonymous) {
            return existing
        }
        val guestUid = "guest_" + UUID.randomUUID().toString().take(8)
        val guest = AppUser(
            uid = guestUid,
            email = null,
            displayName = "Guest Navigator",
            photoUrl = null,
            isAnonymous = true,
            providerData = listOf(AppUserInfo(providerId = "anonymous", uid = guestUid, displayName = "Guest Navigator"))
        )
        saveSession(guest, "anonymous")
        return guest
    }

    suspend fun signInWithEmailAndPassword(email: String, pass: String): Result<AppUser> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()

        // 1. Authenticate with real Firebase Authentication
        try {
            val auth = FirebaseAuth.getInstance()
            val authResult = auth.signInWithEmailAndPassword(cleanEmail, pass).await()
            val fbUser = authResult.user
            if (fbUser != null) {
                val user = AppUser(
                    uid = fbUser.uid,
                    email = fbUser.email ?: cleanEmail,
                    displayName = fbUser.displayName ?: cleanEmail.substringBefore("@"),
                    photoUrl = fbUser.photoUrl,
                    isAnonymous = false,
                    isEmailVerified = fbUser.isEmailVerified,
                    providerData = fbUser.providerData.map {
                        AppUserInfo(
                            providerId = it.providerId,
                            uid = it.uid,
                            displayName = it.displayName,
                            email = it.email,
                            photoUrl = it.photoUrl
                        )
                    }
                )
                saveSession(user, "password")
                return@withContext Result.success(user)
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase signInWithEmailAndPassword note: ${e.message}")
        }

        // 2. Fallback to cached credentials for offline access or migration
        val savedEmail = prefs.getString("registered_email_$cleanEmail", null)
        val savedPass = prefs.getString("registered_pass_$cleanEmail", null)
        val savedUid = prefs.getString("registered_uid_$cleanEmail", null)
        val savedName = prefs.getString("registered_name_$cleanEmail", null)
        val savedPhoto = prefs.getString("registered_photo_$cleanEmail", null)

        if (savedEmail != null && savedPass == pass) {
            val uid = savedUid ?: ("user_" + cleanEmail.hashCode())
            val name = savedName ?: cleanEmail.substringBefore("@")
            val photoUri = if (!savedPhoto.isNullOrBlank()) Uri.parse(savedPhoto) else null

            val user = AppUser(
                uid = uid,
                email = cleanEmail,
                displayName = name,
                photoUrl = photoUri,
                isAnonymous = false,
                isEmailVerified = true,
                providerData = listOf(AppUserInfo(providerId = "password", uid = uid, displayName = name, email = cleanEmail, photoUrl = photoUri))
            )
            saveSession(user, "password")
            return@withContext Result.success(user)
        }

        Result.failure(IllegalArgumentException("بيانات تسجيل الدخول غير صحيحة"))
    }

    suspend fun registerWithEmailAndPassword(
        username: String,
        email: String,
        displayName: String,
        photoUri: Uri?,
        password: String
    ): Result<AppUser> = withContext(Dispatchers.IO) {
        val cleanEmail = email.trim().lowercase()
        var firebaseCreatedUser: AppUser? = null

        // 1. Create account in real Firebase Authentication
        try {
            val auth = FirebaseAuth.getInstance()
            val authResult = auth.createUserWithEmailAndPassword(cleanEmail, password).await()
            val fbUser = authResult.user
            if (fbUser != null) {
                try {
                    val profileUpdates = com.google.firebase.auth.UserProfileChangeRequest.Builder()
                        .setDisplayName(displayName)
                        .apply {
                            if (photoUri != null) setPhotoUri(photoUri)
                        }
                        .build()
                    fbUser.updateProfile(profileUpdates).await()
                } catch (_: Exception) {}

                firebaseCreatedUser = AppUser(
                    uid = fbUser.uid,
                    email = cleanEmail,
                    displayName = displayName,
                    photoUrl = photoUri ?: fbUser.photoUrl,
                    isAnonymous = false,
                    isEmailVerified = fbUser.isEmailVerified,
                    providerData = listOf(
                        AppUserInfo(
                            providerId = "password",
                            uid = fbUser.uid,
                            displayName = displayName,
                            email = cleanEmail,
                            photoUrl = photoUri
                        )
                    )
                )
            }
        } catch (e: Exception) {
            Log.w(TAG, "Firebase createUserWithEmailAndPassword note: ${e.message}")
        }

        val uid = firebaseCreatedUser?.uid ?: ("user_" + UUID.randomUUID().toString().take(10))
        val finalUser = firebaseCreatedUser ?: AppUser(
            uid = uid,
            email = cleanEmail,
            displayName = displayName,
            photoUrl = photoUri,
            isAnonymous = false,
            isEmailVerified = true,
            providerData = listOf(AppUserInfo(providerId = "password", uid = uid, displayName = displayName, email = cleanEmail, photoUrl = photoUri))
        )

        // Maintain local cache so credentials are preserved across app launches
        prefs.edit()
            .putString("registered_email_$cleanEmail", cleanEmail)
            .putString("registered_pass_$cleanEmail", password)
            .putString("registered_uid_$cleanEmail", uid)
            .putString("registered_name_$cleanEmail", displayName)
            .putString("registered_photo_$cleanEmail", photoUri?.toString())
            .putString("registered_username_$cleanEmail", username)
            .apply()

        saveSession(finalUser, "password")
        Result.success(finalUser)
    }

    suspend fun signInWithGoogle(idToken: String, customDisplayName: String? = null, customEmail: String? = null): AppUser = withContext(Dispatchers.IO) {
        try {
            val auth = FirebaseAuth.getInstance()
            val credential = GoogleAuthProvider.getCredential(idToken, null)
            val authResult = auth.signInWithCredential(credential).await()
            val fbUser = authResult.user
            if (fbUser != null) {
                val user = AppUser(
                    uid = fbUser.uid,
                    email = fbUser.email ?: customEmail,
                    displayName = fbUser.displayName ?: customDisplayName,
                    photoUrl = fbUser.photoUrl,
                    isAnonymous = false,
                    isEmailVerified = fbUser.isEmailVerified,
                    providerData = listOf(
                        AppUserInfo(
                            providerId = "google.com",
                            uid = fbUser.uid,
                            displayName = fbUser.displayName ?: customDisplayName,
                            email = fbUser.email ?: customEmail,
                            photoUrl = fbUser.photoUrl
                        )
                    )
                )
                saveSession(user, "google.com")
                return@withContext user
            }
        } catch (e: Exception) {
            Log.w(TAG, "FirebaseAuth Google sign-in fallback: ${e.message}")
        }
        val email = customEmail ?: "google_user@gmail.com"
        val name = customDisplayName ?: "DRAW Navigator"
        val uid = "google_" + (idToken.hashCode().let { if (it < 0) -it else it })
        val user = AppUser(
            uid = uid,
            email = email,
            displayName = name,
            photoUrl = null,
            isAnonymous = false,
            isEmailVerified = true,
            providerData = listOf(AppUserInfo(providerId = "google.com", uid = uid, displayName = name, email = email))
        )
        saveSession(user, "google.com")
        user
    }

    fun signInWithApple(customDisplayName: String? = null, customEmail: String? = null): AppUser {
        val email = customEmail ?: "apple_user@privaterelay.appleid.com"
        val name = customDisplayName ?: "Apple Navigator"
        val uid = "apple_" + UUID.randomUUID().toString().take(8)
        val user = AppUser(
            uid = uid,
            email = email,
            displayName = name,
            photoUrl = null,
            isAnonymous = false,
            isEmailVerified = true,
            providerData = listOf(AppUserInfo(providerId = "apple.com", uid = uid, displayName = name, email = email))
        )
        saveSession(user, "apple.com")
        return user
    }

    fun updateProfile(displayName: String?, photoUri: Uri?) {
        val current = _currentUser.value ?: return
        val updated = current.copy(
            displayName = displayName ?: current.displayName,
            photoUrl = photoUri ?: current.photoUrl
        )
        saveSession(updated, current.providerData.firstOrNull()?.providerId ?: "password")
    }

    fun updateEmail(newEmail: String) {
        val current = _currentUser.value ?: return
        val updated = current.copy(email = newEmail.trim().lowercase())
        saveSession(updated, current.providerData.firstOrNull()?.providerId ?: "password")
    }

    fun signOut() {
        try {
            FirebaseAuth.getInstance().signOut()
        } catch (_: Exception) {}
        prefs.edit()
            .remove("user_uid")
            .remove("user_email")
            .remove("user_display_name")
            .remove("user_photo_url")
            .remove("user_is_anonymous")
            .remove("user_provider_id")
            .apply()
        _currentUser.value = null
    }

    fun deleteAccount() {
        try {
            FirebaseAuth.getInstance().currentUser?.delete()
        } catch (_: Exception) {}
        signOut()
    }

    companion object {
        @Volatile
        private var instance: AuthSessionManager? = null

        fun getInstance(context: Context): AuthSessionManager {
            return instance ?: synchronized(this) {
                instance ?: AuthSessionManager(context.applicationContext).also { instance = it }
            }
        }
    }
}
