package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.data.model.OsrmRoute
import com.example.data.network.OpenRouterService
import com.example.ui.map.navigation.NavigationVoiceSpeaker
import com.example.ui.map.navigation.RouteOption
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [34])
class ExampleRobolectricTest {

  @Test
  fun `read app name string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("DRAW", appName)
  }

  @Test
  fun `verify firestore database id resource exists`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val dbId = context.getString(R.string.firestore_database_id)
    assertEquals("ai-studio-android-apkextra-c85b4f52-c881-44eb-be8d-c98f19c6824a", dbId)
  }

  @Test
  fun `verify default web client id resource exists`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val webClientId = context.getString(R.string.default_web_client_id)
    assertTrue(webClientId.isNotBlank())
  }

  @Test
  fun `verify openrouter map and chat api keys`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val service = OpenRouterService(context)
    val mapKey = service.getMapApiKey()
    val chatKey = service.getChatApiKey()
    assertEquals("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", mapKey)
    assertEquals("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", chatKey)
    assertTrue(service.getConfig().isConnected)
  }

  @Test
  fun `verify four route options ordering and color assignment`() {
    val routes = listOf(
        OsrmRoute(distance = 15000.0, duration = 1800.0),
        OsrmRoute(distance = 8000.0, duration = 900.0),
        OsrmRoute(distance = 12000.0, duration = 1400.0),
        OsrmRoute(distance = 18000.0, duration = 2100.0)
    )
    val sorted = routes.sortedBy { it.distance }.take(4)
    val colorConfigs = listOf(
        Triple("#007AFF", "المسار الأزرق", "أقصر مسار"),
        Triple("#E50914", "المسار الأحمر", "ثاني أقصر مسار"),
        Triple("#FF9500", "المسار البرتقالي", "ثالث أقصر مسار"),
        Triple("#FFCC00", "المسار الأصفر", "رابع أقصر مسار")
    )
    val options = sorted.mapIndexed { idx, r ->
      val (hex, name, rank) = colorConfigs[idx]
      RouteOption(idx, hex, name, rank, r)
    }

    assertEquals(4, options.size)
    // 1st is Blue (shortest, 8km)
    assertEquals("#007AFF", options[0].colorHex)
    assertEquals("المسار الأزرق", options[0].colorNameArabic)
    assertEquals(8000.0, options[0].route.distance, 0.1)

    // 2nd is Red (second shortest, 12km)
    assertEquals("#E50914", options[1].colorHex)
    assertEquals("المسار الأحمر", options[1].colorNameArabic)
    assertEquals(12000.0, options[1].route.distance, 0.1)

    // 3rd is Orange (third shortest, 15km)
    assertEquals("#FF9500", options[2].colorHex)
    assertEquals("المسار البرتقالي", options[2].colorNameArabic)
    assertEquals(15000.0, options[2].route.distance, 0.1)

    // 4th is Yellow (fourth shortest, 18km)
    assertEquals("#FFCC00", options[3].colorHex)
    assertEquals("المسار الأصفر", options[3].colorNameArabic)
    assertEquals(18000.0, options[3].route.distance, 0.1)
  }

  @Test
  fun `verify draw symbol launcher foreground and background exist`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val symbolDrawable = context.getDrawable(R.drawable.draw_symbol)
    assertNotNull(symbolDrawable)
    val fgDrawable = context.getDrawable(R.drawable.ic_launcher_foreground)
    assertNotNull(fgDrawable)
    val bgDrawable = context.getDrawable(R.drawable.ic_launcher_background)
    assertNotNull(bgDrawable)
  }

  @Test
  fun `verify app destination logic`() {
    // 1. Initial destination is SPLASH
    var dest = AppDestination.SPLASH
    assertEquals(AppDestination.SPLASH, dest)

    // 2. If user is null after splash, routes to AUTH
    val hasUser = false
    dest = if (hasUser) AppDestination.MAP else AppDestination.AUTH
    assertEquals(AppDestination.AUTH, dest)

    // 3. When login succeeds, routes directly to MAP without returning to SPLASH
    val userLoggedIn = true
    if (userLoggedIn && dest == AppDestination.AUTH) {
      dest = AppDestination.MAP
    }
    assertEquals(AppDestination.MAP, dest)

    // 4. From MAP to SETTINGS and back
    dest = AppDestination.SETTINGS
    assertEquals(AppDestination.SETTINGS, dest)
    dest = AppDestination.MAP
    assertEquals(AppDestination.MAP, dest)

    // 5. On sign out, routes to AUTH
    dest = AppDestination.AUTH
    assertEquals(AppDestination.AUTH, dest)
  }

  @Test
  fun `verify guest cannot save favorite while registered user can`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val navRepo = com.example.data.repository.NavigationRepository(context)
    val testPlace = com.example.data.model.SavedPlace(
        title = "مكان تجريبي",
        address = "عنوان تجريبي",
        latitude = 21.42,
        longitude = 39.82,
        category = "favorite"
    )

    // Guest saving fails
    val guestResult = navRepo.saveFavorite("guest_abc123", testPlace)
    assertTrue(guestResult is com.example.data.repository.SaveFavoriteResult.Error)

    // Blank user saving fails
    val blankResult = navRepo.saveFavorite("", testPlace)
    assertTrue(blankResult is com.example.data.repository.SaveFavoriteResult.Error)

    // Registered user saving succeeds
    val registeredResult = navRepo.saveFavorite("user_registered_999", testPlace)
    assertTrue(registeredResult is com.example.data.repository.SaveFavoriteResult.Success)
  }

  @Test
  fun `verify guest cannot like place or comment while registered user can`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val interactionsRepo = com.example.data.repository.PlaceInteractionsRepository(context)
    val guestUser = com.example.data.model.AppUser(uid = "guest_xyz", isAnonymous = true)
    val regUser = com.example.data.model.AppUser(uid = "user_real_123", isAnonymous = false, displayName = "مستخدم مسجل")

    // Guest like place fails
    val guestLike = interactionsRepo.togglePlaceLike("place_1", "Place", "owner_1", guestUser)
    assertTrue(guestLike.isFailure)

    // Registered like place succeeds
    val regLike = interactionsRepo.togglePlaceLike("place_1", "Place", "owner_1", regUser)
    assertTrue(regLike.isSuccess)

    // Guest comment fails
    val guestComment = interactionsRepo.addComment("place_1", "Place", "owner_1", guestUser, "تعليق ضيف")
    assertTrue(guestComment.isFailure)

    // Registered comment succeeds
    val regComment = interactionsRepo.addComment("place_1", "Place", "owner_1", regUser, "تعليق مسجل")
    assertTrue(regComment.isSuccess)
  }

  @Test
  fun `verify guest cannot create public place while registered user can`() = kotlinx.coroutines.runBlocking {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val placesRepo = com.example.data.repository.PublicPlacesRepository(context)
    val guestPlace = com.example.data.model.PublicPlace(
        title = "مكان الضيف",
        description = "وصف مكان الضيف",
        creatorId = "guest_123"
    )
    val guestCreate = placesRepo.createPublicPlace(guestPlace)
    assertTrue(guestCreate.isFailure)

    val regPlace = com.example.data.model.PublicPlace(
        title = "مكان مسجل جديد",
        description = "وصف مكان مستخدم مسجل",
        creatorId = "user_real_456"
    )
    val regCreate = placesRepo.createPublicPlace(regPlace)
    assertTrue(regCreate.isSuccess)
  }
}
