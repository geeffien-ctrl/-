# DRAW Android App

مشروع تطبيق DRAW Android بصيغة Kotlin/Jetpack Compose، ومعه نسخة APK تجريبية داخل مجلد `artifacts`.

## فتح المشروع

افتح هذا المجلد بواسطة Android Studio وانتظر اكتمال Gradle Sync. قبل البناء، أضف ملف Firebase الخاص بمشروعك هنا:

```text
app/google-services.json
```

تم استبعاد ملفات Firebase الخاصة، مفاتيح التوقيع، وملفات البناء والكاش من هذه الحزمة لحماية البيانات الحساسة. لا ترفع مفاتيح التوقيع أو ملف Firebase الخاص إلى مستودع عام.

## بناء APK تجريبي

```bash
./gradlew assembleDebug
```

الملف الناتج سيظهر في `app/build/outputs/apk/debug/app-debug.apk`.
